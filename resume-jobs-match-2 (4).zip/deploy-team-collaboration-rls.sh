#!/bin/bash

# Team Collaboration RLS Deployment Script
# This script deploys the team collaboration RLS policies to Supabase

echo "🚀 Starting Team Collaboration RLS Deployment..."

# Check if Supabase CLI is installed
if ! command -v supabase &> /dev/null; then
    echo "❌ Supabase CLI not found. Install it first:"
    echo "   npm install -g supabase"
    exit 1
fi

# Check if logged in
echo "📋 Checking Supabase authentication..."
if ! supabase projects list &> /dev/null; then
    echo "❌ Not logged in to Supabase. Run:"
    echo "   supabase login"
    exit 1
fi

echo "✅ Supabase CLI ready"

# Deploy the migration
echo "📦 Deploying team collaboration RLS policies..."
supabase db push

if [ $? -eq 0 ]; then
    echo "✅ Team collaboration RLS policies deployed successfully!"
    echo ""
    echo "📊 Next steps:"
    echo "1. Verify deployment: supabase db diff"
    echo "2. Test policies with the examples in TEAM-COLLABORATION-RLS-GUIDE.md"
    echo "3. Check RLS status in Supabase Dashboard > Database > Policies"
else
    echo "❌ Deployment failed. Check the error messages above."
    exit 1
fi
