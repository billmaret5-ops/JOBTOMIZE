#!/bin/bash

# Test Fetch-Jobs Edge Function
# Run this after deploying the updated function

echo "🧪 Testing Fetch-Jobs Edge Function"
echo "===================================="
echo ""

FUNCTION_URL="https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs"

# Test 1: Health Check
echo "1️⃣ Testing Health Endpoint..."
curl -s "$FUNCTION_URL/health" | jq .
echo ""
echo ""

# Test 2: GET Search
echo "2️⃣ Testing GET Search..."
curl -s "$FUNCTION_URL/search?query=developer&location=remote" | jq '.jobs | length'
echo ""
echo ""

# Test 3: POST Search
echo "3️⃣ Testing POST Search..."
curl -s -X POST "$FUNCTION_URL" \
  -H "Content-Type: application/json" \
  -d '{"query":"engineer","location":"San Francisco"}' | jq '.jobs | length'
echo ""
echo ""

# Test 4: Check Logs
echo "4️⃣ Checking Recent Logs..."
echo "Run: supabase functions logs fetch-jobs --tail"
echo ""

echo "✅ Tests Complete!"
echo ""
echo "If all tests passed, your function is working!"
echo "If you see 401 errors, check the deployment guide."
