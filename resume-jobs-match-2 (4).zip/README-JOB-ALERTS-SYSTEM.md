# Automated Job Alert System

## Overview
The automated job alert system sends email notifications to users when new jobs matching their criteria are posted. Users can create custom search alerts with frequency preferences (instant/daily/weekly).

## Features

### 1. Job Alert Management
- **Create Alerts**: Set up custom job alerts with multiple filter criteria
- **Edit Alerts**: Modify existing alerts anytime
- **Toggle Active/Inactive**: Enable or disable alerts without deleting them
- **Delete Alerts**: Remove alerts you no longer need

### 2. Filter Criteria
Each alert supports the following filters:
- **Job Title**: Keywords to match in job titles
- **Location**: City, state, or country
- **Employment Type**: Full-time, Part-time, Contract, Internship
- **Experience Level**: Entry, Mid, Senior, Lead/Principal
- **Salary Range**: Minimum and maximum salary expectations
- **Frequency**: How often to receive notifications
  - Instant (Hourly)
  - Daily Digest
  - Weekly Digest

### 3. Email Notifications
- Beautiful HTML email templates
- Job details including title, company, location, salary
- Direct "Apply Now" links
- Unsubscribe/manage alerts link

## Database Schema

The `job_alerts` table includes:
```sql
- id: UUID (Primary Key)
- user_id: UUID (Foreign Key to auth.users)
- name: TEXT (Alert name)
- job_title: TEXT (Job title keywords)
- location: TEXT (Location filter)
- employment_type: TEXT (Employment type filter)
- min_salary: INTEGER (Minimum salary)
- max_salary: INTEGER (Maximum salary)
- experience_level: TEXT (Experience level filter)
- frequency: TEXT (instant/daily/weekly)
- is_active: BOOLEAN (Active status)
- last_sent_at: TIMESTAMP (Last notification sent)
- created_at: TIMESTAMP
- updated_at: TIMESTAMP
```

## Setup Instructions

### 1. Database Setup
The database table and RLS policies are already created via migration:
- `supabase/migrations/create_job_alerts_table.sql`
- `supabase/migrations/create_job_alerts_cron_schedule.sql`

### 2. Environment Variables
Add to your `.env` file:
```env
# RapidAPI Key for JSearch API
VITE_RAPIDAPI_KEY=your_rapidapi_key_here

# Resend API Key for email notifications
RESEND_API_KEY=your_resend_api_key_here
```

### 3. Deploy Edge Function
The edge function code is documented in `DEPLOY-JOB-ALERTS-FUNCTION.md`. Deploy it using:
```bash
supabase functions deploy job-alerts-processor --no-verify-jwt
```

Set the required secrets:
```bash
supabase secrets set RESEND_API_KEY=your_resend_api_key
supabase secrets set RAPIDAPI_KEY=your_rapidapi_key
```

### 4. Configure Cron Job
The cron job is automatically set up via migration to run every hour. It calls the `job-alerts-processor` edge function.

## Usage

### For Users

1. **Navigate to Job Alerts**: Go to `/job-alerts` in your application
2. **Create Alert**: Click "Create Alert" button
3. **Fill in Criteria**: 
   - Give your alert a descriptive name
   - Add job title keywords (e.g., "Software Engineer")
   - Specify location (e.g., "New York, NY")
   - Select employment type, experience level
   - Set salary range if desired
   - Choose notification frequency
4. **Save Alert**: Click "Save Alert"
5. **Manage Alerts**: Toggle active/inactive, edit, or delete alerts

### For Developers

#### Manual Trigger
You can manually trigger alert processing:
```typescript
import { jobAlertsProcessorService } from '@/services/jobAlertsProcessorService';

// Trigger processing
const result = await jobAlertsProcessorService.triggerProcessing();
console.log(result); // { processed: 5, sent: 3 }
```

#### Get Processing Stats
```typescript
const stats = await jobAlertsProcessorService.getProcessingStats();
```

## How It Works

1. **Cron Job**: Runs every hour via pg_cron
2. **Fetch Active Alerts**: Retrieves all active alerts from database
3. **Check Frequency**: Determines if alert should be processed based on:
   - Instant: Every hour
   - Daily: Every 24 hours
   - Weekly: Every 168 hours
4. **Search Jobs**: Queries JSearch API with alert criteria
5. **Filter New Jobs**: Only includes jobs posted since last notification
6. **Send Email**: If matches found, sends formatted HTML email via Resend
7. **Update Timestamp**: Records `last_sent_at` to prevent duplicates

## Email Template

The email includes:
- Personalized greeting
- Number of matching jobs
- Alert name
- Job cards with:
  - Job title
  - Company name
  - Location
  - Employment type
  - Salary (if available)
  - "Apply Now" button
- Manage alerts link

## Testing

### Test Alert Creation
1. Go to `/job-alerts`
2. Create a test alert with broad criteria
3. Set frequency to "instant"
4. Wait for hourly cron job or manually trigger

### Manual Testing
```bash
# Invoke edge function directly
supabase functions invoke job-alerts-processor

# Check logs
supabase functions logs job-alerts-processor
```

### Test Email Delivery
1. Create alert with your email
2. Ensure matching jobs exist
3. Trigger processing
4. Check your inbox

## Troubleshooting

### No Emails Received
- Check alert is active (`is_active = true`)
- Verify email address in user profile
- Check `last_sent_at` timestamp
- Review edge function logs
- Confirm Resend API key is valid

### No Jobs Found
- Broaden search criteria
- Check JSearch API quota
- Verify RapidAPI key is valid
- Test API directly

### Cron Job Not Running
- Check pg_cron extension is enabled
- Verify cron schedule in database
- Check Supabase logs

## API Integration

The system integrates with:
- **JSearch API** (via RapidAPI): Real-time job search
- **Resend API**: Email delivery service

## Security

- Row Level Security (RLS) enabled
- Users can only view/edit their own alerts
- Service role key used for cron job
- Email addresses protected
- API keys stored as secrets

## Future Enhancements

- [ ] SMS notifications
- [ ] Push notifications
- [ ] Advanced filters (skills, company size)
- [ ] Job recommendations based on profile
- [ ] Alert performance analytics
- [ ] A/B testing for email templates
- [ ] Multi-language support
- [ ] Slack/Discord integrations

## Support

For issues or questions:
1. Check edge function logs
2. Review database RLS policies
3. Verify API keys and secrets
4. Test with manual trigger first
