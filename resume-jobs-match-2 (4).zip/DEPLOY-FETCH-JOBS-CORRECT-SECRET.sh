#!/bin/bash

echo "🔧 FIXING RAPIDAPI KEY AND DEPLOYING FETCH-JOBS"
echo "================================================"
echo ""

echo "Step 1: Check current secrets..."
supabase secrets list
echo ""

echo "Step 2: Setting CORRECT secret name (RAPIDAPI_KEY)..."
echo "⚠️  PASTE YOUR RAPIDAPI KEY WHEN PROMPTED"
echo ""
read -p "Enter your RapidAPI key: " RAPIDAPI_KEY

if [ -z "$RAPIDAPI_KEY" ]; then
  echo "❌ No key provided. Exiting."
  exit 1
fi

supabase secrets set RAPIDAPI_KEY="$RAPIDAPI_KEY"
echo "✅ Secret set!"
echo ""

echo "Step 3: Creating function directory..."
mkdir -p supabase/functions/fetch-jobs
echo "✅ Directory ready"
echo ""

echo "Step 4: Creating function code..."
cat > supabase/functions/fetch-jobs/index.ts << 'EOF'
const allowedOrigins = new Set([
  'https://jobtomize.com',
  'https://www.jobtomize.com',
  'http://localhost:3000',
  'http://localhost:5173'
]);

function getOrigin(req: Request): string {
  const origin = req.headers.get('Origin') || '';
  return allowedOrigins.has(origin) ? origin : 'https://jobtomize.com';
}

const corsHeaders = {
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

Deno.serve(async (req) => {
  const origin = getOrigin(req);
  
  if (req.method === 'OPTIONS') {
    return new Response('ok', { 
      headers: { ...corsHeaders, 'Access-Control-Allow-Origin': origin }
    });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;
  const jsonHeaders = {
    ...corsHeaders,
    'Access-Control-Allow-Origin': origin,
    'Content-Type': 'application/json'
  };

  if (pathname.includes('/health')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    return new Response(JSON.stringify({
      ok: true,
      rapidapi_key_present: !!rapidApiKey,
      timestamp: new Date().toISOString()
    }), { headers: jsonHeaders });
  }

  try {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      return new Response(JSON.stringify({
        error: 'RAPIDAPI_KEY not configured'
      }), { status: 500, headers: jsonHeaders });
    }

    let query = 'software engineer';
    let location = '';
    let page = 1;

    if (pathname.includes('/search') && req.method === 'GET') {
      query = url.searchParams.get('query') || query;
      location = url.searchParams.get('location') || '';
      page = parseInt(url.searchParams.get('page') || '1');
    } else if (req.method === 'POST') {
      const body = await req.json();
      query = body.query || query;
      location = body.location || '';
      page = body.page || 1;
    }

    let searchQuery = query;
    if (location) searchQuery += ` in ${location}`;

    const apiUrl = `https://jsearch.p.rapidapi.com/search?query=${encodeURIComponent(searchQuery)}&page=${page}`;
    
    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      return new Response(JSON.stringify({
        error: 'RapidAPI failed',
        status: response.status,
        details: errorText
      }), { status: response.status, headers: jsonHeaders });
    }

    const data = await response.json();
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: `${job.job_city}, ${job.job_state}`,
      description: job.job_description,
      salary: job.job_salary,
      type: job.job_employment_type,
      posted_date: job.job_posted_at_datetime_utc,
      apply_url: job.job_apply_link,
      source: 'jsearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote
    }));

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page
    }), { headers: jsonHeaders });

  } catch (error) {
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), { status: 500, headers: jsonHeaders });
  }
});
EOF

echo "✅ Function code created"
echo ""

echo "Step 5: Deploying function..."
supabase functions deploy fetch-jobs
echo ""

echo "Step 6: Testing health endpoint..."
SUPABASE_URL=$(grep VITE_SUPABASE_URL .env 2>/dev/null | cut -d '=' -f2 | tr -d '"' | tr -d "'")
if [ -z "$SUPABASE_URL" ]; then
  echo "⚠️  Could not find SUPABASE_URL in .env"
  echo "Test manually: curl YOUR_URL/functions/v1/fetch-jobs/health"
else
  curl "${SUPABASE_URL}/functions/v1/fetch-jobs/health"
  echo ""
fi

echo ""
echo "✅ DEPLOYMENT COMPLETE!"
echo ""
echo "📝 Next steps:"
echo "1. Test: curl YOUR_URL/functions/v1/fetch-jobs/health"
echo "2. Should show: rapidapi_key_present: true"
echo "3. Test search from jobtomize.com"
echo ""
