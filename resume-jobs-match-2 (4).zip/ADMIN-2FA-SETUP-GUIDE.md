# Admin Two-Factor Authentication (2FA) Setup Guide

## Overview
All admin accounts on Jobtomize.com now require mandatory two-factor authentication (2FA) using TOTP (Time-based One-Time Password) for enhanced security. This meets enterprise security standards and protects sensitive admin functions.

## Features

### 🔐 Security Features
- **Mandatory 2FA**: All admin accounts must enable 2FA before accessing the admin dashboard
- **TOTP Support**: Compatible with Google Authenticator, Authy, Microsoft Authenticator, and other TOTP apps
- **Backup Codes**: 10 single-use backup recovery codes for emergency access
- **Audit Logging**: All 2FA events are logged for security monitoring
- **Session Management**: 2FA verification required for each login session

### 📱 Supported Authenticator Apps
- Google Authenticator (iOS/Android)
- Authy (iOS/Android/Desktop)
- Microsoft Authenticator (iOS/Android)
- 1Password
- LastPass Authenticator
- Any TOTP-compatible app

## Setup Process

### Step 1: Initial Admin Login
1. Navigate to `/admin-login`
2. Enter your admin email and password
3. Click "Sign In as Admin"

### Step 2: 2FA Setup (First Time Only)
After successful password authentication:

1. **QR Code Scan**
   - Open your authenticator app
   - Scan the QR code displayed on screen
   - Or manually enter the secret key shown

2. **Verification**
   - Enter the 6-digit code from your authenticator app
   - Click "Verify and Enable 2FA"

3. **Backup Codes**
   - **IMPORTANT**: Save your 10 backup codes immediately
   - Download them as a text file
   - Or copy them to a secure location
   - Store them safely - you'll need them if you lose your phone

4. **Complete Setup**
   - Click "Complete Setup" to access the admin dashboard

### Step 3: Subsequent Logins
For all future logins:

1. Enter email and password
2. Enter 6-digit code from authenticator app
3. Access granted to admin dashboard

## Using Backup Codes

### When to Use
- Lost or broken phone
- Authenticator app not working
- New phone without authenticator setup

### How to Use
1. On the 2FA verification screen, click "Use Backup Code"
2. Enter one of your 8-digit backup codes
3. Each code can only be used once
4. Regenerate new codes after using several

### Regenerating Backup Codes
1. Go to Admin Dashboard → Settings → Two-Factor Authentication
2. Click "Regenerate Backup Codes"
3. Download and save the new codes
4. Old codes will be invalidated

## Security Best Practices

### ✅ DO
- Store backup codes in a secure password manager
- Use a reputable authenticator app
- Keep your authenticator app updated
- Regenerate backup codes if you suspect compromise
- Log out when not using the admin panel

### ❌ DON'T
- Share your secret key or QR code
- Store backup codes in plain text on your computer
- Use the same authenticator for personal and admin accounts
- Take screenshots of QR codes or backup codes
- Disable 2FA (it's mandatory for admins)

## Troubleshooting

### "Invalid Code" Error
- Ensure your device time is synchronized (TOTP requires accurate time)
- Try the next code that appears in your authenticator
- Wait for a new code to generate
- Check you're using the correct account in your authenticator

### Lost Access to Authenticator
1. Use a backup code to log in
2. Immediately set up 2FA with a new device
3. Generate new backup codes
4. Contact system administrator if all backup codes are used

### Time Sync Issues
- Go to your authenticator app settings
- Enable "Time Correction for Codes" or similar option
- Sync time with internet time servers

## Database Schema

### Tables Created
```sql
-- Main 2FA table
admin_two_factor_auth
- id (UUID)
- user_id (UUID, references auth.users)
- secret (TEXT, encrypted TOTP secret)
- enabled (BOOLEAN)
- backup_codes (TEXT[], hashed backup codes)
- created_at, updated_at, last_used_at

-- Audit log
admin_2fa_audit_log
- id (UUID)
- user_id (UUID)
- action (TEXT: setup, verify_success, verify_failed, backup_used)
- ip_address (TEXT)
- user_agent (TEXT)
- success (BOOLEAN)
- created_at (TIMESTAMPTZ)
```

## Edge Functions

### admin-two-factor-manager
Handles all 2FA operations:
- `generate`: Create new TOTP secret and backup codes
- `verify`: Verify TOTP code during setup/login
- `verifyBackup`: Verify and consume backup code
- `regenerateBackup`: Generate new backup codes

## Admin Dashboard Integration

The 2FA panel is available in:
- Admin Dashboard → Settings → Two-Factor Authentication
- Shows current status
- Displays remaining backup codes count
- Allows backup code regeneration
- Shows security alerts

## Compliance & Standards

This implementation meets:
- ✅ NIST SP 800-63B guidelines for multi-factor authentication
- ✅ SOC 2 Type II requirements
- ✅ ISO 27001 access control standards
- ✅ PCI DSS multi-factor authentication requirements
- ✅ GDPR security measures for admin access

## Support

### For Admins
- Check authenticator app time sync
- Use backup codes for emergency access
- Contact system administrator for account recovery

### For System Administrators
- Monitor audit logs for suspicious activity
- Review failed login attempts
- Assist with account recovery when all backup codes are exhausted
- Enforce 2FA policy for all admin accounts

## Recovery Process

If an admin loses both authenticator access and backup codes:

1. Identity verification required (in-person or video call)
2. System administrator can reset 2FA for the account
3. Admin must set up 2FA again immediately
4. Incident is logged in audit trail

---

**Security Notice**: Two-factor authentication is mandatory for all admin accounts and cannot be disabled. This ensures the highest level of security for the Jobtomize platform and protects sensitive user data.
