// Updated fetch-jobs Edge Function Code
// Copy this to: supabase/functions/fetch-jobs/index.ts

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;

  // Health check endpoint - verifies secrets are configured
  if (pathname.includes('/health')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST');
    
    console.info('Health check - RAPIDAPI_KEY present:', !!rapidApiKey);
    console.info('Health check - RAPIDAPI_HOST present:', !!rapidApiHost);
    
    return new Response(JSON.stringify({
      ok: true,
      rapidapi_key_present: !!rapidApiKey,
      rapidapi_host_present: !!rapidApiHost,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  // Diagnostics endpoint - tests actual RapidAPI connectivity
  if (pathname.includes('/diagnostics')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';
    const query = url.searchParams.get('query') || 'test';
    
    console.info('Diagnostics - RAPIDAPI_KEY present:', !!rapidApiKey);
    console.info('Diagnostics - RAPIDAPI_HOST:', rapidApiHost);
    
    if (!rapidApiKey) {
      return new Response(JSON.stringify({
        error: 'RAPIDAPI_KEY not configured',
        rapidapi_key_present: false,
        rapidapi_host_present: !!rapidApiHost,
        instructions: 'Run: supabase secrets set RAPIDAPI_KEY=your_key_here'
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    try {
      const testUrl = `https://${rapidApiHost}/search?query=${encodeURIComponent(query)}&page=1&num_pages=1`;
      console.info('Testing RapidAPI with URL:', testUrl);
      
      const response = await fetch(testUrl, {
        headers: {
          'X-RapidAPI-Key': rapidApiKey,
          'X-RapidAPI-Host': rapidApiHost
        }
      });

      const rateLimitRemaining = response.headers.get('x-ratelimit-requests-remaining');
      const rateLimitLimit = response.headers.get('x-ratelimit-requests-limit');
      
      console.info('RapidAPI response status:', response.status);
      console.info('Rate limit remaining:', rateLimitRemaining);

      return new Response(JSON.stringify({
        upstream_ok: response.ok,
        status: response.status,
        rate_limit_remaining: rateLimitRemaining ? parseInt(rateLimitRemaining) : null,
        rate_limit_total: rateLimitLimit ? parseInt(rateLimitLimit) : null,
        rapidapi_key_present: true,
        rapidapi_host: rapidApiHost,
        timestamp: new Date().toISOString()
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    } catch (error) {
      console.error('Diagnostics error:', error);
      return new Response(JSON.stringify({
        error: 'Diagnostics test failed',
        details: error.message,
        rapidapi_key_present: true,
        rapidapi_host: rapidApiHost
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
  }

  // Main job search endpoint
  try {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';
    
    console.info('RAPIDAPI_KEY present:', !!rapidApiKey);
    console.info('Using RapidAPI host:', rapidApiHost);

    if (!rapidApiKey) {
      return new Response(JSON.stringify({
        error: 'RAPIDAPI_KEY not configured',
        instructions: 'Run: supabase secrets set RAPIDAPI_KEY=your_key_here'
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20
    } = await req.json();

    // Build RapidAPI query
    let searchQuery = query;
    if (location) {
      searchQuery += ` in ${location}`;
    }

    const apiUrl = `https://${rapidApiHost}/search?query=${encodeURIComponent(searchQuery)}&page=${page}&num_pages=1`;
    
    console.info('Fetching from RapidAPI');

    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': rapidApiHost
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('RapidAPI error:', response.status, errorText);
      return new Response(JSON.stringify({
        error: 'Failed to fetch jobs from RapidAPI',
        status: response.status,
        details: errorText
      }), {
        status: response.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    const jobs = data.data || [];

    // Transform RapidAPI response to our format
    const transformedJobs: JobListing[] = jobs.map((job: any) => ({
      id: job.job_id || `job_${Date.now()}_${Math.random()}`,
      title: job.job_title || 'Untitled Position',
      company: job.employer_name || 'Unknown Company',
      location: job.job_city && job.job_state ? `${job.job_city}, ${job.job_state}` : job.job_country || 'Location not specified',
      description: job.job_description || 'No description available',
      salary: job.job_min_salary && job.job_max_salary ? `$${job.job_min_salary} - $${job.job_max_salary}` : job.job_salary || undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'jsearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false,
      experience_level: job.job_experience_in_place_of_education ? 'Senior' : 'Mid'
    }));

    return new Response(JSON.stringify({
      jobs: transformedJobs,
      total: data.total || transformedJobs.length,
      page,
      totalPages: Math.ceil((data.total || transformedJobs.length) / limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
