# Deploy Jobtomize.com to Famous.ai Hosting

## ✅ Your App is Ready!

All functionality is built and configured:
- ✅ Supabase backend connected
- ✅ Authentication system working
- ✅ Job search with AI matching
- ✅ Resume builder & optimizer
- ✅ Application tracking
- ✅ Interview preparation
- ✅ Email campaigns
- ✅ All features functional

## 🚀 Deploy to Famous.ai (3 Steps)

### Step 1: Build Your App
```bash
npm install
npm run build
```

This creates a `dist/` folder with all your files.

### Step 2: Upload to Famous.ai

Contact Famous.ai support for:
1. **FTP/SFTP credentials** (host, username, password)
2. **Upload location** (usually `public_html` or `www`)

Then upload the entire `dist/` folder contents to their server.

### Step 3: Configure Domain

In Famous.ai control panel:
1. Point `jobtomize.com` to your hosting account
2. Set up SSL certificate (usually automatic)
3. Configure environment variables (if supported)

## 🔧 Environment Variables

Your app needs these (already configured with fallbacks):
```
VITE_SUPABASE_URL=https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGci...
```

**Note:** Your app has these hardcoded as fallbacks, so it will work even without env vars!

## 🌐 DNS Configuration

If you manage DNS separately:
```
Type: A Record
Host: @
Value: [Famous.ai IP address]

Type: CNAME
Host: www
Value: jobtomize.com
```

## ✅ Verify Deployment

After upload, visit:
- https://jobtomize.com
- Test sign up/login
- Test job search
- Test all features

## 🆘 Troubleshooting

**404 Errors on Routes?**
Add this `.htaccess` file to your upload:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteRule . /index.html [L]
</IfModule>
```

**Need Help?**
Contact Famous.ai support with:
- "I need to deploy a React SPA"
- "I need SPA routing support"
- "I need SSL for jobtomize.com"
