# Deploy Working fetch-jobs Function

## Problem
The current fetch-jobs function uses mock data instead of real RapidAPI integration.

## Solution
Deploy the working RapidAPI code below.

## Step 1: Verify RAPIDAPI_KEY Secret

```bash
# Check if secret exists
supabase secrets list

# If not set, add it:
supabase secrets set RAPIDAPI_KEY=your_actual_rapidapi_key_here
```

## Step 2: Deploy the Function

Save this code to `supabase/functions/fetch-jobs/index.ts`:

```typescript
// Complete working code - see below
```

Then deploy:

```bash
supabase functions deploy fetch-jobs
```

## Step 3: Test the Function

```bash
# Test with curl
curl -X POST https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs \
  -H "Content-Type: application/json" \
  -d '{"query":"software engineer","location":"San Francisco"}'
```

## The Working Code

The complete working fetch-jobs code is in: `supabase/functions/fetch-jobs/index.ts`

Key changes from mock version:
- Uses real RapidAPI JSearch endpoint
- Reads RAPIDAPI_KEY from environment
- Normalizes job data from JSearch format
- Handles both GET and POST requests
- Proper error handling and CORS
