# 🚀 DEPLOY REAL JSEARCH API - IMMEDIATE ACTION REQUIRED

## ⚠️ YOUR SITE IS CURRENTLY SHOWING MOCK DATA

The fetch-jobs function is generating fake jobs. Follow these steps to get REAL jobs from JSearch API.

## 📋 Step-by-Step Deployment

### Step 1: Go to Supabase Dashboard
1. Open https://supabase.com/dashboard
2. Select your **Jobtomize** project
3. Click **Edge Functions** in left sidebar
4. Find and click **fetch-jobs** function

### Step 2: Replace the Code
1. Click **Edit function** or **Code** tab
2. **DELETE ALL existing code**
3. **PASTE the code below** (entire block)
4. Click **Deploy** button

### Step 3: Verify RAPIDAPI_KEY Secret
1. Go to **Project Settings** → **Edge Functions** → **Secrets**
2. Confirm **RAPIDAPI_KEY** exists and has your RapidAPI key
3. If missing, add it with your RapidAPI key from https://rapidapi.com

---

## 📝 COMPLETE FUNCTION CODE (Copy Everything Below)

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface NormalizedJob {
  id: string;
  title: string | null;
  company: string | null;
  location: string | null;
  via: string | null;
  url: string | null;
  type: string | null;
  published_at: string | null;
  salary: string | null;
  remote: boolean | null;
  description?: string | null;
}

const RAPIDAPI_HOST = 'jsearch.p.rapidapi.com';

function normalizeJobs(payload: any): NormalizedJob[] {
  const results: any[] = payload?.data || [];
  return results.map((item) => {
    const id = String(item.job_id ?? crypto.randomUUID());
    const title = item.job_title ?? null;
    const company = item.employer_name ?? null;
    const location = [item.job_city, item.job_state, item.job_country]
      .filter(Boolean).join(', ') || item.job_location || null;
    const via = item.job_publisher ?? null;
    const url = item.job_apply_link ?? null;
    const type = item.job_employment_type ?? null;
    const published_at = item.job_posted_at_datetime_utc ?? null;
    const salary = item.job_min_salary && item.job_max_salary
      ? `$${item.job_min_salary}-$${item.job_max_salary} ${item.job_salary_currency || 'USD'}`.trim()
      : null;
    const remote = item.job_is_remote ?? false;
    const description = item.job_description ?? null;

    return { id, title, company, location, via, url, type, published_at, salary, remote, description };
  });
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const apiKey = Deno.env.get('RAPIDAPI_KEY');
    if (!apiKey) {
      return new Response(JSON.stringify({ 
        error: 'RAPIDAPI_KEY not configured'
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const body = await req.json();
    const query = body.query?.trim() || 'software engineer';
    const location = body.location?.trim() || '';
    const remote = body.remote;
    const page = body.page || 1;

    const searchParams = new URLSearchParams();
    searchParams.set('query', query);
    if (location) searchParams.set('location', location);
    if (typeof remote === 'boolean') searchParams.set('remote_jobs_only', String(remote));
    searchParams.set('page', String(page));

    const url = `https://${RAPIDAPI_HOST}/search?${searchParams.toString()}`;

    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': RAPIDAPI_HOST
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      return new Response(JSON.stringify({
        error: 'RapidAPI request failed',
        status: response.status,
        details: errorText
      }), {
        status: response.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();
    const jobs = normalizeJobs(data);

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      query,
      location
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

---

## ✅ After Deployment - Test It

1. Go to https://jobtomize.com/?test-connection
2. Click **Test Jobs API** button
3. Should show "✅ Real JSearch API" (not mock data)
4. Check sample jobs - should have real company names

## 🔍 Check Logs (if issues)
1. Supabase Dashboard → Edge Functions → fetch-jobs
2. Click **Logs** tab
3. Look for errors about RAPIDAPI_KEY or API responses

## 📊 What Changed
- ❌ Before: Generated fake jobs with "TechCorp", "StartupXYZ"
- ✅ After: Real jobs from Indeed, LinkedIn, Glassdoor via JSearch API
- Uses your RAPIDAPI_KEY secret for authentication
- Normalizes JSearch response to match your frontend interface

## 🆘 Troubleshooting

### "RAPIDAPI_KEY not configured"
- Add secret: Project Settings → Edge Functions → Secrets → Add RAPIDAPI_KEY

### "RapidAPI request failed"
- Check your RapidAPI subscription is active
- Verify key is correct at https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch

### Still seeing mock data after deploy
- Hard refresh: Ctrl+Shift+R (Windows) or Cmd+Shift+R (Mac)
- Clear browser cache
- Wait 30 seconds for function to fully deploy
