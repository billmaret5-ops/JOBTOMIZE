# Deploy Edge Function - Complete Guide

## What You're Deploying

You're deploying a **Supabase Edge Function** called `user-auth-manager`. 

**What it is:**
- A serverless API endpoint hosted on Supabase
- Handles user authentication operations securely
- Uses the service_role key (auto-injected by Supabase)

**Where it lives:**
- Your code: `supabase/functions/user-auth-manager/index.ts` ✅ (already exists!)
- After deploy: `https://YOUR_PROJECT.supabase.co/functions/v1/user-auth-manager`

---

## Step-by-Step Deployment

### 1. Open Terminal in Your Project Root

Open your terminal/command prompt and navigate to your project folder:

```bash
cd /path/to/your/project
```

**Verify you're in the right place:**
```bash
ls
```

You should see folders like: `src/`, `supabase/`, `package.json`

---

### 2. Login to Supabase CLI

```bash
supabase login
```

This will open a browser for authentication.

---

### 3. Link Your Project

```bash
supabase link --project-ref YOUR_PROJECT_REF
```

**Find your project ref:**
- Go to https://supabase.com/dashboard
- Click your project
- Look at the URL: `https://supabase.com/dashboard/project/YOUR_PROJECT_REF`
- Or find it in Settings → General → Reference ID

---

### 4. Deploy the Function

```bash
supabase functions deploy user-auth-manager
```

**What happens:**
- Uploads your function code to Supabase
- Makes it available at: `https://YOUR_PROJECT.supabase.co/functions/v1/user-auth-manager`
- Auto-injects `SUPABASE_SERVICE_ROLE_KEY` (no manual setup needed!)

---

### 5. Test the Function (Optional)

```bash
supabase functions invoke user-auth-manager --no-verify-jwt --data '{"action":"get_user_sessions","data":{"user_id":"test"}}'
```

**Expected response:**
- Success: JSON response with sessions or error message
- Error: Paste the error here and we'll fix it!

---

## Common Issues

### "supabase: command not found"
Install the CLI:
```bash
npm install -g supabase
```

### "Project not linked"
Run:
```bash
supabase link --project-ref YOUR_PROJECT_REF
```

### "Authentication required"
Run:
```bash
supabase login
```

---

## What Happens After Deploy?

Your function is now live! You can call it from your frontend:

```typescript
const response = await fetch(
  `https://YOUR_PROJECT.supabase.co/functions/v1/user-auth-manager`,
  {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${supabaseAnonKey}`
    },
    body: JSON.stringify({
      action: 'create_user',
      data: { email, password, full_name, user_type }
    })
  }
)
```

---

## Quick Reference

| Command | Purpose |
|---------|---------|
| `supabase login` | Authenticate with Supabase |
| `supabase link --project-ref XXX` | Connect to your project |
| `supabase functions deploy user-auth-manager` | Deploy the function |
| `supabase functions invoke user-auth-manager --data '{}'` | Test the function |
| `supabase functions list` | See all deployed functions |

---

## Need Help?

Paste any error messages you get and I'll help fix them immediately! 🚀
