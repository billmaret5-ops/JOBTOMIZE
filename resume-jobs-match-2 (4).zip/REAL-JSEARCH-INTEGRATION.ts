// COPY THIS CODE TO: supabase/functions/fetch-jobs/index.ts
// This replaces the mock data with REAL JSearch API calls

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JSearchJob {
  job_id: string;
  employer_name: string;
  job_title: string;
  job_description: string;
  job_city?: string;
  job_state?: string;
  job_country?: string;
  job_apply_link: string;
  job_employment_type?: string;
  job_posted_at_datetime_utc?: string;
  job_salary_currency?: string;
  job_min_salary?: number;
  job_max_salary?: number;
  job_is_remote?: boolean;
  job_required_skills?: string[];
  employer_company_type?: string;
}

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

const transformJob = (job: JSearchJob): JobListing => {
  const location = [job.job_city, job.job_state, job.job_country]
    .filter(Boolean).join(', ') || 'Not specified';
  
  let salary = undefined;
  if (job.job_min_salary && job.job_max_salary) {
    const curr = job.job_salary_currency || 'USD';
    salary = `${curr} ${job.job_min_salary.toLocaleString()} - ${job.job_max_salary.toLocaleString()}`;
  }

  return {
    id: job.job_id,
    title: job.job_title,
    company: job.employer_name,
    location,
    description: job.job_description || 'No description',
    salary,
    type: job.job_employment_type || 'Full-time',
    posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
    apply_url: job.job_apply_link,
    source: 'JSearch',
    skills: job.job_required_skills || [],
    company_size: job.employer_company_type,
    remote: job.job_is_remote || false,
    experience_level: undefined
  };
};

Deno.serve(async (req) => {
  console.log('=== FETCH-JOBS REQUEST ===');
  console.log('Method:', req.method, 'URL:', req.url);
  
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  
  if (url.pathname.includes('/health')) {
    return new Response(JSON.stringify({ 
      status: 'healthy',
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    // Check for BOTH secret names since your secret is named "Jsearch"
    const apiKey = Deno.env.get('Jsearch') || Deno.env.get('RAPIDAPI_KEY');
    if (!apiKey) {
      throw new Error('API key not configured (Jsearch or RAPIDAPI_KEY)');
    }

    let query = 'software engineer';
    let location = '';
    let remote = undefined;
    let page = 1;

    if (req.method === 'GET') {
      query = url.searchParams.get('query') || query;
      location = url.searchParams.get('location') || location;
      const remoteParam = url.searchParams.get('remote');
      remote = remoteParam ? remoteParam === 'true' : undefined;
      page = parseInt(url.searchParams.get('page') || '1');
    } else if (req.method === 'POST') {
      const body = await req.json();
      query = body.query || query;
      location = body.location || location;
      remote = body.remote;
      page = body.page || page;
    }

    console.log('Calling JSearch API:', { query, location, remote, page });

    const jsearchUrl = new URL('https://jsearch.p.rapidapi.com/search');
    jsearchUrl.searchParams.set('query', query);
    if (location) jsearchUrl.searchParams.set('location', location);
    if (remote !== undefined) jsearchUrl.searchParams.set('remote_jobs_only', String(remote));
    jsearchUrl.searchParams.set('page', String(page));
    jsearchUrl.searchParams.set('num_pages', '1');

    const response = await fetch(jsearchUrl.toString(), {
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch API error:', response.status, errorText);
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    console.log('JSearch response:', data.data?.length || 0, 'jobs');
    
    const jobs: JobListing[] = (data.data || []).map(transformJob);

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      totalPages: 1
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
