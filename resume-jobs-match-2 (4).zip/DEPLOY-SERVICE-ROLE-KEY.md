# 🔑 Deploy Service Role Key to Supabase Edge Function

## ✅ WHAT WE FIXED
The Edge Function `user-auth-manager` now has a `create_user` action that uses `auth.admin.createUser()` with the service_role key.

## 🚀 DEPLOYMENT STEPS

### 1. Add Service Role Key to Supabase Secrets
```bash
# Navigate to your Supabase project
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=sb_secret_FgXdNUI0-o1p-Wr5FfEzgA_8s4pe8I5
```

### 2. Deploy the Edge Function
```bash
# Deploy the updated user-auth-manager function
supabase functions deploy user-auth-manager
```

### 3. Verify Deployment
```bash
# Check function logs
supabase functions logs user-auth-manager
```

## 🧪 TEST THE FUNCTION

### Using the AuthFlowTester Component
1. Go to `/` in your app
2. Scroll to "Auth Flow Tester" section
3. Fill in test credentials
4. Click "Test Signup Flow"
5. Should see success message with user ID

### Using curl
```bash
curl -X POST https://YOUR_PROJECT_REF.supabase.co/functions/v1/user-auth-manager \
  -H "Content-Type: application/json" \
  -d '{
    "action": "create_user",
    "data": {
      "email": "test@example.com",
      "password": "Test123456!",
      "full_name": "Test User",
      "user_type": "job_seeker"
    }
  }'
```

## 📝 WHAT THE FUNCTION DOES
1. Uses service_role key (auto-injected by Supabase)
2. Calls `auth.admin.createUser()` to create user
3. Sets `email_confirm: true` to skip email verification
4. Creates profile in `profiles` table
5. Returns user object

## 🔐 SECURITY NOTES
- Service role key is NEVER exposed to frontend
- Only Edge Function has access to it
- Frontend calls Edge Function via anon key
- Edge Function uses service_role internally
