#!/bin/bash

# Automated Deployment Script for Job Search Platform
# Usage: ./deploy.sh [vercel|netlify]

set -e

echo "🚀 Job Search Platform - Automated Deployment"
echo "=============================================="

# Check if deployment platform is specified
PLATFORM=${1:-vercel}

echo "📦 Installing dependencies..."
npm install

echo "🔨 Building application..."
npm run build

if [ "$PLATFORM" = "vercel" ]; then
    echo "🌐 Deploying to Vercel..."
    
    # Check if vercel CLI is installed
    if ! command -v vercel &> /dev/null; then
        echo "Installing Vercel CLI..."
        npm i -g vercel
    fi
    
    # Deploy to Vercel
    vercel --prod
    
    echo "✅ Deployed to Vercel!"
    echo "⚠️  Don't forget to set environment variables in Vercel Dashboard:"
    echo "   - VITE_SUPABASE_URL"
    echo "   - VITE_SUPABASE_ANON_KEY"
    echo "   - VITE_OPENAI_API_KEY"
    echo "   - VITE_STRIPE_PUBLIC_KEY (optional)"

elif [ "$PLATFORM" = "netlify" ]; then
    echo "🌐 Deploying to Netlify..."
    
    # Check if netlify CLI is installed
    if ! command -v netlify &> /dev/null; then
        echo "Installing Netlify CLI..."
        npm i -g netlify-cli
    fi
    
    # Deploy to Netlify
    netlify deploy --prod
    
    echo "✅ Deployed to Netlify!"
    echo "⚠️  Don't forget to set environment variables in Netlify Dashboard"

else
    echo "❌ Unknown platform: $PLATFORM"
    echo "Usage: ./deploy.sh [vercel|netlify]"
    exit 1
fi

echo ""
echo "📋 Next Steps:"
echo "1. Set environment variables in your platform dashboard"
echo "2. Run Supabase migrations (see DEPLOYMENT.md)"
echo "3. Enable Realtime on Supabase tables"
echo "4. Deploy Supabase Edge Functions"
echo ""
echo "📖 Full deployment guide: See DEPLOYMENT.md"
