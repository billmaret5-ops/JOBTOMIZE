# Deploy Calendar Sync Edge Function

## Edge Function Code

Create `supabase/functions/calendar-sync/index.ts`:

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, provider, authCode, interview, providerId } = await req.json();
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_ANON_KEY') ?? ''
    );

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user } } = await supabaseClient.auth.getUser(token);
    if (!user) throw new Error('Unauthorized');

    if (action === 'connect') {
      let tokenResponse;
      if (provider === 'google') {
        tokenResponse = await fetch('https://oauth2.googleapis.com/token', {
          method: 'POST',
          body: JSON.stringify({
            code: authCode,
            client_id: Deno.env.get('GOOGLE_CLIENT_ID'),
            client_secret: Deno.env.get('GOOGLE_CLIENT_SECRET'),
            redirect_uri: `${Deno.env.get('APP_URL')}/oauth/callback`,
            grant_type: 'authorization_code'
          })
        });
      }
      const tokens = await tokenResponse?.json();
      const { data } = await supabaseClient.from('calendar_integrations').insert({
        user_id: user.id, provider, access_token: tokens.access_token,
        refresh_token: tokens.refresh_token
      }).select().single();
      return new Response(JSON.stringify({ success: true, data }), { headers: corsHeaders });
    }

    if (action === 'sync') {
      const { data: integration } = await supabaseClient
        .from('calendar_integrations').select('*').eq('id', providerId).single();
      
      const eventResponse = await fetch('https://www.googleapis.com/calendar/v3/calendars/primary/events', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${integration.access_token}` },
        body: JSON.stringify({
          summary: interview.title,
          start: { dateTime: interview.start_time },
          end: { dateTime: interview.end_time }
        })
      });
      const event = await eventResponse.json();
      return new Response(JSON.stringify({ success: true, event }), { headers: corsHeaders });
    }
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 400, headers: corsHeaders
    });
  }
});
```

## Deploy Command

```bash
supabase functions deploy calendar-sync --no-verify-jwt
```

## Environment Variables

```bash
supabase secrets set GOOGLE_CLIENT_ID=your_google_client_id
supabase secrets set GOOGLE_CLIENT_SECRET=your_google_client_secret
supabase secrets set OUTLOOK_CLIENT_ID=your_outlook_client_id
supabase secrets set OUTLOOK_CLIENT_SECRET=your_outlook_client_secret
supabase secrets set APP_URL=https://your-app.com
```
