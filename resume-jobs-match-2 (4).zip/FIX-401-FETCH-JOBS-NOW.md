# Fix 401 Errors on fetch-jobs - IMMEDIATE ACTION

## Root Cause
**JWT verification is enabled** on your fetch-jobs function, causing 401 errors for unauthenticated requests.

## Quick Fix (2 commands)

### 1. Deploy with JWT verification DISABLED
```bash
supabase functions deploy fetch-jobs --no-verify-jwt
```

### 2. Verify RAPIDAPI_KEY secret is set
```bash
supabase secrets set RAPIDAPI_KEY=your_actual_rapidapi_key_here
```

## Test It Works
```bash
# Should return 200 with {"ok":true,"service":"fetch-jobs"}
curl -i https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health

# Test actual job search (should return 200 with jobs data)
curl -i "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=developer&location=remote"
```

## Why This Happened
- Function was deployed WITH JWT verification (default or explicit)
- Public endpoints (health, search) don't send Authorization headers
- Supabase returns 401 when JWT is required but missing

## The Fix Explained
`--no-verify-jwt` flag tells Supabase: "This function is PUBLIC, don't require auth tokens"

## If You Still Get 401 After Fix
1. **Check RapidAPI key is valid**: Log into RapidAPI dashboard
2. **Check key format**: Should be a long alphanumeric string
3. **Redeploy after setting secret**: `supabase functions deploy fetch-jobs --no-verify-jwt`

## Expected Results After Fix
✅ `/health` returns 200  
✅ `/search?query=...` returns 200 with job data  
✅ No Authorization header needed  
✅ CORS works from your domains
