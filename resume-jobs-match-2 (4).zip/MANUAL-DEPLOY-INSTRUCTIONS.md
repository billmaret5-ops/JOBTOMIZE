# Manual Deployment Instructions for fetch-jobs Function

## 🚨 IMMEDIATE ACTION REQUIRED

The fetch-jobs function needs to be manually deployed with the updated code that includes comprehensive logging.

## Step 1: Prepare the Function Code

### Create the function directory:
```bash
mkdir -p supabase/functions/fetch-jobs
```

### Create the index.ts file:
```bash
cat > supabase/functions/fetch-jobs/index.ts << 'EOFCODE'
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

const generateMockJobs = (source: string, query: string, location: string, count: number = 10): JobListing[] => {
  const companies = ['TechCorp', 'StartupXYZ', 'MegaCorp', 'InnovateLab', 'DataDriven Inc', 'CloudFirst', 'DevSolutions'];
  const jobTitles = ['Software Engineer', 'Frontend Developer', 'Backend Developer', 'Full Stack Developer', 'DevOps Engineer', 'Data Scientist', 'Product Manager'];
  const locations = ['San Francisco, CA', 'New York, NY', 'Austin, TX', 'Seattle, WA', 'Boston, MA', 'Chicago, IL', 'Remote'];
  const skills = [['JavaScript', 'React', 'Node.js'], ['Python', 'Django', 'PostgreSQL'], ['Java', 'Spring', 'MySQL'], ['TypeScript', 'Angular', 'MongoDB']];
  const companySizes = ['1-10', '11-50', '51-200', '201-1000', '1000+'];
  const experienceLevels = ['Entry', 'Mid', 'Senior'];
  
  return Array.from({ length: count }, (_, i) => {
    const company = companies[i % companies.length];
    const title = query || jobTitles[i % jobTitles.length];
    const jobLocation = location || locations[i % locations.length];
    const isRemote = jobLocation.toLowerCase().includes('remote');
    
    return {
      id: `${source}_${Date.now()}_${i}`,
      title,
      company,
      location: jobLocation,
      description: `We are looking for a talented ${title.toLowerCase()} to join our ${company} team.`,
      salary: `$${60000 + (i * 10000)} - $${90000 + (i * 15000)}`,
      type: i % 4 === 0 ? 'Part-time' : i % 4 === 1 ? 'Contract' : i % 4 === 2 ? 'Internship' : 'Full-time',
      posted_date: new Date(Date.now() - (i * 24 * 60 * 60 * 1000)).toISOString(),
      apply_url: `https://${source}.com/jobs/${Date.now()}_${i}`,
      source,
      skills: skills[i % skills.length],
      company_size: companySizes[i % companySizes.length],
      remote: isRemote,
      experience_level: experienceLevels[i % experienceLevels.length]
    };
  });
};

Deno.serve(async (req) => {
  console.log('=== FETCH-JOBS REQUEST ===');
  console.log('Method:', req.method);
  console.log('URL:', req.url);
  console.log('Headers:', Object.fromEntries(req.headers.entries()));
  
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const url = new URL(req.url);
    const pathname = url.pathname;
    
    if (req.method === 'GET' && (pathname.endsWith('/health') || pathname.includes('/health'))) {
      console.log('Health check requested');
      return new Response(JSON.stringify({ 
        status: 'healthy',
        timestamp: new Date().toISOString(),
        service: 'fetch-jobs',
        version: '2.0'
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (req.method === 'GET' && (pathname.endsWith('/search') || pathname.includes('/search'))) {
      console.log('GET search requested');
      const query = url.searchParams.get('query') || 'software engineer';
      const location = url.searchParams.get('location') || '';
      const sources = url.searchParams.get('sources')?.split(',') || ['indeed', 'linkedin', 'glassdoor'];
      const page = parseInt(url.searchParams.get('page') || '1');
      const limit = parseInt(url.searchParams.get('limit') || '20');

      console.log('GET params:', { query, location, sources, page, limit });

      let allJobs: JobListing[] = [];
      if (sources.includes('indeed')) allJobs = allJobs.concat(generateMockJobs('indeed', query, location, 15));
      if (sources.includes('linkedin')) allJobs = allJobs.concat(generateMockJobs('linkedin', query, location, 12));
      if (sources.includes('glassdoor')) allJobs = allJobs.concat(generateMockJobs('glassdoor', query, location, 10));

      allJobs.sort((a, b) => new Date(b.posted_date).getTime() - new Date(a.posted_date).getTime());
      const startIndex = (page - 1) * limit;
      const paginatedJobs = allJobs.slice(startIndex, startIndex + limit);

      return new Response(JSON.stringify({
        jobs: paginatedJobs,
        total: allJobs.length,
        page,
        totalPages: Math.ceil(allJobs.length / limit)
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    if (req.method === 'POST') {
      console.log('POST search requested');
      const body = await req.json();
      console.log('POST body:', body);
      
      const { 
        query = 'software engineer', 
        location = '', 
        sources = ['indeed', 'linkedin', 'glassdoor'],
        job_type, salary_min, salary_max, company_size, experience_level, remote,
        page = 1, limit = 20
      } = body;

      let allJobs: JobListing[] = [];
      if (sources.includes('indeed')) allJobs = allJobs.concat(generateMockJobs('indeed', query, location, 15));
      if (sources.includes('linkedin')) allJobs = allJobs.concat(generateMockJobs('linkedin', query, location, 12));
      if (sources.includes('glassdoor')) allJobs = allJobs.concat(generateMockJobs('glassdoor', query, location, 10));

      let filteredJobs = allJobs.filter(job => {
        if (job_type && job.type !== job_type) return false;
        if (company_size && job.company_size !== company_size) return false;
        if (experience_level && job.experience_level !== experience_level) return false;
        if (remote !== undefined && job.remote !== remote) return false;
        
        if (salary_min || salary_max) {
          const salaryMatch = job.salary?.match(/\$(\d+(?:,\d{3})*)\s*-\s*\$(\d+(?:,\d{3})*)/);
          if (salaryMatch) {
            const minSalary = parseInt(salaryMatch[1].replace(/,/g, ''));
            const maxSalary = parseInt(salaryMatch[2].replace(/,/g, ''));
            if (salary_min && maxSalary < salary_min) return false;
            if (salary_max && minSalary > salary_max) return false;
          }
        }
        return true;
      });

      filteredJobs.sort((a, b) => new Date(b.posted_date).getTime() - new Date(a.posted_date).getTime());
      const startIndex = (page - 1) * limit;
      const paginatedJobs = filteredJobs.slice(startIndex, startIndex + limit);

      return new Response(JSON.stringify({
        jobs: paginatedJobs,
        total: filteredJobs.length,
        page,
        totalPages: Math.ceil(filteredJobs.length / limit)
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    return new Response(JSON.stringify({ 
      error: 'Method not allowed',
      message: 'Use GET /health, GET /search?query=..., or POST with JSON body'
    }), {
      status: 405,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
EOFCODE
```

## Step 2: Deploy the Function

### Option A: Deploy WITHOUT JWT Verification (for testing)
```bash
supabase functions deploy fetch-jobs --no-verify-jwt
```

### Option B: Deploy WITH JWT Verification (recommended)
```bash
supabase functions deploy fetch-jobs
```

## Step 3: Test the Deployment

### Set environment variables:
```bash
export SUPABASE_URL="https://rgdvevmqrjlkqfkiucdh.supabase.co"
export SUPABASE_ANON_KEY="your-anon-key-here"
```

### Test health endpoint:
```bash
curl -v \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/health"
```

Expected response:
```json
{
  "status": "healthy",
  "timestamp": "2025-11-20T15:52:00.000Z",
  "service": "fetch-jobs",
  "version": "2.0"
}
```

### Test search endpoint:
```bash
curl -v \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/search?query=react&location=remote"
```

## Step 4: Check Logs

### Via CLI:
```bash
supabase functions logs fetch-jobs --follow
```

### Via Dashboard:
1. Go to https://supabase.com/dashboard
2. Select your project
3. Go to Edge Functions
4. Click on fetch-jobs
5. View Logs tab

### What to look for:
```
=== FETCH-JOBS REQUEST ===
Method: GET
URL: https://...
Headers: {
  authorization: 'Bearer eyJ...',
  apikey: 'eyJ...',
  ...
}
```

## Step 5: Verify in Application

After deployment, test in your application:

1. Go to your app with `?diagnostics` query parameter
2. Click "Test Edge Function"
3. Check the console for detailed logs
4. Verify you get 200 responses

## Troubleshooting

### Still getting 401?

1. **Check JWT setting:**
   ```bash
   supabase functions list
   ```
   Look for verify_jwt column

2. **Check logs for headers:**
   ```bash
   supabase functions logs fetch-jobs
   ```
   Verify both authorization and apikey headers are present

3. **Try without JWT:**
   ```bash
   supabase functions deploy fetch-jobs --no-verify-jwt
   ```

4. **Verify token:**
   ```bash
   echo $SUPABASE_ANON_KEY | cut -d'.' -f2 | base64 -d 2>/dev/null | jq
   ```

### Getting different errors?

Check the logs - the comprehensive logging will show exactly what's happening.

## What This Fixes

✅ Adds comprehensive request logging
✅ Shows all received headers
✅ Supports GET /health endpoint
✅ Supports GET /search with query params
✅ Supports POST with JSON body
✅ Better error messages
✅ Helps diagnose 401 errors

## Next Steps

1. Deploy the function using the commands above
2. Check the logs to see what headers are received
3. Test with curl to verify it works
4. Update your application code if needed
5. Report back with the log output

The logs will tell us exactly why authentication is failing!
