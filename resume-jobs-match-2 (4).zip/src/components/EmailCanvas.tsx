import React, { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Trash2, Move, Plus } from 'lucide-react';
import { EmailComponent } from './DragDropEmailBuilder';

interface EmailCanvasProps {
  components: EmailComponent[];
  selectedComponent: string | null;
  onComponentSelect: (id: string | null) => void;
  onComponentUpdate: (id: string, updates: Partial<EmailComponent>) => void;
  onComponentDelete: (id: string) => void;
  onDrop: (componentType: string, index: number) => void;
}

export const EmailCanvas: React.FC<EmailCanvasProps> = ({
  components,
  selectedComponent,
  onComponentSelect,
  onComponentUpdate,
  onComponentDelete,
  onDrop
}) => {
  const [dragOverIndex, setDragOverIndex] = useState<number | null>(null);

  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    setDragOverIndex(index);
  };

  const handleDrop = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    const componentType = e.dataTransfer.getData('text/plain');
    onDrop(componentType, index);
    setDragOverIndex(null);
  };

  const handleDragLeave = () => {
    setDragOverIndex(null);
  };

  const renderComponent = (component: EmailComponent) => {
    switch (component.type) {
      case 'header':
        return (
          <div 
            style={{
              backgroundColor: component.styles.backgroundColor,
              padding: component.styles.padding,
              textAlign: component.styles.textAlign
            }}
          >
            <h1 style={{
              color: component.styles.titleColor,
              fontSize: component.styles.titleSize,
              margin: '0 0 8px 0',
              fontWeight: 'bold'
            }}>
              {component.content.title}
            </h1>
            {component.content.subtitle && (
              <p style={{
                color: component.styles.subtitleColor,
                fontSize: component.styles.subtitleSize,
                margin: 0
              }}>
                {component.content.subtitle}
              </p>
            )}
          </div>
        );
      
      case 'text':
        return (
          <div style={{
            padding: component.styles.padding,
            fontSize: component.styles.fontSize,
            color: component.styles.color,
            lineHeight: component.styles.lineHeight,
            textAlign: component.styles.textAlign
          }}>
            {component.content.text}
          </div>
        );
      
      case 'button':
        return (
          <div style={{ textAlign: component.styles.textAlign, margin: component.styles.margin }}>
            <a
              href={component.content.url}
              style={{
                display: 'inline-block',
                backgroundColor: component.styles.backgroundColor,
                color: component.styles.color,
                padding: component.styles.padding,
                borderRadius: component.styles.borderRadius,
                fontSize: component.styles.fontSize,
                textDecoration: 'none',
                fontWeight: 'bold'
              }}
            >
              {component.content.text}
            </a>
          </div>
        );
      
      case 'image':
        return (
          <div style={{ textAlign: 'center', margin: component.styles.margin }}>
            {component.content.src ? (
              <img
                src={component.content.src}
                alt={component.content.alt}
                style={{
                  width: component.styles.width,
                  maxWidth: component.styles.maxWidth,
                  height: component.styles.height
                }}
              />
            ) : (
              <div 
                style={{
                  width: '100%',
                  height: '200px',
                  backgroundColor: '#f3f4f6',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px dashed #d1d5db',
                  color: '#6b7280'
                }}
              >
                Click to add image
              </div>
            )}
          </div>
        );
      
      case 'spacer':
        return (
          <div style={{ height: `${component.content.height}px` }} />
        );
      
      case 'divider':
        return (
          <div style={{ padding: '10px 20px' }}>
            <hr style={{
              border: 'none',
              borderTop: `1px ${component.content.style} ${component.content.color}`,
              margin: 0
            }} />
          </div>
        );
      
      default:
        return <div>Unknown component</div>;
    }
  };

  return (
    <div className="max-w-2xl mx-auto bg-white rounded-lg shadow-sm border">
      {/* Drop zone at the top */}
      <div
        className={`h-8 border-2 border-dashed transition-colors ${
          dragOverIndex === 0 ? 'border-blue-400 bg-blue-50' : 'border-transparent'
        }`}
        onDragOver={(e) => handleDragOver(e, 0)}
        onDrop={(e) => handleDrop(e, 0)}
        onDragLeave={handleDragLeave}
      >
        {dragOverIndex === 0 && (
          <div className="flex items-center justify-center h-full text-blue-600 text-sm">
            <Plus className="w-4 h-4 mr-1" />
            Drop component here
          </div>
        )}
      </div>

      {components.map((component, index) => (
        <React.Fragment key={component.id}>
          <div
            className={`relative group cursor-pointer transition-all ${
              selectedComponent === component.id 
                ? 'ring-2 ring-blue-500 ring-inset' 
                : 'hover:ring-1 hover:ring-gray-300 hover:ring-inset'
            }`}
            onClick={() => onComponentSelect(component.id)}
          >
            {/* Component controls */}
            {selectedComponent === component.id && (
              <div className="absolute top-2 right-2 flex space-x-1 z-10">
                <Button
                  size="sm"
                  variant="secondary"
                  className="h-6 w-6 p-0 bg-white shadow-sm"
                >
                  <Move className="w-3 h-3" />
                </Button>
                <Button
                  size="sm"
                  variant="destructive"
                  className="h-6 w-6 p-0"
                  onClick={(e) => {
                    e.stopPropagation();
                    onComponentDelete(component.id);
                  }}
                >
                  <Trash2 className="w-3 h-3" />
                </Button>
              </div>
            )}
            
            {renderComponent(component)}
          </div>

          {/* Drop zone between components */}
          <div
            className={`h-8 border-2 border-dashed transition-colors ${
              dragOverIndex === index + 1 ? 'border-blue-400 bg-blue-50' : 'border-transparent'
            }`}
            onDragOver={(e) => handleDragOver(e, index + 1)}
            onDrop={(e) => handleDrop(e, index + 1)}
            onDragLeave={handleDragLeave}
          >
            {dragOverIndex === index + 1 && (
              <div className="flex items-center justify-center h-full text-blue-600 text-sm">
                <Plus className="w-4 h-4 mr-1" />
                Drop component here
              </div>
            )}
          </div>
        </React.Fragment>
      ))}

      {components.length === 0 && (
        <div className="p-12 text-center text-gray-500">
          <div className="w-16 h-16 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <Plus className="w-8 h-8" />
          </div>
          <h3 className="text-lg font-medium mb-2">Start building your email</h3>
          <p className="text-sm">Drag components from the sidebar to begin</p>
        </div>
      )}
    </div>
  );
};