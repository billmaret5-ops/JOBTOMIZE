import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Mail, MessageSquare, Slack, Users, Save } from 'lucide-react';
import { backupAlertService } from '@/services/backupAlertService';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

export default function BackupAlertConfig() {
  const [emailConfig, setEmailConfig] = useState({ email: '', enabled: false });
  const [smsConfig, setSmsConfig] = useState({ phone: '', enabled: false });
  const [slackConfig, setSlackConfig] = useState({ webhook_url: '', channel: '', enabled: false });
  const [teamsConfig, setTeamsConfig] = useState({ webhook_url: '', enabled: false });
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadConfigs();
  }, []);

  const loadConfigs = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data } = await supabase
        .from('backup_alert_config')
        .select('*')
        .eq('user_id', user.id);

      if (data) {
        data.forEach(config => {
          switch (config.alert_type) {
            case 'email':
              setEmailConfig({ ...config.config, enabled: config.enabled });
              break;
            case 'sms':
              setSmsConfig({ ...config.config, enabled: config.enabled });
              break;
            case 'slack':
              setSlackConfig({ ...config.config, enabled: config.enabled });
              break;
            case 'teams':
              setTeamsConfig({ ...config.config, enabled: config.enabled });
              break;
          }
        });
      }
    } catch (error) {
      console.error('Failed to load configs:', error);
    }
  };

  const saveConfig = async (type: string, config: any, enabled: boolean) => {
    setSaving(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      await backupAlertService.updateAlertConfig(user.id, type, config, enabled);
      
      toast({
        title: 'Success',
        description: `${type} alerts ${enabled ? 'enabled' : 'disabled'} successfully`
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to save alert configuration',
        variant: 'destructive'
      });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alert Configuration</CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="email">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="email"><Mail className="h-4 w-4 mr-2" />Email</TabsTrigger>
            <TabsTrigger value="sms"><MessageSquare className="h-4 w-4 mr-2" />SMS</TabsTrigger>
            <TabsTrigger value="slack"><Slack className="h-4 w-4 mr-2" />Slack</TabsTrigger>
            <TabsTrigger value="teams"><Users className="h-4 w-4 mr-2" />Teams</TabsTrigger>
          </TabsList>

          <TabsContent value="email" className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Enable Email Alerts</Label>
              <Switch
                checked={emailConfig.enabled}
                onCheckedChange={(checked) => setEmailConfig({ ...emailConfig, enabled: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label>Email Address</Label>
              <Input
                type="email"
                value={emailConfig.email}
                onChange={(e) => setEmailConfig({ ...emailConfig, email: e.target.value })}
                placeholder="your@email.com"
              />
            </div>
            <Button onClick={() => saveConfig('email', { email: emailConfig.email }, emailConfig.enabled)} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />Save Email Config
            </Button>
          </TabsContent>

          <TabsContent value="sms" className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Enable SMS Alerts</Label>
              <Switch
                checked={smsConfig.enabled}
                onCheckedChange={(checked) => setSmsConfig({ ...smsConfig, enabled: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label>Phone Number</Label>
              <Input
                type="tel"
                value={smsConfig.phone}
                onChange={(e) => setSmsConfig({ ...smsConfig, phone: e.target.value })}
                placeholder="+1234567890"
              />
            </div>
            <Button onClick={() => saveConfig('sms', { phone: smsConfig.phone }, smsConfig.enabled)} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />Save SMS Config
            </Button>
          </TabsContent>

          <TabsContent value="slack" className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Enable Slack Alerts</Label>
              <Switch
                checked={slackConfig.enabled}
                onCheckedChange={(checked) => setSlackConfig({ ...slackConfig, enabled: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label>Webhook URL</Label>
              <Input
                value={slackConfig.webhook_url}
                onChange={(e) => setSlackConfig({ ...slackConfig, webhook_url: e.target.value })}
                placeholder="https://hooks.slack.com/services/..."
              />
            </div>
            <div className="space-y-2">
              <Label>Channel</Label>
              <Input
                value={slackConfig.channel}
                onChange={(e) => setSlackConfig({ ...slackConfig, channel: e.target.value })}
                placeholder="#backups"
              />
            </div>
            <Button onClick={() => saveConfig('slack', slackConfig, slackConfig.enabled)} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />Save Slack Config
            </Button>
          </TabsContent>

          <TabsContent value="teams" className="space-y-4">
            <div className="flex items-center justify-between">
              <Label>Enable Teams Alerts</Label>
              <Switch
                checked={teamsConfig.enabled}
                onCheckedChange={(checked) => setTeamsConfig({ ...teamsConfig, enabled: checked })}
              />
            </div>
            <div className="space-y-2">
              <Label>Webhook URL</Label>
              <Input
                value={teamsConfig.webhook_url}
                onChange={(e) => setTeamsConfig({ ...teamsConfig, webhook_url: e.target.value })}
                placeholder="https://outlook.office.com/webhook/..."
              />
            </div>
            <Button onClick={() => saveConfig('teams', teamsConfig, teamsConfig.enabled)} disabled={saving}>
              <Save className="h-4 w-4 mr-2" />Save Teams Config
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
