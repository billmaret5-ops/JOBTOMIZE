import React, { useState, useEffect } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Brain, 
  GitMerge, 
  Lightbulb, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  MessageSquare,
  Zap,
  Target
} from 'lucide-react';
import { supabase } from '../lib/supabase';

interface AICollaborationAssistantProps {
  resumeId: string;
  userId: string;
  content: string;
  jobRequirements?: string;
  collaborators: Array<{
    id: string;
    name: string;
    avatar: string;
  }>;
  onSuggestionAccept: (suggestion: any) => void;
  onConflictResolve: (resolution: any) => void;
}

export default function AICollaborationAssistant({
  resumeId,
  userId,
  content,
  jobRequirements = '',
  collaborators,
  onSuggestionAccept,
  onConflictResolve
}: AICollaborationAssistantProps) {
  const [suggestions, setSuggestions] = useState([]);
  const [conflicts, setConflicts] = useState([]);
  const [collaborationScore, setCollaborationScore] = useState(85);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [autoAcceptEnabled, setAutoAcceptEnabled] = useState(false);

  useEffect(() => {
    analyzeContent();
    const interval = setInterval(analyzeContent, 30000); // Analyze every 30 seconds
    return () => clearInterval(interval);
  }, [content, jobRequirements]);

  const analyzeContent = async () => {
    if (!content.trim()) return;
    
    setIsAnalyzing(true);
    try {
      const { data } = await supabase.functions.invoke('ai-collaboration-assistant', {
        body: {
          action: 'suggest_improvements',
          resumeId,
          userId,
          content,
          jobRequirements
        }
      });

      if (data?.improvements) {
        setSuggestions(data.improvements);
        
        if (autoAcceptEnabled) {
          data.improvements
            .filter(s => s.confidence > 0.9)
            .forEach(suggestion => {
              setTimeout(() => acceptSuggestion(suggestion), 1000);
            });
        }
      }
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const acceptSuggestion = (suggestion) => {
    onSuggestionAccept(suggestion);
    setSuggestions(prev => prev.filter(s => s.id !== suggestion.id));
  };

  const rejectSuggestion = (suggestionId) => {
    setSuggestions(prev => prev.filter(s => s.id !== suggestionId));
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="h-5 w-5 text-purple-600" />
          AI Collaboration Assistant
          {isAnalyzing && <div className="animate-spin h-4 w-4 border-2 border-purple-600 border-t-transparent rounded-full" />}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="suggestions" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
            <TabsTrigger value="conflicts">Conflicts</TabsTrigger>
            <TabsTrigger value="patterns">Patterns</TabsTrigger>
            <TabsTrigger value="help">Help</TabsTrigger>
          </TabsList>

          <TabsContent value="suggestions" className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Writing Improvements</h3>
              <div className="flex items-center gap-2">
                <label className="text-sm">Auto-accept high confidence</label>
                <input
                  type="checkbox"
                  checked={autoAcceptEnabled}
                  onChange={(e) => setAutoAcceptEnabled(e.target.checked)}
                  className="rounded"
                />
              </div>
            </div>
            
            {suggestions.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <Lightbulb className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>No suggestions available. Keep writing for AI insights!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {suggestions.map((suggestion, index) => (
                  <div key={index} className="border rounded-lg p-4 bg-blue-50">
                    <div className="flex justify-between items-start mb-2">
                      <Badge variant="outline" className="text-xs">
                        {suggestion.type}
                      </Badge>
                      <div className="flex items-center gap-1">
                        <span className="text-xs text-gray-600">
                          {Math.round(suggestion.confidence * 100)}%
                        </span>
                        <Progress value={suggestion.confidence * 100} className="w-16 h-2" />
                      </div>
                    </div>
                    <p className="text-sm mb-3">{suggestion.text}</p>
                    <div className="flex gap-2">
                      <Button 
                        size="sm" 
                        onClick={() => acceptSuggestion(suggestion)}
                        className="bg-green-600 hover:bg-green-700"
                      >
                        <CheckCircle className="h-4 w-4 mr-1" />
                        Accept
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline"
                        onClick={() => rejectSuggestion(suggestion.id)}
                      >
                        Dismiss
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="conflicts" className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <GitMerge className="h-4 w-4" />
              Conflict Resolution
            </h3>
            
            {conflicts.length === 0 ? (
              <div className="text-center py-8 text-gray-500">
                <CheckCircle className="h-12 w-12 mx-auto mb-4 opacity-50 text-green-500" />
                <p>No conflicts detected. Smooth collaboration!</p>
              </div>
            ) : (
              <div className="space-y-3">
                {conflicts.map((conflict, index) => (
                  <div key={index} className="border rounded-lg p-4 bg-yellow-50">
                    <div className="flex items-center gap-2 mb-2">
                      <AlertTriangle className="h-4 w-4 text-yellow-600" />
                      <span className="font-medium text-sm">Merge Conflict</span>
                    </div>
                    <p className="text-sm mb-3">{conflict.description}</p>
                    <Button 
                      size="sm"
                      onClick={() => onConflictResolve(conflict)}
                      className="bg-blue-600 hover:bg-blue-700"
                    >
                      <GitMerge className="h-4 w-4 mr-1" />
                      Smart Merge
                    </Button>
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="patterns" className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <TrendingUp className="h-4 w-4" />
              Collaboration Insights
            </h3>
            
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-green-600">{collaborationScore}%</div>
                  <p className="text-sm text-gray-600">Collaboration Score</p>
                </CardContent>
              </Card>
              
              <Card>
                <CardContent className="p-4">
                  <div className="text-2xl font-bold text-blue-600">{collaborators.length}</div>
                  <p className="text-sm text-gray-600">Active Collaborators</p>
                </CardContent>
              </Card>
            </div>

            <div className="space-y-3">
              <div className="p-3 bg-green-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span className="font-medium text-sm">Strength</span>
                </div>
                <p className="text-sm">High engagement with AI suggestions (92% acceptance rate)</p>
              </div>
              
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center gap-2 mb-1">
                  <Lightbulb className="h-4 w-4 text-blue-600" />
                  <span className="font-medium text-sm">Recommendation</span>
                </div>
                <p className="text-sm">Consider enabling auto-accept for grammar improvements</p>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="help" className="space-y-4">
            <h3 className="font-semibold flex items-center gap-2">
              <Target className="h-4 w-4" />
              Contextual Help
            </h3>
            
            <div className="space-y-3">
              <div className="p-4 border rounded-lg bg-purple-50">
                <div className="flex items-center gap-2 mb-2">
                  <MessageSquare className="h-4 w-4 text-purple-600" />
                  <span className="font-medium">Job Alignment</span>
                </div>
                <p className="text-sm mb-2">Your resume matches 78% of the job requirements</p>
                <ul className="text-xs space-y-1 text-gray-600">
                  <li>• Add more specific technical skills</li>
                  <li>• Include quantifiable achievements</li>
                  <li>• Highlight leadership experience</li>
                </ul>
              </div>
              
              <div className="p-4 border rounded-lg bg-green-50">
                <div className="flex items-center gap-2 mb-2">
                  <Zap className="h-4 w-4 text-green-600" />
                  <span className="font-medium">Quick Tips</span>
                </div>
                <ul className="text-sm space-y-1">
                  <li>• Use action verbs to start bullet points</li>
                  <li>• Keep sentences concise and impactful</li>
                  <li>• Tailor content to job description keywords</li>
                </ul>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}