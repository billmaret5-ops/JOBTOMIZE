import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Camera, Mic, Play, Pause, RotateCcw, Target, Brain, TrendingUp } from 'lucide-react';

interface Question {
  id: string;
  question: string;
  type: 'technical' | 'behavioral' | 'situational';
  difficulty: 'easy' | 'medium' | 'hard';
  keywords: string[];
}

interface InterviewSession {
  id: string;
  date: string;
  score: number;
  questions: number;
  strengths: string[];
  improvements: string[];
}

const AIInterviewPreparation: React.FC = () => {
  const [jobDescription, setJobDescription] = useState('');
  const [selectedIndustry, setSelectedIndustry] = useState('');
  const [isRecording, setIsRecording] = useState(false);
  const [currentQuestion, setCurrentQuestion] = useState<Question | null>(null);
  const [userAnswer, setUserAnswer] = useState('');
  const [feedback, setFeedback] = useState<any>(null);
  const [sessionHistory, setSessionHistory] = useState<InterviewSession[]>([
    { id: '1', date: '2024-01-15', score: 85, questions: 12, strengths: ['Clear communication', 'Technical knowledge'], improvements: ['Body language', 'Confidence'] },
    { id: '2', date: '2024-01-10', score: 78, questions: 10, strengths: ['Problem solving'], improvements: ['Eye contact', 'Speaking pace'] }
  ]);
  const videoRef = useRef<HTMLVideoElement>(null);

  const industries = [
    'Technology', 'Finance', 'Healthcare', 'Marketing', 'Sales', 'Consulting', 'Education', 'Manufacturing'
  ];

  const questionBanks = {
    technical: [
      { id: '1', question: 'Explain your approach to solving complex technical problems.', type: 'technical' as const, difficulty: 'medium' as const, keywords: ['problem-solving', 'technical', 'methodology'] },
      { id: '2', question: 'How do you stay updated with the latest technologies?', type: 'technical' as const, difficulty: 'easy' as const, keywords: ['learning', 'technology', 'growth'] }
    ],
    behavioral: [
      { id: '3', question: 'Tell me about a time you had to work with a difficult team member.', type: 'behavioral' as const, difficulty: 'medium' as const, keywords: ['teamwork', 'conflict-resolution', 'communication'] },
      { id: '4', question: 'Describe a situation where you had to meet a tight deadline.', type: 'behavioral' as const, difficulty: 'medium' as const, keywords: ['time-management', 'pressure', 'delivery'] }
    ],
    situational: [
      { id: '5', question: 'How would you handle a project that is falling behind schedule?', type: 'situational' as const, difficulty: 'hard' as const, keywords: ['project-management', 'problem-solving', 'leadership'] }
    ]
  };

  const startWebcam = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (error) {
      console.log('Webcam access denied');
    }
  };

  const generateQuestions = () => {
    const allQuestions = [...questionBanks.technical, ...questionBanks.behavioral, ...questionBanks.situational];
    const randomQuestion = allQuestions[Math.floor(Math.random() * allQuestions.length)];
    setCurrentQuestion(randomQuestion);
  };

  const analyzeAnswer = () => {
    const mockFeedback = {
      score: Math.floor(Math.random() * 40) + 60,
      keywordMatch: Math.floor(Math.random() * 30) + 70,
      clarity: Math.floor(Math.random() * 25) + 75,
      confidence: Math.floor(Math.random() * 35) + 65,
      bodyLanguage: Math.floor(Math.random() * 30) + 70,
      suggestions: [
        'Include more specific examples',
        'Maintain better eye contact',
        'Speak at a slower pace for clarity',
        'Use more confident body language'
      ]
    };
    setFeedback(mockFeedback);
  };

  const startMockInterview = () => {
    setIsRecording(true);
    startWebcam();
    generateQuestions();
  };

  useEffect(() => {
    startWebcam();
  }, []);

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h2 className="text-3xl font-bold mb-2">AI Interview Preparation</h2>
        <p className="text-gray-600">Practice with AI-powered mock interviews and get real-time feedback</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Job Analysis & Setup
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="block text-sm font-medium mb-2">Industry</label>
                <Select value={selectedIndustry} onValueChange={setSelectedIndustry}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select industry" />
                  </SelectTrigger>
                  <SelectContent>
                    {industries.map(industry => (
                      <SelectItem key={industry} value={industry}>{industry}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              <div>
                <label className="block text-sm font-medium mb-2">Job Description</label>
                <Textarea
                  placeholder="Paste the job description here for personalized questions..."
                  value={jobDescription}
                  onChange={(e) => setJobDescription(e.target.value)}
                  rows={4}
                />
              </div>
              <Button onClick={generateQuestions} className="w-full">
                Generate Practice Questions
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Camera className="h-5 w-5" />
                Mock Interview Session
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="relative bg-gray-100 rounded-lg overflow-hidden" style={{ height: '300px' }}>
                <video
                  ref={videoRef}
                  autoPlay
                  muted
                  className="w-full h-full object-cover"
                />
                {isRecording && (
                  <div className="absolute top-4 right-4 bg-red-500 text-white px-2 py-1 rounded-full text-sm flex items-center gap-1">
                    <div className="w-2 h-2 bg-white rounded-full animate-pulse"></div>
                    Recording
                  </div>
                )}
              </div>

              {currentQuestion && (
                <div className="space-y-4">
                  <div className="p-4 bg-blue-50 rounded-lg">
                    <div className="flex items-center gap-2 mb-2">
                      <Badge variant={currentQuestion.difficulty === 'easy' ? 'secondary' : currentQuestion.difficulty === 'medium' ? 'default' : 'destructive'}>
                        {currentQuestion.difficulty}
                      </Badge>
                      <Badge variant="outline">{currentQuestion.type}</Badge>
                    </div>
                    <p className="font-medium">{currentQuestion.question}</p>
                    <div className="flex flex-wrap gap-1 mt-2">
                      {currentQuestion.keywords.map(keyword => (
                        <Badge key={keyword} variant="outline" className="text-xs">{keyword}</Badge>
                      ))}
                    </div>
                  </div>

                  <Textarea
                    placeholder="Type your answer here or speak aloud..."
                    value={userAnswer}
                    onChange={(e) => setUserAnswer(e.target.value)}
                    rows={4}
                  />

                  <div className="flex gap-2">
                    <Button onClick={startMockInterview} variant={isRecording ? "destructive" : "default"}>
                      {isRecording ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
                      {isRecording ? 'Stop Interview' : 'Start Mock Interview'}
                    </Button>
                    <Button onClick={analyzeAnswer} variant="outline">
                      <Brain className="h-4 w-4 mr-2" />
                      Analyze Answer
                    </Button>
                    <Button onClick={generateQuestions} variant="outline">
                      <RotateCcw className="h-4 w-4 mr-2" />
                      Next Question
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          {feedback && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Brain className="h-5 w-5" />
                  AI Feedback
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Overall Score</span>
                      <span>{feedback.score}%</span>
                    </div>
                    <Progress value={feedback.score} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Keyword Match</span>
                      <span>{feedback.keywordMatch}%</span>
                    </div>
                    <Progress value={feedback.keywordMatch} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Clarity</span>
                      <span>{feedback.clarity}%</span>
                    </div>
                    <Progress value={feedback.clarity} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Confidence</span>
                      <span>{feedback.confidence}%</span>
                    </div>
                    <Progress value={feedback.confidence} />
                  </div>
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Body Language</span>
                      <span>{feedback.bodyLanguage}%</span>
                    </div>
                    <Progress value={feedback.bodyLanguage} />
                  </div>
                </div>

                <div>
                  <h4 className="font-medium mb-2">Improvement Suggestions:</h4>
                  <ul className="space-y-1">
                    {feedback.suggestions.map((suggestion: string, index: number) => (
                      <li key={index} className="text-sm text-gray-600 flex items-start gap-2">
                        <span className="text-blue-500 mt-1">•</span>
                        {suggestion}
                      </li>
                    ))}
                  </ul>
                </div>
              </CardContent>
            </Card>
          )}

          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Performance History
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {sessionHistory.map(session => (
                  <div key={session.id} className="p-3 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <span className="text-sm text-gray-600">{session.date}</span>
                      <Badge variant={session.score >= 80 ? 'default' : 'secondary'}>
                        {session.score}%
                      </Badge>
                    </div>
                    <p className="text-sm mb-2">{session.questions} questions practiced</p>
                    <div className="space-y-1">
                      <div>
                        <span className="text-xs font-medium text-green-600">Strengths:</span>
                        <p className="text-xs text-gray-600">{session.strengths.join(', ')}</p>
                      </div>
                      <div>
                        <span className="text-xs font-medium text-orange-600">Improvements:</span>
                        <p className="text-xs text-gray-600">{session.improvements.join(', ')}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AIInterviewPreparation;