import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { RefreshCw, Clock, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { backupMonitoringService } from '@/services/backupMonitoringService';

interface RetryLog {
  id: string;
  backup_id: string;
  attempt_number: number;
  status: string;
  error_message?: string;
  backoff_seconds: number;
  attempted_at: string;
  completed_at?: string;
}

export default function BackupRetryMonitor() {
  const [retryLogs, setRetryLogs] = useState<RetryLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadRetryLogs();
    const interval = setInterval(loadRetryLogs, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadRetryLogs = async () => {
    try {
      const { data } = await supabase
        .from('backup_retry_log')
        .select('*')
        .order('attempted_at', { ascending: false })
        .limit(20);

      setRetryLogs(data || []);
    } catch (error) {
      console.error('Failed to load retry logs:', error);
    } finally {
      setLoading(false);
    }
  };

  const formatBackoffTime = (seconds: number) => {
    if (seconds < 60) return `${seconds}s`;
    const minutes = Math.floor(seconds / 60);
    if (minutes < 60) return `${minutes}m`;
    const hours = Math.floor(minutes / 60);
    return `${hours}h`;
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'running': return <RefreshCw className="h-4 w-4 text-blue-600 animate-spin" />;
      default: return <Clock className="h-4 w-4 text-yellow-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'success': return 'bg-green-100 text-green-800';
      case 'failed': return 'bg-red-100 text-red-800';
      case 'running': return 'bg-blue-100 text-blue-800';
      default: return 'bg-yellow-100 text-yellow-800';
    }
  };

  const calculateProgress = (attemptNumber: number, maxAttempts = 5) => {
    return (attemptNumber / maxAttempts) * 100;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="flex items-center gap-2">
            <RefreshCw className="h-5 w-5" />
            Retry Monitor
          </span>
          <Button variant="outline" size="sm" onClick={loadRetryLogs}>
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {retryLogs.map((log) => (
            <div key={log.id} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getStatusIcon(log.status)}
                  <span className="font-medium text-sm">Attempt #{log.attempt_number}</span>
                </div>
                <Badge className={getStatusColor(log.status)}>
                  {log.status}
                </Badge>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-muted-foreground">Progress</span>
                  <span className="font-medium">{log.attempt_number}/5 attempts</span>
                </div>
                <Progress value={calculateProgress(log.attempt_number)} />
              </div>

              <div className="grid grid-cols-2 gap-2 text-sm">
                <div>
                  <span className="text-muted-foreground">Backoff Time:</span>
                  <span className="ml-2 font-medium">{formatBackoffTime(log.backoff_seconds)}</span>
                </div>
                <div>
                  <span className="text-muted-foreground">Attempted:</span>
                  <span className="ml-2 font-medium">
                    {new Date(log.attempted_at).toLocaleTimeString()}
                  </span>
                </div>
              </div>

              {log.error_message && (
                <div className="text-sm text-red-600 bg-red-50 p-2 rounded">
                  {log.error_message}
                </div>
              )}
            </div>
          ))}

          {retryLogs.length === 0 && !loading && (
            <p className="text-center text-muted-foreground py-8">No retry attempts</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
