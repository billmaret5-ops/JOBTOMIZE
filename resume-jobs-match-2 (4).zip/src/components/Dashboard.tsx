import React, { useState } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import JobCard from './JobCard';
import { JobFilters } from './JobFilters';
import StatsCard from './StatsCard';
import { ResumeUpload } from './ResumeUpload';
import { ResumeHistory } from './ResumeHistory';
import { ResumeAnalytics } from './ResumeAnalytics';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
export default function Dashboard() {
  const [filters, setFilters] = useState({
    location: '',
    salary_min: 0,
    salary_max: 0,
    job_type: '',
    remote_option: '',
    company_size: ''
  });
  const { user, profile } = useAuth();


  const companyImages = [
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143636664_fe328cd0.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143638767_fcdf5beb.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143640641_be280cc3.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143642808_cdbbe4e2.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143644954_63e4d94d.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143647416_45d888c7.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143650218_0ce704b7.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758143652268_9eadb106.webp'
  ];

  const jobs = [
    {
      title: 'Senior Software Engineer',
      company: 'TechCorp Solutions',
      location: 'San Francisco, CA',
      salary: '$120,000 - $160,000',
      matchScore: 94,
      description: 'Lead development of scalable web applications using React, Node.js, and cloud technologies. Work with cross-functional teams to deliver high-quality software solutions.',
      posted: '2 hours ago',
      companyImage: companyImages[0],
      isNew: true
    },
    {
      title: 'Product Manager',
      company: 'Innovation Labs',
      location: 'New York, NY',
      salary: '$110,000 - $140,000',
      matchScore: 89,
      description: 'Drive product strategy and roadmap for B2B SaaS platform. Collaborate with engineering, design, and sales teams to deliver customer-focused solutions.',
      posted: '4 hours ago',
      companyImage: companyImages[1],
      isNew: true
    },
    {
      title: 'UX Designer',
      company: 'Creative Studio',
      location: 'Austin, TX',
      salary: '$85,000 - $110,000',
      matchScore: 87,
      description: 'Design intuitive user experiences for mobile and web applications. Conduct user research and create wireframes, prototypes, and design systems.',
      posted: '6 hours ago',
      companyImage: companyImages[2]
    },
    {
      title: 'Data Scientist',
      company: 'Analytics Pro',
      location: 'Seattle, WA',
      salary: '$130,000 - $170,000',
      matchScore: 85,
      description: 'Build machine learning models and analyze large datasets to drive business insights. Work with Python, SQL, and cloud platforms.',
      posted: '8 hours ago',
      companyImage: companyImages[3]
    },
    {
      title: 'Marketing Manager',
      company: 'Growth Dynamics',
      location: 'Chicago, IL',
      salary: '$75,000 - $95,000',
      matchScore: 82,
      description: 'Lead digital marketing campaigns and brand strategy. Manage social media, content marketing, and performance analytics.',
      posted: '1 day ago',
      companyImage: companyImages[4]
    },
    {
      title: 'DevOps Engineer',
      company: 'Cloud Systems',
      location: 'Denver, CO',
      salary: '$105,000 - $135,000',
      matchScore: 80,
      description: 'Manage CI/CD pipelines, containerization, and cloud infrastructure. Work with AWS, Docker, and Kubernetes.',
      posted: '1 day ago',
      companyImage: companyImages[5]
    }
  ];

  const statsData = [
    {
      title: 'Active Applications',
      value: '12',
      change: '+3 this week',
      changeType: 'increase' as const,
      icon: (
        <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
          <path d="M9 2a1 1 0 000 2h2a1 1 0 100-2H9z" />
          <path fillRule="evenodd" d="M4 5a2 2 0 012-2v1a1 1 0 102 0V3h4v1a1 1 0 102 0V3a2 2 0 012 2v6a2 2 0 01-2 2H6a2 2 0 01-2-2V5zm3 4a1 1 0 000 2h.01a1 1 0 100-2H7zm3 0a1 1 0 000 2h3a1 1 0 100-2h-3z" clipRule="evenodd" />
        </svg>
      )
    },
    {
      title: 'Profile Views',
      value: '247',
      change: '+18% this month',
      changeType: 'increase' as const,
      icon: (
        <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
          <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
        </svg>
      )
    },
    {
      title: 'Interview Requests',
      value: '5',
      change: '+2 pending',
      changeType: 'increase' as const,
      icon: (
        <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-6-3a2 2 0 11-4 0 2 2 0 014 0zm-2 4a5 5 0 00-4.546 2.916A5.986 5.986 0 0010 16a5.986 5.986 0 004.546-2.084A5 5 0 0010 11z" clipRule="evenodd" />
        </svg>
      )
    },
    {
      title: 'Resume Score',
      value: '87%',
      change: '+5% improved',
      changeType: 'increase' as const,
      icon: (
        <svg className="w-6 h-6 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M3 4a1 1 0 011-1h12a1 1 0 011 1v2a1 1 0 01-1 1H4a1 1 0 01-1-1V4zm0 4a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1zm0 4a1 1 0 011-1h6a1 1 0 110 2H4a1 1 0 01-1-1z" clipRule="evenodd" />
        </svg>
      )
    }
  ];

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {statsData.map((stat, index) => (
          <StatsCard key={index} {...stat} />
        ))}
      </div>

      {/* Main Content with Tabs */}
      <Tabs defaultValue="jobs" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="jobs">Job Search</TabsTrigger>
          <TabsTrigger value="resume">Upload Resume</TabsTrigger>
          <TabsTrigger value="history">Resume History</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs" className="mt-6">
          <div className="grid lg:grid-cols-4 gap-8">
            {/* Filters Sidebar */}
            <div className="lg:col-span-1">
              <JobFilters filters={filters} onFiltersChange={setFilters} />
            </div>

            {/* Job Listings */}
            <div className="lg:col-span-3">
              <div className="flex items-center justify-between mb-6">
                <h2 className="text-2xl font-bold text-gray-900">
                  Recommended Jobs ({jobs.length})
                </h2>
                <div className="flex items-center space-x-4">
                  <select className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent">
                    <option>Best Match</option>
                    <option>Newest</option>
                    <option>Salary: High to Low</option>
                    <option>Distance</option>
                  </select>
                </div>
              </div>

              <div className="grid gap-6">
                {jobs.map((job, index) => (
                  <JobCard key={index} job={{
                    id: index.toString(),
                    title: job.title,
                    company: job.company,
                    location: job.location,
                    salary: job.salary,
                    description: job.description,
                    posted_date: job.posted,
                    matchScore: job.matchScore
                  }} />
                ))}
              </div>

              {/* Load More */}
              <div className="text-center mt-8">
                <button className="px-8 py-3 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors font-medium">
                  Load More Jobs
                </button>
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="resume" className="mt-6">
          <ResumeUpload />
        </TabsContent>

        <TabsContent value="history" className="mt-6">
          <ResumeHistory />
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <ResumeAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
}