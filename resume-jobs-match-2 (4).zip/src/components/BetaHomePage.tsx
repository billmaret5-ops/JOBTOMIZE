import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Briefcase, Brain, FileText, Target, Mail, Video, MessageSquare, TrendingUp, CheckCircle, Sparkles, Users } from 'lucide-react';

export function BetaHomePage() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      {/* Hero Section */}
      <section className="py-20 px-4">
        <div className="container mx-auto max-w-6xl text-center">
          <div className="inline-flex items-center gap-2 bg-blue-100 text-blue-700 px-4 py-2 rounded-full mb-6">
            <Sparkles className="w-4 h-4" />
            <span className="text-sm font-semibold">BETA ACCESS - You're In!</span>
          </div>
          
          <h1 className="text-6xl font-bold text-gray-900 mb-6 leading-tight">
            Welcome to <span className="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">AI JobMatch Pro</span>
          </h1>
          
          <p className="text-2xl text-gray-600 mb-8 max-w-4xl mx-auto">
            Your AI-powered job search platform that finds opportunities, optimizes resumes, 
            and helps you land interviews faster.
          </p>

          <div className="flex items-center justify-center gap-4 mb-12">
            <Button size="lg" className="px-8 py-6 text-lg bg-gradient-to-r from-blue-600 to-purple-600">
              <Brain className="mr-2 w-5 h-5" />
              Explore Features
            </Button>
            <Button size="lg" variant="outline" className="px-8 py-6 text-lg">
              <Users className="mr-2 w-5 h-5" />
              Give Feedback
            </Button>
          </div>

          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {[
              { icon: Target, value: '10+', label: 'Daily Matches' },
              { icon: TrendingUp, value: '94%', label: 'ATS Pass Rate' },
              { icon: CheckCircle, value: '3.2x', label: 'More Interviews' },
              { icon: Sparkles, value: 'AI', label: 'Powered' }
            ].map((stat, i) => (
              <Card key={i} className="p-6 text-center border-2 hover:border-blue-300 transition-all">
                <stat.icon className="w-8 h-8 text-blue-600 mx-auto mb-3" />
                <div className="text-3xl font-bold text-gray-900">{stat.value}</div>
                <div className="text-sm text-gray-600">{stat.label}</div>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-16 px-4 bg-white">
        <div className="container mx-auto max-w-6xl">
          <h2 className="text-4xl font-bold text-center mb-12">Platform Features</h2>
          
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: Brain, title: 'AI Job Matching', desc: 'Smart algorithms find your perfect roles', color: 'blue' },
              { icon: FileText, title: 'Resume Builder', desc: 'ATS-optimized resume generation', color: 'purple' },
              { icon: Target, title: 'Application Tracker', desc: 'Manage all applications in one place', color: 'green' },
              { icon: MessageSquare, title: 'Cover Letters', desc: 'AI-generated personalized letters', color: 'orange' },
              { icon: Video, title: 'Interview Prep', desc: 'Practice with AI coaching', color: 'red' },
              { icon: Mail, title: 'Email Campaigns', desc: 'Automated follow-up sequences', color: 'indigo' }
            ].map((feature, i) => (
              <Card key={i} className="p-6 hover:shadow-xl transition-all border-2 hover:border-blue-200">
                <div className={`w-12 h-12 bg-${feature.color}-100 rounded-xl flex items-center justify-center mb-4`}>
                  <feature.icon className={`w-6 h-6 text-${feature.color}-600`} />
                </div>
                <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
                <p className="text-gray-600">{feature.desc}</p>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
