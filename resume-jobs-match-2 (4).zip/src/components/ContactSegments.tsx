import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Users, Plus, Filter, Zap, MoreHorizontal, Trash2, Edit } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Segment {
  id: string;
  name: string;
  description: string;
  contact_count: number;
  is_dynamic: boolean;
  conditions: any;
  created_at: string;
  last_calculated_at?: string;
}

export function ContactSegments() {
  const [segments, setSegments] = useState<Segment[]>([]);
  const [loading, setLoading] = useState(false);
  const [showCreateDialog, setShowCreateDialog] = useState(false);

  useEffect(() => {
    loadSegments();
  }, []);

  const loadSegments = async () => {
    setLoading(true);
    // Mock segment data
    const mockSegments: Segment[] = [
      {
        id: '1',
        name: 'High-Value Leads',
        description: 'Leads with score > 80 and recent activity',
        contact_count: 245,
        is_dynamic: true,
        conditions: { lead_score: { gte: 80 }, last_activity: { within: '30d' } },
        created_at: '2024-01-10T10:00:00Z',
        last_calculated_at: '2024-01-15T12:00:00Z'
      },
      {
        id: '2',
        name: 'Enterprise Prospects',
        description: 'Contacts from companies with 1000+ employees',
        contact_count: 89,
        is_dynamic: true,
        conditions: { company_size: { gte: 1000 } },
        created_at: '2024-01-08T14:30:00Z',
        last_calculated_at: '2024-01-15T12:00:00Z'
      },
      {
        id: '3',
        name: 'Newsletter subscribers',
        description: 'Manually curated list of newsletter subscribers',
        contact_count: 1250,
        is_dynamic: false,
        conditions: {},
        created_at: '2024-01-05T09:15:00Z'
      }
    ];
    setSegments(mockSegments);
    setLoading(false);
  };

  const handleCreateSegment = () => {
    // Implementation for creating new segment
    setShowCreateDialog(false);
  };

  const handleDeleteSegment = (segmentId: string) => {
    setSegments(segments.filter(s => s.id !== segmentId));
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {[...Array(6)].map((_, i) => (
          <Card key={i}>
            <CardContent className="p-6">
              <div className="space-y-4">
                <div className="h-4 bg-gray-200 rounded animate-pulse" />
                <div className="h-3 bg-gray-200 rounded w-2/3 animate-pulse" />
                <div className="h-8 bg-gray-200 rounded animate-pulse" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Contact Segments</h2>
          <p className="text-muted-foreground">Organize contacts into targeted segments</p>
        </div>
        <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Create Segment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Create New Segment</DialogTitle>
            </DialogHeader>
            <CreateSegmentForm onSubmit={handleCreateSegment} />
          </DialogContent>
        </Dialog>
      </div>

      {/* Segments Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {segments.map((segment) => (
          <Card key={segment.id} className="hover:shadow-md transition-shadow">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-blue-500" />
                  <div>
                    <CardTitle className="text-lg">{segment.name}</CardTitle>
                    {segment.is_dynamic && (
                      <Badge variant="secondary" className="mt-1">
                        <Zap className="h-3 w-3 mr-1" />
                        Dynamic
                      </Badge>
                    )}
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem>
                      <Edit className="h-4 w-4 mr-2" />
                      Edit
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Filter className="h-4 w-4 mr-2" />
                      View Contacts
                    </DropdownMenuItem>
                    <DropdownMenuItem 
                      className="text-red-600"
                      onClick={() => handleDeleteSegment(segment.id)}
                    >
                      <Trash2 className="h-4 w-4 mr-2" />
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                {segment.description}
              </p>
              
              <div className="space-y-3">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">Contacts</span>
                  <Badge variant="outline">
                    {segment.contact_count.toLocaleString()}
                  </Badge>
                </div>
                
                <div className="text-xs text-muted-foreground">
                  <div>Created: {formatDate(segment.created_at)}</div>
                  {segment.last_calculated_at && (
                    <div>Updated: {formatDate(segment.last_calculated_at)}</div>
                  )}
                </div>
              </div>
              
              <div className="mt-4 pt-4 border-t">
                <Button variant="outline" size="sm" className="w-full">
                  View Contacts
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}

function CreateSegmentForm({ onSubmit }: { onSubmit: () => void }) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    type: 'dynamic',
    conditions: []
  });

  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="space-y-2">
          <Label htmlFor="name">Segment Name</Label>
          <Input
            id="name"
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="Enter segment name"
          />
        </div>
        <div className="space-y-2">
          <Label htmlFor="type">Type</Label>
          <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="dynamic">Dynamic</SelectItem>
              <SelectItem value="static">Static</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>
      
      <div className="space-y-2">
        <Label htmlFor="description">Description</Label>
        <Textarea
          id="description"
          value={formData.description}
          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
          placeholder="Describe this segment"
          rows={3}
        />
      </div>

      {formData.type === 'dynamic' && (
        <div className="space-y-2">
          <Label>Conditions</Label>
          <div className="p-4 border rounded-lg bg-muted/50">
            <p className="text-sm text-muted-foreground">
              Condition builder will be implemented here
            </p>
          </div>
        </div>
      )}

      <div className="flex justify-end gap-2">
        <Button variant="outline">Cancel</Button>
        <Button onClick={onSubmit}>Create Segment</Button>
      </div>
    </div>
  );
}