import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { PieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, BarChart, Bar, XAxis, YAxis, CartesianGrid } from 'recharts';
import { backupCostAnalysisService, BackupTypeCost } from '@/services/backupCostAnalysisService';

const COLORS = ['#3b82f6', '#10b981', '#f59e0b'];

export const BackupCostBreakdown: React.FC = () => {
  const [typeCosts, setTypeCosts] = useState<BackupTypeCost[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const costs = await backupCostAnalysisService.getBackupTypeCosts();
    setTypeCosts(costs);
  };

  return (
    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
      <Card>
        <CardHeader>
          <CardTitle>Cost by Backup Type</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <PieChart>
              <Pie data={typeCosts} dataKey="cost" nameKey="type" cx="50%" cy="50%" outerRadius={80} label>
                {typeCosts.map((_, index) => (
                  <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                ))}
              </Pie>
              <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
              <Legend />
            </PieChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Storage by Backup Type</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={typeCosts}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="type" />
              <YAxis />
              <Tooltip />
              <Bar dataKey="storageGB" fill="#3b82f6" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle>Cost Details</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {typeCosts.map((cost) => (
              <div key={cost.type} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-semibold capitalize">{cost.type} Backups</p>
                  <p className="text-sm text-gray-600">{cost.count} backups • {cost.storageGB.toFixed(0)} GB</p>
                </div>
                <div className="text-right">
                  <p className="text-2xl font-bold">${cost.cost.toFixed(2)}</p>
                  <p className="text-sm text-gray-600">{cost.percentage.toFixed(1)}% of total</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
