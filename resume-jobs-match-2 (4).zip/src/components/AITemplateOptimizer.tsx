import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, Loader2 } from 'lucide-react';
import { aiTemplateOptimizationService, OptimizationSuggestion } from '@/services/aiTemplateOptimizationService';
import { TemplateSentimentAnalyzer } from './TemplateSentimentAnalyzer';
import { TemplateReadabilityScorer } from './TemplateReadabilityScorer';
import { ATSKeywordOptimizer } from './ATSKeywordOptimizer';
import { AISubjectLineGenerator } from './AISubjectLineGenerator';
import { TemplateBeforeAfterComparison } from './TemplateBeforeAfterComparison';
import { TemplatePredictiveAnalytics } from './TemplatePredictiveAnalytics';

interface Props {
  templateId: string;
  content: string;
  subject: string;
  position?: string;
  company?: string;
  onOptimize?: (optimizedContent: string, optimizedSubject: string) => void;
}

export const AITemplateOptimizer: React.FC<Props> = ({
  templateId,
  content,
  subject,
  position = 'Software Engineer',
  company = 'Tech Company',
  onOptimize
}) => {
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [optimizedContent, setOptimizedContent] = useState(content);
  const [optimizedSubject, setOptimizedSubject] = useState(subject);

  const runAnalysis = async () => {
    setAnalyzing(true);
    try {
      const result = await aiTemplateOptimizationService.analyzeTemplate(templateId, content, subject);
      const prediction = await aiTemplateOptimizationService.predictPerformance(templateId, result.suggestions);
      setAnalysis({ ...result, prediction });
    } catch (error) {
      console.error('Analysis error:', error);
    } finally {
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    runAnalysis();
  }, [templateId, content]);

  const applyOptimizations = () => {
    onOptimize?.(optimizedContent, optimizedSubject);
  };

  if (analyzing) {
    return (
      <Card>
        <CardContent className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-blue-500" />
          <p className="ml-3 text-gray-600">Analyzing template with AI...</p>
        </CardContent>
      </Card>
    );
  }

  if (!analysis) return null;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-purple-500" />
              AI Template Optimizer
            </div>
            <Button onClick={applyOptimizations}>
              Apply Optimizations
            </Button>
          </CardTitle>
        </CardHeader>
      </Card>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="sentiment">Sentiment</TabsTrigger>
          <TabsTrigger value="readability">Readability</TabsTrigger>
          <TabsTrigger value="ats">ATS Keywords</TabsTrigger>
          <TabsTrigger value="predictions">Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <TemplateBeforeAfterComparison
            before={{
              content,
              sentimentScore: analysis.sentiment.score * 100,
              readabilityScore: analysis.readability.score,
              atsScore: analysis.atsKeywords.score
            }}
            after={{
              content: optimizedContent,
              sentimentScore: Math.min(100, analysis.sentiment.score * 100 + 15),
              readabilityScore: Math.min(100, analysis.readability.score + 12),
              atsScore: Math.min(100, analysis.atsKeywords.score + 20)
            }}
          />
          <AISubjectLineGenerator 
            position={position} 
            company={company}
            onSelect={setOptimizedSubject}
          />
        </TabsContent>

        <TabsContent value="sentiment">
          <TemplateSentimentAnalyzer sentiment={analysis.sentiment} />
        </TabsContent>

        <TabsContent value="readability">
          <TemplateReadabilityScorer readability={analysis.readability} />
        </TabsContent>

        <TabsContent value="ats">
          <ATSKeywordOptimizer 
            analysis={analysis.atsKeywords}
            onAddKeyword={(keyword) => {
              setOptimizedContent(prev => prev + ` ${keyword}`);
            }}
          />
        </TabsContent>

        <TabsContent value="predictions">
          <TemplatePredictiveAnalytics
            currentPerformance={analysis.prediction.current}
            predictedPerformance={analysis.prediction.predicted}
            historicalData={{
              avgOpenRate: 68,
              avgResponseRate: 24,
              avgTimeToResponse: 48,
              totalSent: 1247
            }}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};
