import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { RefreshCw, Activity, Calendar, TestTube, AlertTriangle } from 'lucide-react';
import JobMatchingPerformanceMonitor from './JobMatchingPerformanceMonitor';
import JobMatchingRetrainingScheduler from './JobMatchingRetrainingScheduler';
import JobMatchingModelABTest from './JobMatchingModelABTest';

export default function AutomatedJobMatchingRetrainingDashboard() {
  const [recentJobs, setRecentJobs] = useState([
    { id: '1', type: 'Scheduled', status: 'completed', trigger: 'Daily retraining', time: '2025-10-25 02:00', accuracy: 0.89 },
    { id: '2', type: 'Threshold', status: 'running', trigger: 'Accuracy dropped to 0.78', time: '2025-10-25 14:30', accuracy: null },
    { id: '3', type: 'Manual', status: 'completed', trigger: 'User initiated', time: '2025-10-24 16:45', accuracy: 0.87 }
  ]);

  const [alerts, setAlerts] = useState([
    { id: '1', severity: 'warning', message: 'Model accuracy below 0.85 threshold', time: '2 hours ago' },
    { id: '2', severity: 'info', message: 'Scheduled retraining completed successfully', time: '12 hours ago' }
  ]);

  const triggerManualRetraining = () => {
    setRecentJobs([{
      id: Date.now().toString(),
      type: 'Manual',
      status: 'running',
      trigger: 'User initiated',
      time: new Date().toISOString(),
      accuracy: null
    }, ...recentJobs]);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Automated ML Retraining</h1>
          <p className="text-muted-foreground">Monitor and manage job matching model retraining</p>
        </div>
        <Button onClick={triggerManualRetraining}>
          <RefreshCw className="h-4 w-4 mr-2" />
          Trigger Retraining
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active Models</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">2 in production</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Retraining Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">24</div>
            <p className="text-xs text-muted-foreground">Last 7 days</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Avg Accuracy</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">89.2%</div>
            <p className="text-xs text-green-600">+2.1% from last week</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Active A/B Tests</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">2</div>
            <p className="text-xs text-muted-foreground">1 ready to deploy</p>
          </CardContent>
        </Card>
      </div>

      {alerts.length > 0 && (
        <Card className="border-yellow-200 bg-yellow-50">
          <CardHeader>
            <CardTitle className="text-sm flex items-center gap-2">
              <AlertTriangle className="h-4 w-4" />
              Recent Alerts
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {alerts.map(alert => (
                <div key={alert.id} className="flex items-center justify-between text-sm">
                  <span>{alert.message}</span>
                  <span className="text-muted-foreground">{alert.time}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="monitor" className="space-y-4">
        <TabsList>
          <TabsTrigger value="monitor"><Activity className="h-4 w-4 mr-2" />Monitor</TabsTrigger>
          <TabsTrigger value="schedule"><Calendar className="h-4 w-4 mr-2" />Schedule</TabsTrigger>
          <TabsTrigger value="abtest"><TestTube className="h-4 w-4 mr-2" />A/B Tests</TabsTrigger>
          <TabsTrigger value="history"><RefreshCw className="h-4 w-4 mr-2" />History</TabsTrigger>
        </TabsList>

        <TabsContent value="monitor">
          <JobMatchingPerformanceMonitor />
        </TabsContent>

        <TabsContent value="schedule">
          <JobMatchingRetrainingScheduler />
        </TabsContent>

        <TabsContent value="abtest">
          <JobMatchingModelABTest />
        </TabsContent>

        <TabsContent value="history">
          <Card>
            <CardHeader>
              <CardTitle>Retraining History</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {recentJobs.map(job => (
                  <div key={job.id} className="flex items-center justify-between p-3 border rounded">
                    <div>
                      <Badge variant={job.status === 'completed' ? 'default' : 'secondary'}>{job.type}</Badge>
                      <span className="ml-2 text-sm">{job.trigger}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm">{job.time}</div>
                      {job.accuracy && <div className="text-xs text-muted-foreground">Accuracy: {(job.accuracy * 100).toFixed(1)}%</div>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
