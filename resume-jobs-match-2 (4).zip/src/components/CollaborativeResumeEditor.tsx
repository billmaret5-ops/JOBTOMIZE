import React, { useRef, useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { UserPresenceIndicator } from './collaboration/UserPresenceIndicator';
import { LiveCursorOverlay } from './collaboration/LiveCursorOverlay';
import { CommentSystem } from './collaboration/CommentSystem';
import { ChangeTracker } from './collaboration/ChangeTracker';
import { useRealTimeCollaboration } from '../hooks/useRealTimeCollaboration';
import { Save, Users, MessageSquare, Activity } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface CollaborativeResumeEditorProps {
  resumeId: string;
  userId: string;
  initialContent?: string;
}

export const CollaborativeResumeEditor: React.FC<CollaborativeResumeEditorProps> = ({
  resumeId,
  userId,
  initialContent = ''
}) => {
  const [content, setContent] = useState(initialContent);
  const [showSidebar, setShowSidebar] = useState(true);
  const editorRef = useRef<HTMLTextAreaElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  const {
    users,
    cursors,
    comments,
    activities,
    isConnected,
    sendOperation,
    updateCursor,
    addComment
  } = useRealTimeCollaboration(resumeId, userId);

  const handleContentChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    const newContent = e.target.value;
    const cursorPos = e.target.selectionStart;
    
    setContent(newContent);
    
    // Send operation
    sendOperation({
      type: 'insert',
      position: cursorPos,
      text: newContent,
      userId,
      timestamp: Date.now()
    });
  };

  const handleCursorMove = () => {
    if (editorRef.current) {
      updateCursor(editorRef.current.selectionStart);
    }
  };

  const handleSave = async () => {
    // Save to backend
    console.log('Saving resume:', content);
  };

  return (
    <div className="flex gap-4 h-screen p-4">
      <div className="flex-1 space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Resume Editor</CardTitle>
              <div className="flex items-center gap-4">
                <UserPresenceIndicator users={users} />
                <div className="flex items-center gap-2">
                  {isConnected ? (
                    <span className="flex items-center gap-2 text-sm text-green-600">
                      <span className="w-2 h-2 bg-green-600 rounded-full animate-pulse" />
                      Connected
                    </span>
                  ) : (
                    <span className="text-sm text-red-600">Disconnected</span>
                  )}
                </div>
                <Button onClick={handleSave}>
                  <Save className="w-4 h-4 mr-2" />
                  Save
                </Button>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div ref={containerRef} className="relative">
              <Textarea
                ref={editorRef}
                value={content}
                onChange={handleContentChange}
                onSelect={handleCursorMove}
                onClick={handleCursorMove}
                onKeyUp={handleCursorMove}
                className="min-h-[600px] font-mono"
                placeholder="Start writing your resume..."
              />
              <LiveCursorOverlay 
                cursors={cursors} 
                users={users}
                containerRef={containerRef}
              />
            </div>
          </CardContent>
        </Card>
      </div>

      {showSidebar && (
        <div className="w-96">
          <Tabs defaultValue="comments">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="comments">
                <MessageSquare className="w-4 h-4 mr-2" />
                Comments
              </TabsTrigger>
              <TabsTrigger value="activity">
                <Activity className="w-4 h-4 mr-2" />
                Activity
              </TabsTrigger>
            </TabsList>
            <TabsContent value="comments">
              <CommentSystem
                comments={comments}
                users={users}
                onAddComment={addComment}
              />
            </TabsContent>
            <TabsContent value="activity">
              <ChangeTracker activities={activities} users={users} />
            </TabsContent>
          </Tabs>
        </div>
      )}
    </div>
  );
};
