import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ConversionFunnelChart } from '@/components/analytics/ConversionFunnelChart';
import { TemplatePerformanceMetrics } from '@/components/analytics/TemplatePerformanceMetrics';
import { TemplateComparisonChart } from '@/components/analytics/TemplateComparisonChart';
import { TemplateROICalculator } from '@/components/TemplateROICalculator';
import { TemplateImpactChart } from '@/components/TemplateImpactChart';
import { IndustryBenchmarkComparison } from '@/components/IndustryBenchmarkComparison';
import { AnalyticsFilters } from '@/components/analytics/AnalyticsFilters';
import { ExportManager } from '@/components/analytics/ExportManager';
import { templateAnalyticsService } from '@/services/templateAnalyticsService';
import { BarChart3 } from 'lucide-react';

export const ComprehensiveTemplateAnalyticsDashboard: React.FC = () => {
  const [filters, setFilters] = React.useState<any>({});
  const [loading, setLoading] = React.useState(false);

  // Sample data
  const funnelData = [
    { name: 'Emails Sent', count: 1250, percentage: 100 },
    { name: 'Emails Opened', count: 900, percentage: 72 },
    { name: 'Links Clicked', count: 405, percentage: 32 },
    { name: 'Responses Received', count: 350, percentage: 28 },
  ];

  const metrics = {
    sent: 1250,
    openRate: 72,
    clickRate: 45,
    responseRate: 28,
  };

  const changes = {
    sent: 15,
    openRate: 8,
    clickRate: 12,
    responseRate: 5,
  };

  const templates = [
    { id: '1', name: 'Software Engineer Template', openRate: 75, clickRate: 48, responseRate: 32 },
    { id: '2', name: 'Marketing Manager Template', openRate: 68, clickRate: 42, responseRate: 25 },
    { id: '3', name: 'Data Analyst Template', openRate: 72, clickRate: 45, responseRate: 28 },
  ];

  const roiData = {
    timeSaved: 120,
    responseRate: 28,
    interviewsScheduled: 15,
    estimatedValue: 4500,
    roi: 340,
  };

  const cohortData = [
    { cohort: 'Week 1', templates: 45, avgOpenRate: 68, avgResponseRate: 24, retention: 89 },
    { cohort: 'Week 2', templates: 52, avgOpenRate: 72, avgResponseRate: 28, retention: 92 },
    { cohort: 'Week 3', templates: 48, avgOpenRate: 70, avgResponseRate: 26, retention: 87 },
    { cohort: 'Week 4', templates: 55, avgOpenRate: 75, avgResponseRate: 31, retention: 94 },
  ];

  const geographicData = [
    { location: 'United States', sent: 1250, openRate: 72, responseRate: 28 },
    { location: 'United Kingdom', sent: 680, openRate: 68, responseRate: 25 },
    { location: 'Canada', sent: 420, openRate: 70, responseRate: 27 },
  ];

  const benchmarks = [
    { industry: 'Technology', avgOpenRate: 72, avgResponseRate: 28, avgClickRate: 45 },
    { industry: 'Finance', avgOpenRate: 68, avgResponseRate: 25, avgClickRate: 42 },
    { industry: 'Healthcare', avgOpenRate: 70, avgResponseRate: 26, avgClickRate: 43 },
  ];

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold flex items-center gap-2">
            <BarChart3 className="h-8 w-8" />
            Template Analytics Dashboard
          </h1>
          <p className="text-muted-foreground mt-1">
            Comprehensive performance metrics and insights
          </p>
        </div>
      </div>

      <AnalyticsFilters onFilterChange={setFilters} />

      <TemplatePerformanceMetrics metrics={metrics} changes={changes} />

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <ConversionFunnelChart data={funnelData} />
        </div>
        <ExportManager data={funnelData} templateName="template-analytics" />
      </div>

      <Tabs defaultValue="comparison" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
          <TabsTrigger value="roi">ROI Analysis</TabsTrigger>
          <TabsTrigger value="impact">Impact</TabsTrigger>
          <TabsTrigger value="benchmarks">Benchmarks</TabsTrigger>
        </TabsList>

        <TabsContent value="comparison">
          <TemplateComparisonChart templates={templates} />
        </TabsContent>

        <TabsContent value="roi">
          <TemplateROICalculator data={roiData} />
        </TabsContent>

        <TabsContent value="impact">
          <TemplateImpactChart cohortData={cohortData} geographicData={geographicData} />
        </TabsContent>

        <TabsContent value="benchmarks">
          <IndustryBenchmarkComparison
            benchmarks={benchmarks}
            userMetrics={metrics}
            userIndustry="Technology"
          />
        </TabsContent>
      </Tabs>
    </div>
  );
};
