import React from 'react';
import { EmailComponent } from './DragDropEmailBuilder';

interface EmailPreviewProps {
  components: EmailComponent[];
  mode: 'desktop' | 'tablet' | 'mobile';
}

export const EmailPreview: React.FC<EmailPreviewProps> = ({ components, mode }) => {
  const getPreviewWidth = () => {
    switch (mode) {
      case 'desktop':
        return '600px';
      case 'tablet':
        return '480px';
      case 'mobile':
        return '320px';
      default:
        return '600px';
    }
  };

  const renderComponent = (component: EmailComponent) => {
    switch (component.type) {
      case 'header':
        return (
          <div 
            style={{
              backgroundColor: component.styles.backgroundColor,
              padding: component.styles.padding,
              textAlign: component.styles.textAlign
            }}
          >
            <h1 style={{
              color: component.styles.titleColor,
              fontSize: component.styles.titleSize,
              margin: '0 0 8px 0',
              fontWeight: 'bold',
              fontFamily: 'Arial, sans-serif'
            }}>
              {component.content.title}
            </h1>
            {component.content.subtitle && (
              <p style={{
                color: component.styles.subtitleColor,
                fontSize: component.styles.subtitleSize,
                margin: 0,
                fontFamily: 'Arial, sans-serif'
              }}>
                {component.content.subtitle}
              </p>
            )}
          </div>
        );
      
      case 'text':
        return (
          <div style={{
            padding: component.styles.padding,
            fontSize: component.styles.fontSize,
            color: component.styles.color,
            lineHeight: component.styles.lineHeight,
            textAlign: component.styles.textAlign,
            fontFamily: 'Arial, sans-serif'
          }}>
            {component.content.text.split('\n').map((line: string, index: number) => (
              <React.Fragment key={index}>
                {line}
                {index < component.content.text.split('\n').length - 1 && <br />}
              </React.Fragment>
            ))}
          </div>
        );
      
      case 'button':
        return (
          <div style={{ textAlign: component.styles.textAlign, margin: component.styles.margin }}>
            <table cellPadding="0" cellSpacing="0" style={{ margin: '0 auto' }}>
              <tbody>
                <tr>
                  <td
                    style={{
                      backgroundColor: component.styles.backgroundColor,
                      borderRadius: component.styles.borderRadius,
                      padding: component.styles.padding
                    }}
                  >
                    <a
                      href={component.content.url}
                      style={{
                        color: component.styles.color,
                        fontSize: component.styles.fontSize,
                        textDecoration: 'none',
                        fontWeight: 'bold',
                        fontFamily: 'Arial, sans-serif',
                        display: 'block'
                      }}
                    >
                      {component.content.text}
                    </a>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      
      case 'image':
        return (
          <div style={{ textAlign: 'center', margin: component.styles.margin }}>
            {component.content.src ? (
              component.content.url ? (
                <a href={component.content.url}>
                  <img
                    src={component.content.src}
                    alt={component.content.alt}
                    style={{
                      width: component.styles.width,
                      maxWidth: component.styles.maxWidth,
                      height: component.styles.height,
                      display: 'block',
                      margin: '0 auto'
                    }}
                  />
                </a>
              ) : (
                <img
                  src={component.content.src}
                  alt={component.content.alt}
                  style={{
                    width: component.styles.width,
                    maxWidth: component.styles.maxWidth,
                    height: component.styles.height,
                    display: 'block',
                    margin: '0 auto'
                  }}
                />
              )
            ) : (
              <div 
                style={{
                  width: '100%',
                  height: '200px',
                  backgroundColor: '#f3f4f6',
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                  border: '2px dashed #d1d5db',
                  color: '#6b7280',
                  fontFamily: 'Arial, sans-serif'
                }}
              >
                [Image Placeholder]
              </div>
            )}
          </div>
        );
      
      case 'spacer':
        return (
          <div style={{ height: `${component.content.height}px`, lineHeight: '1px', fontSize: '1px' }}>
            &nbsp;
          </div>
        );
      
      case 'divider':
        return (
          <div style={{ padding: '10px 20px' }}>
            <table cellPadding="0" cellSpacing="0" style={{ width: '100%' }}>
              <tbody>
                <tr>
                  <td style={{
                    borderTop: `1px ${component.content.style} ${component.content.color}`,
                    fontSize: '1px',
                    lineHeight: '1px'
                  }}>
                    &nbsp;
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
        );
      
      default:
        return <div>Unknown component</div>;
    }
  };

  return (
    <div className="flex justify-center">
      <div 
        className="bg-white shadow-lg rounded-lg overflow-hidden"
        style={{ 
          width: getPreviewWidth(),
          maxWidth: '100%',
          fontFamily: 'Arial, sans-serif'
        }}
      >
        <table 
          cellPadding="0" 
          cellSpacing="0" 
          style={{ 
            width: '100%', 
            backgroundColor: '#ffffff',
            fontFamily: 'Arial, sans-serif'
          }}
        >
          <tbody>
            {components.map((component) => (
              <tr key={component.id}>
                <td style={{ padding: 0 }}>
                  {renderComponent(component)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
        
        {components.length === 0 && (
          <div style={{ 
            padding: '60px 20px', 
            textAlign: 'center', 
            color: '#6b7280',
            fontFamily: 'Arial, sans-serif'
          }}>
            <p style={{ margin: 0, fontSize: '16px' }}>
              Your email preview will appear here
            </p>
            <p style={{ margin: '8px 0 0 0', fontSize: '14px' }}>
              Add components to see the preview
            </p>
          </div>
        )}
      </div>
    </div>
  );
};