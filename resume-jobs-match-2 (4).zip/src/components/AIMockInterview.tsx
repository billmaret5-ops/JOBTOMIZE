import { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Mic, MicOff, Video, VideoOff, Send, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { interviewPrepService } from '@/services/interviewPrepService';

interface Props {
  question: any;
  onComplete?: (feedback: any) => void;
}

export default function AIMockInterview({ question, onComplete }: Props) {
  const [recording, setRecording] = useState(false);
  const [videoEnabled, setVideoEnabled] = useState(false);
  const [answer, setAnswer] = useState('');
  const [transcript, setTranscript] = useState('');
  const [evaluating, setEvaluating] = useState(false);
  const [feedback, setFeedback] = useState<any>(null);
  const [sessionId, setSessionId] = useState<string>('');
  
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const videoRef = useRef<HTMLVideoElement>(null);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    createSession();
    setupSpeechRecognition();
  }, []);

  const createSession = async () => {
    const session = await interviewPrepService.createSession({
      session_type: 'mock_interview',
      question_id: question.id,
      company_name: question.company_name,
      role_type: question.role_type,
    });
    setSessionId(session.id);
  };

  const setupSpeechRecognition = () => {
    if ('webkitSpeechRecognition' in window) {
      const recognition = new (window as any).webkitSpeechRecognition();
      recognition.continuous = true;
      recognition.interimResults = true;
      
      recognition.onresult = (event: any) => {
        let interim = '';
        let final = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const transcript = event.results[i][0].transcript;
          if (event.results[i].isFinal) {
            final += transcript + ' ';
          } else {
            interim += transcript;
          }
        }
        
        setTranscript(prev => prev + final);
        setAnswer(prev => prev + final);
      };
      
      recognitionRef.current = recognition;
    }
  };

  const toggleRecording = async () => {
    if (recording) {
      recognitionRef.current?.stop();
      mediaRecorderRef.current?.stop();
      setRecording(false);
    } else {
      recognitionRef.current?.start();
      setRecording(true);
      
      if (videoEnabled) {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
        if (videoRef.current) videoRef.current.srcObject = stream;
        
        const recorder = new MediaRecorder(stream);
        mediaRecorderRef.current = recorder;
        recorder.start();
      }
    }
  };

  const toggleVideo = async () => {
    if (videoEnabled) {
      const stream = videoRef.current?.srcObject as MediaStream;
      stream?.getTracks().forEach(track => track.stop());
      setVideoEnabled(false);
    } else {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true });
      if (videoRef.current) videoRef.current.srcObject = stream;
      setVideoEnabled(true);
    }
  };

  const submitAnswer = async () => {
    setEvaluating(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-interview-coach', {
        body: {
          answer: answer || transcript,
          question: question.question_text,
          questionType: question.question_type,
          useSTAR: question.star_framework,
        }
      });

      if (error) throw error;
      
      setFeedback(data.feedback);
      
      await interviewPrepService.updateSession(sessionId, {
        user_answer: answer || transcript,
        transcript,
        ai_feedback: data.feedback,
        score: data.feedback.score,
        completed: true,
        completed_at: new Date().toISOString(),
      });
      
      onComplete?.(data.feedback);
    } catch (error) {
      console.error('Error:', error);
    } finally {
      setEvaluating(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>{question.question_text}</CardTitle>
          <div className="flex gap-2">
            <Badge>{question.company_name}</Badge>
            <Badge variant="secondary">{question.question_type}</Badge>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          {videoEnabled && (
            <video ref={videoRef} autoPlay muted className="w-full rounded-lg bg-black" />
          )}
          
          <div className="flex gap-2">
            <Button onClick={toggleRecording} variant={recording ? 'destructive' : 'default'}>
              {recording ? <MicOff className="mr-2 h-4 w-4" /> : <Mic className="mr-2 h-4 w-4" />}
              {recording ? 'Stop Recording' : 'Start Recording'}
            </Button>
            <Button onClick={toggleVideo} variant="outline">
              {videoEnabled ? <VideoOff className="mr-2 h-4 w-4" /> : <Video className="mr-2 h-4 w-4" />}
              {videoEnabled ? 'Disable Video' : 'Enable Video'}
            </Button>
          </div>

          <Textarea
            placeholder="Your answer (or use voice recording)..."
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            rows={6}
          />

          <Button onClick={submitAnswer} disabled={evaluating || !answer} className="w-full">
            {evaluating ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : <Send className="mr-2 h-4 w-4" />}
            Submit Answer
          </Button>
        </CardContent>
      </Card>

      {feedback && (
        <Card>
          <CardHeader>
            <CardTitle>AI Feedback</CardTitle>
            <Badge variant={feedback.score >= 80 ? 'default' : 'secondary'}>
              Score: {feedback.score}/100
            </Badge>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <h4 className="font-semibold mb-2">Strengths:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {feedback.strengths?.map((s: string, i: number) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-2">Areas for Improvement:</h4>
              <ul className="list-disc pl-5 space-y-1">
                {feedback.improvements?.map((imp: string, i: number) => (
                  <li key={i}>{imp}</li>
                ))}
              </ul>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}