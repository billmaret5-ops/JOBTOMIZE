import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Mail, CheckCircle, XCircle, Calendar, FileText } from 'lucide-react';

interface ParsedEmail {
  id: string;
  subject: string;
  from: string;
  type: 'application' | 'confirmation' | 'interview' | 'rejection' | 'follow_up';
  date: string;
  parsed: {
    company?: string;
    position?: string;
    interviewDate?: string;
    status?: string;
  };
  processed: boolean;
}

export default function EmailParserDashboard() {
  const [emails] = useState<ParsedEmail[]>([
    {
      id: '1',
      subject: 'Application Received - Software Engineer Position',
      from: 'hr@techcorp.com',
      type: 'confirmation',
      date: '2024-01-15',
      parsed: { company: 'TechCorp', position: 'Software Engineer', status: 'received' },
      processed: true
    },
    {
      id: '2',
      subject: 'Interview Invitation - Senior Developer Role',
      from: 'recruiting@startup.io',
      type: 'interview',
      date: '2024-01-14',
      parsed: { company: 'Startup.io', position: 'Senior Developer', interviewDate: '2024-01-20' },
      processed: false
    },
    {
      id: '3',
      subject: 'Thank you for your application',
      from: 'noreply@bigtech.com',
      type: 'rejection',
      date: '2024-01-13',
      parsed: { company: 'BigTech', position: 'Full Stack Developer', status: 'rejected' },
      processed: true
    }
  ]);

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'confirmation': return <CheckCircle className="h-5 w-5 text-green-500" />;
      case 'interview': return <Calendar className="h-5 w-5 text-blue-500" />;
      case 'rejection': return <XCircle className="h-5 w-5 text-red-500" />;
      case 'application': return <FileText className="h-5 w-5 text-purple-500" />;
      default: return <Mail className="h-5 w-5 text-gray-500" />;
    }
  };

  const getTypeBadge = (type: string) => {
    const variants: Record<string, any> = {
      confirmation: 'default',
      interview: 'default',
      rejection: 'destructive',
      application: 'secondary'
    };
    return variants[type] || 'secondary';
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Email Parser</h2>
        <p className="text-muted-foreground">Auto-detected job application emails</p>
      </div>

      <div className="grid grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="text-2xl font-bold">24</div>
          <div className="text-sm text-muted-foreground">Total Parsed</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-green-600">8</div>
          <div className="text-sm text-muted-foreground">Confirmations</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-blue-600">5</div>
          <div className="text-sm text-muted-foreground">Interviews</div>
        </Card>
        <Card className="p-4">
          <div className="text-2xl font-bold text-red-600">3</div>
          <div className="text-sm text-muted-foreground">Rejections</div>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="font-semibold mb-4">Recent Parsed Emails</h3>
        <div className="space-y-3">
          {emails.map((email) => (
            <div key={email.id} className="flex items-start gap-4 p-4 border rounded-lg hover:bg-accent/50 transition-colors">
              <div className="mt-1">{getTypeIcon(email.type)}</div>
              <div className="flex-1 min-w-0">
                <div className="flex items-start justify-between gap-2 mb-2">
                  <div className="flex-1">
                    <h4 className="font-medium truncate">{email.subject}</h4>
                    <p className="text-sm text-muted-foreground">From: {email.from}</p>
                  </div>
                  <Badge variant={getTypeBadge(email.type)}>
                    {email.type}
                  </Badge>
                </div>
                {email.parsed.company && (
                  <div className="flex flex-wrap gap-3 text-sm">
                    <span><strong>Company:</strong> {email.parsed.company}</span>
                    {email.parsed.position && <span><strong>Position:</strong> {email.parsed.position}</span>}
                    {email.parsed.interviewDate && <span><strong>Interview:</strong> {email.parsed.interviewDate}</span>}
                  </div>
                )}
                <div className="flex items-center gap-2 mt-2">
                  <span className="text-xs text-muted-foreground">{email.date}</span>
                  {email.processed && (
                    <Badge variant="outline" className="text-xs">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Processed
                    </Badge>
                  )}
                </div>
              </div>
              {!email.processed && (
                <Button size="sm">Process</Button>
              )}
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
