import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TrendingUp, TrendingDown, Award, AlertCircle, Download } from 'lucide-react';
import { abTestService, ABTest, ABTestVariant, ABTestResult } from '@/services/abTestService';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface ABTestResultsProps {
  test: ABTest;
}

interface VariantMetrics {
  variant: ABTestVariant;
  metrics: {
    open_rate: number;
    click_rate: number;
    conversion_rate: number;
    unsubscribe_rate: number;
  };
  sample_size: number;
  confidence_intervals: {
    [key: string]: [number, number];
  };
  is_significant: boolean;
}

export function ABTestResults({ test }: ABTestResultsProps) {
  const [variants, setVariants] = useState<ABTestVariant[]>([]);
  const [results, setResults] = useState<ABTestResult[]>([]);
  const [variantMetrics, setVariantMetrics] = useState<VariantMetrics[]>([]);
  const [winner, setWinner] = useState<{ winner: ABTestVariant | null; confidence: number; recommendation: string } | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTestData();
  }, [test.id]);

  const loadTestData = async () => {
    try {
      const [variantsData, resultsData, winnerData] = await Promise.all([
        abTestService.getVariants(test.id),
        abTestService.getTestResults(test.id),
        abTestService.getWinnerRecommendation(test.id)
      ]);

      setVariants(variantsData);
      setResults(resultsData);
      setWinner(winnerData);

      // Process metrics for each variant
      const metrics = variantsData.map(variant => {
        const variantResults = resultsData.filter(r => r.variant_id === variant.id);
        const openResult = variantResults.find(r => r.metric_type === 'open_rate');
        const clickResult = variantResults.find(r => r.metric_type === 'click_rate');
        const conversionResult = variantResults.find(r => r.metric_type === 'conversion_rate');
        const unsubscribeResult = variantResults.find(r => r.metric_type === 'unsubscribe_rate');

        return {
          variant,
          metrics: {
            open_rate: openResult?.value || 0,
            click_rate: clickResult?.value || 0,
            conversion_rate: conversionResult?.value || 0,
            unsubscribe_rate: unsubscribeResult?.value || 0
          },
          sample_size: openResult?.sample_size || 0,
          confidence_intervals: {
            open_rate: [openResult?.confidence_interval_lower || 0, openResult?.confidence_interval_upper || 0],
            click_rate: [clickResult?.confidence_interval_lower || 0, clickResult?.confidence_interval_upper || 0],
            conversion_rate: [conversionResult?.confidence_interval_lower || 0, conversionResult?.confidence_interval_upper || 0],
            unsubscribe_rate: [unsubscribeResult?.confidence_interval_lower || 0, unsubscribeResult?.confidence_interval_upper || 0]
          },
          is_significant: clickResult?.statistical_significance || false
        };
      });

      setVariantMetrics(metrics);
    } catch (error) {
      console.error('Failed to load test data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      case 'paused': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const formatPercentage = (value: number) => `${(value * 100).toFixed(2)}%`;

  const exportResults = () => {
    const csvContent = [
      ['Variant', 'Open Rate', 'Click Rate', 'Conversion Rate', 'Unsubscribe Rate', 'Sample Size', 'Significant'],
      ...variantMetrics.map(vm => [
        vm.variant.name,
        formatPercentage(vm.metrics.open_rate),
        formatPercentage(vm.metrics.click_rate),
        formatPercentage(vm.metrics.conversion_rate),
        formatPercentage(vm.metrics.unsubscribe_rate),
        vm.sample_size.toString(),
        vm.is_significant ? 'Yes' : 'No'
      ])
    ].map(row => row.join(',')).join('\n');

    const blob = new Blob([csvContent], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ab-test-results-${test.name}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading test results...</div>;
  }

  const chartData = variantMetrics.map(vm => ({
    name: vm.variant.name,
    'Open Rate': vm.metrics.open_rate * 100,
    'Click Rate': vm.metrics.click_rate * 100,
    'Conversion Rate': vm.metrics.conversion_rate * 100,
    'Sample Size': vm.sample_size
  }));

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>{test.name}</CardTitle>
            <div className="flex items-center space-x-2 mt-2">
              <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
              <Badge variant="outline">{test.test_type.replace('_', ' ')}</Badge>
            </div>
          </div>
          <Button onClick={exportResults} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Results
          </Button>
        </CardHeader>
      </Card>

      {winner && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Award className="h-5 w-5 mr-2 text-yellow-500" />
              Winner Recommendation
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-4">
              <div className="flex-1">
                <p className="text-lg">{winner.recommendation}</p>
                {winner.winner && (
                  <p className="text-sm text-gray-600 mt-2">
                    Confidence: {winner.confidence.toFixed(1)}%
                  </p>
                )}
              </div>
              {winner.confidence < 95 && (
                <AlertCircle className="h-8 w-8 text-yellow-500" />
              )}
            </div>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="detailed">Detailed Metrics</TabsTrigger>
          <TabsTrigger value="confidence">Confidence Intervals</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip formatter={(value: number) => `${value.toFixed(2)}%`} />
                    <Bar dataKey="Open Rate" fill="#8884d8" />
                    <Bar dataKey="Click Rate" fill="#82ca9d" />
                    <Bar dataKey="Conversion Rate" fill="#ffc658" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Sample Size Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={chartData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="name" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="Sample Size" fill="#8884d8" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="detailed">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {variantMetrics.map((vm, index) => (
              <Card key={vm.variant.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle className="text-lg">{vm.variant.name}</CardTitle>
                    <div className="flex items-center space-x-2">
                      {vm.variant.is_control && <Badge variant="secondary">Control</Badge>}
                      {vm.is_significant && <Badge className="bg-green-500">Significant</Badge>}
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Open Rate</span>
                      <span className="font-medium">{formatPercentage(vm.metrics.open_rate)}</span>
                    </div>
                    <Progress value={vm.metrics.open_rate * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Click Rate</span>
                      <span className="font-medium">{formatPercentage(vm.metrics.click_rate)}</span>
                    </div>
                    <Progress value={vm.metrics.click_rate * 100} className="h-2" />
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between">
                      <span className="text-sm">Conversion Rate</span>
                      <span className="font-medium">{formatPercentage(vm.metrics.conversion_rate)}</span>
                    </div>
                    <Progress value={vm.metrics.conversion_rate * 100} className="h-2" />
                  </div>

                  <div className="pt-2 border-t">
                    <div className="flex justify-between text-sm">
                      <span>Sample Size</span>
                      <span>{vm.sample_size.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span>Traffic Split</span>
                      <span>{vm.variant.traffic_percentage}%</span>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="confidence">
          <Card>
            <CardHeader>
              <CardTitle>Confidence Intervals ({(test.confidence_level * 100).toFixed(0)}% Confidence Level)</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {['open_rate', 'click_rate', 'conversion_rate'].map(metric => (
                  <div key={metric} className="space-y-2">
                    <h4 className="font-medium capitalize">{metric.replace('_', ' ')}</h4>
                    <div className="space-y-2">
                      {variantMetrics.map(vm => (
                        <div key={vm.variant.id} className="flex items-center justify-between p-3 border rounded">
                          <span className="font-medium">{vm.variant.name}</span>
                          <div className="text-right">
                            <div className="font-medium">
                              {formatPercentage(vm.metrics[metric as keyof typeof vm.metrics])}
                            </div>
                            <div className="text-sm text-gray-600">
                              CI: [{formatPercentage(vm.confidence_intervals[metric][0])}, {formatPercentage(vm.confidence_intervals[metric][1])}]
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}