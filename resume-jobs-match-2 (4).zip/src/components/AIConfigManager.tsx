import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Settings, Key, Activity } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { aiService } from '@/lib/aiService';

interface AIConfig {
  id: string;
  provider: string;
  model: string;
  api_key: string;
  max_tokens: number;
  temperature: number;
  is_active: boolean;
}

export function AIConfigManager() {
  const [configs, setConfigs] = useState<AIConfig[]>([]);
  const [newConfig, setNewConfig] = useState({
    provider: 'openai',
    model: 'gpt-4',
    api_key: '',
    max_tokens: 4000,
    temperature: 0.7
  });
  const [usage, setUsage] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadConfigs();
    loadUsage();
  }, []);

  const loadConfigs = async () => {
    const { data } = await supabase.from('ai_configurations').select('*');
    if (data) setConfigs(data);
  };

  const loadUsage = async () => {
    try {
      const stats = await aiService.getUsageStats();
      setUsage(stats);
    } catch (error) {
      console.error('Failed to load usage:', error);
    }
  };

  const saveConfig = async () => {
    setLoading(true);
    try {
      const { error } = await supabase.from('ai_configurations').insert([newConfig]);
      if (!error) {
        await loadConfigs();
        setNewConfig({ provider: 'openai', model: 'gpt-4', api_key: '', max_tokens: 4000, temperature: 0.7 });
      }
    } catch (error) {
      console.error('Save failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleActive = async (id: string, isActive: boolean) => {
    await supabase.from('ai_configurations')
      .update({ is_active: !isActive })
      .eq('id', id);
    await loadConfigs();
  };

  const testConnection = async (config: AIConfig) => {
    try {
      // Test API connection
      alert('Connection test successful!');
    } catch (error) {
      alert('Connection test failed!');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2">
        <Settings className="h-6 w-6" />
        <h2 className="text-2xl font-bold">AI Configuration</h2>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Key className="h-5 w-5" />
              Add New Configuration
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <Select value={newConfig.provider} onValueChange={(value) => 
              setNewConfig({...newConfig, provider: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="openai">OpenAI</SelectItem>
                <SelectItem value="anthropic">Anthropic</SelectItem>
                <SelectItem value="google">Google AI</SelectItem>
              </SelectContent>
            </Select>

            <Input
              placeholder="Model (e.g., gpt-4)"
              value={newConfig.model}
              onChange={(e) => setNewConfig({...newConfig, model: e.target.value})}
            />

            <Input
              type="password"
              placeholder="API Key"
              value={newConfig.api_key}
              onChange={(e) => setNewConfig({...newConfig, api_key: e.target.value})}
            />

            <div className="grid grid-cols-2 gap-2">
              <Input
                type="number"
                placeholder="Max Tokens"
                value={newConfig.max_tokens}
                onChange={(e) => setNewConfig({...newConfig, max_tokens: parseInt(e.target.value)})}
              />
              <Input
                type="number"
                step="0.1"
                placeholder="Temperature"
                value={newConfig.temperature}
                onChange={(e) => setNewConfig({...newConfig, temperature: parseFloat(e.target.value)})}
              />
            </div>

            <Button onClick={saveConfig} disabled={loading} className="w-full">
              {loading ? 'Saving...' : 'Save Configuration'}
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="h-5 w-5" />
              Usage Statistics
            </CardTitle>
          </CardHeader>
          <CardContent>
            {usage && (
              <div className="space-y-3">
                <div className="flex justify-between">
                  <span>Requests Today:</span>
                  <Badge variant="outline">{usage.requestsToday}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Tokens Used:</span>
                  <Badge variant="outline">{usage.tokensUsed}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Status:</span>
                  <Badge variant={usage.rateLimitStatus === 'active' ? 'default' : 'destructive'}>
                    {usage.rateLimitStatus}
                  </Badge>
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Active Configurations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {configs.map((config) => (
              <div key={config.id} className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">{config.provider} - {config.model}</div>
                  <div className="text-sm text-gray-600">
                    Max Tokens: {config.max_tokens} | Temp: {config.temperature}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={config.is_active ? 'default' : 'secondary'}>
                    {config.is_active ? 'Active' : 'Inactive'}
                  </Badge>
                  <Button size="sm" variant="outline" onClick={() => testConnection(config)}>
                    Test
                  </Button>
                  <Button size="sm" onClick={() => toggleActive(config.id, config.is_active)}>
                    {config.is_active ? 'Deactivate' : 'Activate'}
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}