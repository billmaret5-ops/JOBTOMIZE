import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Clock, Tag, Database, FileText, TrendingUp, TrendingDown } from 'lucide-react';
import { backupVersioningService, BackupVersion } from '@/services/backupVersioningService';

export function BackupVersionTimeline({ jobId }: { jobId: string }) {
  const [versions, setVersions] = useState<BackupVersion[]>([]);
  const [selectedVersion, setSelectedVersion] = useState<string | null>(null);

  useEffect(() => {
    loadVersions();
  }, [jobId]);

  const loadVersions = async () => {
    const data = await backupVersioningService.getVersions(jobId);
    setVersions(data);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'full': return 'bg-blue-500';
      case 'incremental': return 'bg-green-500';
      case 'differential': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Backup Version Timeline</h3>
      
      <div className="space-y-4">
        {versions.map((version, index) => (
          <div
            key={version.id}
            className={`relative pl-8 pb-8 border-l-2 ${
              selectedVersion === version.id ? 'border-blue-500' : 'border-gray-200'
            }`}
          >
            <div className={`absolute left-[-9px] top-0 w-4 h-4 rounded-full ${getTypeColor(version.backup_type)}`} />
            
            <div
              className={`cursor-pointer p-4 rounded-lg border ${
                selectedVersion === version.id ? 'border-blue-500 bg-blue-50' : 'border-gray-200 hover:border-gray-300'
              }`}
              onClick={() => setSelectedVersion(version.id)}
            >
              <div className="flex items-start justify-between mb-2">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <span className="font-semibold">Version {version.version_number}</span>
                    <Badge variant="outline" className="text-xs">
                      {version.backup_type}
                    </Badge>
                    {version.is_tagged && (
                      <Badge variant="secondary" className="text-xs">
                        <Tag className="w-3 h-3 mr-1" />
                        Tagged
                      </Badge>
                    )}
                  </div>
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    {new Date(version.created_at).toLocaleString()}
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="font-semibold">{formatSize(version.size_bytes)}</div>
                  <div className="flex items-center gap-1 text-sm">
                    {version.size_delta > 0 ? (
                      <>
                        <TrendingUp className="w-3 h-3 text-red-500" />
                        <span className="text-red-500">+{formatSize(version.size_delta)}</span>
                      </>
                    ) : version.size_delta < 0 ? (
                      <>
                        <TrendingDown className="w-3 h-3 text-green-500" />
                        <span className="text-green-500">{formatSize(version.size_delta)}</span>
                      </>
                    ) : (
                      <span className="text-gray-500">No change</span>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex items-center gap-4 text-sm text-gray-600 mb-2">
                <div className="flex items-center gap-1">
                  <FileText className="w-4 h-4" />
                  {version.file_count} files
                </div>
                <div className="flex items-center gap-1">
                  <Database className="w-4 h-4" />
                  {version.retention_policy}
                </div>
              </div>

              <p className="text-sm text-gray-700">{version.change_summary}</p>

              {version.tags.length > 0 && (
                <div className="flex gap-2 mt-2">
                  {version.tags.map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
      </div>

      {versions.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No backup versions found
        </div>
      )}
    </Card>
  );
}
