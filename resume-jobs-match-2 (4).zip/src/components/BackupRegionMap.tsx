import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { backupReplicationService, Region, ReplicationStatus } from '@/services/backupReplicationService';
import { Globe, Server, Activity, AlertCircle, CheckCircle, Clock } from 'lucide-react';

export default function BackupRegionMap() {
  const [regions, setRegions] = useState<Region[]>([]);
  const [replicationStatus, setReplicationStatus] = useState<ReplicationStatus[]>([]);

  useEffect(() => {
    loadData();
    const interval = setInterval(loadData, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadData = async () => {
    const [regionsData, statusData] = await Promise.all([
      backupReplicationService.getRegions(),
      backupReplicationService.getReplicationStatus()
    ]);
    setRegions(regionsData);
    setReplicationStatus(statusData);
  };

  const getRegionBackupCount = (regionId: string) => {
    return replicationStatus.filter(s => 
      s.target_region === regionId && s.status === 'completed'
    ).length;
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="w-5 h-5" />
            Global Backup Distribution
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative bg-slate-50 rounded-lg p-8 h-96">
            {regions.map((region) => {
              const backupCount = getRegionBackupCount(region.id);
              const usagePercent = (region.used / region.capacity) * 100;
              
              return (
                <div
                  key={region.id}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2"
                  style={{
                    left: `${((region.location.lng + 180) / 360) * 100}%`,
                    top: `${((90 - region.location.lat) / 180) * 100}%`
                  }}
                >
                  <div className="relative group">
                    <div className={`w-12 h-12 rounded-full flex items-center justify-center shadow-lg cursor-pointer transition-transform hover:scale-110 ${
                      region.status === 'healthy' ? 'bg-green-500' :
                      region.status === 'degraded' ? 'bg-yellow-500' : 'bg-red-500'
                    }`}>
                      <Server className="w-6 h-6 text-white" />
                    </div>
                    
                    <div className="absolute bottom-full left-1/2 transform -translate-x-1/2 mb-2 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10">
                      <Card className="w-64 shadow-xl">
                        <CardContent className="p-4 space-y-2">
                          <div className="font-semibold">{region.name}</div>
                          <div className="text-sm text-muted-foreground">{region.code}</div>
                          <div className="flex items-center gap-2 text-sm">
                            {region.status === 'healthy' ? <CheckCircle className="w-4 h-4 text-green-500" /> :
                             region.status === 'degraded' ? <AlertCircle className="w-4 h-4 text-yellow-500" /> :
                             <AlertCircle className="w-4 h-4 text-red-500" />}
                            <span className="capitalize">{region.status}</span>
                          </div>
                          <div className="text-sm">
                            <div className="flex justify-between mb-1">
                              <span>Capacity</span>
                              <span>{usagePercent.toFixed(1)}%</span>
                            </div>
                            <div className="w-full bg-gray-200 rounded-full h-2">
                              <div className="bg-blue-500 h-2 rounded-full" style={{ width: `${usagePercent}%` }} />
                            </div>
                          </div>
                          <div className="text-sm">
                            <strong>{backupCount}</strong> backups replicated
                          </div>
                        </CardContent>
                      </Card>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        {regions.map((region) => (
          <Card key={region.id}>
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-2">
                <Badge variant={region.status === 'healthy' ? 'default' : region.status === 'degraded' ? 'secondary' : 'destructive'}>
                  {region.code}
                </Badge>
                {region.status === 'healthy' ? <CheckCircle className="w-4 h-4 text-green-500" /> :
                 region.status === 'degraded' ? <Clock className="w-4 h-4 text-yellow-500" /> :
                 <AlertCircle className="w-4 h-4 text-red-500" />}
              </div>
              <div className="text-sm font-medium mb-1">{region.name}</div>
              <div className="text-xs text-muted-foreground">
                {getRegionBackupCount(region.id)} backups
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
