import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingDown, AlertCircle, Download } from 'lucide-react';
import { costAnalysisService } from '@/services/costAnalysisService';
import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function CostAnalysisDashboard() {
  const [providers, setProviders] = useState<any[]>([]);
  const [spending, setSpending] = useState<any[]>([]);
  const [alerts, setAlerts] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [providersData, alertsData] = await Promise.all([
        costAnalysisService.getProviderCosts(),
        costAnalysisService.getBudgetAlerts()
      ]);
      
      setProviders(providersData || []);
      setAlerts(alertsData || []);
      
      const endDate = new Date().toISOString();
      const startDate = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString();
      const spendingData = await costAnalysisService.getSpendingHistory(startDate, endDate);
      setSpending(spendingData || []);
    } catch (error) {
      console.error('Error loading cost data:', error);
    } finally {
      setLoading(false);
    }
  };

  const totalMonthlyCost = providers.reduce((acc, p) => acc + (p.monthly_cost || 0), 0);
  const avgCostPerEmail = providers.reduce((acc, p) => acc + (p.cost_per_email || 0), 0) / providers.length || 0;

  const exportReport = () => {
    const report = {
      providers,
      spending,
      totalMonthlyCost,
      avgCostPerEmail,
      generatedAt: new Date().toISOString()
    };
    
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `cost-analysis-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Cost Analysis & Optimization</h1>
        <Button onClick={exportReport}>
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Monthly Spend</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${totalMonthlyCost.toFixed(2)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Avg Cost/Email</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${avgCostPerEmail.toFixed(4)}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader>
            <CardTitle>Active Alerts</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-orange-600">{alerts.length}</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Provider Cost Comparison</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={providers}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="provider_name" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="monthly_cost" fill="#3b82f6" name="Monthly Cost" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {providers.map((provider) => (
          <Card key={provider.id}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start mb-4">
                <div>
                  <h3 className="font-semibold text-lg">{provider.provider_name}</h3>
                  <p className="text-sm text-gray-500">{provider.monthly_emails?.toLocaleString()} emails/month</p>
                </div>
                <Badge>{provider.status}</Badge>
              </div>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Cost per email</span>
                  <span className="font-semibold">${provider.cost_per_email?.toFixed(4)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">Monthly cost</span>
                  <span className="font-semibold">${provider.monthly_cost?.toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-500">ROI</span>
                  <span className="font-semibold text-green-600">{provider.roi || 0}%</span>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
