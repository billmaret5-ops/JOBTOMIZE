import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { EmailComponent } from './DragDropEmailBuilder';

interface ComponentEditorProps {
  component: EmailComponent;
  onUpdate: (updates: Partial<EmailComponent>) => void;
}

export const ComponentEditor: React.FC<ComponentEditorProps> = ({
  component,
  onUpdate
}) => {
  const updateContent = (key: string, value: any) => {
    onUpdate({
      content: { ...component.content, [key]: value }
    });
  };

  const updateStyle = (key: string, value: any) => {
    onUpdate({
      styles: { ...component.styles, [key]: value }
    });
  };

  const renderContentEditor = () => {
    switch (component.type) {
      case 'header':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={component.content.title}
                onChange={(e) => updateContent('title', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="subtitle">Subtitle</Label>
              <Input
                id="subtitle"
                value={component.content.subtitle}
                onChange={(e) => updateContent('subtitle', e.target.value)}
              />
            </div>
          </div>
        );
      
      case 'text':
        return (
          <div>
            <Label htmlFor="text">Text Content</Label>
            <Textarea
              id="text"
              value={component.content.text}
              onChange={(e) => updateContent('text', e.target.value)}
              rows={4}
            />
          </div>
        );
      
      case 'button':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="buttonText">Button Text</Label>
              <Input
                id="buttonText"
                value={component.content.text}
                onChange={(e) => updateContent('text', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="buttonUrl">Link URL</Label>
              <Input
                id="buttonUrl"
                value={component.content.url}
                onChange={(e) => updateContent('url', e.target.value)}
                placeholder="https://example.com"
              />
            </div>
          </div>
        );
      
      case 'image':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="imageSrc">Image URL</Label>
              <Input
                id="imageSrc"
                value={component.content.src}
                onChange={(e) => updateContent('src', e.target.value)}
                placeholder="https://example.com/image.jpg"
              />
            </div>
            <div>
              <Label htmlFor="imageAlt">Alt Text</Label>
              <Input
                id="imageAlt"
                value={component.content.alt}
                onChange={(e) => updateContent('alt', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="imageUrl">Link URL (optional)</Label>
              <Input
                id="imageUrl"
                value={component.content.url}
                onChange={(e) => updateContent('url', e.target.value)}
                placeholder="https://example.com"
              />
            </div>
          </div>
        );
      
      case 'spacer':
        return (
          <div>
            <Label>Height: {component.content.height}px</Label>
            <Slider
              value={[component.content.height]}
              onValueChange={([value]) => updateContent('height', value)}
              min={10}
              max={100}
              step={5}
              className="mt-2"
            />
          </div>
        );
      
      case 'divider':
        return (
          <div className="space-y-4">
            <div>
              <Label>Style</Label>
              <Select 
                value={component.content.style} 
                onValueChange={(value) => updateContent('style', value)}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="solid">Solid</SelectItem>
                  <SelectItem value="dashed">Dashed</SelectItem>
                  <SelectItem value="dotted">Dotted</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="dividerColor">Color</Label>
              <Input
                id="dividerColor"
                type="color"
                value={component.content.color}
                onChange={(e) => updateContent('color', e.target.value)}
              />
            </div>
          </div>
        );
      
      default:
        return null;
    }
  };

  const renderStyleEditor = () => {
    const commonStyles = (
      <div className="space-y-4">
        {component.styles.backgroundColor !== undefined && (
          <div>
            <Label htmlFor="backgroundColor">Background Color</Label>
            <Input
              id="backgroundColor"
              type="color"
              value={component.styles.backgroundColor}
              onChange={(e) => updateStyle('backgroundColor', e.target.value)}
            />
          </div>
        )}
        
        {component.styles.padding !== undefined && (
          <div>
            <Label htmlFor="padding">Padding</Label>
            <Input
              id="padding"
              value={component.styles.padding}
              onChange={(e) => updateStyle('padding', e.target.value)}
              placeholder="20px"
            />
          </div>
        )}
        
        {component.styles.textAlign !== undefined && (
          <div>
            <Label>Text Alignment</Label>
            <Select 
              value={component.styles.textAlign} 
              onValueChange={(value) => updateStyle('textAlign', value)}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="left">Left</SelectItem>
                <SelectItem value="center">Center</SelectItem>
                <SelectItem value="right">Right</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}
      </div>
    );

    switch (component.type) {
      case 'header':
        return (
          <div className="space-y-4">
            {commonStyles}
            <div>
              <Label htmlFor="titleColor">Title Color</Label>
              <Input
                id="titleColor"
                type="color"
                value={component.styles.titleColor}
                onChange={(e) => updateStyle('titleColor', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="titleSize">Title Size</Label>
              <Input
                id="titleSize"
                value={component.styles.titleSize}
                onChange={(e) => updateStyle('titleSize', e.target.value)}
                placeholder="28px"
              />
            </div>
          </div>
        );
      
      case 'text':
        return (
          <div className="space-y-4">
            {commonStyles}
            <div>
              <Label htmlFor="fontSize">Font Size</Label>
              <Input
                id="fontSize"
                value={component.styles.fontSize}
                onChange={(e) => updateStyle('fontSize', e.target.value)}
                placeholder="16px"
              />
            </div>
            <div>
              <Label htmlFor="color">Text Color</Label>
              <Input
                id="color"
                type="color"
                value={component.styles.color}
                onChange={(e) => updateStyle('color', e.target.value)}
              />
            </div>
          </div>
        );
      
      case 'button':
        return (
          <div className="space-y-4">
            <div>
              <Label htmlFor="btnBgColor">Background Color</Label>
              <Input
                id="btnBgColor"
                type="color"
                value={component.styles.backgroundColor}
                onChange={(e) => updateStyle('backgroundColor', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="btnColor">Text Color</Label>
              <Input
                id="btnColor"
                type="color"
                value={component.styles.color}
                onChange={(e) => updateStyle('color', e.target.value)}
              />
            </div>
            <div>
              <Label htmlFor="borderRadius">Border Radius</Label>
              <Input
                id="borderRadius"
                value={component.styles.borderRadius}
                onChange={(e) => updateStyle('borderRadius', e.target.value)}
                placeholder="6px"
              />
            </div>
          </div>
        );
      
      default:
        return commonStyles;
    }
  };

  return (
    <div className="h-full p-4 overflow-y-auto">
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Content</CardTitle>
          </CardHeader>
          <CardContent>
            {renderContentEditor()}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="text-lg">Styling</CardTitle>
          </CardHeader>
          <CardContent>
            {renderStyleEditor()}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};