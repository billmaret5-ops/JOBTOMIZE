import React, { useState, useCallback } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Save, Eye, Smartphone, Monitor, Tablet } from 'lucide-react';
import { ComponentLibrary } from './ComponentLibrary';
import { EmailCanvas } from './EmailCanvas';
import { ComponentEditor } from './ComponentEditor';
import { EmailPreview } from './EmailPreview';

export interface EmailComponent {
  id: string;
  type: 'header' | 'text' | 'button' | 'image' | 'spacer' | 'divider';
  content: any;
  styles: any;
}

export const DragDropEmailBuilder: React.FC = () => {
  const [components, setComponents] = useState<EmailComponent[]>([]);
  const [selectedComponent, setSelectedComponent] = useState<string | null>(null);
  const [templateName, setTemplateName] = useState('');
  const [previewMode, setPreviewMode] = useState<'desktop' | 'tablet' | 'mobile'>('desktop');
  const [activeTab, setActiveTab] = useState('build');

  const handleDrop = useCallback((componentType: string, index: number) => {
    const newComponent: EmailComponent = {
      id: `${componentType}-${Date.now()}`,
      type: componentType as any,
      content: getDefaultContent(componentType),
      styles: getDefaultStyles(componentType)
    };

    const newComponents = [...components];
    newComponents.splice(index, 0, newComponent);
    setComponents(newComponents);
  }, [components]);

  const handleComponentUpdate = useCallback((id: string, updates: Partial<EmailComponent>) => {
    setComponents(prev => prev.map(comp => 
      comp.id === id ? { ...comp, ...updates } : comp
    ));
  }, []);

  const handleComponentDelete = useCallback((id: string) => {
    setComponents(prev => prev.filter(comp => comp.id !== id));
    setSelectedComponent(null);
  }, []);

  const handleSaveTemplate = async () => {
    if (!templateName.trim()) {
      alert('Please enter a template name');
      return;
    }

    try {
      // Save template logic here
      console.log('Saving template:', { name: templateName, components });
      alert('Template saved successfully!');
    } catch (error) {
      console.error('Error saving template:', error);
      alert('Error saving template');
    }
  };

  return (
    <div className="h-screen flex flex-col bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b px-6 py-4 flex items-center justify-between">
        <div className="flex items-center space-x-4">
          <Input
            placeholder="Template name..."
            value={templateName}
            onChange={(e) => setTemplateName(e.target.value)}
            className="w-64"
          />
        </div>
        <div className="flex items-center space-x-2">
          <Button onClick={handleSaveTemplate} className="bg-blue-600 hover:bg-blue-700">
            <Save className="w-4 h-4 mr-2" />
            Save Template
          </Button>
        </div>
      </div>

      <div className="flex-1 flex">
        {/* Component Library Sidebar */}
        <div className="w-80 bg-white border-r">
          <ComponentLibrary />
        </div>

        {/* Main Content */}
        <div className="flex-1 flex flex-col">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
            <TabsList className="grid w-full grid-cols-2 bg-white border-b">
              <TabsTrigger value="build">Build</TabsTrigger>
              <TabsTrigger value="preview">Preview</TabsTrigger>
            </TabsList>

            <TabsContent value="build" className="flex-1 flex">
              <div className="flex-1 p-6">
                <EmailCanvas
                  components={components}
                  selectedComponent={selectedComponent}
                  onComponentSelect={setSelectedComponent}
                  onComponentUpdate={handleComponentUpdate}
                  onComponentDelete={handleComponentDelete}
                  onDrop={handleDrop}
                />
              </div>
              
              {/* Properties Panel */}
              {selectedComponent && (
                <div className="w-80 bg-white border-l">
                  <ComponentEditor
                    component={components.find(c => c.id === selectedComponent)!}
                    onUpdate={(updates) => handleComponentUpdate(selectedComponent, updates)}
                  />
                </div>
              )}
            </TabsContent>

            <TabsContent value="preview" className="flex-1">
              <div className="p-6">
                <div className="flex items-center justify-center mb-4 space-x-2">
                  <Button
                    variant={previewMode === 'desktop' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPreviewMode('desktop')}
                  >
                    <Monitor className="w-4 h-4 mr-2" />
                    Desktop
                  </Button>
                  <Button
                    variant={previewMode === 'tablet' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPreviewMode('tablet')}
                  >
                    <Tablet className="w-4 h-4 mr-2" />
                    Tablet
                  </Button>
                  <Button
                    variant={previewMode === 'mobile' ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setPreviewMode('mobile')}
                  >
                    <Smartphone className="w-4 h-4 mr-2" />
                    Mobile
                  </Button>
                </div>
                <EmailPreview components={components} mode={previewMode} />
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};

function getDefaultContent(type: string) {
  switch (type) {
    case 'header':
      return { title: 'Your Header Text', subtitle: 'Optional subtitle' };
    case 'text':
      return { text: 'Add your text content here...' };
    case 'button':
      return { text: 'Click Here', url: '#' };
    case 'image':
      return { src: '', alt: 'Image', url: '' };
    case 'spacer':
      return { height: 20 };
    case 'divider':
      return { style: 'solid', color: '#e5e7eb' };
    default:
      return {};
  }
}

function getDefaultStyles(type: string) {
  switch (type) {
    case 'header':
      return { 
        backgroundColor: '#ffffff',
        padding: '20px',
        textAlign: 'center',
        titleColor: '#1f2937',
        titleSize: '28px',
        subtitleColor: '#6b7280',
        subtitleSize: '16px'
      };
    case 'text':
      return {
        padding: '15px 20px',
        fontSize: '16px',
        color: '#374151',
        lineHeight: '1.6',
        textAlign: 'left'
      };
    case 'button':
      return {
        backgroundColor: '#3b82f6',
        color: '#ffffff',
        padding: '12px 24px',
        borderRadius: '6px',
        fontSize: '16px',
        textAlign: 'center',
        margin: '20px'
      };
    case 'image':
      return {
        width: '100%',
        maxWidth: '600px',
        height: 'auto',
        margin: '10px 0'
      };
    default:
      return {};
  }
}

export default DragDropEmailBuilder;
