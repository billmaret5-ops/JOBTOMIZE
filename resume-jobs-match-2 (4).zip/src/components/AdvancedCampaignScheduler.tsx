import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, Users, TrendingUp, Zap, Settings } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface CampaignSchedule {
  id: string;
  campaignName: string;
  campaignType: string;
  scheduledDate: string;
  status: string;
  recipientCount: number;
  optimalSendTimeEnabled: boolean;
  autoDeployWinner: boolean;
}

export default function AdvancedCampaignScheduler() {
  const [schedules, setSchedules] = useState<CampaignSchedule[]>([]);
  const [loading, setLoading] = useState(false);
  const [showScheduleForm, setShowScheduleForm] = useState(false);
  const [optimalTimes, setOptimalTimes] = useState<any>(null);

  const [formData, setFormData] = useState({
    campaignName: '',
    campaignType: 'one_time',
    scheduledDate: '',
    timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    optimalSendTimeEnabled: true,
    customSendTime: '10:00',
    recurrencePattern: '',
    autoDeployWinner: true,
    minStatisticalSignificance: 0.95,
    industry: 'technology',
    audienceType: 'b2b'
  });

  useEffect(() => {
    loadSchedules();
  }, []);

  const loadSchedules = async () => {
    setLoading(true);
    try {
      // Simulate loading schedules
      const mockSchedules: CampaignSchedule[] = [
        {
          id: '1',
          campaignName: 'Product Launch Campaign',
          campaignType: 'one_time',
          scheduledDate: new Date(Date.now() + 86400000).toISOString(),
          status: 'scheduled',
          recipientCount: 1250,
          optimalSendTimeEnabled: true,
          autoDeployWinner: true
        },
        {
          id: '2',
          campaignName: 'Weekly Newsletter',
          campaignType: 'recurring',
          scheduledDate: new Date(Date.now() + 172800000).toISOString(),
          status: 'running',
          recipientCount: 3400,
          optimalSendTimeEnabled: true,
          autoDeployWinner: false
        }
      ];
      setSchedules(mockSchedules);
    } catch (error) {
      console.error('Error loading schedules:', error);
    } finally {
      setLoading(false);
    }
  };

  const getOptimalSendTime = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('advanced-campaign-scheduler', {
        body: {
          action: 'get_optimal_send_time',
          userId: 'user-123',
          recipients: ['user1@example.com', 'user2@example.com'],
          industry: formData.industry,
          audienceType: formData.audienceType,
          timeZone: formData.timeZone
        }
      });

      if (data?.success) {
        setOptimalTimes(data);
      }
    } catch (error) {
      console.error('Error getting optimal send time:', error);
    } finally {
      setLoading(false);
    }
  };

  const scheduleCampaign = async () => {
    setLoading(true);
    try {
      const { data } = await supabase.functions.invoke('advanced-campaign-scheduler', {
        body: {
          action: 'schedule_campaign',
          userId: 'user-123',
          ...formData
        }
      });

      if (data?.success) {
        await loadSchedules();
        setShowScheduleForm(false);
        setFormData({
          campaignName: '',
          campaignType: 'one_time',
          scheduledDate: '',
          timeZone: Intl.DateTimeFormat().resolvedOptions().timeZone,
          optimalSendTimeEnabled: true,
          customSendTime: '10:00',
          recurrencePattern: '',
          autoDeployWinner: true,
          minStatisticalSignificance: 0.95,
          industry: 'technology',
          audienceType: 'b2b'
        });
      }
    } catch (error) {
      console.error('Error scheduling campaign:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors = {
      scheduled: 'bg-blue-100 text-blue-800',
      running: 'bg-green-100 text-green-800',
      completed: 'bg-gray-100 text-gray-800',
      paused: 'bg-yellow-100 text-yellow-800',
      cancelled: 'bg-red-100 text-red-800'
    };
    return colors[status as keyof typeof colors] || colors.scheduled;
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">Advanced Campaign Scheduler</h2>
        <Button onClick={() => setShowScheduleForm(true)}>
          <Calendar className="w-4 h-4 mr-2" />
          Schedule Campaign
        </Button>
      </div>

      {/* Optimal Send Time Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="w-5 h-5 mr-2" />
            Send Time Optimization
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
            <Select value={formData.industry} onValueChange={(value) => setFormData({...formData, industry: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Select Industry" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="technology">Technology</SelectItem>
                <SelectItem value="retail">Retail</SelectItem>
                <SelectItem value="finance">Finance</SelectItem>
                <SelectItem value="healthcare">Healthcare</SelectItem>
                <SelectItem value="education">Education</SelectItem>
                <SelectItem value="nonprofit">Non-profit</SelectItem>
              </SelectContent>
            </Select>

            <Select value={formData.audienceType} onValueChange={(value) => setFormData({...formData, audienceType: value})}>
              <SelectTrigger>
                <SelectValue placeholder="Audience Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="b2b">B2B</SelectItem>
                <SelectItem value="b2c">B2C</SelectItem>
                <SelectItem value="mixed">Mixed</SelectItem>
              </SelectContent>
            </Select>

            <Button onClick={getOptimalSendTime} disabled={loading}>
              <Clock className="w-4 h-4 mr-2" />
              Get Optimal Time
            </Button>
          </div>

          {optimalTimes && (
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold mb-2">Recommended Send Time</h4>
              <p className="text-sm text-gray-600 mb-2">
                Based on recipient engagement and industry best practices
              </p>
              <div className="flex items-center space-x-4">
                <Badge variant="secondary">
                  {new Date(optimalTimes.optimalTime.dateTime).toLocaleString()}
                </Badge>
                <Badge variant="outline">
                  Confidence: {Math.round(optimalTimes.optimalTime.confidence * 100)}%
                </Badge>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Schedule Form */}
      {showScheduleForm && (
        <Card>
          <CardHeader>
            <CardTitle>Schedule New Campaign</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <Label htmlFor="campaignName">Campaign Name</Label>
                <Input
                  id="campaignName"
                  value={formData.campaignName}
                  onChange={(e) => setFormData({...formData, campaignName: e.target.value})}
                  placeholder="Enter campaign name"
                />
              </div>

              <div>
                <Label htmlFor="campaignType">Campaign Type</Label>
                <Select value={formData.campaignType} onValueChange={(value) => setFormData({...formData, campaignType: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="one_time">One-time Campaign</SelectItem>
                    <SelectItem value="recurring">Recurring Campaign</SelectItem>
                    <SelectItem value="drip_sequence">Drip Sequence</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="scheduledDate">Scheduled Date</Label>
                <Input
                  id="scheduledDate"
                  type="datetime-local"
                  value={formData.scheduledDate}
                  onChange={(e) => setFormData({...formData, scheduledDate: e.target.value})}
                />
              </div>

              <div>
                <Label htmlFor="timeZone">Time Zone</Label>
                <Input
                  id="timeZone"
                  value={formData.timeZone}
                  onChange={(e) => setFormData({...formData, timeZone: e.target.value})}
                />
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.optimalSendTimeEnabled}
                onCheckedChange={(checked) => setFormData({...formData, optimalSendTimeEnabled: checked})}
              />
              <Label>Enable optimal send time calculation</Label>
            </div>

            <div className="flex items-center space-x-2">
              <Switch
                checked={formData.autoDeployWinner}
                onCheckedChange={(checked) => setFormData({...formData, autoDeployWinner: checked})}
              />
              <Label>Auto-deploy A/B test winner</Label>
            </div>

            {formData.campaignType === 'recurring' && (
              <div>
                <Label htmlFor="recurrencePattern">Recurrence Pattern</Label>
                <Select value={formData.recurrencePattern} onValueChange={(value) => setFormData({...formData, recurrencePattern: value})}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select recurrence" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="daily">Daily</SelectItem>
                    <SelectItem value="weekly">Weekly</SelectItem>
                    <SelectItem value="monthly">Monthly</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            )}

            <div className="flex justify-end space-x-2">
              <Button variant="outline" onClick={() => setShowScheduleForm(false)}>
                Cancel
              </Button>
              <Button onClick={scheduleCampaign} disabled={loading}>
                Schedule Campaign
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Scheduled Campaigns */}
      <Card>
        <CardHeader>
          <CardTitle>Scheduled Campaigns</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {schedules.map((schedule) => (
              <div key={schedule.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <h4 className="font-semibold">{schedule.campaignName}</h4>
                  <p className="text-sm text-gray-600">
                    {new Date(schedule.scheduledDate).toLocaleString()}
                  </p>
                  <div className="flex items-center space-x-2 mt-2">
                    <Badge className={getStatusColor(schedule.status)}>
                      {schedule.status}
                    </Badge>
                    <span className="text-sm text-gray-500 flex items-center">
                      <Users className="w-4 h-4 mr-1" />
                      {schedule.recipientCount} recipients
                    </span>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  {schedule.optimalSendTimeEnabled && (
                    <Badge variant="outline">
                      <TrendingUp className="w-3 h-3 mr-1" />
                      Optimized
                    </Badge>
                  )}
                  {schedule.autoDeployWinner && (
                    <Badge variant="outline">
                      <Zap className="w-3 h-3 mr-1" />
                      Auto-deploy
                    </Badge>
                  )}
                  <Button variant="outline" size="sm">
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}