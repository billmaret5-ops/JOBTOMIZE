import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { dashboardBuilderService, DashboardTemplate } from '@/services/dashboardBuilderService';
import { Briefcase, Users, Bell } from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface Props {
  open: boolean;
  onClose: () => void;
  onSelect: (dashboardId: string) => void;
}

export const DashboardTemplateSelector: React.FC<Props> = ({ open, onClose, onSelect }) => {
  const [templates, setTemplates] = useState<DashboardTemplate[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<string | null>(null);
  const [dashboardName, setDashboardName] = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      loadTemplates();
    }
  }, [open]);

  const loadTemplates = async () => {
    try {
      const data = await dashboardBuilderService.getTemplates();
      setTemplates(data);
    } catch (error) {
      console.error('Failed to load templates:', error);
    }
  };

  const handleCreate = async () => {
    if (!selectedTemplate || !dashboardName.trim()) {
      toast({ title: 'Please select a template and enter a name', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const dashboard = await dashboardBuilderService.createFromTemplate(selectedTemplate, dashboardName);
      toast({ title: 'Dashboard created successfully' });
      onSelect(dashboard.id);
      onClose();
    } catch (error) {
      toast({ title: 'Failed to create dashboard', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const getIcon = (role: string) => {
    switch (role) {
      case 'ops': return Briefcase;
      case 'management': return Users;
      case 'on-call': return Bell;
      default: return Briefcase;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Dashboard from Template</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {templates.map((template) => {
              const Icon = getIcon(template.role);
              return (
                <Card
                  key={template.id}
                  className={`cursor-pointer transition-all ${
                    selectedTemplate === template.id ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedTemplate(template.id)}
                >
                  <CardHeader>
                    <div className="flex items-center gap-2">
                      <Icon className="h-5 w-5" />
                      <CardTitle className="text-base">{template.name}</CardTitle>
                    </div>
                    <CardDescription>{template.description}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="text-xs text-muted-foreground">
                      Role: <span className="font-medium capitalize">{template.role}</span>
                    </div>
                    <div className="text-xs text-muted-foreground mt-1">
                      {template.layout.length} widgets
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>

          {selectedTemplate && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Dashboard Name</label>
                <Input
                  value={dashboardName}
                  onChange={(e) => setDashboardName(e.target.value)}
                  placeholder="Enter dashboard name"
                  className="mt-1"
                />
              </div>

              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={onClose}>Cancel</Button>
                <Button onClick={handleCreate} disabled={loading}>
                  {loading ? 'Creating...' : 'Create Dashboard'}
                </Button>
              </div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};
