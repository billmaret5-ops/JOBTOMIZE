import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card } from '@/components/ui/card';
import EmailIntegrationDashboard from './EmailIntegrationDashboard';
import EmailParserDashboard from './EmailParserDashboard';
import JobEmailTemplateLibrary from './JobEmailTemplateLibrary';
import EmailAutomationRules from './EmailAutomationRules';
import { Mail, Inbox, FileText, Zap, BarChart3 } from 'lucide-react';

export default function ComprehensiveEmailIntegrationSystem() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="container mx-auto px-4 py-8">
        <div className="mb-8">
          <h1 className="text-4xl font-bold mb-2 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            Email Integration System
          </h1>
          <p className="text-lg text-muted-foreground">
            Auto-track applications, parse emails, and manage communication
          </p>
        </div>

        <div className="grid grid-cols-5 gap-4 mb-8">
          <Card className="p-4">
            <div className="text-2xl font-bold text-blue-600">2</div>
            <div className="text-sm text-muted-foreground">Connected Accounts</div>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-green-600">24</div>
            <div className="text-sm text-muted-foreground">Parsed Emails</div>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-purple-600">8</div>
            <div className="text-sm text-muted-foreground">Templates</div>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-orange-600">5</div>
            <div className="text-sm text-muted-foreground">Active Rules</div>
          </Card>
          <Card className="p-4">
            <div className="text-2xl font-bold text-pink-600">92%</div>
            <div className="text-sm text-muted-foreground">Auto-Detection Rate</div>
          </Card>
        </div>

        <Tabs defaultValue="connections" className="space-y-6">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="connections" className="flex items-center gap-2">
              <Mail className="h-4 w-4" />
              Connections
            </TabsTrigger>
            <TabsTrigger value="parser" className="flex items-center gap-2">
              <Inbox className="h-4 w-4" />
              Email Parser
            </TabsTrigger>
            <TabsTrigger value="templates" className="flex items-center gap-2">
              <FileText className="h-4 w-4" />
              Templates
            </TabsTrigger>
            <TabsTrigger value="automation" className="flex items-center gap-2">
              <Zap className="h-4 w-4" />
              Automation
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="connections">
            <EmailIntegrationDashboard />
          </TabsContent>

          <TabsContent value="parser">
            <EmailParserDashboard />
          </TabsContent>

          <TabsContent value="templates">
            <JobEmailTemplateLibrary />
          </TabsContent>

          <TabsContent value="automation">
            <EmailAutomationRules />
          </TabsContent>

          <TabsContent value="analytics">
            <Card className="p-6">
              <h3 className="text-xl font-semibold mb-4">Email Analytics</h3>
              <div className="grid md:grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-blue-600 mb-2">156</div>
                  <div className="text-sm text-muted-foreground">Total Emails Tracked</div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-green-600 mb-2">89%</div>
                  <div className="text-sm text-muted-foreground">Parse Success Rate</div>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-3xl font-bold text-purple-600 mb-2">42</div>
                  <div className="text-sm text-muted-foreground">Auto-Created Apps</div>
                </div>
              </div>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
