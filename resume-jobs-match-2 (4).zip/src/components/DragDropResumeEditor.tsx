import React, { useState, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  GripVertical, 
  Plus, 
  Trash2, 
  Eye, 
  Save,
  Download,
  Settings,
  FileText,
  ArrowUp,
  ArrowDown,
  Edit
} from 'lucide-react';
import { PDFExportSystem } from './PDFExportSystem';
interface ResumeSection {
  id: string;
  type: 'header' | 'experience' | 'education' | 'skills' | 'achievements' | 'custom';
  title: string;
  content: any;
  order: number;
}

interface DragDropResumeEditorProps {
  initialSections?: ResumeSection[];
  onSave?: (sections: ResumeSection[]) => void;
}

export function DragDropResumeEditor({ initialSections = [], onSave }: DragDropResumeEditorProps) {
  const [sections, setSections] = useState<ResumeSection[]>(
    initialSections.length > 0 ? initialSections : [
      {
        id: '1',
        type: 'header',
        title: 'Personal Information',
        content: {
          name: 'John Doe',
          email: 'john.doe@email.com',
          phone: '+1 (555) 123-4567',
          location: 'New York, NY',
          linkedin: 'linkedin.com/in/johndoe'
        },
        order: 0
      },
      {
        id: '2',
        type: 'experience',
        title: 'Work Experience',
        content: [
          {
            company: 'Tech Corp',
            position: 'Senior Software Engineer',
            duration: '2020 - Present',
            description: 'Led development of scalable web applications using React and Node.js'
          }
        ],
        order: 1
      },
      {
        id: '3',
        type: 'education',
        title: 'Education',
        content: [
          {
            school: 'University of Technology',
            degree: 'Bachelor of Computer Science',
            year: '2016 - 2020',
            gpa: '3.8/4.0'
          }
        ],
        order: 2
      },
      {
        id: '4',
        type: 'skills',
        title: 'Skills',
        content: {
          technical: ['React', 'Node.js', 'Python', 'SQL'],
          soft: ['Leadership', 'Communication', 'Problem Solving']
        },
        order: 3
      }
    ]
  );
  
  const [editingSection, setEditingSection] = useState<string | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  const moveSection = (id: string, direction: 'up' | 'down') => {
    const sortedSections = [...sections].sort((a, b) => a.order - b.order);
    const currentIndex = sortedSections.findIndex(s => s.id === id);
    
    if (direction === 'up' && currentIndex > 0) {
      const temp = sortedSections[currentIndex].order;
      sortedSections[currentIndex].order = sortedSections[currentIndex - 1].order;
      sortedSections[currentIndex - 1].order = temp;
    } else if (direction === 'down' && currentIndex < sortedSections.length - 1) {
      const temp = sortedSections[currentIndex].order;
      sortedSections[currentIndex].order = sortedSections[currentIndex + 1].order;
      sortedSections[currentIndex + 1].order = temp;
    }
    
    setSections(sortedSections);
  };

  const addSection = (type: ResumeSection['type']) => {
    const newSection: ResumeSection = {
      id: Date.now().toString(),
      type,
      title: type.charAt(0).toUpperCase() + type.slice(1),
      content: type === 'skills' ? { technical: [], soft: [] } : [],
      order: sections.length
    };
    setSections([...sections, newSection]);
  };

  const deleteSection = (id: string) => {
    setSections(sections.filter(section => section.id !== id));
  };

  const updateSection = (id: string, updates: Partial<ResumeSection>) => {
    setSections(sections.map(section => 
      section.id === id ? { ...section, ...updates } : section
    ));
  };

  const renderSectionEditor = (section: ResumeSection) => {
    switch (section.type) {
      case 'header':
        return (
          <div className="space-y-4">
            <Input
              placeholder="Full Name"
              value={section.content.name || ''}
              onChange={(e) => updateSection(section.id, {
                content: { ...section.content, name: e.target.value }
              })}
            />
            <div className="grid grid-cols-2 gap-4">
              <Input
                placeholder="Email"
                value={section.content.email || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { ...section.content, email: e.target.value }
                })}
              />
              <Input
                placeholder="Phone"
                value={section.content.phone || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { ...section.content, phone: e.target.value }
                })}
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <Input
                placeholder="Location"
                value={section.content.location || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { ...section.content, location: e.target.value }
                })}
              />
              <Input
                placeholder="LinkedIn"
                value={section.content.linkedin || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { ...section.content, linkedin: e.target.value }
                })}
              />
            </div>
          </div>
        );
      
      case 'skills':
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Technical Skills</label>
              <Input
                placeholder="React, Node.js, Python (comma separated)"
                value={section.content.technical?.join(', ') || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { 
                    ...section.content, 
                    technical: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  }
                })}
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Soft Skills</label>
              <Input
                placeholder="Leadership, Communication (comma separated)"
                value={section.content.soft?.join(', ') || ''}
                onChange={(e) => updateSection(section.id, {
                  content: { 
                    ...section.content, 
                    soft: e.target.value.split(',').map(s => s.trim()).filter(Boolean)
                  }
                })}
              />
            </div>
          </div>
        );
      
      default:
        return (
          <Textarea
            placeholder={`Enter ${section.type} details...`}
            className="min-h-[100px]"
            value={typeof section.content === 'string' ? section.content : JSON.stringify(section.content, null, 2)}
            onChange={(e) => updateSection(section.id, { content: e.target.value })}
          />
        );
    }
  };

  const renderSectionPreview = (section: ResumeSection) => {
    switch (section.type) {
      case 'header':
        return (
          <div className="text-center border-b pb-4 mb-4">
            <h1 className="text-2xl font-bold">{section.content.name}</h1>
            <div className="text-gray-600 mt-2">
              {section.content.email} • {section.content.phone}
            </div>
            <div className="text-gray-600">
              {section.content.location} • {section.content.linkedin}
            </div>
          </div>
        );
      
      case 'skills':
        return (
          <div>
            <h2 className="text-lg font-semibold mb-3">{section.title}</h2>
            {section.content.technical?.length > 0 && (
              <div className="mb-2">
                <strong>Technical:</strong> {section.content.technical.join(', ')}
              </div>
            )}
            {section.content.soft?.length > 0 && (
              <div>
                <strong>Soft Skills:</strong> {section.content.soft.join(', ')}
              </div>
            )}
          </div>
        );
      
      default:
        return (
          <div>
            <h2 className="text-lg font-semibold mb-3">{section.title}</h2>
            <div className="text-gray-700">
              {typeof section.content === 'string' ? section.content : JSON.stringify(section.content)}
            </div>
          </div>
        );
    }
  };

  if (previewMode) {
    return (
      <div className="max-w-4xl mx-auto">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Resume Preview</h2>
          <div className="space-x-2">
            <Button variant="outline" onClick={() => setPreviewMode(false)}>
              <Edit className="w-4 h-4 mr-2" />
              Edit
            </Button>
            <Button onClick={() => onSave?.(sections)}>
              <Save className="w-4 h-4 mr-2" />
              Save
            </Button>
          </div>
        </div>
        
        <Card className="p-8 bg-white shadow-lg">
          <div className="space-y-6">
            {sections
              .sort((a, b) => a.order - b.order)
              .map((section) => (
                <div key={section.id}>
                  {renderSectionPreview(section)}
                </div>
              ))}
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="max-w-6xl mx-auto">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold">Resume Builder</h2>
        <div className="space-x-2">
          <Button variant="outline" onClick={() => setPreviewMode(true)}>
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
          <Button onClick={() => onSave?.(sections)}>
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div>
          <div className="mb-4">
            <h3 className="text-lg font-semibold mb-3">Add Section</h3>
            <div className="flex flex-wrap gap-2">
              {['experience', 'education', 'skills', 'achievements', 'custom'].map((type) => (
                <Button
                  key={type}
                  variant="outline"
                  size="sm"
                  onClick={() => addSection(type as ResumeSection['type'])}
                >
                  <Plus className="w-3 h-3 mr-1" />
                  {type.charAt(0).toUpperCase() + type.slice(1)}
                </Button>
              ))}
            </div>
          </div>

          <div className="space-y-4">
            {sections
              .sort((a, b) => a.order - b.order)
              .map((section, index) => (
                <Card key={section.id} className="border-l-4 border-l-blue-500">
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center space-x-2">
                        <GripVertical className="w-4 h-4 text-gray-400" />
                        <CardTitle className="text-sm">{section.title}</CardTitle>
                        <Badge variant="secondary">{section.type}</Badge>
                      </div>
                      <div className="flex space-x-1">
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => moveSection(section.id, 'up')}
                          disabled={index === 0}
                        >
                          <ArrowUp className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => moveSection(section.id, 'down')}
                          disabled={index === sections.length - 1}
                        >
                          <ArrowDown className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setEditingSection(
                            editingSection === section.id ? null : section.id
                          )}
                        >
                          <Edit className="w-3 h-3" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => deleteSection(section.id)}
                        >
                          <Trash2 className="w-3 h-3" />
                        </Button>
                      </div>
                    </div>
                  </CardHeader>
                  {editingSection === section.id && (
                    <CardContent>
                      {renderSectionEditor(section)}
                    </CardContent>
                  )}
                </Card>
              ))}
          </div>
        </div>

        <div className="lg:sticky lg:top-6">
          <Card className="p-6 bg-gray-50">
            <h3 className="text-lg font-semibold mb-4">Live Preview</h3>
            <div className="bg-white p-6 rounded-lg shadow-sm space-y-4 max-h-[600px] overflow-y-auto">
              {sections
                .sort((a, b) => a.order - b.order)
                .map((section) => (
                  <div key={section.id} className="text-sm">
                    {renderSectionPreview(section)}
                  </div>
                ))}
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}