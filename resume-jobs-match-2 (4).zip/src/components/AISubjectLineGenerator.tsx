import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Copy, RefreshCw, Check } from 'lucide-react';
import { aiTemplateOptimizationService } from '@/services/aiTemplateOptimizationService';

interface Props {
  position: string;
  company: string;
  onSelect?: (subject: string) => void;
}

export const AISubjectLineGenerator: React.FC<Props> = ({ position, company, onSelect }) => {
  const [subjectLines, setSubjectLines] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  useEffect(() => {
    generateSubjectLines();
  }, [position, company]);

  const generateSubjectLines = async () => {
    setLoading(true);
    try {
      const lines = await aiTemplateOptimizationService.generateSubjectLines(position, company);
      setSubjectLines(lines);
    } catch (error) {
      console.error('Error generating subject lines:', error);
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => setCopiedIndex(null), 2000);
  };

  const getPerformanceScore = (index: number) => {
    const scores = [92, 88, 85, 82, 78];
    return scores[index] || 75;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-5 h-5 text-purple-500" />
            AI Subject Line Generator
          </div>
          <Button 
            variant="outline" 
            size="sm" 
            onClick={generateSubjectLines}
            disabled={loading}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Regenerate
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        {subjectLines.map((line, index) => (
          <div 
            key={index} 
            className="p-3 border rounded-lg hover:bg-gray-50 transition-colors cursor-pointer"
            onClick={() => onSelect?.(line)}
          >
            <div className="flex items-start justify-between gap-2">
              <div className="flex-1">
                <p className="text-sm font-medium mb-1">{line}</p>
                <div className="flex items-center gap-2">
                  <Badge variant="secondary" className="text-xs">
                    Performance: {getPerformanceScore(index)}%
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    {index === 0 ? 'Most Professional' : index === 1 ? 'Action-Oriented' : index === 2 ? 'Enthusiastic' : 'Standard'}
                  </span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  copyToClipboard(line, index);
                }}
              >
                {copiedIndex === index ? (
                  <Check className="w-4 h-4 text-green-500" />
                ) : (
                  <Copy className="w-4 h-4" />
                )}
              </Button>
            </div>
          </div>
        ))}

        <div className="bg-purple-50 p-3 rounded-lg">
          <p className="text-sm text-purple-900">
            💡 Tip: Subject lines with specific position titles have 23% higher open rates
          </p>
        </div>
      </CardContent>
    </Card>
  );
};
