import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Zap, Settings, BarChart3, Users } from 'lucide-react';
import { WorkflowCanvas } from './workflow/WorkflowCanvas';
import DripSequenceBuilder from './DripSequenceBuilder';
import { EmailAutomationWorkflow } from './EmailAutomationWorkflow';

export const EmailCampaignAutomationSystem: React.FC = () => {
  const [activeTab, setActiveTab] = useState('builder');

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Zap className="h-6 w-6 text-blue-500" />
        <h2 className="text-2xl font-bold">Email Campaign Automation</h2>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="builder">Workflow Builder</TabsTrigger>
          <TabsTrigger value="sequences">Drip Sequences</TabsTrigger>
          <TabsTrigger value="triggers">Triggers & Logic</TabsTrigger>
          <TabsTrigger value="analytics">Performance</TabsTrigger>
        </TabsList>

        <TabsContent value="builder">
          <WorkflowCanvas />
        </TabsContent>

        <TabsContent value="sequences">
          <DripSequenceBuilder />
        </TabsContent>

        <TabsContent value="triggers">
          <EmailAutomationWorkflow />
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold">87%</div>
                  <div className="text-sm text-gray-600">Delivery Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">24%</div>
                  <div className="text-sm text-gray-600">Open Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold">5.2%</div>
                  <div className="text-sm text-gray-600">Click Rate</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};