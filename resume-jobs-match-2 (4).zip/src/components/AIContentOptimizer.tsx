import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, CheckCircle, AlertTriangle, Lightbulb, Target, TrendingUp, Zap, RefreshCw } from 'lucide-react';

interface OptimizationSuggestion {
  type: 'ats' | 'tone' | 'engagement' | 'personalization';
  severity: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  suggestion: string;
}

export function AIContentOptimizer() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysisComplete, setAnalysisComplete] = useState(false);

  const atsScore = 87;
  const toneScore = 92;
  const engagementScore = 78;
  const overallScore = 85;

  const suggestions: OptimizationSuggestion[] = [
    {
      type: 'ats',
      severity: 'medium',
      title: 'Add Industry Keywords',
      description: 'Your template lacks specific industry keywords',
      suggestion: 'Include terms like "software development", "agile methodology", and "full-stack" to improve ATS matching'
    },
    {
      type: 'tone',
      severity: 'low',
      title: 'Professional Tone Enhancement',
      description: 'Some phrases could be more professional',
      suggestion: 'Replace "I think" with "I believe" and "pretty good" with "excellent" for stronger impact'
    },
    {
      type: 'engagement',
      severity: 'high',
      title: 'Weak Call-to-Action',
      description: 'Your CTA lacks urgency and specificity',
      suggestion: 'Change "Hope to hear from you" to "I would welcome the opportunity to discuss how my skills align with your needs"'
    },
    {
      type: 'personalization',
      severity: 'medium',
      title: 'Add Personalization Tokens',
      description: 'Template could be more personalized',
      suggestion: 'Include {{company_recent_news}} and {{hiring_manager_name}} tokens for better connection'
    }
  ];

  const handleAnalyze = () => {
    setIsAnalyzing(true);
    setTimeout(() => {
      setIsAnalyzing(false);
      setAnalysisComplete(true);
    }, 3000);
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'ats': return <Target className="w-4 h-4" />;
      case 'tone': return <Brain className="w-4 h-4" />;
      case 'engagement': return <TrendingUp className="w-4 h-4" />;
      case 'personalization': return <Zap className="w-4 h-4" />;
      default: return <Lightbulb className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center">
              <Brain className="w-5 h-5 mr-2 text-purple-600" />
              AI Content Optimization
            </CardTitle>
            <Button 
              onClick={handleAnalyze}
              disabled={isAnalyzing}
              className="bg-purple-600 hover:bg-purple-700"
            >
              {isAnalyzing ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Brain className="w-4 h-4 mr-2" />
                  Analyze Content
                </>
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {!analysisComplete && !isAnalyzing && (
            <div className="text-center py-8">
              <Brain className="w-16 h-16 text-gray-400 mx-auto mb-4" />
              <p className="text-gray-600 mb-4">Click "Analyze Content" to get AI-powered optimization suggestions</p>
              <p className="text-sm text-gray-500">Our AI will analyze your email template for ATS compatibility, tone, engagement, and personalization opportunities</p>
            </div>
          )}

          {isAnalyzing && (
            <div className="text-center py-8">
              <div className="animate-pulse">
                <Brain className="w-16 h-16 text-purple-600 mx-auto mb-4" />
              </div>
              <p className="text-lg font-medium mb-2">Analyzing your content...</p>
              <p className="text-sm text-gray-600 mb-4">Our AI is reviewing your template for optimization opportunities</p>
              <Progress value={66} className="w-full max-w-md mx-auto" />
            </div>
          )}

          {analysisComplete && (
            <Tabs defaultValue="overview" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="overview">Overview</TabsTrigger>
                <TabsTrigger value="ats">ATS Analysis</TabsTrigger>
                <TabsTrigger value="tone">Tone Analysis</TabsTrigger>
                <TabsTrigger value="suggestions">Suggestions</TabsTrigger>
              </TabsList>

              <TabsContent value="overview" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-purple-600">{overallScore}%</div>
                      <div className="text-sm text-gray-600">Overall Score</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-green-600">{atsScore}%</div>
                      <div className="text-sm text-gray-600">ATS Compatibility</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-blue-600">{toneScore}%</div>
                      <div className="text-sm text-gray-600">Professional Tone</div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-4 text-center">
                      <div className="text-2xl font-bold text-orange-600">{engagementScore}%</div>
                      <div className="text-sm text-gray-600">Engagement Score</div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="ats" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Target className="w-5 h-5 mr-2 text-green-600" />
                      ATS Compatibility Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="flex items-center justify-between">
                      <span>Keyword Density</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={75} className="w-24" />
                        <span className="text-sm font-medium">75%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Industry Terms</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={60} className="w-24" />
                        <span className="text-sm font-medium">60%</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between">
                      <span>Format Compatibility</span>
                      <div className="flex items-center space-x-2">
                        <Progress value={95} className="w-24" />
                        <span className="text-sm font-medium">95%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="tone" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="flex items-center">
                      <Brain className="w-5 h-5 mr-2 text-blue-600" />
                      Tone & Style Analysis
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div className="text-center p-4 bg-green-50 rounded-lg">
                        <div className="text-2xl font-bold text-green-600">Professional</div>
                        <div className="text-sm text-gray-600">Primary Tone</div>
                      </div>
                      <div className="text-center p-4 bg-blue-50 rounded-lg">
                        <div className="text-2xl font-bold text-blue-600">Confident</div>
                        <div className="text-sm text-gray-600">Secondary Tone</div>
                      </div>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between">
                        <span>Formality Level</span>
                        <Badge variant="outline">Appropriate</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Enthusiasm</span>
                        <Badge variant="outline">Moderate</Badge>
                      </div>
                      <div className="flex justify-between">
                        <span>Clarity</span>
                        <Badge variant="outline" className="bg-green-50 text-green-700">Excellent</Badge>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="suggestions" className="space-y-4">
                {suggestions.map((suggestion, index) => (
                  <Card key={index}>
                    <CardContent className="p-4">
                      <div className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          {getTypeIcon(suggestion.type)}
                        </div>
                        <div className="flex-grow">
                          <div className="flex items-center space-x-2 mb-2">
                            <h4 className="font-medium">{suggestion.title}</h4>
                            <Badge className={getSeverityColor(suggestion.severity)}>
                              {suggestion.severity}
                            </Badge>
                          </div>
                          <p className="text-sm text-gray-600 mb-2">{suggestion.description}</p>
                          <p className="text-sm bg-blue-50 p-3 rounded-lg border-l-4 border-blue-400">
                            <strong>Suggestion:</strong> {suggestion.suggestion}
                          </p>
                        </div>
                        <Button size="sm" variant="outline">
                          Apply
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  );
}