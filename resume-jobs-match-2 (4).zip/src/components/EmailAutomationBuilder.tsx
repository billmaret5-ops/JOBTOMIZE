import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { WorkflowCanvas } from './WorkflowCanvas';
import { BehavioralTriggerManager } from './BehavioralTriggerManager';
import { BehaviorAnalyticsDashboard } from './BehaviorAnalyticsDashboard';
import { RealTimeBehaviorTracker } from './RealTimeBehaviorTracker';
import { workflowEngineService, EmailWorkflow } from '../services/workflowEngineService';

export const EmailAutomationBuilder: React.FC = () => {
  const [workflows, setWorkflows] = useState<EmailWorkflow[]>([]);
  const [selectedWorkflow, setSelectedWorkflow] = useState<EmailWorkflow | null>(null);
  const [loading, setLoading] = useState(false);
  const [workflowForm, setWorkflowForm] = useState({
    name: '',
    description: '',
    trigger_type: 'behavioral',
    is_active: true
  });

  useEffect(() => {
    loadWorkflows();
  }, []);

  const loadWorkflows = async () => {
    setLoading(true);
    try {
      const data = await workflowEngineService.getWorkflows();
      setWorkflows(data);
    } catch (error) {
      console.error('Error loading workflows:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWorkflow = async () => {
    setLoading(true);
    try {
      const workflowId = await workflowEngineService.createWorkflow({
        ...workflowForm,
        nodes: [],
        connections: []
      });
      
      await loadWorkflows();
      setWorkflowForm({
        name: '',
        description: '',
        trigger_type: 'behavioral',
        is_active: true
      });
    } catch (error) {
      console.error('Error creating workflow:', error);
    } finally {
      setLoading(false);
    }
  };
  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Advanced Email Automation</h2>
        <Badge variant="secondary">{workflows.length} Workflows</Badge>
      </div>

      <Tabs defaultValue="workflows" className="space-y-4">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="workflows">Workflows</TabsTrigger>
          <TabsTrigger value="builder">Visual Builder</TabsTrigger>
          <TabsTrigger value="triggers">Behavioral Triggers</TabsTrigger>
          <TabsTrigger value="tracking">Real-Time Tracking</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="workflows" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Create New Workflow</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="workflow-name">Workflow Name</Label>
                  <Input
                    id="workflow-name"
                    value={workflowForm.name}
                    onChange={(e) => setWorkflowForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Welcome Series"
                  />
                </div>
                <div>
                  <Label htmlFor="workflow-description">Description</Label>
                  <Input
                    id="workflow-description"
                    value={workflowForm.description}
                    onChange={(e) => setWorkflowForm(prev => ({ ...prev, description: e.target.value }))}
                    placeholder="Brief description"
                  />
                </div>
              </div>
              <Button onClick={handleCreateWorkflow} disabled={loading || !workflowForm.name}>
                {loading ? 'Creating...' : 'Create Workflow'}
              </Button>
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {workflows.map((workflow) => (
              <Card key={workflow.id} className="cursor-pointer hover:shadow-md" 
                    onClick={() => setSelectedWorkflow(workflow)}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div>
                      <h3 className="font-semibold">{workflow.name}</h3>
                      <p className="text-sm text-muted-foreground">{workflow.description}</p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {workflow.nodes?.length || 0} steps • {workflow.trigger_type} trigger
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={workflow.is_active ? 'default' : 'secondary'}>
                        {workflow.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      <Button
                        size="sm"
                        onClick={(e) => {
                          e.stopPropagation();
                          setSelectedWorkflow(workflow);
                        }}
                      >
                        Edit
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="builder">
          {selectedWorkflow ? (
            <div className="h-96">
              <WorkflowCanvas
                nodes={selectedWorkflow.nodes || []}
                connections={selectedWorkflow.connections || []}
                onNodesChange={(nodes) => console.log('Nodes changed:', nodes)}
                onConnectionsChange={(connections) => console.log('Connections changed:', connections)}
              />
            </div>
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <p className="text-muted-foreground">Select a workflow to start building</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="triggers">
          <BehavioralTriggerManager
            workflowId={selectedWorkflow?.id}
            onTriggerCreated={(triggerId) => {
              console.log('Trigger created:', triggerId);
              // Refresh workflows or update state
            }}
          />
        </TabsContent>

        <TabsContent value="tracking">
          <RealTimeBehaviorTracker
            userId="demo-user-123"
            onEventTracked={(event) => {
              console.log('Event tracked:', event);
            }}
          />
        </TabsContent>

        <TabsContent value="analytics">
          <BehaviorAnalyticsDashboard />
        </TabsContent>
      </Tabs>
    </div>
  );
};