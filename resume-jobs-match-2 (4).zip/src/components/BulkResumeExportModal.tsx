import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Progress } from '@/components/ui/progress';
import { Download, Plus, X } from 'lucide-react';

interface BulkExportModalProps {
  open: boolean;
  onClose: () => void;
  optimizedData: any;
  onBulkExport: (versions: ExportVersion[]) => Promise<void>;
}

export interface ExportVersion {
  name: string;
  format: 'pdf' | 'docx' | 'txt';
  sections: { summary: boolean; experience: boolean; skills: boolean };
}

export default function BulkResumeExportModal({ open, onClose, optimizedData, onBulkExport }: BulkExportModalProps) {

  const [versions, setVersions] = useState<ExportVersion[]>([
    { name: 'Standard Resume', format: 'pdf', sections: { summary: true, experience: true, skills: true } },
    { name: 'Technical Focus', format: 'docx', sections: { summary: true, experience: true, skills: true } }
  ]);
  const [exporting, setExporting] = useState(false);
  const [progress, setProgress] = useState(0);

  const addVersion = () => {
    setVersions([...versions, {
      name: `Version ${versions.length + 1}`,
      format: 'pdf',
      sections: { summary: true, experience: true, skills: true }
    }]);
  };

  const removeVersion = (index: number) => {
    setVersions(versions.filter((_, i) => i !== index));
  };

  const updateVersion = (index: number, updates: Partial<ExportVersion>) => {
    setVersions(versions.map((v, i) => i === index ? { ...v, ...updates } : v));
  };

  const handleBulkExport = async () => {
    setExporting(true);
    setProgress(0);
    
    const increment = 100 / versions.length;
    
    try {
      for (let i = 0; i < versions.length; i++) {
        await new Promise(resolve => setTimeout(resolve, 500));
        setProgress((i + 1) * increment);
      }
      
      await onBulkExport(versions);
      
      setTimeout(() => {
        onClose();
        setExporting(false);
        setProgress(0);
      }, 500);
    } catch (error) {
      console.error('Bulk export error:', error);
      setExporting(false);
      setProgress(0);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-3xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Bulk Export Resume Versions</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          {versions.map((version, index) => (
            <div key={index} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-center gap-3">
                <Input
                  value={version.name}
                  onChange={(e) => updateVersion(index, { name: e.target.value })}
                  className="flex-1"
                  placeholder="Version name"
                />
                <select
                  value={version.format}
                  onChange={(e) => updateVersion(index, { format: e.target.value as any })}
                  className="border rounded px-3 py-2"
                >
                  <option value="pdf">PDF</option>
                  <option value="docx">DOCX</option>
                  <option value="txt">TXT</option>
                </select>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => removeVersion(index)}
                  disabled={versions.length === 1}
                >
                  <X className="w-4 h-4" />
                </Button>
              </div>
              
              <div className="flex gap-4">
                {Object.entries(version.sections).map(([key, checked]) => (
                  <div key={key} className="flex items-center space-x-2">
                    <Checkbox
                      checked={checked}
                      onCheckedChange={(c) => updateVersion(index, {
                        sections: { ...version.sections, [key]: !!c }
                      })}
                    />
                    <Label className="capitalize text-sm">{key}</Label>
                  </div>
                ))}
              </div>
            </div>
          ))}

          <Button variant="outline" onClick={addVersion} className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Add Version
          </Button>

          {exporting && (
            <div className="space-y-2">
              <Progress value={progress} />
              <p className="text-sm text-gray-600 text-center">
                Exporting {Math.ceil(progress / (100 / versions.length))} of {versions.length}...
              </p>
            </div>
          )}

          <div className="flex justify-end gap-3 pt-4">
            <Button variant="outline" onClick={onClose} disabled={exporting}>Cancel</Button>
            <Button onClick={handleBulkExport} disabled={exporting}>
              <Download className="w-4 h-4 mr-2" />
              Export All ({versions.length})
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

