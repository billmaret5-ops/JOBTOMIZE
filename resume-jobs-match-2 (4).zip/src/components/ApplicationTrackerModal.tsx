import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { FileText, Calendar, Clock, CheckCircle, XCircle, AlertCircle, Plus, Search } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface ApplicationTrackerModalProps {
  open: boolean;
  onClose: () => void;
}

interface JobApplication {
  id: string;
  job_title: string;
  company: string;
  status: 'applied' | 'screening' | 'interview' | 'offer' | 'rejected' | 'withdrawn';
  applied_date: string;
  last_updated: string;
  next_step?: string;
  next_step_date?: string;
  notes?: string;
  salary_offered?: string;
}

const ApplicationTrackerModal: React.FC<ApplicationTrackerModalProps> = ({ open, onClose }) => {
  const { user } = useAuth();
  const [applications, setApplications] = useState<JobApplication[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    if (open && user) {
      loadApplications();
    }
  }, [open, user]);

  const loadApplications = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .select('*')
        .eq('user_id', user.id)
        .order('applied_date', { ascending: false });

      if (error) {
        console.error('Error loading applications:', error);
      } else {
        setApplications(data || []);
      }
    } catch (error) {
      console.error('Error loading applications:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: JobApplication['status']) => {
    switch (status) {
      case 'applied': return 'bg-blue-100 text-blue-800';
      case 'screening': return 'bg-yellow-100 text-yellow-800';
      case 'interview': return 'bg-purple-100 text-purple-800';
      case 'offer': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      case 'withdrawn': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusIcon = (status: JobApplication['status']) => {
    switch (status) {
      case 'applied': return <Clock className="h-4 w-4" />;
      case 'screening': return <AlertCircle className="h-4 w-4" />;
      case 'interview': return <Calendar className="h-4 w-4" />;
      case 'offer': return <CheckCircle className="h-4 w-4" />;
      case 'rejected': return <XCircle className="h-4 w-4" />;
      case 'withdrawn': return <XCircle className="h-4 w-4" />;
      default: return <Clock className="h-4 w-4" />;
    }
  };

  const getProgressValue = (status: JobApplication['status']) => {
    switch (status) {
      case 'applied': return 20;
      case 'screening': return 40;
      case 'interview': return 60;
      case 'offer': return 100;
      case 'rejected': return 0;
      case 'withdrawn': return 0;
      default: return 0;
    }
  };

  // Mock data for demonstration
  const mockApplications: JobApplication[] = [
    {
      id: '1',
      job_title: 'Senior Frontend Developer',
      company: 'TechCorp',
      status: 'interview',
      applied_date: '2024-01-10T00:00:00Z',
      last_updated: '2024-01-15T00:00:00Z',
      next_step: 'Technical Interview',
      next_step_date: '2024-01-20T00:00:00Z',
      notes: 'Completed initial screening call. Technical round scheduled.'
    },
    {
      id: '2',
      job_title: 'Product Manager',
      company: 'StartupXYZ',
      status: 'screening',
      applied_date: '2024-01-12T00:00:00Z',
      last_updated: '2024-01-14T00:00:00Z',
      next_step: 'Phone Screen',
      next_step_date: '2024-01-18T00:00:00Z'
    },
    {
      id: '3',
      job_title: 'UX Designer',
      company: 'DesignStudio',
      status: 'offer',
      applied_date: '2024-01-05T00:00:00Z',
      last_updated: '2024-01-16T00:00:00Z',
      salary_offered: '$95,000',
      notes: 'Received offer! Need to respond by Jan 25th.'
    },
    {
      id: '4',
      job_title: 'Software Engineer',
      company: 'BigTech',
      status: 'rejected',
      applied_date: '2024-01-08T00:00:00Z',
      last_updated: '2024-01-13T00:00:00Z',
      notes: 'Not selected after technical interview.'
    }
  ];

  const displayApplications = applications.length > 0 ? applications : mockApplications;
  
  const filteredApplications = displayApplications.filter(app => {
    const matchesSearch = app.job_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.company.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const statusCounts = displayApplications.reduce((acc, app) => {
    acc[app.status] = (acc[app.status] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-6xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <FileText className="h-5 w-5" />
            <span>Application Tracker</span>
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Stats Overview */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">{statusCounts.applied || 0}</div>
                <div className="text-sm text-gray-600">Applied</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-yellow-600">{statusCounts.screening || 0}</div>
                <div className="text-sm text-gray-600">Screening</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">{statusCounts.interview || 0}</div>
                <div className="text-sm text-gray-600">Interview</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">{statusCounts.offer || 0}</div>
                <div className="text-sm text-gray-600">Offers</div>
              </CardContent>
            </Card>
          </div>

          {/* Search and Filter */}
          <div className="flex space-x-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search applications..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="border rounded-md px-3 py-2 text-sm"
            >
              <option value="all">All Status</option>
              <option value="applied">Applied</option>
              <option value="screening">Screening</option>
              <option value="interview">Interview</option>
              <option value="offer">Offer</option>
              <option value="rejected">Rejected</option>
              <option value="withdrawn">Withdrawn</option>
            </select>
            <Button>
              <Plus className="h-4 w-4 mr-2" />
              Add Application
            </Button>
          </div>

          {/* Applications List */}
          <div className="space-y-4">
            {filteredApplications.map((app) => (
              <Card key={app.id} className="hover:shadow-md transition-shadow">
                <CardHeader className="pb-3">
                  <div className="flex justify-between items-start">
                    <div>
                      <CardTitle className="text-lg">{app.job_title}</CardTitle>
                      <p className="text-gray-600">{app.company}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge className={getStatusColor(app.status)}>
                        {getStatusIcon(app.status)}
                        <span className="ml-1 capitalize">{app.status}</span>
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  {/* Progress Bar */}
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Application Progress</span>
                      <span>{getProgressValue(app.status)}%</span>
                    </div>
                    <Progress value={getProgressValue(app.status)} className="h-2" />
                  </div>

                  {/* Application Details */}
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                    <div>
                      <span className="font-medium">Applied:</span>
                      <p className="text-gray-600">
                        {new Date(app.applied_date).toLocaleDateString()}
                      </p>
                    </div>
                    <div>
                      <span className="font-medium">Last Updated:</span>
                      <p className="text-gray-600">
                        {new Date(app.last_updated).toLocaleDateString()}
                      </p>
                    </div>
                    {app.next_step && (
                      <div>
                        <span className="font-medium">Next Step:</span>
                        <p className="text-gray-600">{app.next_step}</p>
                      </div>
                    )}
                    {app.salary_offered && (
                      <div>
                        <span className="font-medium">Salary Offered:</span>
                        <p className="text-green-600 font-medium">{app.salary_offered}</p>
                      </div>
                    )}
                  </div>

                  {/* Next Step Date */}
                  {app.next_step_date && (
                    <div className="flex items-center space-x-2 text-sm bg-blue-50 p-2 rounded">
                      <Calendar className="h-4 w-4 text-blue-600" />
                      <span>
                        <strong>{app.next_step}</strong> scheduled for{' '}
                        {new Date(app.next_step_date).toLocaleDateString()}
                      </span>
                    </div>
                  )}

                  {/* Notes */}
                  {app.notes && (
                    <div className="text-sm">
                      <span className="font-medium">Notes:</span>
                      <p className="text-gray-600 mt-1">{app.notes}</p>
                    </div>
                  )}

                  {/* Action Buttons */}
                  <div className="flex justify-end space-x-2 pt-2">
                    <Button size="sm" variant="outline">
                      Edit
                    </Button>
                    <Button size="sm" variant="outline">
                      Add Note
                    </Button>
                    <Button size="sm" variant="outline">
                      Update Status
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>

          {filteredApplications.length === 0 && (
            <div className="text-center py-8 text-gray-500">
              <FileText className="h-12 w-12 mx-auto mb-4 text-gray-300" />
              <p>No applications found</p>
              <p className="text-sm">Start tracking your job applications here</p>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default ApplicationTrackerModal;