import React, { useState, useEffect, useRef } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { X, Send, MessageCircle, Video } from 'lucide-react';
import { warmupCollaborationService, ChatMessage } from '../services/warmupCollaborationService';


interface CollaborativeChatSidebarProps {
  currentUser: { id: string; name: string };
  onClose: () => void;
  videoCallActive?: boolean;
  onVideoToggle?: () => void;
}


export const CollaborativeChatSidebar: React.FC<CollaborativeChatSidebarProps> = ({ 
  currentUser,
  onClose,
  videoCallActive = false,
  onVideoToggle
}) => {

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    loadMessages();
    const interval = setInterval(loadMessages, 2000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const loadMessages = () => {
    setMessages(warmupCollaborationService.getChatMessages());
  };

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const handleSendMessage = async () => {
    if (!newMessage.trim()) return;

    await warmupCollaborationService.sendMessage(
      currentUser.id,
      currentUser.name,
      newMessage
    );

    setNewMessage('');
    loadMessages();
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="w-80 h-full flex flex-col border-l">
      <div className="flex items-center justify-between p-4 border-b">
        <div className="flex items-center gap-2">
          <MessageCircle className="w-5 h-5" />
          <h3 className="font-semibold">Team Chat</h3>
          {videoCallActive && (
            <Badge variant="secondary" className="ml-2">
              <Video className="w-3 h-3 mr-1" />
              Live
            </Badge>
          )}
        </div>
        <div className="flex items-center gap-2">
          {onVideoToggle && (
            <Button 
              variant={videoCallActive ? 'default' : 'outline'} 
              size="sm" 
              onClick={onVideoToggle}
            >
              <Video className="w-4 h-4" />
            </Button>
          )}
          <Button variant="ghost" size="sm" onClick={onClose}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>


      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {messages.map((message) => (
          <div
            key={message.id}
            className={`${
              message.userId === currentUser.id ? 'ml-auto' : 'mr-auto'
            } max-w-[80%]`}
          >
            {message.type === 'system' ? (
              <div className="text-center text-xs text-gray-500 py-2">
                {message.content}
              </div>
            ) : (
              <div>
                {message.userId !== currentUser.id && (
                  <p className="text-xs text-gray-500 mb-1">{message.userName}</p>
                )}
                <div
                  className={`rounded-lg p-3 ${
                    message.userId === currentUser.id
                      ? 'bg-blue-500 text-white'
                      : 'bg-gray-100 text-gray-900'
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
                <p className="text-xs text-gray-400 mt-1">
                  {new Date(message.timestamp).toLocaleTimeString()}
                </p>
              </div>
            )}
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      <div className="p-4 border-t">
        <div className="flex gap-2">
          <Input
            placeholder="Type a message..."
            value={newMessage}
            onChange={(e) => setNewMessage(e.target.value)}
            onKeyPress={handleKeyPress}
          />
          <Button onClick={handleSendMessage} size="sm">
            <Send className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </Card>
  );
};
