import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/ProductionAuthContext';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Shield, Database, Mail, Users, BarChart, Settings, CheckCircle, XCircle, Loader2, Brain } from 'lucide-react';

import { useNavigate } from 'react-router-dom';

export function AdminAccessHub() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [isAdmin, setIsAdmin] = useState(false);
  const [loading, setLoading] = useState(true);
  const [granting, setGranting] = useState(false);

  useEffect(() => {
    checkAdminStatus();
  }, [user]);

  const checkAdminStatus = async () => {
    if (!user) {
      setLoading(false);
      return;
    }

    try {
      const { data, error } = await supabase
        .from('user_roles')
        .select('role')
        .eq('user_id', user.id)
        .single();

      if (!error && data?.role === 'admin') {
        setIsAdmin(true);
      }
    } catch (err) {
      console.error('Error checking admin status:', err);
    } finally {
      setLoading(false);
    }
  };

  const grantAdminAccess = async () => {
    if (!user) return;
    
    setGranting(true);
    try {
      const { error } = await supabase
        .from('user_roles')
        .upsert({ 
          user_id: user.id, 
          role: 'admin',
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
      
      setIsAdmin(true);
      alert('Admin access granted successfully!');
    } catch (err: any) {
      alert(`Error: ${err.message}`);
    } finally {
      setGranting(false);
    }
  };

  const dashboards = [
    { name: 'Admin Dashboard', path: '/admin', icon: Shield, color: 'bg-red-500' },
    { name: 'Unified Analytics', path: '/unified-analytics', icon: BarChart, color: 'bg-blue-600' },
    { name: 'Predictive Analytics', path: '/predictive-analytics', icon: Brain, color: 'bg-purple-600' },
    { name: 'Advanced ML Models', path: '/advanced-ml', icon: Brain, color: 'bg-indigo-600' },
    { name: 'Email Analytics', path: '/email-analytics', icon: Mail, color: 'bg-blue-500' },
    { name: 'Template Analytics', path: '/template-analytics', icon: BarChart, color: 'bg-green-500' },
    { name: 'User Management', path: '/admin', icon: Users, color: 'bg-purple-500' },
    { name: 'Email Templates', path: '/email-templates', icon: Mail, color: 'bg-indigo-500' },
    { name: 'Contact Management', path: '/contact-management', icon: Database, color: 'bg-yellow-500' },
    { name: 'Applications', path: '/applications', icon: BarChart, color: 'bg-pink-500' },
    { name: 'Job Matching', path: '/job-matching', icon: Settings, color: 'bg-teal-500' },
  ];




  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gray-50">
        <Card className="p-8 max-w-md">
          <h2 className="text-2xl font-bold mb-4">Admin Access Required</h2>
          <p className="text-gray-600 mb-4">Please log in to access admin features.</p>
          <Button onClick={() => navigate('/')}>Go to Login</Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100 p-8">
      <div className="max-w-7xl mx-auto">
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Admin Access Hub</h1>
          <p className="text-gray-600">Logged in as: {user.email}</p>
        </div>

        <Card className="p-6 mb-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              {isAdmin ? (
                <>
                  <CheckCircle className="h-8 w-8 text-green-600" />
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">Admin Access Active</h3>
                    <p className="text-gray-600">You have full admin privileges</p>
                  </div>
                </>
              ) : (
                <>
                  <XCircle className="h-8 w-8 text-red-600" />
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">No Admin Access</h3>
                    <p className="text-gray-600">Grant yourself admin privileges to continue</p>
                  </div>
                </>
              )}
            </div>
            {!isAdmin && (
              <Button onClick={grantAdminAccess} disabled={granting}>
                {granting ? 'Granting...' : 'Grant Admin Access'}
              </Button>
            )}
          </div>
        </Card>

        {isAdmin && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {dashboards.map((dashboard) => (
              <Card 
                key={dashboard.path}
                className="p-6 hover:shadow-lg transition-shadow cursor-pointer"
                onClick={() => navigate(dashboard.path)}
              >
                <div className={`${dashboard.color} w-12 h-12 rounded-lg flex items-center justify-center mb-4`}>
                  <dashboard.icon className="h-6 w-6 text-white" />
                </div>
                <h3 className="text-lg font-bold text-gray-900 mb-2">{dashboard.name}</h3>
                <p className="text-sm text-gray-600">Access {dashboard.name.toLowerCase()}</p>
              </Card>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
