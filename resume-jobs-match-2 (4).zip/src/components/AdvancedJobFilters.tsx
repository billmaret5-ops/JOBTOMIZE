import { useState } from 'react';
import { Button } from './ui/button';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { Switch } from './ui/switch';
import { Card } from './ui/card';

interface FilterProps {
  onApplyFilters: (filters: any) => void;
  onResetFilters: () => void;
}

export function AdvancedJobFilters({ onApplyFilters, onResetFilters }: FilterProps) {
  const [datePosted, setDatePosted] = useState('all');
  const [remoteOnly, setRemoteOnly] = useState(false);
  const [employmentTypes, setEmploymentTypes] = useState<string[]>([]);
  const [experienceLevel, setExperienceLevel] = useState('all');
  const [salaryRange, setSalaryRange] = useState([0, 200000]);
  const [radius, setRadius] = useState(25);

  const handleApply = () => {
    onApplyFilters({
      date_posted: datePosted !== 'all' ? datePosted : undefined,
      remote_jobs_only: remoteOnly,
      employment_types: employmentTypes.join(','),
      job_requirements: experienceLevel !== 'all' ? experienceLevel : undefined,
      min_salary: salaryRange[0],
      max_salary: salaryRange[1],
      radius,
    });
  };

  const handleReset = () => {
    setDatePosted('all');
    setRemoteOnly(false);
    setEmploymentTypes([]);
    setExperienceLevel('all');
    setSalaryRange([0, 200000]);
    setRadius(25);
    onResetFilters();
  };

  const toggleEmploymentType = (type: string) => {
    setEmploymentTypes(prev =>
      prev.includes(type) ? prev.filter(t => t !== type) : [...prev, type]
    );
  };

  return (
    <Card className="p-6 space-y-6">
      <div>
        <h3 className="font-semibold mb-4">Filters</h3>
      </div>

      <div className="space-y-2">
        <Label>Date Posted</Label>
        <Select value={datePosted} onValueChange={setDatePosted}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Time</SelectItem>
            <SelectItem value="today">Today</SelectItem>
            <SelectItem value="3days">Last 3 Days</SelectItem>
            <SelectItem value="week">Last Week</SelectItem>
            <SelectItem value="month">Last Month</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="flex items-center justify-between">
        <Label>Remote Only</Label>
        <Switch checked={remoteOnly} onCheckedChange={setRemoteOnly} />
      </div>

      <div className="space-y-2">
        <Label>Employment Type</Label>
        <div className="space-y-2">
          {['FULLTIME', 'PARTTIME', 'CONTRACTOR', 'INTERN'].map(type => (
            <label key={type} className="flex items-center gap-2 cursor-pointer">
              <input
                type="checkbox"
                checked={employmentTypes.includes(type)}
                onChange={() => toggleEmploymentType(type)}
                className="rounded"
              />
              <span className="text-sm">{type.replace('FULLTIME', 'Full Time').replace('PARTTIME', 'Part Time')}</span>
            </label>
          ))}
        </div>
      </div>

      <div className="space-y-2">
        <Label>Experience Level</Label>
        <Select value={experienceLevel} onValueChange={setExperienceLevel}>
          <SelectTrigger>
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Levels</SelectItem>
            <SelectItem value="no_experience">Entry Level</SelectItem>
            <SelectItem value="under_3_years_experience">1-3 Years</SelectItem>
            <SelectItem value="more_than_3_years_experience">3+ Years</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-3">
        <Label>Salary Range (USD)</Label>
        <Slider
          value={salaryRange}
          onValueChange={setSalaryRange}
          min={0}
          max={200000}
          step={5000}
        />
        <div className="flex justify-between text-sm text-gray-600">
          <span>${salaryRange[0].toLocaleString()}</span>
          <span>${salaryRange[1].toLocaleString()}</span>
        </div>
      </div>

      <div className="space-y-3">
        <Label>Search Radius (miles)</Label>
        <Slider value={[radius]} onValueChange={([v]) => setRadius(v)} min={5} max={100} step={5} />
        <p className="text-sm text-gray-600">{radius} miles</p>
      </div>

      <div className="flex gap-2 pt-4">
        <Button onClick={handleApply} className="flex-1">Apply Filters</Button>
        <Button onClick={handleReset} variant="outline">Reset</Button>
      </div>
    </Card>
  );
}
