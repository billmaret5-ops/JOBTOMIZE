import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Search, Filter, Clock, Users, Star, Code2, Database, Cpu } from 'lucide-react';

interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: 'Algorithm' | 'Data Structure' | 'System Design';
  timeLimit: number;
  completionRate: number;
  tags: string[];
  solved: boolean;
  attempts: number;
}

interface CodingChallengeListProps {
  onSelectChallenge: (challenge: Challenge) => void;
}

export const CodingChallengeList: React.FC<CodingChallengeListProps> = ({
  onSelectChallenge
}) => {
  const [challenges, setChallenges] = useState<Challenge[]>([]);
  const [filteredChallenges, setFilteredChallenges] = useState<Challenge[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [difficultyFilter, setDifficultyFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [sortBy, setSortBy] = useState('title');

  useEffect(() => {
    // Mock challenge data
    const mockChallenges: Challenge[] = [
      {
        id: '1',
        title: 'Two Sum',
        description: 'Given an array of integers, return indices of two numbers that add up to target.',
        difficulty: 'Easy',
        category: 'Algorithm',
        timeLimit: 30,
        completionRate: 85,
        tags: ['Array', 'Hash Table'],
        solved: true,
        attempts: 2
      },
      {
        id: '2',
        title: 'Binary Tree Traversal',
        description: 'Implement in-order, pre-order, and post-order traversal of a binary tree.',
        difficulty: 'Medium',
        category: 'Data Structure',
        timeLimit: 45,
        completionRate: 65,
        tags: ['Tree', 'Recursion', 'DFS'],
        solved: false,
        attempts: 1
      },
      {
        id: '3',
        title: 'Design URL Shortener',
        description: 'Design a URL shortening service like bit.ly with scalability considerations.',
        difficulty: 'Hard',
        category: 'System Design',
        timeLimit: 90,
        completionRate: 35,
        tags: ['System Design', 'Scalability', 'Database'],
        solved: false,
        attempts: 0
      },
      {
        id: '4',
        title: 'Valid Parentheses',
        description: 'Determine if the input string has valid parentheses.',
        difficulty: 'Easy',
        category: 'Algorithm',
        timeLimit: 20,
        completionRate: 78,
        tags: ['Stack', 'String'],
        solved: true,
        attempts: 1
      },
      {
        id: '5',
        title: 'LRU Cache',
        description: 'Design and implement a data structure for Least Recently Used (LRU) cache.',
        difficulty: 'Medium',
        category: 'Data Structure',
        timeLimit: 60,
        completionRate: 52,
        tags: ['Hash Table', 'Linked List', 'Design'],
        solved: false,
        attempts: 3
      },
      {
        id: '6',
        title: 'Design Chat System',
        description: 'Design a real-time chat system supporting millions of users.',
        difficulty: 'Hard',
        category: 'System Design',
        timeLimit: 120,
        completionRate: 28,
        tags: ['System Design', 'Real-time', 'WebSocket'],
        solved: false,
        attempts: 0
      }
    ];
    
    setChallenges(mockChallenges);
    setFilteredChallenges(mockChallenges);
  }, []);

  useEffect(() => {
    let filtered = challenges.filter(challenge => {
      const matchesSearch = challenge.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           challenge.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           challenge.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
      
      const matchesDifficulty = difficultyFilter === 'all' || challenge.difficulty === difficultyFilter;
      const matchesCategory = categoryFilter === 'all' || challenge.category === categoryFilter;
      
      return matchesSearch && matchesDifficulty && matchesCategory;
    });

    // Sort challenges
    filtered.sort((a, b) => {
      switch (sortBy) {
        case 'difficulty':
          const difficultyOrder = { 'Easy': 1, 'Medium': 2, 'Hard': 3 };
          return difficultyOrder[a.difficulty] - difficultyOrder[b.difficulty];
        case 'completion':
          return b.completionRate - a.completionRate;
        case 'time':
          return a.timeLimit - b.timeLimit;
        default:
          return a.title.localeCompare(b.title);
      }
    });

    setFilteredChallenges(filtered);
  }, [challenges, searchTerm, difficultyFilter, categoryFilter, sortBy]);

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case 'Easy': return 'bg-green-100 text-green-800';
      case 'Medium': return 'bg-yellow-100 text-yellow-800';
      case 'Hard': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'Algorithm': return <Code2 className="h-4 w-4" />;
      case 'Data Structure': return <Database className="h-4 w-4" />;
      case 'System Design': return <Cpu className="h-4 w-4" />;
      default: return <Code2 className="h-4 w-4" />;
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900">Coding Challenges</h1>
        <p className="text-gray-600 mt-2">Practice your programming skills with curated challenges</p>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="p-4">
          <div className="flex flex-wrap gap-4">
            <div className="flex-1 min-w-64">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                <Input
                  placeholder="Search challenges..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
            </div>
            
            <Select value={difficultyFilter} onValueChange={setDifficultyFilter}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Difficulty" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Levels</SelectItem>
                <SelectItem value="Easy">Easy</SelectItem>
                <SelectItem value="Medium">Medium</SelectItem>
                <SelectItem value="Hard">Hard</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={categoryFilter} onValueChange={setCategoryFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Category" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Categories</SelectItem>
                <SelectItem value="Algorithm">Algorithm</SelectItem>
                <SelectItem value="Data Structure">Data Structure</SelectItem>
                <SelectItem value="System Design">System Design</SelectItem>
              </SelectContent>
            </Select>
            
            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-32">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="title">Title</SelectItem>
                <SelectItem value="difficulty">Difficulty</SelectItem>
                <SelectItem value="completion">Completion</SelectItem>
                <SelectItem value="time">Time Limit</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Challenge Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredChallenges.map((challenge) => (
          <Card key={challenge.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardHeader>
              <div className="flex items-start justify-between">
                <div className="flex items-center space-x-2">
                  {getCategoryIcon(challenge.category)}
                  <CardTitle className="text-lg">{challenge.title}</CardTitle>
                </div>
                {challenge.solved && (
                  <Star className="h-5 w-5 text-yellow-500 fill-current" />
                )}
              </div>
            </CardHeader>
            
            <CardContent>
              <p className="text-gray-600 text-sm mb-4 line-clamp-2">
                {challenge.description}
              </p>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <Badge className={getDifficultyColor(challenge.difficulty)}>
                    {challenge.difficulty}
                  </Badge>
                  <Badge variant="outline">{challenge.category}</Badge>
                </div>
                
                <div className="flex items-center justify-between text-sm text-gray-500">
                  <div className="flex items-center space-x-1">
                    <Clock className="h-4 w-4" />
                    <span>{challenge.timeLimit} min</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <Users className="h-4 w-4" />
                    <span>{challenge.completionRate}% solved</span>
                  </div>
                </div>
                
                <div className="flex flex-wrap gap-1">
                  {challenge.tags.slice(0, 3).map((tag) => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {challenge.tags.length > 3 && (
                    <Badge variant="secondary" className="text-xs">
                      +{challenge.tags.length - 3}
                    </Badge>
                  )}
                </div>
                
                <div className="pt-2">
                  <Button 
                    className="w-full" 
                    onClick={() => onSelectChallenge(challenge)}
                  >
                    {challenge.solved ? 'Solve Again' : challenge.attempts > 0 ? 'Continue' : 'Start Challenge'}
                  </Button>
                </div>
                
                {challenge.attempts > 0 && (
                  <p className="text-xs text-gray-500 text-center">
                    {challenge.attempts} attempt{challenge.attempts !== 1 ? 's' : ''}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
      
      {filteredChallenges.length === 0 && (
        <Card>
          <CardContent className="p-8 text-center">
            <Filter className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h3 className="text-lg font-medium text-gray-900 mb-2">No challenges found</h3>
            <p className="text-gray-500">Try adjusting your search or filter criteria</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};