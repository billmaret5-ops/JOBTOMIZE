import React, { useEffect } from 'react';
import { notificationService } from '../services/realTimeNotificationService';
import { pushNotificationService } from '../services/pushNotificationService';

interface ApplicationNotificationCenterProps {
  applications: Array<{
    id: string;
    company: string;
    position: string;
    status: string;
    appliedDate: string;
    lastUpdate?: string;
  }>;
}

export const ApplicationNotificationCenter: React.FC<ApplicationNotificationCenterProps> = ({
  applications
}) => {
  useEffect(() => {
    // Initialize notification services
    const initializeServices = async () => {
      await notificationService.initialize();
      await pushNotificationService.initialize();
    };

    initializeServices();

    // Monitor application status changes
    const checkApplicationUpdates = () => {
      applications.forEach(app => {
        // Simulate status change detection
        if (app.lastUpdate) {
          const lastUpdateTime = new Date(app.lastUpdate);
          const now = new Date();
          const timeDiff = now.getTime() - lastUpdateTime.getTime();
          
          // If updated within last 5 minutes, consider it a new update
          if (timeDiff < 5 * 60 * 1000) {
            handleApplicationUpdate(app);
          }
        }
      });
    };

    // Check for updates every minute
    const interval = setInterval(checkApplicationUpdates, 60000);

    return () => clearInterval(interval);
  }, [applications]);

  const handleApplicationUpdate = async (application: any) => {
    let notificationType: 'application_response' | 'interview_scheduled' | 'offer_received' | 'application_viewed';
    let title: string;
    let message: string;

    // Determine notification type based on status
    switch (application.status.toLowerCase()) {
      case 'interview scheduled':
        notificationType = 'interview_scheduled';
        title = 'Interview Scheduled!';
        message = `Your interview with ${application.company} for ${application.position} has been scheduled.`;
        break;
      case 'offer received':
        notificationType = 'offer_received';
        title = 'Job Offer Received!';
        message = `Congratulations! You've received an offer from ${application.company} for ${application.position}.`;
        break;
      case 'application viewed':
        notificationType = 'application_viewed';
        title = 'Application Viewed';
        message = `Your application to ${application.company} for ${application.position} has been viewed.`;
        break;
      default:
        notificationType = 'application_response';
        title = 'Application Update';
        message = `There's an update on your application to ${application.company} for ${application.position}.`;
    }

    // Add notification to the system
    await notificationService.addNotification({
      type: notificationType,
      title,
      message,
      applicationId: application.id,
      companyName: application.company,
      jobTitle: application.position,
      priority: notificationType === 'offer_received' ? 'high' : 'medium'
    });

    // Send push notification
    await pushNotificationService.sendPushNotification({
      title,
      body: message,
      icon: '/favicon.ico',
      tag: `app-${application.id}`,
      requireInteraction: notificationType === 'offer_received',
      actions: [
        {
          action: 'view',
          title: 'View Application'
        },
        {
          action: 'dismiss',
          title: 'Dismiss'
        }
      ]
    });
  };

  // Simulate receiving notifications for demo purposes
  const simulateNotifications = async () => {
    const sampleNotifications = [
      {
        type: 'application_response' as const,
        title: 'Application Response Received',
        message: 'Your application to TechCorp for Software Engineer has received a response.',
        companyName: 'TechCorp',
        jobTitle: 'Software Engineer',
        priority: 'medium' as const
      },
      {
        type: 'interview_scheduled' as const,
        title: 'Interview Scheduled',
        message: 'Your interview with DataFlow Inc. for Data Scientist has been scheduled for tomorrow at 2 PM.',
        companyName: 'DataFlow Inc.',
        jobTitle: 'Data Scientist',
        priority: 'high' as const
      },
      {
        type: 'offer_received' as const,
        title: 'Job Offer Received!',
        message: 'Congratulations! You have received an offer from StartupXYZ for Full Stack Developer.',
        companyName: 'StartupXYZ',
        jobTitle: 'Full Stack Developer',
        priority: 'high' as const
      }
    ];

    // Add notifications with random delays
    sampleNotifications.forEach((notification, index) => {
      setTimeout(async () => {
        await notificationService.addNotification(notification);
      }, (index + 1) * 10000); // 10 seconds apart
    });
  };

  useEffect(() => {
    // Simulate notifications after 5 seconds
    const timer = setTimeout(simulateNotifications, 5000);
    return () => clearTimeout(timer);
  }, []);

  // This component doesn't render anything visible
  // It's a background service component
  return null;
};