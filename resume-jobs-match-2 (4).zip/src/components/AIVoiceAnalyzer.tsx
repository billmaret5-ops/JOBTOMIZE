import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, TrendingUp, Target, Award } from 'lucide-react';

interface VoiceAnalysis {
  overall_score: number;
  clarity_score: number;
  pace_score: number;
  tone_score: number;
  projection_score: number;
  detailed_feedback: string;
  recommendations: string[];
  strengths: string[];
  areas_for_improvement: string[];
  timestamp: string;
}

interface AIVoiceAnalyzerProps {
  recordingId: string;
  audioUrl: string;
  duration: number;
  onAnalysisComplete: (analysis: VoiceAnalysis) => void;
}

export const AIVoiceAnalyzer: React.FC<AIVoiceAnalyzerProps> = ({
  recordingId,
  audioUrl,
  duration,
  onAnalysisComplete
}) => {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<VoiceAnalysis | null>(null);

  const analyzeRecording = async () => {
    setIsAnalyzing(true);
    try {
      // Simulate AI analysis with realistic data
      await new Promise(resolve => setTimeout(resolve, 3000));
      
      const mockAnalysis: VoiceAnalysis = {
        overall_score: Math.floor(Math.random() * 3) + 7,
        clarity_score: Math.floor(Math.random() * 3) + 7,
        pace_score: Math.floor(Math.random() * 3) + 6,
        tone_score: Math.floor(Math.random() * 3) + 7,
        projection_score: Math.floor(Math.random() * 3) + 6,
        detailed_feedback: "Your speech demonstrates good clarity and natural rhythm. The pace is generally appropriate, though there are moments where slowing down could enhance comprehension. Your tone is engaging and professional, with good emotional range. Voice projection could be improved for better audience engagement.",
        recommendations: [
          "Practice speaking 10-15% slower for better clarity",
          "Work on diaphragmatic breathing for stronger projection",
          "Use more pauses between key points",
          "Practice varying your tone to maintain listener interest"
        ],
        strengths: [
          "Clear articulation of consonants",
          "Natural speaking rhythm",
          "Good use of inflection",
          "Professional tone"
        ],
        areas_for_improvement: [
          "Speaking pace consistency",
          "Voice projection strength",
          "Strategic use of pauses",
          "Volume control"
        ],
        timestamp: new Date().toISOString()
      };

      setAnalysis(mockAnalysis);
      onAnalysisComplete(mockAnalysis);
    } catch (error) {
      console.error('Analysis failed:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 8) return 'text-green-600';
    if (score >= 6) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreBadge = (score: number) => {
    if (score >= 8) return 'Excellent';
    if (score >= 6) return 'Good';
    return 'Needs Work';
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Brain className="w-5 h-5" />
          AI Voice Analysis
        </CardTitle>
      </CardHeader>
      <CardContent>
        {!analysis ? (
          <div className="text-center py-8">
            <Button 
              onClick={analyzeRecording}
              disabled={isAnalyzing}
              className="mb-4"
            >
              {isAnalyzing ? 'Analyzing...' : 'Start AI Analysis'}
            </Button>
            {isAnalyzing && (
              <div className="space-y-2">
                <div className="animate-pulse text-sm text-gray-600">
                  Analyzing speech patterns...
                </div>
                <Progress value={33} className="w-full" />
              </div>
            )}
          </div>
        ) : (
          <Tabs defaultValue="scores" className="w-full">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="scores">Scores</TabsTrigger>
              <TabsTrigger value="feedback">Feedback</TabsTrigger>
              <TabsTrigger value="coaching">Coaching</TabsTrigger>
              <TabsTrigger value="progress">Progress</TabsTrigger>
            </TabsList>

            <TabsContent value="scores" className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Overall Score</span>
                    <div className="flex items-center gap-2">
                      <span className={`font-bold ${getScoreColor(analysis.overall_score)}`}>
                        {analysis.overall_score}/10
                      </span>
                      <Badge variant="secondary">{getScoreBadge(analysis.overall_score)}</Badge>
                    </div>
                  </div>
                  <Progress value={analysis.overall_score * 10} />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Clarity</span>
                    <span className={`font-bold ${getScoreColor(analysis.clarity_score)}`}>
                      {analysis.clarity_score}/10
                    </span>
                  </div>
                  <Progress value={analysis.clarity_score * 10} />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Pace</span>
                    <span className={`font-bold ${getScoreColor(analysis.pace_score)}`}>
                      {analysis.pace_score}/10
                    </span>
                  </div>
                  <Progress value={analysis.pace_score * 10} />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Tone</span>
                    <span className={`font-bold ${getScoreColor(analysis.tone_score)}`}>
                      {analysis.tone_score}/10
                    </span>
                  </div>
                  <Progress value={analysis.tone_score * 10} />
                </div>

                <div className="space-y-3">
                  <div className="flex justify-between items-center">
                    <span>Projection</span>
                    <span className={`font-bold ${getScoreColor(analysis.projection_score)}`}>
                      {analysis.projection_score}/10
                    </span>
                  </div>
                  <Progress value={analysis.projection_score * 10} />
                </div>
              </div>
            </TabsContent>

            <TabsContent value="feedback" className="space-y-4">
              <div className="prose prose-sm max-w-none">
                <p className="text-gray-700 leading-relaxed">
                  {analysis.detailed_feedback}
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Award className="w-4 h-4 text-green-600" />
                      Strengths
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {analysis.strengths.map((strength, index) => (
                        <li key={index} className="text-sm text-green-700 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-green-500 rounded-full" />
                          {strength}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader className="pb-3">
                    <CardTitle className="text-sm flex items-center gap-2">
                      <Target className="w-4 h-4 text-orange-600" />
                      Areas for Improvement
                    </CardTitle>
                  </CardHeader>
                  <CardContent>
                    <ul className="space-y-2">
                      {analysis.areas_for_improvement.map((area, index) => (
                        <li key={index} className="text-sm text-orange-700 flex items-center gap-2">
                          <div className="w-1.5 h-1.5 bg-orange-500 rounded-full" />
                          {area}
                        </li>
                      ))}
                    </ul>
                  </CardContent>
                </Card>
              </div>
            </TabsContent>

            <TabsContent value="coaching" className="space-y-4">
              <div className="space-y-3">
                <h3 className="font-semibold flex items-center gap-2">
                  <TrendingUp className="w-4 h-4" />
                  Personalized Recommendations
                </h3>
                <div className="space-y-3">
                  {analysis.recommendations.map((recommendation, index) => (
                    <Card key={index}>
                      <CardContent className="pt-4">
                        <div className="flex items-start gap-3">
                          <div className="w-6 h-6 bg-blue-100 rounded-full flex items-center justify-center flex-shrink-0">
                            <span className="text-xs font-bold text-blue-600">{index + 1}</span>
                          </div>
                          <p className="text-sm text-gray-700">{recommendation}</p>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            </TabsContent>

            <TabsContent value="progress" className="space-y-4">
              <div className="text-center py-8 text-gray-500">
                <TrendingUp className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Record more sessions to track your progress over time</p>
                <p className="text-sm mt-2">AI will analyze trends and provide personalized coaching</p>
              </div>
            </TabsContent>
          </Tabs>
        )}
      </CardContent>
    </Card>
  );
};