import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  Briefcase, FileText, Mail, MessageSquare, CheckCircle, 
  Loader2, Sparkles, TrendingUp, Target, Award, Zap, Brain
} from 'lucide-react';

const MOCK_JOBS = [
  { id: 1, title: 'Senior Software Engineer', company: 'TechCorp', salary: '$140k-180k', match: 94, location: 'San Francisco, CA' },
  { id: 2, title: 'Full Stack Developer', company: 'StartupXYZ', salary: '$120k-160k', match: 91, location: 'Austin, TX' },
  { id: 3, title: 'Frontend Engineer', company: 'DesignCo', salary: '$110k-150k', match: 89, location: 'New York, NY' },
  { id: 4, title: 'Backend Developer', company: 'DataSystems', salary: '$130k-170k', match: 88, location: 'Seattle, WA' },
  { id: 5, title: 'DevOps Engineer', company: 'CloudTech', salary: '$125k-165k', match: 87, location: 'Boston, MA' },
  { id: 6, title: 'Software Architect', company: 'Enterprise Inc', salary: '$150k-200k', match: 86, location: 'Chicago, IL' },
  { id: 7, title: 'Mobile Developer', company: 'AppStudio', salary: '$115k-155k', match: 85, location: 'Los Angeles, CA' },
  { id: 8, title: 'ML Engineer', company: 'AI Labs', salary: '$145k-190k', match: 84, location: 'San Francisco, CA' },
  { id: 9, title: 'Security Engineer', company: 'SecureNet', salary: '$135k-175k', match: 83, location: 'Denver, CO' },
  { id: 10, title: 'Platform Engineer', company: 'InfraCo', salary: '$128k-168k', match: 82, location: 'Portland, OR' }
];

export function DemoOrchestrator() {
  const [step, setStep] = useState(0);
  const [currentJob, setCurrentJob] = useState(0);
  const [progress, setProgress] = useState(0);
  const [completedJobs, setCompletedJobs] = useState<number[]>([]);
  const [isProcessing, setIsProcessing] = useState(false);

  useEffect(() => {
    if (!isProcessing) return;
    
    const timer = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          if (currentJob < 9) {
            setCompletedJobs(prev => [...prev, currentJob]);
            setCurrentJob(c => c + 1);
            return 0;
          } else {
            setIsProcessing(false);
            setStep(5);
            return 100;
          }
        }
        return p + 3;
      });
    }, 40);

    return () => clearInterval(timer);
  }, [isProcessing, currentJob]);

  const startDemo = () => {
    setStep(1);
    setIsProcessing(true);
  };

  if (step === 0) {
    return (
      <Card className="p-12 text-center max-w-3xl mx-auto bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
        <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center mx-auto mb-6">
          <Sparkles className="w-10 h-10 text-white" />
        </div>
        <h2 className="text-4xl font-bold mb-4 bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
          AI Daily Job Workflow
        </h2>
        <p className="text-gray-600 mb-8 text-lg leading-relaxed">
          Watch as our AI finds 10 perfect jobs, customizes your resume for each one, 
          writes personalized cover letters, and prepares interview materials — all in seconds.
        </p>
        <Button size="lg" onClick={startDemo} className="px-10 py-6 text-lg bg-gradient-to-r from-blue-600 to-purple-600 hover:scale-105 transition-transform">
          <Zap className="mr-2 w-5 h-5" />
          Start Demo
        </Button>
      </Card>
    );
  }

  if (step === 5) {
    return (
      <div className="space-y-6 animate-in fade-in duration-500">
        <Card className="p-8 bg-gradient-to-r from-green-50 to-blue-50 border-2 border-green-300 shadow-xl">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-16 h-16 bg-green-600 rounded-full flex items-center justify-center">
              <CheckCircle className="w-10 h-10 text-white" />
            </div>
            <div>
              <h2 className="text-3xl font-bold text-gray-900">Workflow Complete!</h2>
              <p className="text-gray-600 text-lg">10 jobs ready to apply with optimized materials</p>
            </div>
          </div>
          <div className="grid grid-cols-3 gap-4 mb-6">
            <div className="bg-white p-5 rounded-xl text-center shadow-md">
              <Target className="w-7 h-7 text-blue-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-blue-600">10</div>
              <div className="text-sm text-gray-600 font-medium">Jobs Matched</div>
            </div>
            <div className="bg-white p-5 rounded-xl text-center shadow-md">
              <TrendingUp className="w-7 h-7 text-green-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-green-600">94%</div>
              <div className="text-sm text-gray-600 font-medium">Avg ATS Score</div>
            </div>
            <div className="bg-white p-5 rounded-xl text-center shadow-md">
              <Award className="w-7 h-7 text-purple-600 mx-auto mb-2" />
              <div className="text-3xl font-bold text-purple-600">87%</div>
              <div className="text-sm text-gray-600 font-medium">Avg Match</div>
            </div>
          </div>
        </Card>

        <div className="grid gap-3">
          {MOCK_JOBS.map(job => (
            <Card key={job.id} className="p-4 hover:shadow-lg transition-all hover:border-blue-300 border-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-4 flex-1">
                  <div className="w-14 h-14 bg-gradient-to-br from-blue-100 to-purple-100 rounded-xl flex items-center justify-center">
                    <Briefcase className="w-7 h-7 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-lg">{job.title}</h3>
                    <p className="text-sm text-gray-600">{job.company} • {job.location}</p>
                    <p className="text-sm text-gray-500">{job.salary}</p>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <Badge variant="outline" className="bg-green-50 text-green-700 border-green-300 px-3 py-1">
                    {job.match}% Match
                  </Badge>
                  <div className="flex gap-2">
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center" title="Resume Ready">
                      <FileText className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center" title="Cover Letter Ready">
                      <Mail className="w-4 h-4 text-green-600" />
                    </div>
                    <div className="w-8 h-8 bg-green-100 rounded-full flex items-center justify-center" title="Interview Prep Ready">
                      <Brain className="w-4 h-4 text-green-600" />
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  const job = MOCK_JOBS[currentJob];
  const currentStepName = progress < 33 ? 'Resume' : progress < 66 ? 'Cover Letter' : 'Interview Prep';

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-2xl font-bold">Processing Job {currentJob + 1} of 10</h2>
          <Badge className="text-lg px-4 py-1">{currentJob + 1}/10</Badge>
        </div>
        <Progress value={(currentJob * 10) + (progress / 10)} className="h-3" />
      </Card>

      <Card className="p-6 border-2 border-blue-300 bg-gradient-to-br from-blue-50 to-white shadow-lg">
        <div className="flex items-start gap-4 mb-6">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-purple-600 rounded-xl flex items-center justify-center flex-shrink-0">
            <Briefcase className="w-10 h-10 text-white" />
          </div>
          <div className="flex-1">
            <h3 className="text-2xl font-bold mb-1">{job.title}</h3>
            <p className="text-gray-600 mb-1">{job.company} • {job.location}</p>
            <p className="text-gray-500 mb-3">{job.salary}</p>
            <Badge className="bg-green-600 text-white px-3 py-1">{job.match}% Match</Badge>
          </div>
        </div>
        
        <div className="space-y-4">
          <div className={`flex items-center gap-3 p-3 rounded-lg ${progress > 0 ? 'bg-green-50' : 'bg-gray-50'}`}>
            {progress > 33 ? <CheckCircle className="w-6 h-6 text-green-600" /> : <Loader2 className="w-6 h-6 animate-spin text-blue-600" />}
            <div className="flex-1">
              <span className="font-semibold">Optimizing Resume for ATS</span>
              <p className="text-sm text-gray-600">Analyzing job requirements & matching keywords</p>
            </div>
          </div>
          <div className={`flex items-center gap-3 p-3 rounded-lg ${progress > 33 ? 'bg-green-50' : 'bg-gray-50'}`}>
            {progress > 66 ? <CheckCircle className="w-6 h-6 text-green-600" /> : progress > 33 ? <Loader2 className="w-6 h-6 animate-spin text-blue-600" /> : <div className="w-6 h-6 border-2 border-gray-300 rounded-full" />}
            <div className="flex-1">
              <span className="font-semibold">Writing Tailored Cover Letter</span>
              <p className="text-sm text-gray-600">Creating personalized content for this role</p>
            </div>
          </div>
          <div className={`flex items-center gap-3 p-3 rounded-lg ${progress > 66 ? 'bg-blue-50' : 'bg-gray-50'}`}>
            {progress > 66 ? <Loader2 className="w-6 h-6 animate-spin text-blue-600" /> : <div className="w-6 h-6 border-2 border-gray-300 rounded-full" />}
            <div className="flex-1">
              <span className="font-semibold">Preparing Interview Questions</span>
              <p className="text-sm text-gray-600">Generating likely questions & best answers</p>
            </div>
          </div>
        </div>
        
        <Progress value={progress} className="mt-4 h-2" />
      </Card>

      {completedJobs.length > 0 && (
        <Card className="p-5 bg-green-50 border-2 border-green-200">
          <h3 className="font-semibold mb-3 text-green-700 flex items-center gap-2">
            <CheckCircle className="w-5 h-5" />
            Completed ({completedJobs.length})
          </h3>
          <div className="space-y-2">
            {completedJobs.map(idx => (
              <div key={idx} className="flex items-center justify-between text-sm bg-white p-2 rounded">
                <span className="font-medium">{MOCK_JOBS[idx].title}</span>
                <CheckCircle className="w-4 h-4 text-green-600" />
              </div>
            ))}
          </div>
        </Card>
      )}
    </div>
  );
}
