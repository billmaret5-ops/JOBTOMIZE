import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { User, Settings, Bell, Activity, Shield } from 'lucide-react';
import { ProfileCompletionTracker } from './ProfileCompletionTracker';
import { AvatarUpload } from './AvatarUpload';
import { NotificationPreferencesManager } from './NotificationPreferencesManager';
import { ActivityHistory } from './ActivityHistory';
import { supabase } from '@/lib/supabase';

export const ComprehensiveUserProfile: React.FC = () => {
  const [user, setUser] = useState<any>(null);
  const [profile, setProfile] = useState<any>({});
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadUserProfile();
  }, []);

  const loadUserProfile = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        setUser(user);
        const { data } = await supabase
          .from('profiles')
          .select('*')
          .eq('id', user.id)
          .single();
        setProfile(data || {});
      }
    } catch (error) {
      console.error('Error loading profile:', error);
    }
  };

  const updateProfile = async (updates: any) => {
    if (!user) return;
    setLoading(true);
    try {
      const { error } = await supabase
        .from('profiles')
        .upsert({ id: user.id, ...updates });
      if (error) throw error;
      setProfile(prev => ({ ...prev, ...updates }));
    } catch (error) {
      console.error('Error updating profile:', error);
    } finally {
      setLoading(false);
    }
  };

  const profileSections = [
    { id: 'basic', name: 'Basic Info', completed: !!profile.full_name, required: true, description: 'Name and contact information' },
    { id: 'avatar', name: 'Profile Picture', completed: !!profile.avatar_url, required: false, description: 'Upload your photo' },
    { id: 'professional', name: 'Professional Info', completed: !!profile.job_title, required: false, description: 'Job title and company' },
    { id: 'preferences', name: 'Preferences', completed: true, required: true, description: 'Account and notification settings' }
  ];

  const completionPercentage = Math.round((profileSections.filter(s => s.completed).length / profileSections.length) * 100);

  if (!user) return <div>Loading...</div>;

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <ProfileCompletionTracker 
            sections={profileSections}
            completionPercentage={completionPercentage}
          />
        </div>
        
        <div className="lg:col-span-3">
          <Tabs defaultValue="profile" className="space-y-6">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="profile" className="flex items-center gap-2">
                <User className="h-4 w-4" />
                Profile
              </TabsTrigger>
              <TabsTrigger value="settings" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Settings
              </TabsTrigger>
              <TabsTrigger value="notifications" className="flex items-center gap-2">
                <Bell className="h-4 w-4" />
                Notifications
              </TabsTrigger>
              <TabsTrigger value="activity" className="flex items-center gap-2">
                <Activity className="h-4 w-4" />
                Activity
              </TabsTrigger>
              <TabsTrigger value="privacy" className="flex items-center gap-2">
                <Shield className="h-4 w-4" />
                Privacy
              </TabsTrigger>
            </TabsList>

            <TabsContent value="profile" className="space-y-6">
              <AvatarUpload
                currentAvatar={profile.avatar_url}
                userId={user.id}
                onAvatarUpdate={(url) => updateProfile({ avatar_url: url })}
              />
              
              <Card>
                <CardHeader>
                  <CardTitle>Personal Information</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div>
                      <Label>Full Name</Label>
                      <Input
                        value={profile.full_name || ''}
                        onChange={(e) => setProfile(prev => ({ ...prev, full_name: e.target.value }))}
                        onBlur={() => updateProfile({ full_name: profile.full_name })}
                      />
                    </div>
                    <div>
                      <Label>Email</Label>
                      <Input value={user.email} disabled />
                    </div>
                    <div>
                      <Label>Phone</Label>
                      <Input
                        value={profile.phone || ''}
                        onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                        onBlur={() => updateProfile({ phone: profile.phone })}
                      />
                    </div>
                    <div>
                      <Label>Location</Label>
                      <Input
                        value={profile.location || ''}
                        onChange={(e) => setProfile(prev => ({ ...prev, location: e.target.value }))}
                        onBlur={() => updateProfile({ location: profile.location })}
                      />
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="settings">
              <Card>
                <CardHeader>
                  <CardTitle>Account Settings</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Profile Visibility</Label>
                    <Select
                      value={profile.profile_visibility || 'private'}
                      onValueChange={(value) => updateProfile({ profile_visibility: value })}
                    >
                      <SelectTrigger className="w-40">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="public">Public</SelectItem>
                        <SelectItem value="private">Private</SelectItem>
                        <SelectItem value="contacts_only">Contacts Only</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notifications">
              <NotificationPreferencesManager userId={user.id} />
            </TabsContent>

            <TabsContent value="activity">
              <ActivityHistory userId={user.id} />
            </TabsContent>

            <TabsContent value="privacy">
              <Card>
                <CardHeader>
                  <CardTitle>Privacy Controls</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="flex items-center justify-between">
                    <Label>Show email publicly</Label>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Allow contact from other users</Label>
                    <Switch />
                  </div>
                  <div className="flex items-center justify-between">
                    <Label>Data processing consent</Label>
                    <Switch defaultChecked />
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};