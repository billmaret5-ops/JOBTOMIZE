import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { calendarSyncService, CalendarProvider } from '@/services/calendarSyncService';
import { supabase } from '@/lib/supabase';
import { Calendar, CheckCircle2, XCircle, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function CalendarSyncManager() {
  const [providers, setProviders] = useState<CalendarProvider[]>([]);
  const [autoSync, setAutoSync] = useState(true);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadProviders();
  }, []);

  const loadProviders = async () => {
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return;

    const connectedProviders = await calendarSyncService.getConnectedProviders(user.id);
    setProviders(connectedProviders);
  };

  const connectGoogle = async () => {
    setLoading(true);
    try {
      // In production, this would open OAuth flow
      const authUrl = `https://accounts.google.com/o/oauth2/v2/auth?client_id=YOUR_CLIENT_ID&redirect_uri=${window.location.origin}/oauth/callback&response_type=code&scope=https://www.googleapis.com/auth/calendar`;
      window.location.href = authUrl;
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect to Google Calendar.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const connectOutlook = async () => {
    setLoading(true);
    try {
      const authUrl = `https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=YOUR_CLIENT_ID&response_type=code&redirect_uri=${window.location.origin}/oauth/callback&scope=Calendars.ReadWrite`;
      window.location.href = authUrl;
    } catch (error) {
      toast({
        title: 'Connection Failed',
        description: 'Failed to connect to Outlook.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const disconnect = async (providerId: string) => {
    try {
      await calendarSyncService.disconnectProvider(providerId);
      setProviders(providers.filter(p => p.id !== providerId));
      toast({
        title: 'Disconnected',
        description: 'Calendar has been disconnected.'
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to disconnect calendar.',
        variant: 'destructive'
      });
    }
  };

  const availableProviders = [
    { type: 'google', name: 'Google Calendar', color: 'bg-blue-500' },
    { type: 'outlook', name: 'Outlook Calendar', color: 'bg-blue-600' },
    { type: 'apple', name: 'Apple Calendar', color: 'bg-gray-700' }
  ];

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="w-5 h-5" />
          Calendar Integrations
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="flex items-center justify-between">
          <Label htmlFor="auto-sync">Auto-sync interviews</Label>
          <Switch
            id="auto-sync"
            checked={autoSync}
            onCheckedChange={setAutoSync}
          />
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Connected Calendars</h4>
          {providers.length === 0 ? (
            <p className="text-sm text-muted-foreground">No calendars connected</p>
          ) : (
            providers.map(provider => (
              <div key={provider.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <div className={`w-3 h-3 rounded-full ${
                    provider.type === 'google' ? 'bg-blue-500' :
                    provider.type === 'outlook' ? 'bg-blue-600' : 'bg-gray-700'
                  }`} />
                  <div>
                    <p className="font-medium">{provider.name}</p>
                    <p className="text-xs text-muted-foreground capitalize">{provider.type}</p>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant="outline" className="flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" />
                    Connected
                  </Badge>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => disconnect(provider.id)}
                  >
                    <XCircle className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))
          )}
        </div>

        <div className="space-y-3">
          <h4 className="text-sm font-semibold">Available Calendars</h4>
          <div className="grid gap-2">
            {availableProviders
              .filter(ap => !providers.some(p => p.type === ap.type))
              .map(provider => (
                <Button
                  key={provider.type}
                  variant="outline"
                  onClick={() => {
                    if (provider.type === 'google') connectGoogle();
                    else if (provider.type === 'outlook') connectOutlook();
                  }}
                  disabled={loading}
                  className="justify-start"
                >
                  {loading ? (
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  ) : (
                    <div className={`w-3 h-3 rounded-full mr-2 ${provider.color}`} />
                  )}
                  Connect {provider.name}
                </Button>
              ))}
          </div>
        </div>

        <div className="p-3 bg-muted rounded-lg text-sm">
          <p className="font-semibold mb-1">Sync Features</p>
          <ul className="space-y-1 text-muted-foreground">
            <li>• Automatic interview event creation</li>
            <li>• Two-way sync for updates</li>
            <li>• Meeting link integration</li>
            <li>• Reminder synchronization</li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
