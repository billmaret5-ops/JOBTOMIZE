import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { TrendingUp, TrendingDown, Minus } from 'lucide-react';

interface ABTestResult {
  id: string;
  recommendation_type: string;
  recommendation_data: any;
  confidence_score: number;
  impact_score: number;
  status: string;
  votes_approve: number;
  votes_reject: number;
  created_at: string;
}

interface ABTestResultsProps {
  results: ABTestResult[];
}

export const ABTestResultsVisualization: React.FC<ABTestResultsProps> = ({ results }) => {
  const [selectedTest, setSelectedTest] = useState<ABTestResult | null>(null);

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'approved': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getImpactIcon = (score: number) => {
    if (score > 0.7) return <TrendingUp className="h-4 w-4 text-green-600" />;
    if (score < 0.3) return <TrendingDown className="h-4 w-4 text-red-600" />;
    return <Minus className="h-4 w-4 text-gray-600" />;
  };

  return (
    <>
      <Card>
        <CardHeader>
          <CardTitle>A/B Test Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {results.map((test) => (
              <div
                key={test.id}
                className="p-4 border rounded-lg hover:bg-gray-50 cursor-pointer transition"
                onClick={() => setSelectedTest(test)}
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getImpactIcon(test.impact_score)}
                    <div>
                      <p className="font-medium">{test.recommendation_data?.title || 'A/B Test'}</p>
                      <p className="text-sm text-gray-600">
                        Confidence: {(test.confidence_score * 100).toFixed(0)}%
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                    <span className="text-sm text-gray-600">
                      {test.votes_approve}👍 {test.votes_reject}👎
                    </span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Dialog open={!!selectedTest} onOpenChange={() => setSelectedTest(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>A/B Test Details</DialogTitle>
          </DialogHeader>
          {selectedTest && (
            <div className="space-y-4">
              <div>
                <h4 className="font-semibold mb-2">Recommendation</h4>
                <p>{JSON.stringify(selectedTest.recommendation_data, null, 2)}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </>
  );
};
