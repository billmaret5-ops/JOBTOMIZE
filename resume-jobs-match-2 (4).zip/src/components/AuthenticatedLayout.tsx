import React, { useState } from 'react';
import { useAuth } from '@/contexts/ProductionAuthContext';

import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { User, FileText, Bell, LogOut, Menu, Home, Briefcase, Search, Calendar, MessageSquare, Video, Target, BarChart3, Mail, BellRing, BookOpen } from 'lucide-react';



import { UserDashboard } from './UserDashboard';
import { ProfileSettings } from './ProfileSettings';
import { AIResumeBuilderDashboard } from './AIResumeBuilderDashboard';
import DailyJobMatchingOrchestrator from './DailyJobMatchingOrchestrator';
import { ComprehensiveApplicationTrackingSystem } from './ComprehensiveApplicationTrackingSystem';
import EnhancedJobSearchPlatform from './EnhancedJobSearchPlatform';

import { AIInterviewCoach } from './AIInterviewCoach';
import AICoverLetterGenerator from './AICoverLetterGenerator';

import { JobApplicationEmailManager } from './JobApplicationEmailManager';
import JobAlertsManager from './JobAlertsManager';
import InterviewPreparationPlatform from './InterviewPreparationPlatform';





export function AuthenticatedLayout() {
  const { user, profile, signOut } = useAuth();
  const [activeTab, setActiveTab] = useState('dashboard');

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6">
          <div className="flex items-center justify-between h-16">
            <div className="text-xl sm:text-2xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              AI Job Match Pro
            </div>
            
            <div className="hidden lg:flex items-center space-x-2">
              <Button variant={activeTab === 'dashboard' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('dashboard')}>
                <Home className="w-4 h-4 mr-2" />Dashboard
              </Button>
              <Button variant={activeTab === 'jobs' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('jobs')}>
                <Briefcase className="w-4 h-4 mr-2" />AI Jobs
              </Button>
              <Button variant={activeTab === 'search' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('search')}>
                <Search className="w-4 h-4 mr-2" />Search
              </Button>
              <Button variant={activeTab === 'tracker' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('tracker')}>
                <Target className="w-4 h-4 mr-2" />Tracker
              </Button>
              <Button variant={activeTab === 'resume' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('resume')}>
                <FileText className="w-4 h-4 mr-2" />Resume
              </Button>
              <Button variant={activeTab === 'cover' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('cover')}>
                <MessageSquare className="w-4 h-4 mr-2" />Cover
              </Button>
              <Button variant={activeTab === 'interview' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('interview')}>
                <Video className="w-4 h-4 mr-2" />Interview
              </Button>
              <Button variant={activeTab === 'email' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('email')}>
                <Mail className="w-4 h-4 mr-2" />Email
              </Button>
              <Button variant={activeTab === 'alerts' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('alerts')}>
                <BellRing className="w-4 h-4 mr-2" />Alerts
              </Button>
              <Button variant={activeTab === 'prep' ? 'default' : 'ghost'} size="sm" onClick={() => setActiveTab('prep')}>
                <BookOpen className="w-4 h-4 mr-2" />Prep
              </Button>



            </div>

            
            <div className="flex items-center space-x-2 sm:space-x-4">
              <Button variant="ghost" size="sm" className="hidden sm:flex"><Bell className="w-4 h-4" /></Button>
              <Button variant="ghost" size="sm" onClick={signOut}><LogOut className="w-4 h-4 sm:mr-2" /><span className="hidden sm:inline">Sign Out</span></Button>
              <div className="hidden sm:flex items-center space-x-2 px-3 py-1 bg-blue-50 rounded-lg">
                <User className="w-4 h-4 text-blue-600" />
                <span className="text-sm font-medium text-blue-700">{profile?.full_name || user?.email?.split('@')[0]}</span>
              </div>
            </div>
          </div>
        </div>
      </nav>

      <main className="py-4 sm:py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <div className="lg:hidden px-4 mb-6">
            <TabsList className="grid w-full grid-cols-4 mb-2">
              <TabsTrigger value="dashboard">Home</TabsTrigger>
              <TabsTrigger value="jobs">AI Jobs</TabsTrigger>
              <TabsTrigger value="search">Search</TabsTrigger>
              <TabsTrigger value="tracker">Track</TabsTrigger>
            </TabsList>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="resume">Resume</TabsTrigger>
              <TabsTrigger value="cover">Cover</TabsTrigger>
              <TabsTrigger value="interview">Interview</TabsTrigger>
              <TabsTrigger value="email">Email</TabsTrigger>
              <TabsTrigger value="alerts">Alerts</TabsTrigger>
              <TabsTrigger value="prep">Prep</TabsTrigger>
            </TabsList>


          </div>

          <TabsContent value="dashboard"><UserDashboard /></TabsContent>
          <TabsContent value="jobs"><div className="max-w-7xl mx-auto px-4 sm:px-6"><DailyJobMatchingOrchestrator /></div></TabsContent>
          <TabsContent value="search"><div className="max-w-7xl mx-auto px-4 sm:px-6"><EnhancedJobSearchPlatform /></div></TabsContent>

          <TabsContent value="tracker"><div className="max-w-7xl mx-auto px-4 sm:px-6"><ComprehensiveApplicationTrackingSystem /></div></TabsContent>
          <TabsContent value="resume"><div className="max-w-7xl mx-auto px-4 sm:px-6"><AIResumeBuilderDashboard /></div></TabsContent>
          <TabsContent value="cover"><div className="max-w-7xl mx-auto px-4 sm:px-6"><AICoverLetterGenerator /></div></TabsContent>
          <TabsContent value="interview"><div className="max-w-7xl mx-auto px-4 sm:px-6"><AIInterviewCoach /></div></TabsContent>
          <TabsContent value="email"><div className="max-w-7xl mx-auto px-4 sm:px-6"><JobApplicationEmailManager /></div></TabsContent>
          <TabsContent value="alerts"><div className="max-w-7xl mx-auto px-4 sm:px-6"><JobAlertsManager /></div></TabsContent>
          <TabsContent value="prep"><InterviewPreparationPlatform /></TabsContent>



        </Tabs>

      </main>
    </div>
  );
}

export default AuthenticatedLayout;
