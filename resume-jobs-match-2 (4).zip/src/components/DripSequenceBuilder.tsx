import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Mail, Clock, ArrowDown } from 'lucide-react';

interface DripEmail {
  id: string;
  subject: string;
  content: string;
  delay: number;
  delayUnit: 'hours' | 'days' | 'weeks';
  conditions?: string[];
}

interface DripSequence {
  id: string;
  name: string;
  trigger: string;
  emails: DripEmail[];
  status: 'active' | 'draft';
}

export const DripSequenceBuilder: React.FC = () => {
  const [sequences, setSequences] = useState<DripSequence[]>([
    {
      id: '1',
      name: 'Post-Application Follow-up',
      trigger: 'job_application_submitted',
      status: 'active',
      emails: [
        {
          id: 'e1',
          subject: 'Thank you for your application',
          content: 'Hi {{name}}, thank you for applying to {{job_title}} at {{company}}...',
          delay: 1,
          delayUnit: 'hours'
        },
        {
          id: 'e2',
          subject: 'Following up on my application',
          content: 'Hi {{hiring_manager}}, I wanted to follow up on my application...',
          delay: 3,
          delayUnit: 'days'
        }
      ]
    }
  ]);

  const [editingSequence, setEditingSequence] = useState<string | null>(null);
  const [newEmail, setNewEmail] = useState<Partial<DripEmail>>({
    subject: '',
    content: '',
    delay: 1,
    delayUnit: 'days'
  });

  const addEmailToSequence = (sequenceId: string) => {
    if (!newEmail.subject || !newEmail.content) return;
    
    const email: DripEmail = {
      id: Date.now().toString(),
      subject: newEmail.subject,
      content: newEmail.content,
      delay: newEmail.delay || 1,
      delayUnit: newEmail.delayUnit || 'days'
    };

    setSequences(prev => prev.map(seq => 
      seq.id === sequenceId 
        ? { ...seq, emails: [...seq.emails, email] }
        : seq
    ));

    setNewEmail({ subject: '', content: '', delay: 1, delayUnit: 'days' });
  };

  const removeEmail = (sequenceId: string, emailId: string) => {
    setSequences(prev => prev.map(seq => 
      seq.id === sequenceId 
        ? { ...seq, emails: seq.emails.filter(e => e.id !== emailId) }
        : seq
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Drip Sequence Builder</h2>
        <Button className="flex items-center gap-2">
          <Plus className="h-4 w-4" />
          New Sequence
        </Button>
      </div>

      {sequences.map((sequence) => (
        <Card key={sequence.id}>
          <CardHeader>
            <div className="flex justify-between items-center">
              <div>
                <CardTitle className="flex items-center gap-2">
                  {sequence.name}
                  <Badge variant={sequence.status === 'active' ? 'default' : 'secondary'}>
                    {sequence.status}
                  </Badge>
                </CardTitle>
                <p className="text-sm text-muted-foreground">
                  Trigger: {sequence.trigger.replace(/_/g, ' ')}
                </p>
              </div>
              <Button 
                variant="outline" 
                onClick={() => setEditingSequence(editingSequence === sequence.id ? null : sequence.id)}
              >
                {editingSequence === sequence.id ? 'Close' : 'Edit'}
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sequence.emails.map((email, index) => (
                <div key={email.id} className="border rounded-lg p-4 space-y-3">
                  <div className="flex justify-between items-start">
                    <div className="flex items-center gap-2">
                      <Mail className="h-4 w-4 text-blue-500" />
                      <span className="font-medium">Email {index + 1}</span>
                      <div className="flex items-center gap-1 text-sm text-muted-foreground">
                        <Clock className="h-3 w-3" />
                        {email.delay} {email.delayUnit} delay
                      </div>
                    </div>
                    {editingSequence === sequence.id && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => removeEmail(sequence.id, email.id)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <div>
                    <div className="font-medium text-sm mb-1">Subject:</div>
                    <div className="text-sm bg-gray-50 p-2 rounded">{email.subject}</div>
                  </div>
                  
                  <div>
                    <div className="font-medium text-sm mb-1">Content Preview:</div>
                    <div className="text-sm bg-gray-50 p-2 rounded line-clamp-2">
                      {email.content.substring(0, 100)}...
                    </div>
                  </div>
                  
                  {index < sequence.emails.length - 1 && (
                    <div className="flex justify-center">
                      <ArrowDown className="h-4 w-4 text-muted-foreground" />
                    </div>
                  )}
                </div>
              ))}

              {editingSequence === sequence.id && (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 space-y-4">
                  <h4 className="font-medium">Add New Email</h4>
                  
                  <div className="grid grid-cols-2 gap-4">
                    <Input
                      placeholder="Email subject"
                      value={newEmail.subject}
                      onChange={(e) => setNewEmail(prev => ({ ...prev, subject: e.target.value }))}
                    />
                    <div className="flex gap-2">
                      <Input
                        type="number"
                        placeholder="Delay"
                        value={newEmail.delay}
                        onChange={(e) => setNewEmail(prev => ({ ...prev, delay: parseInt(e.target.value) }))}
                        className="w-20"
                      />
                      <Select
                        value={newEmail.delayUnit}
                        onValueChange={(value: 'hours' | 'days' | 'weeks') => 
                          setNewEmail(prev => ({ ...prev, delayUnit: value }))
                        }
                      >
                        <SelectTrigger className="w-24">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="hours">Hours</SelectItem>
                          <SelectItem value="days">Days</SelectItem>
                          <SelectItem value="weeks">Weeks</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                  
                  <Textarea
                    placeholder="Email content (use {{variable}} for personalization)"
                    value={newEmail.content}
                    onChange={(e) => setNewEmail(prev => ({ ...prev, content: e.target.value }))}
                    rows={4}
                  />
                  
                  <Button onClick={() => addEmailToSequence(sequence.id)}>
                    Add Email
                  </Button>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      ))}
    </div>
  );
};