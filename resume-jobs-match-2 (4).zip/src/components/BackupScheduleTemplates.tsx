import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Clock, Calendar, Zap } from 'lucide-react';

interface ScheduleTemplate {
  name: string;
  description: string;
  cronExpression: string;
  icon: any;
  color: string;
}

const templates: ScheduleTemplate[] = [
  {
    name: 'Daily at 2 AM',
    description: 'Run backup every day at 2:00 AM',
    cronExpression: '0 2 * * *',
    icon: Calendar,
    color: 'bg-blue-500'
  },
  {
    name: 'Weekly Sunday',
    description: 'Run backup every Sunday at 3:00 AM',
    cronExpression: '0 3 * * 0',
    icon: Clock,
    color: 'bg-purple-500'
  },
  {
    name: 'Monthly 1st',
    description: 'Run backup on 1st of each month at 1:00 AM',
    cronExpression: '0 1 1 * *',
    icon: Calendar,
    color: 'bg-green-500'
  },
  {
    name: 'Every 6 Hours',
    description: 'Run backup every 6 hours',
    cronExpression: '0 */6 * * *',
    icon: Zap,
    color: 'bg-orange-500'
  },
  {
    name: 'Weekday Nights',
    description: 'Run backup Mon-Fri at 11:00 PM',
    cronExpression: '0 23 * * 1-5',
    icon: Clock,
    color: 'bg-indigo-500'
  },
  {
    name: 'Hourly',
    description: 'Run backup every hour',
    cronExpression: '0 * * * *',
    icon: Zap,
    color: 'bg-red-500'
  }
];

export default function BackupScheduleTemplates({ onSelect }: { onSelect: (template: ScheduleTemplate) => void }) {
  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
      {templates.map((template) => (
        <Card key={template.name} className="p-6 hover:shadow-lg transition-shadow">
          <div className="flex items-start gap-4">
            <div className={`${template.color} p-3 rounded-lg`}>
              <template.icon className="h-6 w-6 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="font-semibold text-lg mb-1">{template.name}</h3>
              <p className="text-sm text-muted-foreground mb-3">{template.description}</p>
              <code className="text-xs bg-muted px-2 py-1 rounded">{template.cronExpression}</code>
              <Button 
                onClick={() => onSelect(template)} 
                className="w-full mt-4"
                variant="outline"
              >
                Use Template
              </Button>
            </div>
          </div>
        </Card>
      ))}
    </div>
  );
}
