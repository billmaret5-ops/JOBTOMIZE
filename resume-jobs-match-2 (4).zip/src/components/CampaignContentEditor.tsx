import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { 
  Type, Image, Link, Mail, Palette, Eye, Code, 
  Bold, Italic, Underline, AlignLeft, AlignCenter, AlignRight 
} from 'lucide-react';

interface ContentComponent {
  id: string;
  type: 'text' | 'image' | 'button' | 'divider' | 'social';
  content: any;
  styles: any;
}

interface CampaignContentEditorProps {
  content: { components: ContentComponent[] };
  onContentChange: (content: { components: ContentComponent[] }) => void;
}

export const CampaignContentEditor: React.FC<CampaignContentEditorProps> = ({
  content,
  onContentChange
}) => {
  const [selectedComponent, setSelectedComponent] = useState<ContentComponent | null>(null);
  const [previewMode, setPreviewMode] = useState(false);

  const addComponent = (type: ContentComponent['type']) => {
    const newComponent: ContentComponent = {
      id: `comp-${Date.now()}`,
      type,
      content: getDefaultContent(type),
      styles: getDefaultStyles(type)
    };

    onContentChange({
      components: [...content.components, newComponent]
    });
  };

  const getDefaultContent = (type: string) => {
    switch (type) {
      case 'text':
        return { text: 'Enter your text here...', tag: 'p' };
      case 'image':
        return { src: '', alt: 'Image', url: '' };
      case 'button':
        return { text: 'Click Here', url: '#' };
      case 'divider':
        return { style: 'solid' };
      case 'social':
        return { platforms: ['facebook', 'twitter', 'linkedin'] };
      default:
        return {};
    }
  };

  const getDefaultStyles = (type: string) => {
    return {
      fontSize: '16px',
      color: '#333333',
      textAlign: 'left',
      padding: '10px',
      margin: '10px 0'
    };
  };

  const updateComponent = (id: string, updates: Partial<ContentComponent>) => {
    const updatedComponents = content.components.map(comp =>
      comp.id === id ? { ...comp, ...updates } : comp
    );
    onContentChange({ components: updatedComponents });
  };

  const deleteComponent = (id: string) => {
    const updatedComponents = content.components.filter(comp => comp.id !== id);
    onContentChange({ components: updatedComponents });
    setSelectedComponent(null);
  };

  const moveComponent = (id: string, direction: 'up' | 'down') => {
    const components = [...content.components];
    const index = components.findIndex(comp => comp.id === id);
    
    if (direction === 'up' && index > 0) {
      [components[index], components[index - 1]] = [components[index - 1], components[index]];
    } else if (direction === 'down' && index < components.length - 1) {
      [components[index], components[index + 1]] = [components[index + 1], components[index]];
    }
    
    onContentChange({ components });
  };

  const componentLibrary = [
    { type: 'text', icon: Type, label: 'Text Block' },
    { type: 'image', icon: Image, label: 'Image' },
    { type: 'button', icon: Link, label: 'Button' },
    { type: 'divider', icon: Mail, label: 'Divider' },
    { type: 'social', icon: Mail, label: 'Social Links' }
  ];

  return (
    <div className="grid grid-cols-12 gap-6 h-[600px]">
      {/* Component Library */}
      <div className="col-span-3">
        <Card className="h-full">
          <CardHeader>
            <CardTitle className="text-lg">Components</CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {componentLibrary.map(({ type, icon: Icon, label }) => (
              <Button
                key={type}
                variant="outline"
                className="w-full justify-start"
                onClick={() => addComponent(type as ContentComponent['type'])}
              >
                <Icon className="w-4 h-4 mr-2" />
                {label}
              </Button>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Main Editor */}
      <div className="col-span-6">
        <Card className="h-full">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Email Content</CardTitle>
            <div className="flex gap-2">
              <Button
                size="sm"
                variant={previewMode ? "default" : "outline"}
                onClick={() => setPreviewMode(!previewMode)}
              >
                <Eye className="w-4 h-4 mr-2" />
                {previewMode ? 'Edit' : 'Preview'}
              </Button>
            </div>
          </CardHeader>
          <CardContent className="h-[500px] overflow-y-auto">
            {previewMode ? (
              <div className="bg-white p-6 rounded border">
                {content.components.map(component => (
                  <div key={component.id} style={component.styles}>
                    {renderComponent(component)}
                  </div>
                ))}
              </div>
            ) : (
              <div className="space-y-2">
                {content.components.map((component, index) => (
                  <div
                    key={component.id}
                    className={`p-3 border rounded cursor-pointer hover:bg-gray-50 ${
                      selectedComponent?.id === component.id ? 'border-blue-500 bg-blue-50' : ''
                    }`}
                    onClick={() => setSelectedComponent(component)}
                  >
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Badge variant="outline">{component.type}</Badge>
                        <span className="text-sm">
                          {getComponentPreview(component)}
                        </span>
                      </div>
                      <div className="flex gap-1">
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            moveComponent(component.id, 'up');
                          }}
                          disabled={index === 0}
                        >
                          ↑
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            moveComponent(component.id, 'down');
                          }}
                          disabled={index === content.components.length - 1}
                        >
                          ↓
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          onClick={(e) => {
                            e.stopPropagation();
                            deleteComponent(component.id);
                          }}
                        >
                          ×
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
                {content.components.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <Mail className="w-12 h-12 mx-auto mb-4 opacity-50" />
                    <p>Start building your email by adding components</p>
                  </div>
                )}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Properties Panel */}
      <div className="col-span-3">
        <Card className="h-full">
          <CardHeader>
            <CardTitle className="text-lg">Properties</CardTitle>
          </CardHeader>
          <CardContent>
            {selectedComponent ? (
              <div className="space-y-4">
                <div>
                  <Label>Component Type</Label>
                  <Badge>{selectedComponent.type}</Badge>
                </div>
                
                {selectedComponent.type === 'text' && (
                  <>
                    <div>
                      <Label>Text Content</Label>
                      <Textarea
                        value={selectedComponent.content.text}
                        onChange={(e) => updateComponent(selectedComponent.id, {
                          content: { ...selectedComponent.content, text: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Text Size</Label>
                      <Input
                        value={selectedComponent.styles.fontSize}
                        onChange={(e) => updateComponent(selectedComponent.id, {
                          styles: { ...selectedComponent.styles, fontSize: e.target.value }
                        })}
                      />
                    </div>
                  </>
                )}

                {selectedComponent.type === 'button' && (
                  <>
                    <div>
                      <Label>Button Text</Label>
                      <Input
                        value={selectedComponent.content.text}
                        onChange={(e) => updateComponent(selectedComponent.id, {
                          content: { ...selectedComponent.content, text: e.target.value }
                        })}
                      />
                    </div>
                    <div>
                      <Label>Link URL</Label>
                      <Input
                        value={selectedComponent.content.url}
                        onChange={(e) => updateComponent(selectedComponent.id, {
                          content: { ...selectedComponent.content, url: e.target.value }
                        })}
                      />
                    </div>
                  </>
                )}

                <div>
                  <Label>Text Color</Label>
                  <Input
                    type="color"
                    value={selectedComponent.styles.color}
                    onChange={(e) => updateComponent(selectedComponent.id, {
                      styles: { ...selectedComponent.styles, color: e.target.value }
                    })}
                  />
                </div>
              </div>
            ) : (
              <p className="text-gray-500 text-sm">Select a component to edit its properties</p>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );

  function renderComponent(component: ContentComponent) {
    switch (component.type) {
      case 'text':
        return <div dangerouslySetInnerHTML={{ __html: component.content.text }} />;
      case 'button':
        return (
          <a 
            href={component.content.url}
            style={{
              display: 'inline-block',
              padding: '12px 24px',
              backgroundColor: '#007bff',
              color: 'white',
              textDecoration: 'none',
              borderRadius: '4px'
            }}
          >
            {component.content.text}
          </a>
        );
      case 'divider':
        return <hr style={{ margin: '20px 0', border: '1px solid #eee' }} />;
      default:
        return <div>Component: {component.type}</div>;
    }
  }

  function getComponentPreview(component: ContentComponent) {
    switch (component.type) {
      case 'text':
        return component.content.text?.substring(0, 30) + '...';
      case 'button':
        return component.content.text;
      case 'image':
        return component.content.alt || 'Image';
      default:
        return component.type;
    }
  }
};