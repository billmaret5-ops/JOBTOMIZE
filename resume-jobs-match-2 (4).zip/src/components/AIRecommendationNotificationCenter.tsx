import React, { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Bell, X, TrendingUp, Users, CheckCircle, AlertTriangle } from 'lucide-react';
import { AIRecommendation, realtimeAIRecommendationService } from '@/services/realtimeAIRecommendationService';

interface Notification {
  id: string;
  type: 'new_recommendation' | 'vote_update' | 'applied' | 'conflict';
  title: string;
  message: string;
  timestamp: Date;
  recommendation?: AIRecommendation;
  read: boolean;
}

interface AIRecommendationNotificationCenterProps {
  onNotificationClick?: (notification: Notification) => void;
}

export const AIRecommendationNotificationCenter: React.FC<AIRecommendationNotificationCenterProps> = ({
  onNotificationClick
}) => {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const unreadCount = notifications.filter(n => !n.read).length;

  useEffect(() => {
    const handleNewRecommendation = (recommendation: AIRecommendation) => {
      const notification: Notification = {
        id: `new-${recommendation.id}-${Date.now()}`,
        type: 'new_recommendation',
        title: 'New AI Recommendation',
        message: recommendation.title,
        timestamp: new Date(),
        recommendation,
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    };

    const handleVote = (vote: any) => {
      const notification: Notification = {
        id: `vote-${vote.id}-${Date.now()}`,
        type: 'vote_update',
        title: 'New Vote Cast',
        message: `A team member voted to ${vote.vote} a recommendation`,
        timestamp: new Date(),
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    };

    const handleApplied = (payload: any) => {
      const notification: Notification = {
        id: `applied-${payload.recommendationId}-${Date.now()}`,
        type: 'applied',
        title: 'Recommendation Applied',
        message: 'An AI recommendation has been applied to the template',
        timestamp: new Date(),
        recommendation: payload.recommendation,
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    };

    const handleConflict = (payload: any) => {
      const notification: Notification = {
        id: `conflict-${payload.recommendationId}-${Date.now()}`,
        type: 'conflict',
        title: 'Conflict Detected',
        message: 'A conflict was detected while applying a recommendation',
        timestamp: new Date(),
        read: false
      };
      setNotifications(prev => [notification, ...prev]);
    };

    realtimeAIRecommendationService.on('recommendation:new', handleNewRecommendation);
    realtimeAIRecommendationService.on('vote:new', handleVote);
    realtimeAIRecommendationService.on('recommendation:applied', handleApplied);
    realtimeAIRecommendationService.on('conflict:detected', handleConflict);

    return () => {
      realtimeAIRecommendationService.off('recommendation:new', handleNewRecommendation);
      realtimeAIRecommendationService.off('vote:new', handleVote);
      realtimeAIRecommendationService.off('recommendation:applied', handleApplied);
      realtimeAIRecommendationService.off('conflict:detected', handleConflict);
    };
  }, []);

  const markAsRead = (id: string) => {
    setNotifications(prev =>
      prev.map(n => n.id === id ? { ...n, read: true } : n)
    );
  };

  const markAllAsRead = () => {
    setNotifications(prev => prev.map(n => ({ ...n, read: true })));
  };

  const removeNotification = (id: string) => {
    setNotifications(prev => prev.filter(n => n.id !== id));
  };

  const getIcon = (type: Notification['type']) => {
    switch (type) {
      case 'new_recommendation':
        return <TrendingUp className="w-4 h-4 text-blue-400" />;
      case 'vote_update':
        return <Users className="w-4 h-4 text-purple-400" />;
      case 'applied':
        return <CheckCircle className="w-4 h-4 text-green-400" />;
      case 'conflict':
        return <AlertTriangle className="w-4 h-4 text-yellow-400" />;
    }
  };

  return (
    <div className="relative">
      <Button
        variant="ghost"
        size="sm"
        onClick={() => setIsOpen(!isOpen)}
        className="relative"
      >
        <Bell className="w-5 h-5" />
        {unreadCount > 0 && (
          <Badge className="absolute -top-1 -right-1 h-5 w-5 p-0 flex items-center justify-center bg-red-500">
            {unreadCount}
          </Badge>
        )}
      </Button>

      {isOpen && (
        <Card className="absolute right-0 top-12 w-96 max-h-96 overflow-hidden bg-gray-800 border-gray-700 shadow-xl z-50">
          <div className="p-4 border-b border-gray-700 flex items-center justify-between">
            <h3 className="font-semibold text-white">AI Recommendations</h3>
            {unreadCount > 0 && (
              <Button
                variant="ghost"
                size="sm"
                onClick={markAllAsRead}
                className="text-xs"
              >
                Mark all read
              </Button>
            )}
          </div>

          <div className="overflow-y-auto max-h-80">
            {notifications.length === 0 ? (
              <div className="p-8 text-center text-gray-400">
                <Bell className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>No notifications yet</p>
              </div>
            ) : (
              notifications.map((notification) => (
                <div
                  key={notification.id}
                  className={`p-4 border-b border-gray-700 hover:bg-gray-750 cursor-pointer transition-colors ${
                    !notification.read ? 'bg-gray-750' : ''
                  }`}
                  onClick={() => {
                    markAsRead(notification.id);
                    onNotificationClick?.(notification);
                  }}
                >
                  <div className="flex items-start gap-3">
                    <div className="mt-1">{getIcon(notification.type)}</div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-start justify-between gap-2">
                        <h4 className="text-sm font-medium text-white">
                          {notification.title}
                        </h4>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={(e) => {
                            e.stopPropagation();
                            removeNotification(notification.id);
                          }}
                          className="h-6 w-6 p-0"
                        >
                          <X className="w-3 h-3" />
                        </Button>
                      </div>
                      <p className="text-sm text-gray-400 mt-1">
                        {notification.message}
                      </p>
                      <span className="text-xs text-gray-500 mt-1 block">
                        {notification.timestamp.toLocaleTimeString()}
                      </span>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </Card>
      )}
    </div>
  );
};
