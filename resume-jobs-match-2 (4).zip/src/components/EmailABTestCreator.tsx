import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Trash2, TestTube } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';

interface Variant {
  id: string;
  name: string;
  subjectLine: string;
  content: string;
}

export default function EmailABTestCreator({ onTestCreated }: { onTestCreated?: () => void }) {
  const { toast } = useToast();
  const [testName, setTestName] = useState('');
  const [testType, setTestType] = useState<'subject_line' | 'content' | 'both'>('subject_line');
  const [variants, setVariants] = useState<Variant[]>([
    { id: '1', name: 'Variant A', subjectLine: '', content: '' },
    { id: '2', name: 'Variant B', subjectLine: '', content: '' }
  ]);
  const [loading, setLoading] = useState(false);

  const addVariant = () => {
    if (variants.length < 3) {
      setVariants([...variants, {
        id: Date.now().toString(),
        name: `Variant ${String.fromCharCode(65 + variants.length)}`,
        subjectLine: '',
        content: ''
      }]);
    }
  };

  const removeVariant = (id: string) => {
    if (variants.length > 2) {
      setVariants(variants.filter(v => v.id !== id));
    }
  };

  const updateVariant = (id: string, field: keyof Variant, value: string) => {
    setVariants(variants.map(v => v.id === id ? { ...v, [field]: value } : v));
  };

  const createTest = async () => {
    if (!testName || variants.some(v => !v.subjectLine || !v.content)) {
      toast({ title: 'Error', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { data: test, error: testError } = await supabase
        .from('email_ab_tests')
        .insert({
          user_id: user.id,
          test_name: testName,
          test_type: testType,
          status: 'active'
        })
        .select()
        .single();

      if (testError) throw testError;

      const variantInserts = variants.map(v => ({
        test_id: test.id,
        variant_name: v.name,
        subject_line: v.subjectLine,
        email_content: v.content
      }));

      const { error: variantsError } = await supabase
        .from('email_test_variants')
        .insert(variantInserts);

      if (variantsError) throw variantsError;

      toast({ title: 'Success', description: 'A/B test created successfully' });
      onTestCreated?.();
      setTestName('');
      setVariants([
        { id: '1', name: 'Variant A', subjectLine: '', content: '' },
        { id: '2', name: 'Variant B', subjectLine: '', content: '' }
      ]);
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <TestTube className="h-5 w-5" />
          Create A/B Test
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <Label>Test Name</Label>
          <Input value={testName} onChange={(e) => setTestName(e.target.value)} placeholder="Follow-up Email Test" />
        </div>

        <div>
          <Label>Test Type</Label>
          <Select value={testType} onValueChange={(v: any) => setTestType(v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="subject_line">Subject Line Only</SelectItem>
              <SelectItem value="content">Content Only</SelectItem>
              <SelectItem value="both">Subject & Content</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {variants.map((variant, idx) => (
          <Card key={variant.id} className="p-4">
            <div className="flex justify-between items-center mb-3">
              <h4 className="font-semibold">{variant.name}</h4>
              {variants.length > 2 && (
                <Button size="sm" variant="ghost" onClick={() => removeVariant(variant.id)}>
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
            <div className="space-y-3">
              <div>
                <Label>Subject Line</Label>
                <Input
                  value={variant.subjectLine}
                  onChange={(e) => updateVariant(variant.id, 'subjectLine', e.target.value)}
                  placeholder="Email subject line"
                />
              </div>
              <div>
                <Label>Email Content</Label>
                <Textarea
                  value={variant.content}
                  onChange={(e) => updateVariant(variant.id, 'content', e.target.value)}
                  placeholder="Email body content"
                  rows={4}
                />
              </div>
            </div>
          </Card>
        ))}

        {variants.length < 3 && (
          <Button variant="outline" onClick={addVariant} className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Add Variant C
          </Button>
        )}

        <Button onClick={createTest} disabled={loading} className="w-full">
          {loading ? 'Creating...' : 'Create A/B Test'}
        </Button>
      </CardContent>
    </Card>
  );
}