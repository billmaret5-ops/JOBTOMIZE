import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import BackupScheduleBuilder from './BackupScheduleBuilder';
import BackupHealthWidget from './BackupHealthWidget';
import AutomatedOptimizationDashboard from './AutomatedOptimizationDashboard';
import PredictiveAnalyticsDashboard from './PredictiveAnalyticsDashboard';
import AutomatedReportingSystem from './AutomatedReportingSystem';
import RealTimeCostDashboard from './RealTimeCostDashboard';
import SlackTeamsIntegration from './SlackTeamsIntegration';
import { MLAnomalyDetectionDashboard } from './MLAnomalyDetectionDashboard';

import { AlertRoutingDashboard } from './AlertRoutingDashboard';
import OnCallScheduler from './OnCallScheduler';
import EscalationPolicyManager from './EscalationPolicyManager';
import IncidentManager from './IncidentManager';

import AlertAnalyticsDashboard from './AlertAnalyticsDashboard';
import { CustomDashboardManager } from './CustomDashboardManager';



export default function BackupDashboard() {
  const [activeTab, setActiveTab] = useState('schedule');

  return (
    <div className="container mx-auto p-6">
      <h1 className="text-3xl font-bold mb-6">Backup Management Dashboard</h1>
      
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-11">

          <TabsTrigger value="schedule">Schedule</TabsTrigger>
          <TabsTrigger value="health">Health</TabsTrigger>
          <TabsTrigger value="optimization">Auto Optimize</TabsTrigger>
          <TabsTrigger value="realtime">Real-Time</TabsTrigger>
          <TabsTrigger value="ml">ML Anomaly</TabsTrigger>
          <TabsTrigger value="alerts">Alert Routing</TabsTrigger>
          <TabsTrigger value="oncall">On-Call</TabsTrigger>
          <TabsTrigger value="escalation">Escalation</TabsTrigger>
          <TabsTrigger value="incidents">Incidents</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="dashboards">Dashboards</TabsTrigger>
        </TabsList>




        <TabsContent value="schedule">
          <BackupScheduleBuilder />
        </TabsContent>

        <TabsContent value="health">
          <BackupHealthWidget />
        </TabsContent>

        <TabsContent value="optimization">
          <div className="space-y-6">
            <AutomatedOptimizationDashboard />
            <PredictiveAnalyticsDashboard />
            <AutomatedReportingSystem />
          </div>
        </TabsContent>

        <TabsContent value="realtime">
          <RealTimeCostDashboard />
        </TabsContent>

        <TabsContent value="ml">
          <MLAnomalyDetectionDashboard />
        </TabsContent>

        <TabsContent value="alerts">
          <AlertRoutingDashboard />
        </TabsContent>

        <TabsContent value="oncall">
          <OnCallScheduler />
        </TabsContent>

        <TabsContent value="escalation">
          <EscalationPolicyManager />
        </TabsContent>

        <TabsContent value="incidents">
          <IncidentManager />
        </TabsContent>

        <TabsContent value="analytics">
          <AlertAnalyticsDashboard />
        </TabsContent>

        <TabsContent value="dashboards">
          <CustomDashboardManager />
        </TabsContent>
      </Tabs>

    </div>
  );
}
