import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Clock, Database, TrendingUp, AlertTriangle } from 'lucide-react';
import { backupSchedulingService } from '@/services/backupSchedulingService';

interface SimulationResult {
  timestamp: Date;
  scheduleName: string;
  estimatedDuration: number;
  estimatedSize: number;
  resourceUsage: number;
}

export default function BackupScheduleSimulator({ schedules }: { schedules: any[] }) {
  const [simulations, setSimulations] = useState<SimulationResult[]>([]);
  const [totalSize, setTotalSize] = useState(0);
  const [peakUsage, setPeakUsage] = useState(0);
  const [conflicts, setConflicts] = useState<any[]>([]);

  useEffect(() => {
    runSimulation();
  }, [schedules]);

  const runSimulation = () => {
    const results: SimulationResult[] = [];
    let total = 0;
    let peak = 0;

    schedules.forEach(schedule => {
      const times = backupSchedulingService.parseCronExpression(schedule.cronExpression);
      times.forEach(time => {
        const size = Math.random() * 5000 + 1000; // MB
        const duration = Math.random() * 120 + 30; // minutes
        const usage = Math.random() * 80 + 20; // percentage
        
        results.push({
          timestamp: time,
          scheduleName: schedule.name,
          estimatedDuration: duration,
          estimatedSize: size,
          resourceUsage: usage
        });
        
        total += size;
        peak = Math.max(peak, usage);
      });
    });

    results.sort((a, b) => a.timestamp.getTime() - b.timestamp.getTime());
    setSimulations(results.slice(0, 20));
    setTotalSize(total);
    setPeakUsage(peak);
    setConflicts(backupSchedulingService.detectConflicts(schedules));
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <Clock className="h-8 w-8 text-blue-500" />
            <div>
              <p className="text-sm text-muted-foreground">Upcoming Backups</p>
              <p className="text-2xl font-bold">{simulations.length}</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <Database className="h-8 w-8 text-green-500" />
            <div>
              <p className="text-sm text-muted-foreground">Est. Total Size</p>
              <p className="text-2xl font-bold">{(totalSize / 1024).toFixed(1)} GB</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <TrendingUp className="h-8 w-8 text-purple-500" />
            <div>
              <p className="text-sm text-muted-foreground">Peak Usage</p>
              <p className="text-2xl font-bold">{peakUsage.toFixed(0)}%</p>
            </div>
          </div>
        </Card>
        <Card className="p-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="h-8 w-8 text-orange-500" />
            <div>
              <p className="text-sm text-muted-foreground">Conflicts</p>
              <p className="text-2xl font-bold">{conflicts.length}</p>
            </div>
          </div>
        </Card>
      </div>

      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4">Upcoming Backup Timeline</h3>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {simulations.map((sim, idx) => (
            <div key={idx} className="flex items-center justify-between p-3 border rounded-lg hover:bg-muted/50">
              <div className="flex-1">
                <p className="font-medium">{sim.scheduleName}</p>
                <p className="text-sm text-muted-foreground">
                  {sim.timestamp.toLocaleString()}
                </p>
              </div>
              <div className="flex gap-4 text-sm">
                <Badge variant="outline">{sim.estimatedDuration.toFixed(0)}m</Badge>
                <Badge variant="outline">{(sim.estimatedSize / 1024).toFixed(2)} GB</Badge>
                <Badge variant={sim.resourceUsage > 70 ? "destructive" : "secondary"}>
                  {sim.resourceUsage.toFixed(0)}% CPU
                </Badge>
              </div>
            </div>
          ))}
        </div>
      </Card>
    </div>
  );
}
