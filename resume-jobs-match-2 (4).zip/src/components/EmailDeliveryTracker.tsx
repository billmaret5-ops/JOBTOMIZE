import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Mail, CheckCircle, XCircle, Eye, MousePointerClick, AlertTriangle } from 'lucide-react';

interface DeliveryLog {
  id: string;
  provider_name: string;
  message_id: string;
  recipient_email: string;
  subject: string;
  status: string;
  bounce_type?: string;
  bounce_reason?: string;
  opened_at?: string;
  clicked_at?: string;
  delivered_at?: string;
  bounced_at?: string;
  created_at: string;
}

export default function EmailDeliveryTracker() {
  const [logs, setLogs] = useState<DeliveryLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    loadDeliveryLogs();
    
    const subscription = supabase
      .channel('delivery_logs')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'email_delivery_logs' },
        () => loadDeliveryLogs()
      )
      .subscribe();

    return () => { subscription.unsubscribe(); };
  }, []);

  const loadDeliveryLogs = async () => {
    let query = supabase
      .from('email_delivery_logs')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(100);

    if (statusFilter !== 'all') {
      query = query.eq('status', statusFilter);
    }

    const { data } = await query;
    if (data) setLogs(data);
  };

  const filteredLogs = logs.filter(log =>
    log.recipient_email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.subject?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getStatusBadge = (status: string) => {
    const variants: Record<string, { color: string; icon: any }> = {
      sent: { color: 'bg-blue-500', icon: Mail },
      delivered: { color: 'bg-green-500', icon: CheckCircle },
      opened: { color: 'bg-purple-500', icon: Eye },
      clicked: { color: 'bg-indigo-500', icon: MousePointerClick },
      bounced: { color: 'bg-red-500', icon: XCircle },
      failed: { color: 'bg-orange-500', icon: AlertTriangle }
    };

    const variant = variants[status] || variants.sent;
    const Icon = variant.icon;

    return (
      <Badge className={variant.color}>
        <Icon className="w-3 h-3 mr-1" />
        {status}
      </Badge>
    );
  };

  const stats = {
    total: logs.length,
    sent: logs.filter(l => l.status === 'sent').length,
    delivered: logs.filter(l => l.status === 'delivered').length,
    opened: logs.filter(l => l.opened_at).length,
    clicked: logs.filter(l => l.clicked_at).length,
    bounced: logs.filter(l => l.status === 'bounced').length
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold">Email Delivery Tracking</h2>
        <p className="text-muted-foreground">Monitor email delivery status and engagement</p>
      </div>

      <div className="grid grid-cols-2 md:grid-cols-6 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold">{stats.total}</div>
            <div className="text-xs text-muted-foreground">Total Sent</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-green-600">{stats.delivered}</div>
            <div className="text-xs text-muted-foreground">Delivered</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-purple-600">{stats.opened}</div>
            <div className="text-xs text-muted-foreground">Opened</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-indigo-600">{stats.clicked}</div>
            <div className="text-xs text-muted-foreground">Clicked</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-red-600">{stats.bounced}</div>
            <div className="text-xs text-muted-foreground">Bounced</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="text-2xl font-bold text-blue-600">
              {stats.delivered > 0 ? ((stats.delivered / stats.total) * 100).toFixed(1) : 0}%
            </div>
            <div className="text-xs text-muted-foreground">Delivery Rate</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Delivery Logs</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-4">
            <Input
              placeholder="Search by recipient or subject..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="max-w-sm"
            />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="all">All Status</option>
              <option value="sent">Sent</option>
              <option value="delivered">Delivered</option>
              <option value="opened">Opened</option>
              <option value="clicked">Clicked</option>
              <option value="bounced">Bounced</option>
              <option value="failed">Failed</option>
            </select>
          </div>

          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Recipient</TableHead>
                <TableHead>Subject</TableHead>
                <TableHead>Provider</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Sent At</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredLogs.map((log) => (
                <TableRow key={log.id}>
                  <TableCell className="font-medium">{log.recipient_email}</TableCell>
                  <TableCell className="max-w-xs truncate">{log.subject}</TableCell>
                  <TableCell>
                    <Badge variant="outline" className="capitalize">
                      {log.provider_name.replace('_', ' ')}
                    </Badge>
                  </TableCell>
                  <TableCell>{getStatusBadge(log.status)}</TableCell>
                  <TableCell>{new Date(log.created_at).toLocaleString()}</TableCell>
                  <TableCell>
                    <div className="flex gap-1 text-xs">
                      {log.opened_at && <Badge variant="secondary">Opened</Badge>}
                      {log.clicked_at && <Badge variant="secondary">Clicked</Badge>}
                      {log.bounce_type && <Badge variant="destructive">{log.bounce_type}</Badge>}
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
