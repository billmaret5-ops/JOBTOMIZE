import React, { useState, useRef, useCallback } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { Camera, Upload, X, CheckCircle, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ScanResult {
  text: string;
  confidence: number;
  sections: {
    name?: string;
    email?: string;
    phone?: string;
    skills?: string[];
    experience?: string[];
  };
}

export function CameraResumeScanner() {
  const [isScanning, setIsScanning] = useState(false);
  const [stream, setStream] = useState<MediaStream | null>(null);
  const [scanResult, setScanResult] = useState<ScanResult | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [processing, setProcessing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startCamera = useCallback(async () => {
    try {
      setError(null);
      const mediaStream = await navigator.mediaDevices.getUserMedia({
        video: { 
          facingMode: 'environment',
          width: { ideal: 1920 },
          height: { ideal: 1080 }
        }
      });
      
      setStream(mediaStream);
      setIsScanning(true);
      
      if (videoRef.current) {
        videoRef.current.srcObject = mediaStream;
      }
    } catch (err) {
      setError('Camera access denied. Please enable camera permissions.');
    }
  }, []);

  const stopCamera = useCallback(() => {
    if (stream) {
      stream.getTracks().forEach(track => track.stop());
      setStream(null);
    }
    setIsScanning(false);
  }, [stream]);

  const captureAndScan = useCallback(async () => {
    if (!videoRef.current || !canvasRef.current) return;

    setProcessing(true);
    const canvas = canvasRef.current;
    const video = videoRef.current;
    const context = canvas.getContext('2d');

    if (context) {
      canvas.width = video.videoWidth;
      canvas.height = video.videoHeight;
      context.drawImage(video, 0, 0);
      
      canvas.toBlob(async (blob) => {
        if (blob) {
          try {
            const formData = new FormData();
            formData.append('file', blob, 'resume-scan.jpg');
            
            const { data, error } = await supabase.functions.invoke('parse-resume', {
              body: formData
            });

            if (error) throw error;

            setScanResult(data);
            stopCamera();
          } catch (err) {
            setError('Failed to process resume. Please try again.');
          }
        }
        setProcessing(false);
      }, 'image/jpeg', 0.8);
    }
  }, [stopCamera]);

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Camera className="h-5 w-5" />
          Resume Scanner
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {!isScanning && !scanResult && (
          <div className="text-center space-y-4">
            <p className="text-muted-foreground">
              Use your camera to scan and extract text from resume documents
            </p>
            <Button onClick={startCamera} className="w-full">
              <Camera className="w-4 h-4 mr-2" />
              Start Camera
            </Button>
          </div>
        )}

        {isScanning && (
          <div className="space-y-4">
            <div className="relative">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                className="w-full rounded-lg"
              />
              <canvas ref={canvasRef} className="hidden" />
            </div>
            
            <div className="flex gap-2">
              <Button 
                onClick={captureAndScan} 
                disabled={processing}
                className="flex-1"
              >
                {processing ? 'Processing...' : 'Capture & Scan'}
              </Button>
              <Button variant="outline" onClick={stopCamera}>
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        )}

        {scanResult && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-green-600">
              <CheckCircle className="h-5 w-5" />
              <span className="font-medium">Scan Complete</span>
              <Badge variant="secondary">
                {Math.round(scanResult.confidence * 100)}% confidence
              </Badge>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {scanResult.sections.name && (
                <div>
                  <h4 className="font-medium">Name</h4>
                  <p className="text-sm text-muted-foreground">{scanResult.sections.name}</p>
                </div>
              )}
              
              {scanResult.sections.email && (
                <div>
                  <h4 className="font-medium">Email</h4>
                  <p className="text-sm text-muted-foreground">{scanResult.sections.email}</p>
                </div>
              )}
              
              {scanResult.sections.phone && (
                <div>
                  <h4 className="font-medium">Phone</h4>
                  <p className="text-sm text-muted-foreground">{scanResult.sections.phone}</p>
                </div>
              )}
              
              {scanResult.sections.skills && (
                <div className="md:col-span-2">
                  <h4 className="font-medium mb-2">Skills</h4>
                  <div className="flex flex-wrap gap-1">
                    {scanResult.sections.skills.map((skill, index) => (
                      <Badge key={index} variant="outline">{skill}</Badge>
                    ))}
                  </div>
                </div>
              )}
            </div>

            <Button 
              onClick={() => {
                setScanResult(null);
                setError(null);
              }}
              variant="outline" 
              className="w-full"
            >
              Scan Another Resume
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}