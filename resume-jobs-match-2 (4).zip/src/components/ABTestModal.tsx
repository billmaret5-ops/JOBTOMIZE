import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Copy, Play, BarChart3 } from 'lucide-react';

interface ABTestModalProps {
  template: any;
  onClose: () => void;
}

export const ABTestModal: React.FC<ABTestModalProps> = ({ template, onClose }) => {
  const [testName, setTestName] = useState(`${template.name} A/B Test`);
  const [variantSubject, setVariantSubject] = useState(template.subject);
  const [trafficSplit, setTrafficSplit] = useState(50);

  const handleCreateTest = () => {
    console.log('Creating A/B test:', { testName, variantSubject, trafficSplit });
    onClose();
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle>Create A/B Test</DialogTitle>
          <DialogDescription>
            Configure and launch an A/B test to compare email variants
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          <div>
            <Label htmlFor="test-name">Test Name</Label>
            <Input
              id="test-name"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Version A (Original)</CardTitle>
                <Badge variant="secondary">Control</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <div className="text-sm font-medium">Subject:</div>
                  <div className="text-sm text-gray-600 p-2 bg-gray-50 rounded">
                    {template.subject}
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="text-sm">Version B (Variant)</CardTitle>
                <Badge variant="outline">Test</Badge>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  <Label htmlFor="variant-subject">Subject:</Label>
                  <Input
                    id="variant-subject"
                    value={variantSubject}
                    onChange={(e) => setVariantSubject(e.target.value)}
                    placeholder="Enter variant subject line"
                  />
                </div>
              </CardContent>
            </Card>
          </div>

          <div>
            <Label>Traffic Split</Label>
            <div className="mt-2 flex items-center space-x-4">
              <div className="flex-1">
                <input
                  type="range"
                  min="10"
                  max="90"
                  value={trafficSplit}
                  onChange={(e) => setTrafficSplit(Number(e.target.value))}
                  className="w-full"
                />
                <div className="flex justify-between text-sm text-gray-600 mt-1">
                  <span>Version A: {100 - trafficSplit}%</span>
                  <span>Version B: {trafficSplit}%</span>
                </div>
              </div>
            </div>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-sm">Test Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex justify-between text-sm">
                <span>Duration:</span>
                <span>7 days</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Minimum sample size:</span>
                <span>100 emails per variant</span>
              </div>
              <div className="flex justify-between text-sm">
                <span>Success metric:</span>
                <span>Open rate</span>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleCreateTest} className="bg-green-600 hover:bg-green-700">
            <Play className="w-4 h-4 mr-2" />
            Start A/B Test
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
};