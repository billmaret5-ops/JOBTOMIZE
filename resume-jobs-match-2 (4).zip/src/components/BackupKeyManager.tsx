import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Key, Plus, RotateCw, Shield } from 'lucide-react';
import { backupEncryptionService } from '@/services/backupEncryptionService';
import { useToast } from '@/hooks/use-toast';

export const BackupKeyManager: React.FC = () => {
  const [keyName, setKeyName] = useState('');
  const [algorithm, setAlgorithm] = useState<'AES-256' | 'RSA-2048' | 'RSA-4096'>('AES-256');
  const [escrowEnabled, setEscrowEnabled] = useState(false);
  const [rotationDays, setRotationDays] = useState('90');
  const { toast } = useToast();

  const handleCreateKey = async () => {
    if (!keyName) {
      toast({ title: 'Error', description: 'Please enter a key name', variant: 'destructive' });
      return;
    }

    await backupEncryptionService.createEncryptionKey(keyName, algorithm, escrowEnabled);
    toast({ title: 'Success', description: 'Encryption key created successfully' });
    setKeyName('');
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Plus className="h-5 w-5" />
            Create Encryption Key
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="keyName">Key Name</Label>
            <Input
              id="keyName"
              value={keyName}
              onChange={(e) => setKeyName(e.target.value)}
              placeholder="e.g., Production Backup Key"
            />
          </div>

          <div>
            <Label htmlFor="algorithm">Encryption Algorithm</Label>
            <Select value={algorithm} onValueChange={(v: any) => setAlgorithm(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="AES-256">AES-256 (Recommended)</SelectItem>
                <SelectItem value="RSA-2048">RSA-2048</SelectItem>
                <SelectItem value="RSA-4096">RSA-4096 (High Security)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center justify-between">
            <Label htmlFor="escrow">Enable Key Escrow</Label>
            <Switch
              id="escrow"
              checked={escrowEnabled}
              onCheckedChange={setEscrowEnabled}
            />
          </div>

          <Button onClick={handleCreateKey} className="w-full">
            <Key className="h-4 w-4 mr-2" />
            Create Encryption Key
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RotateCw className="h-5 w-5" />
            Automatic Key Rotation
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="rotationDays">Rotation Interval (days)</Label>
            <Input
              id="rotationDays"
              type="number"
              value={rotationDays}
              onChange={(e) => setRotationDays(e.target.value)}
              placeholder="90"
            />
          </div>

          <div className="p-4 bg-blue-50 rounded-lg">
            <div className="flex items-start gap-2">
              <Shield className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="text-sm text-blue-800">
                <div className="font-medium mb-1">Key Rotation Policy</div>
                <div>Keys will be automatically rotated every {rotationDays} days. Old keys will be retained for decryption of existing backups.</div>
              </div>
            </div>
          </div>

          <Button variant="outline" className="w-full">
            Save Rotation Policy
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Encryption Settings</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-center justify-between p-3 border rounded">
            <span>Encrypt backups in transit</span>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between p-3 border rounded">
            <span>Encrypt backups at rest</span>
            <Switch defaultChecked />
          </div>
          <div className="flex items-center justify-between p-3 border rounded">
            <span>Require encryption for all backups</span>
            <Switch defaultChecked />
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
