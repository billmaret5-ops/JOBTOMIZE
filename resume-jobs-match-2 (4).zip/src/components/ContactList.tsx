import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Checkbox } from '@/components/ui/checkbox';
import { Avatar, AvatarFallback, AvatarInitials } from '@/components/ui/avatar';
import { ContactProfile } from './ContactProfile';
import { 
  MoreHorizontal, 
  Mail, 
  Phone, 
  Building, 
  Calendar,
  Star,
  Tag
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';

interface Contact {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  company?: string;
  lifecycle_stage: string;
  lead_score: number;
  engagement_score: number;
  tags: string[];
  last_activity_at?: string;
}

interface ContactListProps {
  contacts: Contact[];
  selectedContacts: string[];
  onSelectionChange: (selected: string[]) => void;
  loading: boolean;
}

export function ContactList({ 
  contacts, 
  selectedContacts, 
  onSelectionChange, 
  loading 
}: ContactListProps) {
  const [selectedContact, setSelectedContact] = useState<Contact | null>(null);

  const handleSelectAll = (checked: boolean) => {
    if (checked) {
      onSelectionChange(contacts.map(c => c.id));
    } else {
      onSelectionChange([]);
    }
  };

  const handleSelectContact = (contactId: string, checked: boolean) => {
    if (checked) {
      onSelectionChange([...selectedContacts, contactId]);
    } else {
      onSelectionChange(selectedContacts.filter(id => id !== contactId));
    }
  };

  const getLifecycleColor = (stage: string) => {
    const colors = {
      lead: 'bg-blue-100 text-blue-800',
      prospect: 'bg-yellow-100 text-yellow-800',
      customer: 'bg-green-100 text-green-800',
      evangelist: 'bg-purple-100 text-purple-800'
    };
    return colors[stage as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const formatDate = (dateString?: string) => {
    if (!dateString) return 'Never';
    return new Date(dateString).toLocaleDateString();
  };

  if (loading) {
    return (
      <Card>
        <CardContent className="p-6">
          <div className="space-y-4">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="flex items-center space-x-4">
                <div className="w-10 h-10 bg-gray-200 rounded-full animate-pulse" />
                <div className="flex-1 space-y-2">
                  <div className="h-4 bg-gray-200 rounded animate-pulse" />
                  <div className="h-3 bg-gray-200 rounded w-2/3 animate-pulse" />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <>
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Contacts ({contacts.length})</CardTitle>
            <div className="flex items-center gap-2">
              <Checkbox
                checked={selectedContacts.length === contacts.length && contacts.length > 0}
                onCheckedChange={handleSelectAll}
              />
              <span className="text-sm text-muted-foreground">
                {selectedContacts.length} selected
              </span>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {contacts.map((contact) => (
              <div
                key={contact.id}
                className="flex items-center space-x-4 p-4 border rounded-lg hover:bg-muted/50 transition-colors"
              >
                <Checkbox
                  checked={selectedContacts.includes(contact.id)}
                  onCheckedChange={(checked) => 
                    handleSelectContact(contact.id, checked as boolean)
                  }
                />
                
                <Avatar className="h-10 w-10">
                  <AvatarFallback>
                    {contact.first_name?.[0]}{contact.last_name?.[0]}
                  </AvatarFallback>
                </Avatar>

                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <p className="font-medium truncate">
                      {contact.first_name} {contact.last_name}
                    </p>
                    <Badge 
                      variant="secondary" 
                      className={getLifecycleColor(contact.lifecycle_stage)}
                    >
                      {contact.lifecycle_stage}
                    </Badge>
                  </div>
                  
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <div className="flex items-center gap-1">
                      <Mail className="h-3 w-3" />
                      {contact.email}
                    </div>
                    {contact.company && (
                      <div className="flex items-center gap-1">
                        <Building className="h-3 w-3" />
                        {contact.company}
                      </div>
                    )}
                    <div className="flex items-center gap-1">
                      <Calendar className="h-3 w-3" />
                      {formatDate(contact.last_activity_at)}
                    </div>
                  </div>

                  <div className="flex items-center gap-2 mt-2">
                    {contact.tags.map((tag) => (
                      <Badge key={tag} variant="outline" className="text-xs">
                        <Tag className="h-2 w-2 mr-1" />
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div className="flex items-center gap-4 text-sm">
                  <div className="text-center">
                    <div className={`font-medium ${getScoreColor(contact.lead_score)}`}>
                      {contact.lead_score}
                    </div>
                    <div className="text-xs text-muted-foreground">Lead Score</div>
                  </div>
                  
                  <div className="text-center">
                    <div className={`font-medium ${getScoreColor(contact.engagement_score)}`}>
                      {contact.engagement_score}
                    </div>
                    <div className="text-xs text-muted-foreground">Engagement</div>
                  </div>
                </div>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm">
                      <MoreHorizontal className="h-4 w-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end">
                    <DropdownMenuItem onClick={() => setSelectedContact(contact)}>
                      View Profile
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Send Email
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Add to List
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      Add Tag
                    </DropdownMenuItem>
                    <DropdownMenuItem className="text-red-600">
                      Delete
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {selectedContact && (
        <ContactProfile
          contact={selectedContact}
          open={!!selectedContact}
          onClose={() => setSelectedContact(null)}
        />
      )}
    </>
  );
}