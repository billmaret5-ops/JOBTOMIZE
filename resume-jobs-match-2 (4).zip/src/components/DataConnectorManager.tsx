import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Database, Link, Activity, Settings, Plus, CheckCircle, AlertCircle } from 'lucide-react';

interface DataConnector {
  id: string;
  name: string;
  type: string;
  status: 'connected' | 'disconnected' | 'error';
  url: string;
  lastSync: string;
  recordCount: number;
}

export const DataConnectorManager: React.FC = () => {
  const [connectors, setConnectors] = useState<DataConnector[]>([
    {
      id: '1',
      name: 'Sales API',
      type: 'REST API',
      status: 'connected',
      url: 'https://api.example.com/sales',
      lastSync: '2 minutes ago',
      recordCount: 1250
    },
    {
      id: '2',
      name: 'Analytics DB',
      type: 'PostgreSQL',
      status: 'connected',
      url: 'postgres://analytics.db',
      lastSync: '5 minutes ago',
      recordCount: 45000
    },
    {
      id: '3',
      name: 'Marketing Data',
      type: 'GraphQL',
      status: 'error',
      url: 'https://api.marketing.com/graphql',
      lastSync: '1 hour ago',
      recordCount: 0
    }
  ]);

  const [newConnector, setNewConnector] = useState({
    name: '',
    type: 'REST API',
    url: '',
    headers: '',
    query: ''
  });

  const connectorTypes = [
    'REST API', 'GraphQL', 'PostgreSQL', 'MySQL', 'MongoDB', 'Redis', 'Webhook'
  ];

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
      default: return <Activity className="h-4 w-4 text-gray-500" />;
    }
  };

  const testConnection = (id: string) => {
    // Simulate connection test
    setConnectors(prev => prev.map(conn => 
      conn.id === id ? { ...conn, status: 'connected' as const, lastSync: 'Just now' } : conn
    ));
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Database className="h-5 w-5" />
          Data Connector Manager
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="connectors" className="w-full">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="connectors">Active Connectors</TabsTrigger>
            <TabsTrigger value="new">Add Connector</TabsTrigger>
          </TabsList>

          <TabsContent value="connectors" className="space-y-4">
            {connectors.map(connector => (
              <Card key={connector.id}>
                <CardContent className="pt-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      {getStatusIcon(connector.status)}
                      <div>
                        <h3 className="font-medium">{connector.name}</h3>
                        <p className="text-sm text-muted-foreground">{connector.type}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="outline">{connector.recordCount.toLocaleString()} records</Badge>
                      <Badge variant={connector.status === 'connected' ? 'default' : 'destructive'}>
                        {connector.status}
                      </Badge>
                    </div>
                  </div>
                  
                  <div className="mt-3 flex items-center justify-between text-sm text-muted-foreground">
                    <span>Last sync: {connector.lastSync}</span>
                    <div className="flex gap-2">
                      <Button size="sm" variant="outline" onClick={() => testConnection(connector.id)}>
                        Test
                      </Button>
                      <Button size="sm" variant="outline">
                        <Settings className="h-3 w-3 mr-1" />
                        Configure
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="new" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Connector Name</Label>
                <Input
                  value={newConnector.name}
                  onChange={(e) => setNewConnector({...newConnector, name: e.target.value})}
                  placeholder="My API Connector"
                />
              </div>
              <div>
                <Label>Connector Type</Label>
                <Select value={newConnector.type} onValueChange={(value) => setNewConnector({...newConnector, type: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {connectorTypes.map(type => (
                      <SelectItem key={type} value={type}>{type}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <Label>Connection URL</Label>
              <Input
                value={newConnector.url}
                onChange={(e) => setNewConnector({...newConnector, url: e.target.value})}
                placeholder="https://api.example.com/data"
              />
            </div>

            <Button className="w-full">
              <Plus className="h-4 w-4 mr-2" />
              Add Connector
            </Button>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};