import { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Download, Mail, Clock, FileText, CheckCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { automatedCostOptimizationService, OptimizationReport } from '@/services/automatedCostOptimizationService';

export default function AutomatedReportingSystem() {
  const [reports, setReports] = useState<OptimizationReport[]>([]);
  const [scheduleFrequency, setScheduleFrequency] = useState('weekly');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadReports();
  }, []);

  const loadReports = async () => {
    setLoading(true);
    const report = await automatedCostOptimizationService.generateOptimizationReport(
      new Date(Date.now() - 30 * 24 * 60 * 60 * 1000).toISOString(),
      new Date().toISOString()
    );
    setReports([report]);
    setLoading(false);
  };

  const generateReport = async () => {
    setLoading(true);
    await loadReports();
    setLoading(false);
  };

  const schedules = [
    { id: '1', name: 'Weekly Cost Optimization Report', frequency: 'weekly', recipients: ['admin@company.com'], lastRun: '2024-01-20', nextRun: '2024-01-27' },
    { id: '2', name: 'Monthly Executive Summary', frequency: 'monthly', recipients: ['cfo@company.com', 'cto@company.com'], lastRun: '2024-01-01', nextRun: '2024-02-01' },
    { id: '3', name: 'Daily Operations Report', frequency: 'daily', recipients: ['ops@company.com'], lastRun: '2024-01-25', nextRun: '2024-01-26' }
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Automated Reporting</h2>
          <p className="text-muted-foreground">Schedule and manage cost optimization reports</p>
        </div>
        <Button onClick={generateReport} disabled={loading}>
          <FileText className="w-4 h-4 mr-2" />
          Generate Report
        </Button>
      </div>

      <div className="grid gap-4 md:grid-cols-3">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Scheduled Reports</CardTitle>
            <Calendar className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{schedules.length}</div>
            <p className="text-xs text-muted-foreground">Active schedules</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Reports Generated</CardTitle>
            <FileText className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">47</div>
            <p className="text-xs text-muted-foreground">This month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Savings Tracked</CardTitle>
            <CheckCircle className="h-4 w-4 text-purple-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$45,230</div>
            <p className="text-xs text-muted-foreground">Year to date</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Report Schedules</CardTitle>
          <CardDescription>Manage automated report generation and distribution</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {schedules.map((schedule) => (
              <div key={schedule.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h4 className="font-medium">{schedule.name}</h4>
                    <Badge>{schedule.frequency}</Badge>
                  </div>
                  <div className="flex items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <Mail className="w-3 h-3" />
                      {schedule.recipients.length} recipients
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      Last: {schedule.lastRun}
                    </span>
                    <span className="flex items-center gap-1">
                      <Calendar className="w-3 h-3" />
                      Next: {schedule.nextRun}
                    </span>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm">Edit</Button>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
          <CardDescription>View and download generated optimization reports</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reports.map((report) => (
              <div key={report.id} className="p-4 border rounded-lg">
                <div className="flex items-start justify-between mb-4">
                  <div>
                    <h4 className="font-medium mb-1">Cost Optimization Report</h4>
                    <p className="text-sm text-muted-foreground">
                      {new Date(report.period.start).toLocaleDateString()} - {new Date(report.period.end).toLocaleDateString()}
                    </p>
                  </div>
                  <Button variant="outline" size="sm">
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
                
                <div className="grid grid-cols-3 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Total Savings</p>
                    <p className="text-xl font-bold text-green-600">${report.total_savings.toLocaleString()}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Actions Taken</p>
                    <p className="text-xl font-bold">{report.actions_taken}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Recommendations</p>
                    <p className="text-xl font-bold">{report.recommendations.length}</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h5 className="font-medium text-sm">Key Actions</h5>
                  {report.recommendations.map((rec, idx) => (
                    <div key={idx} className="flex items-center justify-between text-sm p-2 bg-muted rounded">
                      <span>{rec.description}</span>
                      <div className="flex items-center gap-2">
                        <span className="text-green-600 font-medium">${rec.potential_savings}</span>
                        {rec.applied && <CheckCircle className="w-4 h-4 text-green-500" />}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
