import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, Sparkles, Wand2, List, FileText } from 'lucide-react';
import { generateAIContent } from '@/lib/aiService';
import { useToast } from '@/hooks/use-toast';

interface AIResumeBuilderProps {
  onContentGenerated: (content: string) => void;
}

export default function AIResumeBuilder({ onContentGenerated }: AIResumeBuilderProps) {
  const [loading, setLoading] = useState(false);
  const [tone, setTone] = useState<'professional' | 'creative' | 'technical'>('professional');
  const [jobTitle, setJobTitle] = useState('');
  const [description, setDescription] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const { toast } = useToast();

  const handleGenerate = async (action: string) => {
    setLoading(true);
    try {
      const content = await generateAIContent({
        action: action as any,
        data: { jobTitle, description, tone, jobDescription }
      });
      onContentGenerated(content);
      toast({ title: 'Content generated!', description: 'AI-powered content ready' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to generate content', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="p-6 space-y-6">
      <div className="flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-purple-600" />
        <h2 className="text-2xl font-bold">AI Resume Assistant</h2>
      </div>

      <div className="space-y-4">
        <div>
          <label className="block text-sm font-medium mb-2">Tone</label>
          <Select value={tone} onValueChange={(v: any) => setTone(v)}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="professional">Professional</SelectItem>
              <SelectItem value="creative">Creative</SelectItem>
              <SelectItem value="technical">Technical</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Job Title</label>
          <input
            type="text"
            value={jobTitle}
            onChange={(e) => setJobTitle(e.target.value)}
            className="w-full px-3 py-2 border rounded-md"
            placeholder="e.g., Senior Software Engineer"
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Job Description (Optional)</label>
          <Textarea
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            placeholder="Paste job description to tailor content..."
            rows={4}
          />
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Current Content</label>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Enter your experience or responsibilities..."
            rows={4}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <Button onClick={() => handleGenerate('generate_bullet_points')} disabled={loading}>
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <List className="w-4 h-4" />}
            <span className="ml-2">Generate Bullets</span>
          </Button>
          <Button onClick={() => handleGenerate('improve_writing')} disabled={loading} variant="outline">
            {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wand2 className="w-4 h-4" />}
            <span className="ml-2">Improve Writing</span>
          </Button>
          <Button onClick={() => handleGenerate('suggest_action_verbs')} disabled={loading} variant="outline">
            <FileText className="w-4 h-4 mr-2" />
            Action Verbs
          </Button>
          <Button onClick={() => handleGenerate('tailor_to_job')} disabled={loading} variant="outline">
            <Sparkles className="w-4 h-4 mr-2" />
            Tailor to Job
          </Button>
        </div>
      </div>
    </Card>
  );
}
