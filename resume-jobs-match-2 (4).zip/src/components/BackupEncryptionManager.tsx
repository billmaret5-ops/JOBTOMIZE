import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Shield, Lock, Key, CheckCircle, AlertTriangle } from 'lucide-react';
import { backupEncryptionService, EncryptionKey } from '@/services/backupEncryptionService';

export const BackupEncryptionManager: React.FC = () => {
  const [keys, setKeys] = useState<EncryptionKey[]>([]);
  const [selectedKey, setSelectedKey] = useState<string | null>(null);
  const [verifying, setVerifying] = useState(false);
  const [verificationResult, setVerificationResult] = useState<boolean | null>(null);

  useEffect(() => {
    loadKeys();
  }, []);

  const loadKeys = async () => {
    const data = await backupEncryptionService.getEncryptionKeys();
    setKeys(data);
  };

  const handleVerifyBackup = async () => {
    if (!selectedKey) return;
    setVerifying(true);
    const result = await backupEncryptionService.verifyEncryptedBackup('backup_1', selectedKey);
    setVerificationResult(result);
    setVerifying(false);
  };

  const handleRotateKey = async (keyId: string) => {
    await backupEncryptionService.rotateKey(keyId);
    loadKeys();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Encryption Overview
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-3 gap-4">
            <div className="text-center">
              <div className="text-3xl font-bold text-green-600">{keys.filter(k => k.status === 'active').length}</div>
              <div className="text-sm text-gray-600">Active Keys</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-blue-600">256-bit</div>
              <div className="text-sm text-gray-600">Encryption Strength</div>
            </div>
            <div className="text-center">
              <div className="text-3xl font-bold text-purple-600">100%</div>
              <div className="text-sm text-gray-600">Backups Encrypted</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Encryption Keys</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {keys.map((key) => (
              <div key={key.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Key className="h-5 w-5 text-blue-600" />
                  <div>
                    <div className="font-medium">{key.name}</div>
                    <div className="text-sm text-gray-600">
                      {key.algorithm} • Created {new Date(key.created_at).toLocaleDateString()}
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  <Badge variant={key.status === 'active' ? 'default' : 'secondary'}>
                    {key.status}
                  </Badge>
                  {key.escrow_enabled && (
                    <Badge variant="outline">Escrow</Badge>
                  )}
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setSelectedKey(key.id)}
                  >
                    Select
                  </Button>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => handleRotateKey(key.id)}
                  >
                    Rotate
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Backup Verification</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center gap-2">
              <Lock className="h-5 w-5" />
              <span>Selected Key: {selectedKey || 'None'}</span>
            </div>
            <Button onClick={handleVerifyBackup} disabled={!selectedKey || verifying}>
              {verifying ? 'Verifying...' : 'Verify Encrypted Backup'}
            </Button>
            {verificationResult !== null && (
              <div className={`flex items-center gap-2 p-3 rounded-lg ${
                verificationResult ? 'bg-green-50 text-green-800' : 'bg-red-50 text-red-800'
              }`}>
                {verificationResult ? (
                  <>
                    <CheckCircle className="h-5 w-5" />
                    <span>Backup verification successful</span>
                  </>
                ) : (
                  <>
                    <AlertTriangle className="h-5 w-5" />
                    <span>Backup verification failed</span>
                  </>
                )}
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
