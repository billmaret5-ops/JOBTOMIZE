import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Sparkles, TrendingUp, AlertCircle, CheckCircle2, Loader2, Wand2, Download, FileDown } from 'lucide-react';

import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import ResumeComparisonView from './ResumeComparisonView';
import BulkApplyModal from './BulkApplyModal';
import OptimizedResumeExportModal from './OptimizedResumeExportModal';
import BulkResumeExportModal from './BulkResumeExportModal';
import { resumeService } from '@/services/resumeService';


interface AIResumeOptimizerPanelProps {
  resumeData: any;
  resumeId: string;
  onResumeUpdate: () => void;
}

export default function AIResumeOptimizerPanel({ 
  resumeData, 
  resumeId,
  onResumeUpdate 
}: AIResumeOptimizerPanelProps) {
  const [jobDescription, setJobDescription] = useState('');
  const [analyzing, setAnalyzing] = useState(false);
  const [analysis, setAnalysis] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [appliedSections, setAppliedSections] = useState<Set<string>>(new Set());
  const [undoStack, setUndoStack] = useState<Map<string, any>>(new Map());
  const [showBulkApplyModal, setShowBulkApplyModal] = useState(false);
  const [showExportModal, setShowExportModal] = useState(false);
  const [showBulkExportModal, setShowBulkExportModal] = useState(false);



  const analyzeResume = async () => {
    if (!jobDescription.trim()) {
      toast.error('Please enter a job description');
      return;
    }

    setAnalyzing(true);
    try {
      const resumeContent = `
        ${resumeData.full_name || ''}
        ${resumeData.email || ''} | ${resumeData.phone || ''}
        ${resumeData.summary || ''}
        
        Experience:
        ${resumeData.experience?.map((exp: any) => `${exp.title} at ${exp.company}\n${exp.description}`).join('\n\n')}
        
        Education:
        ${resumeData.education?.map((edu: any) => `${edu.degree} - ${edu.institution}`).join('\n')}
        
        Skills: ${resumeData.skills?.join(', ')}
      `;

      const { data, error } = await supabase.functions.invoke('ai-resume-optimizer', {
        body: { resumeContent, jobDescription, resumeData }
      });

      if (error) throw error;
      setAnalysis(data);
      setAppliedSections(new Set());
      setUndoStack(new Map());
      toast.success('Resume analysis complete!');
    } catch (error: any) {
      console.error('Analysis error:', error);
      toast.error('Failed to analyze resume. Please try again.');
    } finally {
      setAnalyzing(false);
    }
  };

  const handleApplyChanges = async (section: string, data: any) => {
    try {
      const { data: currentResume } = await resumeService.getResume(resumeId);
      if (!currentResume) throw new Error('Resume not found');

      // Store original data for undo
      const originalData = { ...currentResume.content };
      const newUndoStack = new Map(undoStack);
      newUndoStack.set(section, originalData);
      setUndoStack(newUndoStack);

      // Apply changes based on section
      let updatedContent = { ...currentResume.content };
      
      if (section === 'summary') {
        updatedContent.summary = data;
      } else if (section === 'skills') {
        updatedContent.skills = data;
      } else if (section.startsWith('experience-')) {
        const idx = parseInt(section.split('-')[1]);
        updatedContent.experience = [...(updatedContent.experience || [])];
        updatedContent.experience[idx] = data;
      }

      // Update resume in database
      await resumeService.updateResume(resumeId, {
        content: updatedContent
      });

      // Create version snapshot
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await resumeService.createVersion(resumeId, user.id, updatedContent);
      }

      // Mark section as applied
      const newAppliedSections = new Set(appliedSections);
      newAppliedSections.add(section);
      setAppliedSections(newAppliedSections);

      onResumeUpdate();
    } catch (error) {
      console.error('Error applying changes:', error);
      throw error;
    }
  };

  const handleUndo = async (section: string) => {
    try {
      const originalData = undoStack.get(section);
      if (!originalData) return;

      await resumeService.updateResume(resumeId, {
        content: originalData
      });

      // Remove from applied sections
      const newAppliedSections = new Set(appliedSections);
      newAppliedSections.delete(section);
      setAppliedSections(newAppliedSections);

      // Remove from undo stack
      const newUndoStack = new Map(undoStack);
      newUndoStack.delete(section);
      setUndoStack(newUndoStack);

      onResumeUpdate();
      toast.success('Changes reverted successfully');
    } catch (error) {
      console.error('Error undoing changes:', error);
      toast.error('Failed to undo changes');
    }
  };

  const handleBulkApply = async (selectedSections: string[]) => {
    try {
      const { data: currentResume } = await resumeService.getResume(resumeId);
      if (!currentResume) throw new Error('Resume not found');

      // Store original data for undo
      const originalData = { ...currentResume.content };
      const newUndoStack = new Map(undoStack);
      newUndoStack.set('bulk', originalData);
      setUndoStack(newUndoStack);

      // Apply changes for all selected sections
      let updatedContent = { ...currentResume.content };
      
      if (selectedSections.includes('summary') && analysis.optimizedContent?.summary) {
        updatedContent.summary = analysis.optimizedContent.summary;
      }
      
      if (selectedSections.includes('skills') && analysis.optimizedContent?.skills) {
        updatedContent.skills = analysis.optimizedContent.skills;
      }
      
      if (selectedSections.includes('experience') && analysis.optimizedContent?.experience) {
        updatedContent.experience = analysis.optimizedContent.experience;
      }

      // Update resume in database
      await resumeService.updateResume(resumeId, {
        content: updatedContent
      });

      // Create version snapshot
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        await resumeService.createVersion(resumeId, user.id, updatedContent);
      }

      // Mark sections as applied
      const newAppliedSections = new Set(appliedSections);
      selectedSections.forEach(section => newAppliedSections.add(section));
      setAppliedSections(newAppliedSections);

      onResumeUpdate();
      toast.success(`Successfully applied ${selectedSections.length} section(s)`);
    } catch (error) {
      console.error('Error applying bulk changes:', error);
      toast.error('Failed to apply changes');
    }
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const handleExport = async (config: any) => {
    try {
      const { format, sections, formatting } = config;
      
      // Build content based on selected sections
      let content = { ...resumeData };
      if (analysis?.optimizedContent) {
        if (sections.summary) content.summary = analysis.optimizedContent.summary || content.summary;
        if (sections.experience) content.experience = analysis.optimizedContent.experience || content.experience;
        if (sections.skills) content.skills = analysis.optimizedContent.skills || content.skills;
      }
      
      // Generate export file
      const blob = await generateExportFile(content, format, formatting);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `optimized-resume.${format}`;
      a.click();
      URL.revokeObjectURL(url);
      
      toast.success(`Resume exported as ${format.toUpperCase()}`);
    } catch (error) {
      console.error('Export error:', error);
      toast.error('Failed to export resume');
    }
  };

  const handleBulkExport = async (versions: any[]) => {
    try {
      for (const version of versions) {
        let content = { ...resumeData };
        if (analysis?.optimizedContent) {
          if (version.sections.summary) content.summary = analysis.optimizedContent.summary || content.summary;
          if (version.sections.experience) content.experience = analysis.optimizedContent.experience || content.experience;
          if (version.sections.skills) content.skills = analysis.optimizedContent.skills || content.skills;
        }
        
        const blob = await generateExportFile(content, version.format, {});
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${version.name.replace(/\s+/g, '-')}.${version.format}`;
        a.click();
        URL.revokeObjectURL(url);
        
        await new Promise(resolve => setTimeout(resolve, 500));
      }
      
      toast.success(`Exported ${versions.length} resume version(s)`);
    } catch (error) {
      console.error('Bulk export error:', error);
      toast.error('Failed to export resumes');
    }
  };

  const generateExportFile = async (content: any, format: string, formatting: any): Promise<Blob> => {
    if (format === 'txt') {
      const text = `
${content.full_name || ''}
${content.email || ''} | ${content.phone || ''}

SUMMARY
${content.summary || ''}

EXPERIENCE
${content.experience?.map((exp: any) => `
${exp.title} at ${exp.company}
${exp.start_date} - ${exp.end_date || 'Present'}
${exp.description}
`).join('\n') || ''}

EDUCATION
${content.education?.map((edu: any) => `${edu.degree} - ${edu.institution}`).join('\n') || ''}

SKILLS
${content.skills?.join(', ') || ''}
      `.trim();
      return new Blob([text], { type: 'text/plain' });
    }
    
    // For PDF/DOCX, create HTML and convert (simplified)
    const html = `
      <html><body style="font-family: ${formatting.fontFamily || 'Arial'}; font-size: ${formatting.fontSize || 11}pt; line-height: ${formatting.lineSpacing || 1.15};">
        <h1>${content.full_name || ''}</h1>
        <p>${content.email || ''} | ${content.phone || ''}</p>
        <h2>Summary</h2>
        <p>${content.summary || ''}</p>
        <h2>Experience</h2>
        ${content.experience?.map((exp: any) => `
          <div>
            <h3>${exp.title} at ${exp.company}</h3>
            <p><em>${exp.start_date} - ${exp.end_date || 'Present'}</em></p>
            <p>${exp.description}</p>
          </div>
        `).join('') || ''}
        <h2>Skills</h2>
        <p>${content.skills?.join(', ') || ''}</p>
      </body></html>
    `;
    
    return new Blob([html], { type: format === 'pdf' ? 'application/pdf' : 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' });
  };



  return (
    <div className="space-y-6">
      <Card className="p-6">
        <div className="flex items-center gap-2 mb-4">
          <Sparkles className="w-5 h-5 text-purple-600" />
          <h3 className="text-lg font-semibold">AI Resume Optimizer</h3>
        </div>
        
        <Textarea
          placeholder="Paste the job description here..."
          value={jobDescription}
          onChange={(e) => setJobDescription(e.target.value)}
          rows={6}
          className="mb-4"
        />
        
        <Button onClick={analyzeResume} disabled={analyzing} className="w-full">
          {analyzing ? (
            <>
              <Loader2 className="w-4 h-4 mr-2 animate-spin" />
              Analyzing...
            </>
          ) : (
            <>
              <Sparkles className="w-4 h-4 mr-2" />
              Analyze Resume
            </>
          )}
        </Button>
      </Card>

      {analysis && (
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="keywords">Keywords</TabsTrigger>
            <TabsTrigger value="skills">Skills Gap</TabsTrigger>
            <TabsTrigger value="comparison">Comparison</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-4">
            <Card className="p-6">
              <div className="flex items-center justify-between mb-4">
                <h4 className="font-semibold">ATS Score</h4>
                <span className={`text-3xl font-bold ${getScoreColor(analysis.atsScore)}`}>
                  {analysis.atsScore}%
                </span>
              </div>
              <Progress value={analysis.atsScore} className="mb-4" />
              <p className="text-sm text-gray-600">{analysis.overallFeedback}</p>
            </Card>

            {Object.entries(analysis.sectionRecommendations || {}).map(([section, data]: [string, any]) => (
              <Card key={section} className="p-6">
                <div className="flex items-center justify-between mb-3">
                  <h4 className="font-semibold capitalize">{section}</h4>
                  <Badge className={getScoreColor(data.score)}>{data.score}%</Badge>
                </div>
                <p className="text-sm text-gray-600 mb-3">{data.feedback}</p>
                <div className="space-y-2">
                  {data.suggestions?.map((suggestion: string, idx: number) => (
                    <div key={idx} className="flex items-start gap-2 text-sm">
                      <TrendingUp className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                      <span>{suggestion}</span>
                    </div>
                  ))}
                </div>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="keywords" className="space-y-4">
            <Card className="p-6">
              <h4 className="font-semibold mb-4 flex items-center gap-2">
                <CheckCircle2 className="w-5 h-5 text-green-600" />
                Matched Keywords
              </h4>
              <div className="flex flex-wrap gap-2">
                {analysis.keywordMatches?.matched?.map((keyword: string, idx: number) => (
                  <Badge key={idx} className="bg-green-600">{keyword}</Badge>
                ))}
              </div>
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold mb-4 flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-red-600" />
                Missing Keywords
              </h4>
              <div className="flex flex-wrap gap-2">
                {analysis.keywordMatches?.missing?.map((keyword: string, idx: number) => (
                  <Badge key={idx} variant="destructive">{keyword}</Badge>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="skills" className="space-y-4">
            <Card className="p-6">
              <h4 className="font-semibold mb-4">Your Skills</h4>
              <div className="flex flex-wrap gap-2 mb-4">
                {analysis.skillsGap?.hasSkills?.map((skill: string, idx: number) => (
                  <Badge key={idx} className="bg-green-600">{skill}</Badge>
                ))}
              </div>
              
              <h4 className="font-semibold mb-4 mt-6">Missing Skills</h4>
              <div className="flex flex-wrap gap-2 mb-4">
                {analysis.skillsGap?.missingSkills?.map((skill: string, idx: number) => (
                  <Badge key={idx} variant="destructive">{skill}</Badge>
                ))}
              </div>

              <h4 className="font-semibold mb-3 mt-6">Recommendations</h4>
              <div className="space-y-2">
                {analysis.skillsGap?.recommendations?.map((rec: string, idx: number) => (
                  <div key={idx} className="flex items-start gap-2 text-sm">
                    <TrendingUp className="w-4 h-4 text-blue-600 mt-0.5 flex-shrink-0" />
                    <span>{rec}</span>
                  </div>
                ))}
              </div>
            </Card>
          </TabsContent>

          <TabsContent value="comparison" className="space-y-6">
            <div className="flex justify-end gap-3 mb-4">
              <Button 
                onClick={() => setShowExportModal(true)}
                variant="outline"
                disabled={!analysis?.optimizedContent}
              >
                <Download className="w-4 h-4 mr-2" />
                Export Resume
              </Button>
              <Button 
                onClick={() => setShowBulkExportModal(true)}
                variant="outline"
                disabled={!analysis?.optimizedContent}
              >
                <FileDown className="w-4 h-4 mr-2" />
                Bulk Export
              </Button>
              <Button 
                onClick={() => setShowBulkApplyModal(true)}
                className="bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700"
              >
                <Wand2 className="w-4 h-4 mr-2" />
                Apply All Suggestions
              </Button>
            </div>


            <Card className="p-6">
              <h4 className="font-semibold mb-4">Summary</h4>
              <ResumeComparisonView
                original={resumeData}
                optimized={analysis.optimizedContent}
                section="summary"
                onApplyChanges={handleApplyChanges}
                onUndo={handleUndo}
                appliedSections={appliedSections}
              />
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold mb-4">Experience</h4>
              <ResumeComparisonView
                original={resumeData}
                optimized={analysis.optimizedContent}
                section="experience"
                onApplyChanges={handleApplyChanges}
                onUndo={handleUndo}
                appliedSections={appliedSections}
              />
            </Card>

            <Card className="p-6">
              <h4 className="font-semibold mb-4">Skills</h4>
              <ResumeComparisonView
                original={resumeData}
                optimized={analysis.optimizedContent}
                section="skills"
                onApplyChanges={handleApplyChanges}
                onUndo={handleUndo}
                appliedSections={appliedSections}
              />
            </Card>
          </TabsContent>
        </Tabs>
      )}

      <BulkApplyModal
        open={showBulkApplyModal}
        onOpenChange={setShowBulkApplyModal}
        optimizedData={analysis?.optimizedContent}
        originalData={resumeData}
        onApply={handleBulkApply}
      />

      <OptimizedResumeExportModal
        open={showExportModal}
        onClose={() => setShowExportModal(false)}
        optimizedData={analysis?.optimizedContent}
        onExport={handleExport}
      />

      <BulkResumeExportModal
        open={showBulkExportModal}
        onClose={() => setShowBulkExportModal(false)}
        optimizedData={analysis?.optimizedContent}
        onBulkExport={handleBulkExport}
      />
    </div>
  );
}
