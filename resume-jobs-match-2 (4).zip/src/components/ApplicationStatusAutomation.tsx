import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Settings, Clock, Mail, Bell } from 'lucide-react';
import { toast } from 'sonner';

interface AutomationRule {
  id: string;
  name: string;
  trigger_status: string;
  action_type: 'send_email' | 'update_status' | 'create_reminder' | 'schedule_followup';
  action_config: any;
  delay_days: number;
  is_active: boolean;
}

export default function ApplicationStatusAutomation() {
  const { user } = useAuth();
  const [rules, setRules] = useState<AutomationRule[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddRule, setShowAddRule] = useState(false);
  const [newRule, setNewRule] = useState({
    name: '',
    trigger_status: '',
    action_type: 'send_email',
    delay_days: 0,
    is_active: true
  });

  useEffect(() => {
    if (user) {
      fetchAutomationRules();
    }
  }, [user]);

  const fetchAutomationRules = async () => {
    try {
      const { data, error } = await supabase
        .from('application_automation_rules')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      setRules(data || []);
    } catch (error) {
      toast.error('Failed to fetch automation rules');
    } finally {
      setLoading(false);
    }
  };

  const createAutomationRule = async () => {
    try {
      const { error } = await supabase
        .from('application_automation_rules')
        .insert([{
          ...newRule,
          user_id: user?.id,
          action_config: getDefaultActionConfig(newRule.action_type)
        }]);

      if (error) throw error;
      
      toast.success('Automation rule created');
      setShowAddRule(false);
      setNewRule({
        name: '',
        trigger_status: '',
        action_type: 'send_email',
        delay_days: 0,
        is_active: true
      });
      fetchAutomationRules();
    } catch (error) {
      toast.error('Failed to create automation rule');
    }
  };

  const toggleRuleStatus = async (ruleId: string, isActive: boolean) => {
    try {
      const { error } = await supabase
        .from('application_automation_rules')
        .update({ is_active: isActive })
        .eq('id', ruleId);

      if (error) throw error;
      
      toast.success(`Rule ${isActive ? 'activated' : 'deactivated'}`);
      fetchAutomationRules();
    } catch (error) {
      toast.error('Failed to update rule status');
    }
  };

  const getDefaultActionConfig = (actionType: string) => {
    switch (actionType) {
      case 'send_email':
        return { template: 'follow_up', subject: 'Following up on my application' };
      case 'update_status':
        return { new_status: 'reviewing' };
      case 'create_reminder':
        return { reminder_text: 'Follow up on application' };
      case 'schedule_followup':
        return { followup_days: 7 };
      default:
        return {};
    }
  };

  const getActionIcon = (actionType: string) => {
    switch (actionType) {
      case 'send_email': return <Mail className="h-4 w-4" />;
      case 'update_status': return <Settings className="h-4 w-4" />;
      case 'create_reminder': return <Bell className="h-4 w-4" />;
      case 'schedule_followup': return <Clock className="h-4 w-4" />;
      default: return <Zap className="h-4 w-4" />;
    }
  };

  if (loading) {
    return <div className="flex justify-center items-center h-32">Loading automation rules...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="h-5 w-5" />
            Application Automation
          </div>
          <Button onClick={() => setShowAddRule(!showAddRule)} size="sm">
            Add Rule
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent>
        {showAddRule && (
          <Card className="mb-6">
            <CardContent className="p-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Rule Name</Label>
                  <Input
                    value={newRule.name}
                    onChange={(e) => setNewRule({ ...newRule, name: e.target.value })}
                    placeholder="Follow up after submission"
                  />
                </div>
                <div>
                  <Label>Trigger Status</Label>
                  <Select value={newRule.trigger_status} onValueChange={(value) => setNewRule({ ...newRule, trigger_status: value })}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="submitted">Submitted</SelectItem>
                      <SelectItem value="reviewing">Under Review</SelectItem>
                      <SelectItem value="interview">Interview</SelectItem>
                      <SelectItem value="rejected">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Action Type</Label>
                  <Select value={newRule.action_type} onValueChange={(value: any) => setNewRule({ ...newRule, action_type: value })}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="send_email">Send Follow-up Email</SelectItem>
                      <SelectItem value="create_reminder">Create Reminder</SelectItem>
                      <SelectItem value="schedule_followup">Schedule Follow-up</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Delay (days)</Label>
                  <Input
                    type="number"
                    value={newRule.delay_days}
                    onChange={(e) => setNewRule({ ...newRule, delay_days: parseInt(e.target.value) || 0 })}
                    min="0"
                  />
                </div>
              </div>
              <div className="flex justify-end gap-2 mt-4">
                <Button variant="outline" onClick={() => setShowAddRule(false)}>Cancel</Button>
                <Button onClick={createAutomationRule}>Create Rule</Button>
              </div>
            </CardContent>
          </Card>
        )}

        <div className="space-y-4">
          {rules.length === 0 ? (
            <p className="text-gray-500 text-center py-4">No automation rules configured</p>
          ) : (
            rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3">
                  {getActionIcon(rule.action_type)}
                  <div>
                    <h4 className="font-medium">{rule.name}</h4>
                    <p className="text-sm text-gray-600">
                      When status becomes "{rule.trigger_status}" → {rule.action_type.replace('_', ' ')}
                      {rule.delay_days > 0 && ` (after ${rule.delay_days} days)`}
                    </p>
                  </div>
                </div>
                <Switch
                  checked={rule.is_active}
                  onCheckedChange={(checked) => toggleRuleStatus(rule.id, checked)}
                />
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}