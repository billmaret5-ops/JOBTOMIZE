import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TestTube, Play, Pause, CheckCircle, BarChart3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import EmailABTestCreator from './EmailABTestCreator';
import EmailABTestResults from './EmailABTestResults';

interface Test {
  id: string;
  test_name: string;
  test_type: string;
  status: 'active' | 'paused' | 'completed';
  confidence_level: number;
  sample_size: number;
  start_date: string;
  variants: any[];
}

export default function EmailABTestDashboard() {
  const { toast } = useToast();
  const [tests, setTests] = useState<Test[]>([]);
  const [selectedTest, setSelectedTest] = useState<Test | null>(null);
  const [loading, setLoading] = useState(true);
  const [stats, setStats] = useState({
    activeTests: 0,
    completedTests: 0,
    avgConfidence: 0,
    totalSends: 0
  });

  useEffect(() => {
    loadTests();
  }, []);

  const loadTests = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const { data: testsData, error } = await supabase
        .from('email_ab_tests')
        .select(`
          *,
          variants:email_test_variants(*)
        `)
        .eq('user_id', user.id)
        .order('created_at', { ascending: false });

      if (error) throw error;

      const testsWithStats = testsData?.map(test => ({
        ...test,
        variants: test.variants.map((v: any) => ({
          id: v.id,
          name: v.variant_name,
          sends: v.sends_count,
          opens: v.opens_count,
          clicks: v.clicks_count,
          replies: v.replies_count,
          openRate: v.open_rate,
          clickRate: v.click_rate,
          replyRate: v.reply_rate
        }))
      })) || [];

      setTests(testsWithStats);

      const activeTests = testsWithStats.filter(t => t.status === 'active').length;
      const completedTests = testsWithStats.filter(t => t.status === 'completed').length;
      const avgConfidence = testsWithStats.reduce((sum, t) => sum + (t.confidence_level || 0), 0) / testsWithStats.length || 0;
      const totalSends = testsWithStats.reduce((sum, t) => sum + t.sample_size, 0);

      setStats({ activeTests, completedTests, avgConfidence, totalSends });
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const toggleTestStatus = async (testId: string, currentStatus: string) => {
    try {
      const newStatus = currentStatus === 'active' ? 'paused' : 'active';
      const { error } = await supabase
        .from('email_ab_tests')
        .update({ status: newStatus })
        .eq('id', testId);

      if (error) throw error;
      toast({ title: 'Success', description: `Test ${newStatus}` });
      loadTests();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  const completeTest = async (testId: string) => {
    try {
      const { error } = await supabase
        .from('email_ab_tests')
        .update({ status: 'completed', end_date: new Date().toISOString() })
        .eq('id', testId);

      if (error) throw error;
      toast({ title: 'Success', description: 'Test completed' });
      loadTests();
    } catch (error: any) {
      toast({ title: 'Error', description: error.message, variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Tests</p>
                <p className="text-2xl font-bold">{stats.activeTests}</p>
              </div>
              <Play className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Completed</p>
                <p className="text-2xl font-bold">{stats.completedTests}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Confidence</p>
                <p className="text-2xl font-bold">{stats.avgConfidence.toFixed(0)}%</p>
              </div>
              <BarChart3 className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Sends</p>
                <p className="text-2xl font-bold">{stats.totalSends}</p>
              </div>
              <TestTube className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="tests">
        <TabsList>
          <TabsTrigger value="tests">All Tests</TabsTrigger>
          <TabsTrigger value="create">Create Test</TabsTrigger>
        </TabsList>

        <TabsContent value="tests" className="space-y-4">
          {tests.map(test => (
            <Card key={test.id}>
              <CardHeader>
                <div className="flex justify-between items-start">
                  <div>
                    <CardTitle className="flex items-center gap-2">
                      {test.test_name}
                      <Badge variant="outline">{test.test_type.replace('_', ' ')}</Badge>
                    </CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      {test.sample_size} emails sent • Started {new Date(test.start_date).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex gap-2">
                    {test.status !== 'completed' && (
                      <>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => toggleTestStatus(test.id, test.status)}
                        >
                          {test.status === 'active' ? <Pause className="h-4 w-4" /> : <Play className="h-4 w-4" />}
                        </Button>
                        <Button
                          size="sm"
                          onClick={() => completeTest(test.id)}
                        >
                          Complete
                        </Button>
                      </>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <EmailABTestResults
                  testName={test.test_name}
                  variants={test.variants}
                  confidenceLevel={test.confidence_level}
                  status={test.status}
                />
              </CardContent>
            </Card>
          ))}

          {tests.length === 0 && !loading && (
            <Card>
              <CardContent className="py-12 text-center">
                <TestTube className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">No A/B tests yet. Create one to get started!</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="create">
          <EmailABTestCreator onTestCreated={loadTests} />
        </TabsContent>
      </Tabs>
    </div>
  );
}