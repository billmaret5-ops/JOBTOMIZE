import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Activity, AlertTriangle, CheckCircle, XCircle, Clock } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface HealthMetrics {
  totalBackups: number;
  successfulBackups: number;
  failedBackups: number;
  retryingBackups: number;
  averageHealthScore: number;
  storageUsedPercentage: number;
}

export default function BackupHealthWidget() {
  const [metrics, setMetrics] = useState<HealthMetrics>({
    totalBackups: 0,
    successfulBackups: 0,
    failedBackups: 0,
    retryingBackups: 0,
    averageHealthScore: 100,
    storageUsedPercentage: 0
  });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHealthMetrics();
    const interval = setInterval(loadHealthMetrics, 30000);
    return () => clearInterval(interval);
  }, []);

  const loadHealthMetrics = async () => {
    try {
      const { data: monitoring } = await supabase
        .from('backup_monitoring')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100);

      if (monitoring) {
        const successful = monitoring.filter(m => m.status === 'completed').length;
        const failed = monitoring.filter(m => m.status === 'failed').length;
        const retrying = monitoring.filter(m => m.status === 'retrying').length;
        const avgHealth = monitoring.reduce((sum, m) => sum + (m.health_score || 0), 0) / monitoring.length || 100;

        setMetrics({
          totalBackups: monitoring.length,
          successfulBackups: successful,
          failedBackups: failed,
          retryingBackups: retrying,
          averageHealthScore: Math.round(avgHealth),
          storageUsedPercentage: monitoring[0]?.storage_percentage || 0
        });
      }
    } catch (error) {
      console.error('Failed to load health metrics:', error);
    } finally {
      setLoading(false);
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getStorageColor = (percentage: number) => {
    if (percentage >= 95) return 'bg-red-600';
    if (percentage >= 80) return 'bg-yellow-600';
    return 'bg-green-600';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="h-5 w-5" />
          Backup Health Status
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="grid grid-cols-2 gap-4">
          <div className="flex items-center gap-2">
            <CheckCircle className="h-4 w-4 text-green-600" />
            <div>
              <p className="text-2xl font-bold">{metrics.successfulBackups}</p>
              <p className="text-sm text-muted-foreground">Successful</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <XCircle className="h-4 w-4 text-red-600" />
            <div>
              <p className="text-2xl font-bold">{metrics.failedBackups}</p>
              <p className="text-sm text-muted-foreground">Failed</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Clock className="h-4 w-4 text-yellow-600" />
            <div>
              <p className="text-2xl font-bold">{metrics.retryingBackups}</p>
              <p className="text-sm text-muted-foreground">Retrying</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Activity className={`h-4 w-4 ${getHealthColor(metrics.averageHealthScore)}`} />
            <div>
              <p className="text-2xl font-bold">{metrics.averageHealthScore}%</p>
              <p className="text-sm text-muted-foreground">Health Score</p>
            </div>
          </div>
        </div>

        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span>Storage Usage</span>
            <span className="font-medium">{metrics.storageUsedPercentage.toFixed(1)}%</span>
          </div>
          <Progress value={metrics.storageUsedPercentage} className={getStorageColor(metrics.storageUsedPercentage)} />
          {metrics.storageUsedPercentage >= 80 && (
            <div className="flex items-center gap-2 text-sm text-yellow-600">
              <AlertTriangle className="h-4 w-4" />
              <span>Storage quota warning</span>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}
