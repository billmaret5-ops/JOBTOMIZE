import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Mail, MousePointer, Target, AlertTriangle, Zap } from 'lucide-react';

export const AdvancedEmailAnalytics = () => {
  const [selectedCampaign, setSelectedCampaign] = useState('all');
  
  const campaignMetrics = {
    totalSent: 125000,
    delivered: 122500,
    opens: 30625,
    clicks: 4900,
    conversions: 2450,
    bounces: 2500,
    unsubscribes: 125,
    openRate: 25.0,
    clickRate: 4.0,
    conversionRate: 2.0,
    bounceRate: 2.0
  };

  const performanceData = [
    { date: '2024-01-01', opens: 2200, clicks: 350, conversions: 175, bounces: 45 },
    { date: '2024-01-02', opens: 2350, clicks: 380, conversions: 190, bounces: 38 },
    { date: '2024-01-03', opens: 2420, clicks: 390, conversions: 195, bounces: 42 },
    { date: '2024-01-04', opens: 2510, clicks: 410, conversions: 205, bounces: 35 },
    { date: '2024-01-05', opens: 2480, clicks: 400, conversions: 200, bounces: 40 }
  ];

  const abTestResults = [
    {
      id: 1,
      name: 'Subject Line Test',
      status: 'completed',
      winner: 'Variant B',
      confidence: 95,
      variants: [
        { name: 'A', openRate: 22.5, clickRate: 3.2, conversions: 180 },
        { name: 'B', openRate: 28.1, clickRate: 4.8, conversions: 240 }
      ]
    }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Advanced Email Analytics</h1>
          <p className="text-muted-foreground">Comprehensive campaign performance tracking</p>
        </div>
        <Button className="flex items-center gap-2">
          <Zap className="h-4 w-4" />
          Auto-Optimize
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Open Rate</p>
                <p className="text-2xl font-bold">{campaignMetrics.openRate}%</p>
              </div>
              <Mail className="h-8 w-8 text-blue-500" />
            </div>
            <Progress value={campaignMetrics.openRate} className="mt-2" />
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Click Rate</p>
                <p className="text-2xl font-bold">{campaignMetrics.clickRate}%</p>
              </div>
              <MousePointer className="h-8 w-8 text-green-500" />
            </div>
            <Progress value={campaignMetrics.clickRate * 5} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Conversion Rate</p>
                <p className="text-2xl font-bold">{campaignMetrics.conversionRate}%</p>
              </div>
              <Target className="h-8 w-8 text-purple-500" />
            </div>
            <Progress value={campaignMetrics.conversionRate * 10} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Bounce Rate</p>
                <p className="text-2xl font-bold">{campaignMetrics.bounceRate}%</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-500" />
            </div>
            <Progress value={campaignMetrics.bounceRate * 10} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="abtests">A/B Tests</TabsTrigger>
          <TabsTrigger value="heatmaps">Heatmaps</TabsTrigger>
          <TabsTrigger value="funnels">Funnels</TabsTrigger>
        </TabsList>

        <TabsContent value="performance">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="opens" stroke="#3b82f6" strokeWidth={2} />
                  <Line type="monotone" dataKey="clicks" stroke="#10b981" strokeWidth={2} />
                  <Line type="monotone" dataKey="conversions" stroke="#8b5cf6" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="abtests">
          <div className="space-y-4">
            {abTestResults.map((test) => (
              <Card key={test.id}>
                <CardHeader>
                  <div className="flex justify-between items-center">
                    <CardTitle>{test.name}</CardTitle>
                    <Badge variant={test.status === 'completed' ? 'default' : 'secondary'}>
                      {test.status}
                    </Badge>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    {test.variants.map((variant) => (
                      <div key={variant.name} className="p-4 border rounded-lg">
                        <h4 className="font-semibold mb-2">Variant {variant.name}</h4>
                        <div className="space-y-2">
                          <div className="flex justify-between">
                            <span>Open Rate:</span>
                            <span className="font-medium">{variant.openRate}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Click Rate:</span>
                            <span className="font-medium">{variant.clickRate}%</span>
                          </div>
                          <div className="flex justify-between">
                            <span>Conversions:</span>
                            <span className="font-medium">{variant.conversions}</span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  {test.winner && (
                    <div className="mt-4 p-3 bg-green-50 border border-green-200 rounded-lg">
                      <p className="text-green-800">
                        <strong>Winner:</strong> {test.winner} ({test.confidence}% confidence)
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="heatmaps">
          <Card>
            <CardHeader>
              <CardTitle>Email Interaction Heatmap</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <TrendingUp className="h-12 w-12 text-muted-foreground mx-auto mb-4" />
                <p className="text-muted-foreground">Heatmap visualization coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="funnels">
          <Card>
            <CardHeader>
              <CardTitle>Email Conversion Funnel</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-blue-50 rounded-lg">
                  <span>Emails Sent</span>
                  <span className="font-bold">{campaignMetrics.totalSent.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-green-50 rounded-lg">
                  <span>Emails Opened</span>
                  <span className="font-bold">{campaignMetrics.opens.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-purple-50 rounded-lg">
                  <span>Links Clicked</span>
                  <span className="font-bold">{campaignMetrics.clicks.toLocaleString()}</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-orange-50 rounded-lg">
                  <span>Conversions</span>
                  <span className="font-bold">{campaignMetrics.conversions.toLocaleString()}</span>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};