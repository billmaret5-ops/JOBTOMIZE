import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Search, Filter, Download, TrendingUp, BarChart3, PieChart } from 'lucide-react';

interface DataPoint {
  id: string;
  category: string;
  value: number;
  date: string;
  region: string;
  status: string;
}

export const DataExplorationTool: React.FC = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilters, setSelectedFilters] = useState<string[]>([]);
  const [drillDownPath, setDrillDownPath] = useState<string[]>(['All Data']);

  const sampleData: DataPoint[] = [
    { id: '1', category: 'Sales', value: 15420, date: '2024-01-15', region: 'North', status: 'Active' },
    { id: '2', category: 'Marketing', value: 8750, date: '2024-01-15', region: 'South', status: 'Active' },
    { id: '3', category: 'Support', value: 3200, date: '2024-01-15', region: 'East', status: 'Pending' },
    { id: '4', category: 'Sales', value: 22100, date: '2024-01-16', region: 'West', status: 'Active' },
    { id: '5', category: 'Marketing', value: 12300, date: '2024-01-16', region: 'North', status: 'Complete' }
  ];

  const metrics = [
    { label: 'Total Records', value: '1,234', change: '+12%' },
    { label: 'Avg Value', value: '$12,354', change: '+5.2%' },
    { label: 'Categories', value: '8', change: '0%' },
    { label: 'Active Items', value: '892', change: '+8.1%' }
  ];

  const categories = ['Sales', 'Marketing', 'Support', 'Operations'];
  const regions = ['North', 'South', 'East', 'West'];

  const drillDown = (dimension: string, value: string) => {
    setDrillDownPath([...drillDownPath, `${dimension}: ${value}`]);
  };

  const navigateUp = (index: number) => {
    setDrillDownPath(drillDownPath.slice(0, index + 1));
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="h-5 w-5" />
          Data Exploration Tool
        </CardTitle>
        <div className="flex items-center gap-2 text-sm text-muted-foreground">
          {drillDownPath.map((path, index) => (
            <React.Fragment key={index}>
              <button
                onClick={() => navigateUp(index)}
                className="hover:text-foreground cursor-pointer"
              >
                {path}
              </button>
              {index < drillDownPath.length - 1 && <span>/</span>}
            </React.Fragment>
          ))}
        </div>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="explore" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="explore">Data Explorer</TabsTrigger>
            <TabsTrigger value="metrics">Custom Metrics</TabsTrigger>
            <TabsTrigger value="visualize">Visualizations</TabsTrigger>
          </TabsList>

          <TabsContent value="explore" className="space-y-4">
            <div className="flex items-center gap-4">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                <Input
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search data..."
                  className="pl-10"
                />
              </div>
              <Button variant="outline">
                <Filter className="h-4 w-4 mr-2" />
                Filters
              </Button>
              <Button variant="outline">
                <Download className="h-4 w-4 mr-2" />
                Export
              </Button>
            </div>

            <div className="grid grid-cols-4 gap-4">
              {metrics.map(metric => (
                <Card key={metric.label}>
                  <CardContent className="pt-4">
                    <div className="text-2xl font-bold">{metric.value}</div>
                    <p className="text-sm text-muted-foreground">{metric.label}</p>
                    <Badge variant={metric.change.startsWith('+') ? 'default' : 'destructive'} className="mt-1">
                      {metric.change}
                    </Badge>
                  </CardContent>
                </Card>
              ))}
            </div>

            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Category</TableHead>
                  <TableHead>Value</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Region</TableHead>
                  <TableHead>Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {sampleData.map(item => (
                  <TableRow key={item.id}>
                    <TableCell>
                      <button
                        onClick={() => drillDown('Category', item.category)}
                        className="text-blue-600 hover:underline"
                      >
                        {item.category}
                      </button>
                    </TableCell>
                    <TableCell>${item.value.toLocaleString()}</TableCell>
                    <TableCell>{item.date}</TableCell>
                    <TableCell>
                      <button
                        onClick={() => drillDown('Region', item.region)}
                        className="text-blue-600 hover:underline"
                      >
                        {item.region}
                      </button>
                    </TableCell>
                    <TableCell>
                      <Badge variant={item.status === 'Active' ? 'default' : 'secondary'}>
                        {item.status}
                      </Badge>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </TabsContent>

          <TabsContent value="metrics" className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Custom Calculation</CardTitle>
                </CardHeader>
                <CardContent>
                  <Input placeholder="SUM(value) / COUNT(*)" />
                  <Button className="mt-2 w-full" size="sm">Calculate</Button>
                </CardContent>
              </Card>
              
              <Card>
                <CardHeader>
                  <CardTitle className="text-sm">Result</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">$12,354</div>
                  <p className="text-sm text-muted-foreground">Average per record</p>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="visualize" className="space-y-4">
            <div className="grid grid-cols-3 gap-4">
              <Button variant="outline" className="h-20 flex flex-col gap-2">
                <BarChart3 className="h-6 w-6" />
                <span className="text-sm">Bar Chart</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col gap-2">
                <TrendingUp className="h-6 w-6" />
                <span className="text-sm">Line Chart</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col gap-2">
                <PieChart className="h-6 w-6" />
                <span className="text-sm">Pie Chart</span>
              </Button>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};