import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Search, Plus, TrendingUp } from 'lucide-react';
import { ATSKeywordAnalysis } from '@/services/aiTemplateOptimizationService';

interface Props {
  analysis: ATSKeywordAnalysis;
  onAddKeyword?: (keyword: string) => void;
}

export const ATSKeywordOptimizer: React.FC<Props> = ({ analysis, onAddKeyword }) => {
  const getScoreColor = () => {
    if (analysis.score > 70) return 'bg-green-500';
    if (analysis.score > 50) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Search className="w-5 h-5" />
          ATS Keyword Optimization
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <div className="flex justify-between mb-2">
            <span className="text-sm font-medium">ATS Compatibility Score</span>
            <Badge variant={analysis.score > 70 ? 'default' : 'secondary'}>
              {analysis.score.toFixed(0)}%
            </Badge>
          </div>
          <Progress value={analysis.score} className={getScoreColor()} />
          <p className="text-xs text-muted-foreground mt-1">
            {analysis.foundKeywords.length} of {analysis.foundKeywords.length + analysis.missingKeywords.length} recommended keywords found
          </p>
        </div>

        <div>
          <h4 className="text-sm font-semibold mb-2 flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-green-500" />
            Found Keywords ({analysis.foundKeywords.length})
          </h4>
          <div className="flex flex-wrap gap-2">
            {analysis.foundKeywords.map((keyword) => (
              <Badge key={keyword} variant="default" className="bg-green-100 text-green-800">
                {keyword}
                <span className="ml-1 text-xs">({analysis.keywordDensity[keyword] || 1}x)</span>
              </Badge>
            ))}
          </div>
        </div>

        {analysis.missingKeywords.length > 0 && (
          <div>
            <h4 className="text-sm font-semibold mb-2 text-orange-600">
              Missing Keywords ({analysis.missingKeywords.length})
            </h4>
            <div className="flex flex-wrap gap-2">
              {analysis.missingKeywords.map((keyword) => (
                <Badge 
                  key={keyword} 
                  variant="outline" 
                  className="cursor-pointer hover:bg-orange-50"
                  onClick={() => onAddKeyword?.(keyword)}
                >
                  {keyword}
                  <Plus className="w-3 h-3 ml-1" />
                </Badge>
              ))}
            </div>
          </div>
        )}

        {analysis.suggestions.length > 0 && (
          <div className="bg-orange-50 p-3 rounded-lg space-y-2">
            <h4 className="text-sm font-semibold text-orange-900">Optimization Tips</h4>
            <ul className="space-y-1">
              {analysis.suggestions.map((suggestion, index) => (
                <li key={index} className="text-sm text-orange-800 flex items-start gap-2">
                  <span>•</span>
                  {suggestion}
                </li>
              ))}
            </ul>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
