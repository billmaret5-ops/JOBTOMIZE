import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { TrendingUp, Clock, Calendar, MousePointer, Eye } from 'lucide-react';

interface HeatmapData {
  hour: number;
  day: number;
  opens: number;
  clicks: number;
  responses: number;
}

export default function EmailAnalyticsHeatmap() {
  const [selectedMetric, setSelectedMetric] = useState<'opens' | 'clicks' | 'responses'>('opens');
  
  // Generate sample heatmap data
  const heatmapData: HeatmapData[] = [];
  for (let day = 0; day < 7; day++) {
    for (let hour = 0; hour < 24; hour++) {
      heatmapData.push({
        hour,
        day,
        opens: Math.floor(Math.random() * 20) + 1,
        clicks: Math.floor(Math.random() * 10) + 1,
        responses: Math.floor(Math.random() * 5) + 1
      });
    }
  }

  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const hours = Array.from({ length: 24 }, (_, i) => i);

  const getIntensity = (value: number, metric: string) => {
    const maxValues = { opens: 20, clicks: 10, responses: 5 };
    const intensity = value / maxValues[metric as keyof typeof maxValues];
    return Math.min(intensity, 1);
  };

  const getHeatmapColor = (intensity: number) => {
    if (intensity < 0.2) return 'bg-blue-100';
    if (intensity < 0.4) return 'bg-blue-200';
    if (intensity < 0.6) return 'bg-blue-300';
    if (intensity < 0.8) return 'bg-blue-400';
    return 'bg-blue-500';
  };

  const bestTimes = [
    { time: '9:00 AM', day: 'Tuesday', metric: 'Opens', value: '85%' },
    { time: '2:00 PM', day: 'Wednesday', metric: 'Clicks', value: '12%' },
    { time: '11:00 AM', day: 'Thursday', metric: 'Responses', value: '8%' }
  ];

  const insights = [
    'Tuesday mornings show highest open rates',
    'Avoid sending emails on weekends',
    'Afternoon emails get more clicks',
    'Thursday is best for follow-ups'
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Email Engagement Heatmap</h2>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">Last 30 Days</Button>
          <Button variant="outline" size="sm">Export Data</Button>
        </div>
      </div>

      <Tabs value={selectedMetric} onValueChange={(value) => setSelectedMetric(value as any)}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="opens" className="flex items-center gap-2">
            <Eye className="h-4 w-4" />
            Opens
          </TabsTrigger>
          <TabsTrigger value="clicks" className="flex items-center gap-2">
            <MousePointer className="h-4 w-4" />
            Clicks
          </TabsTrigger>
          <TabsTrigger value="responses" className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4" />
            Responses
          </TabsTrigger>
        </TabsList>

        <TabsContent value={selectedMetric} className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Weekly {selectedMetric.charAt(0).toUpperCase() + selectedMetric.slice(1)} Heatmap
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {/* Heatmap Grid */}
                <div className="overflow-x-auto">
                  <div className="grid grid-cols-25 gap-1 min-w-max">
                    {/* Header row */}
                    <div></div>
                    {hours.map(hour => (
                      <div key={hour} className="text-xs text-center p-1 font-medium">
                        {hour}
                      </div>
                    ))}
                    
                    {/* Data rows */}
                    {days.map((day, dayIndex) => (
                      <React.Fragment key={day}>
                        <div className="text-xs font-medium p-2 flex items-center">
                          {day}
                        </div>
                        {hours.map(hour => {
                          const data = heatmapData.find(d => d.day === dayIndex && d.hour === hour);
                          const value = data ? data[selectedMetric] : 0;
                          const intensity = getIntensity(value, selectedMetric);
                          return (
                            <div
                              key={`${dayIndex}-${hour}`}
                              className={`w-8 h-8 rounded ${getHeatmapColor(intensity)} flex items-center justify-center text-xs font-medium cursor-pointer hover:scale-110 transition-transform`}
                              title={`${day} ${hour}:00 - ${value} ${selectedMetric}`}
                            >
                              {value > 0 ? value : ''}
                            </div>
                          );
                        })}
                      </React.Fragment>
                    ))}
                  </div>
                </div>

                {/* Legend */}
                <div className="flex items-center gap-4 text-sm">
                  <span>Less</span>
                  <div className="flex gap-1">
                    {[0.1, 0.3, 0.5, 0.7, 0.9].map(intensity => (
                      <div
                        key={intensity}
                        className={`w-4 h-4 rounded ${getHeatmapColor(intensity)}`}
                      ></div>
                    ))}
                  </div>
                  <span>More</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Best Times */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Clock className="h-5 w-5" />
                Optimal Send Times
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-3">
                {bestTimes.map((time, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <Badge variant="outline">{time.metric}</Badge>
                      <span className="font-bold text-lg">{time.value}</span>
                    </div>
                    <p className="font-semibold">{time.time}</p>
                    <p className="text-sm text-gray-600">{time.day}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Insights */}
          <Card>
            <CardHeader>
              <CardTitle>Key Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2">
                {insights.map((insight, index) => (
                  <li key={index} className="flex items-center gap-2">
                    <TrendingUp className="h-4 w-4 text-blue-500" />
                    <span className="text-sm">{insight}</span>
                  </li>
                ))}
              </ul>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}