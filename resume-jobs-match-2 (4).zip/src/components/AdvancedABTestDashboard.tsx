import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ABTestComparisonChart } from '@/components/analytics/ABTestComparisonChart';
import { StatisticalSignificanceChart } from '@/components/analytics/StatisticalSignificanceChart';
import { abTestStatisticsService } from '@/services/abTestStatisticsService';
import { supabase } from '@/lib/supabase';
import { Trophy, RefreshCw, Download } from 'lucide-react';
import { Badge } from '@/components/ui/badge';

export function AdvancedABTestDashboard() {
  const [tests, setTests] = useState<any[]>([]);
  const [selectedTest, setSelectedTest] = useState<string>('');
  const [variants, setVariants] = useState<any[]>([]);
  const [winner, setWinner] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [selectedMetric, setSelectedMetric] = useState('conversion_rate');

  useEffect(() => {
    loadTests();
  }, []);

  useEffect(() => {
    if (selectedTest) {
      loadTestData(selectedTest);
    }
  }, [selectedTest, selectedMetric]);

  const loadTests = async () => {
    const { data } = await supabase
      .from('ab_tests')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) {
      setTests(data);
      if (data.length > 0 && !selectedTest) {
        setSelectedTest(data[0].id);
      }
    }
  };

  const loadTestData = async (testId: string) => {
    setLoading(true);
    
    const { data: variantsData } = await supabase
      .from('test_variants')
      .select('*')
      .eq('test_id', testId);

    if (variantsData) {
      const enrichedVariants = await Promise.all(
        variantsData.map(async (variant) => {
          const ci = await abTestStatisticsService.calculateConfidenceInterval(variant.id);
          return {
            ...variant,
            ...ci,
          };
        })
      );

      setVariants(enrichedVariants);

      const controlVariant = enrichedVariants.find(v => v.is_control);
      if (controlVariant && enrichedVariants.length > 1) {
        const testVariant = enrichedVariants.find(v => !v.is_control);
        if (testVariant) {
          const pValueResult = await abTestStatisticsService.calculatePValue(
            controlVariant.id,
            testVariant.id
          );
          
          if (pValueResult) {
            setVariants(prev => prev.map(v => 
              v.id === testVariant.id ? { ...v, p_value: pValueResult.p_value } : v
            ));
          }
        }
      }
    }

    const winnerData = await abTestStatisticsService.determineTestWinner(
      testId,
      selectedMetric
    );
    setWinner(winnerData);
    
    setLoading(false);
  };

  const handleRefresh = () => {
    if (selectedTest) {
      loadTestData(selectedTest);
    }
  };

  const exportResults = () => {
    const data = {
      test: tests.find(t => t.id === selectedTest),
      variants,
      winner,
      exportedAt: new Date().toISOString(),
    };
    
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ab-test-results-${selectedTest}.json`;
    a.click();
  };

  const controlVariant = variants.find(v => v.is_control);
  const testVariant = variants.find(v => !v.is_control);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">A/B Test Analytics</h1>
        <div className="flex gap-2">
          <Button onClick={handleRefresh} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
          <Button onClick={exportResults} variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <div className="flex gap-4">
        <Select value={selectedTest} onValueChange={setSelectedTest}>
          <SelectTrigger className="w-64">
            <SelectValue placeholder="Select test" />
          </SelectTrigger>
          <SelectContent>
            {tests.map(test => (
              <SelectItem key={test.id} value={test.id}>
                {test.name}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select value={selectedMetric} onValueChange={setSelectedMetric}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
            <SelectItem value="click_through_rate">Click Rate</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {winner && (
        <Card className="border-2 border-yellow-400 bg-yellow-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Trophy className="h-5 w-5 text-yellow-600" />
              Test Winner Determination
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div>
                <p className="text-sm text-muted-foreground">Winner</p>
                <p className="text-lg font-bold">{winner.winner_name}</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Metric Value</p>
                <p className="text-lg font-bold">{winner.winning_metric_value?.toFixed(2)}%</p>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Confidence</p>
                <Badge className={winner.is_conclusive ? 'bg-green-500' : 'bg-yellow-500'}>
                  {winner.confidence_level}%
                </Badge>
              </div>
              <div>
                <p className="text-sm text-muted-foreground">Status</p>
                <Badge variant={winner.is_conclusive ? 'default' : 'secondary'}>
                  {winner.is_conclusive ? 'Conclusive' : 'Inconclusive'}
                </Badge>
              </div>
            </div>
            <p className="mt-4 text-sm">{winner.recommendation}</p>
          </CardContent>
        </Card>
      )}

      <Tabs defaultValue="comparison" className="space-y-4">
        <TabsList>
          <TabsTrigger value="comparison">Comparison</TabsTrigger>
          <TabsTrigger value="statistics">Statistics</TabsTrigger>
          <TabsTrigger value="details">Details</TabsTrigger>
        </TabsList>

        <TabsContent value="comparison" className="space-y-4">
          <ABTestComparisonChart variants={variants} />
        </TabsContent>

        <TabsContent value="statistics" className="space-y-4">
          {controlVariant && testVariant && testVariant.p_value && (
            <StatisticalSignificanceChart
              pValue={testVariant.p_value}
              zScore={testVariant.z_score || 0}
              confidenceLevel={winner?.confidence_level || 95}
              improvementPercentage={
                ((testVariant.conversion_rate - controlVariant.conversion_rate) / 
                controlVariant.conversion_rate * 100) || 0
              }
              isSignificant={testVariant.p_value < 0.05}
              sampleSize={testVariant.total_impressions}
            />
          )}
        </TabsContent>

        <TabsContent value="details" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Variant Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {variants.map(variant => (
                  <div key={variant.id} className="border rounded p-4">
                    <h4 className="font-semibold mb-2">{variant.name}</h4>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <p className="text-muted-foreground">Impressions</p>
                        <p className="font-semibold">{variant.total_impressions}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Clicks</p>
                        <p className="font-semibold">{variant.total_clicks}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Conversions</p>
                        <p className="font-semibold">{variant.total_conversions}</p>
                      </div>
                      <div>
                        <p className="text-muted-foreground">Revenue</p>
                        <p className="font-semibold">${variant.total_revenue}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
