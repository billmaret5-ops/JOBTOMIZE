import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, Clock, Target, TrendingUp, Brain, AlertCircle, BookOpen } from 'lucide-react';

interface TrainingRecommendation {
  id: string;
  commandName: string;
  priority: 'high' | 'medium' | 'low';
  reason: string;
  estimatedImprovement: number;
  suggestedSessions: number;
}

interface ScheduledSession {
  id: string;
  commandId: string;
  commandName: string;
  scheduledTime: Date;
  duration: number;
  type: 'pronunciation' | 'accuracy' | 'confidence';
  status: 'scheduled' | 'completed' | 'missed';
}

interface ProgressMetrics {
  commandId: string;
  commandName: string;
  initialAccuracy: number;
  currentAccuracy: number;
  improvement: number;
  sessionsCompleted: number;
  lastTrained: Date;
}

export const AdvancedVoiceCommandProcessor: React.FC = () => {
  const [recommendations, setRecommendations] = useState<TrainingRecommendation[]>([
    {
      id: '1',
      commandName: 'replace word',
      priority: 'high',
      reason: 'Low accuracy (79.6%) with pronunciation issues',
      estimatedImprovement: 15,
      suggestedSessions: 3
    },
    {
      id: '2',
      commandName: 'search for text',
      priority: 'medium',
      reason: 'Inconsistent confidence scores',
      estimatedImprovement: 8,
      suggestedSessions: 2
    },
    {
      id: '3',
      commandName: 'create bulleted list',
      priority: 'low',
      reason: 'Minor accuracy improvements possible',
      estimatedImprovement: 4,
      suggestedSessions: 1
    }
  ]);

  const [scheduledSessions, setScheduledSessions] = useState<ScheduledSession[]>([
    {
      id: '1',
      commandId: '1',
      commandName: 'replace word',
      scheduledTime: new Date(Date.now() + 2 * 60 * 60 * 1000), // 2 hours from now
      duration: 10,
      type: 'pronunciation',
      status: 'scheduled'
    },
    {
      id: '2',
      commandId: '2',
      commandName: 'search for text',
      scheduledTime: new Date(Date.now() + 24 * 60 * 60 * 1000), // tomorrow
      duration: 8,
      type: 'confidence',
      status: 'scheduled'
    }
  ]);

  const [progressMetrics, setProgressMetrics] = useState<ProgressMetrics[]>([
    {
      commandId: '1',
      commandName: 'format as bold',
      initialAccuracy: 85.2,
      currentAccuracy: 92.3,
      improvement: 7.1,
      sessionsCompleted: 4,
      lastTrained: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000)
    },
    {
      commandId: '2',
      commandName: 'undo last change',
      initialAccuracy: 89.1,
      currentAccuracy: 95.4,
      improvement: 6.3,
      sessionsCompleted: 2,
      lastTrained: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000)
    }
  ]);

  const [autoScheduling, setAutoScheduling] = useState(true);

  const scheduleTrainingSession = (recommendation: TrainingRecommendation) => {
    const newSession: ScheduledSession = {
      id: Date.now().toString(),
      commandId: recommendation.id,
      commandName: recommendation.commandName,
      scheduledTime: new Date(Date.now() + 60 * 60 * 1000), // 1 hour from now
      duration: 10,
      type: recommendation.priority === 'high' ? 'pronunciation' : 'accuracy',
      status: 'scheduled'
    };

    setScheduledSessions(prev => [...prev, newSession]);
  };

  const completeSession = (sessionId: string) => {
    setScheduledSessions(prev => 
      prev.map(session => 
        session.id === sessionId 
          ? { ...session, status: 'completed' as const }
          : session
      )
    );

    // Update progress metrics
    const session = scheduledSessions.find(s => s.id === sessionId);
    if (session) {
      setProgressMetrics(prev => {
        const existing = prev.find(p => p.commandName === session.commandName);
        if (existing) {
          return prev.map(p => 
            p.commandName === session.commandName
              ? {
                  ...p,
                  currentAccuracy: p.currentAccuracy + Math.random() * 3 + 1,
                  improvement: p.improvement + Math.random() * 3 + 1,
                  sessionsCompleted: p.sessionsCompleted + 1,
                  lastTrained: new Date()
                }
              : p
          );
        } else {
          return [...prev, {
            commandId: session.commandId,
            commandName: session.commandName,
            initialAccuracy: 75 + Math.random() * 10,
            currentAccuracy: 80 + Math.random() * 10,
            improvement: Math.random() * 5 + 2,
            sessionsCompleted: 1,
            lastTrained: new Date()
          }];
        }
      });
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'destructive';
      case 'medium': return 'secondary';
      case 'low': return 'outline';
      default: return 'outline';
    }
  };

  const getSessionTypeIcon = (type: string) => {
    switch (type) {
      case 'pronunciation': return '🗣️';
      case 'accuracy': return '🎯';
      case 'confidence': return '💪';
      default: return '📚';
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Voice Training Intelligence</h1>
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">Auto-scheduling</span>
          <Button
            variant={autoScheduling ? "default" : "outline"}
            size="sm"
            onClick={() => setAutoScheduling(!autoScheduling)}
          >
            {autoScheduling ? 'ON' : 'OFF'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="recommendations" className="space-y-4">
        <TabsList>
          <TabsTrigger value="recommendations">AI Recommendations</TabsTrigger>
          <TabsTrigger value="schedule">Training Schedule</TabsTrigger>
          <TabsTrigger value="progress">Progress Tracking</TabsTrigger>
        </TabsList>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Brain className="h-5 w-5" />
                Personalized Training Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {recommendations.map((rec) => (
                <div key={rec.id} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span className="font-medium">{rec.commandName}</span>
                      <Badge variant={getPriorityColor(rec.priority)}>
                        {rec.priority} priority
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <TrendingUp className="h-4 w-4" />
                      +{rec.estimatedImprovement}% improvement
                    </div>
                  </div>
                  
                  <p className="text-sm text-muted-foreground">{rec.reason}</p>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm">
                      Suggested sessions: {rec.suggestedSessions}
                    </span>
                    <Button 
                      size="sm" 
                      onClick={() => scheduleTrainingSession(rec)}
                    >
                      Schedule Training
                    </Button>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Upcoming Training Sessions
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {scheduledSessions.map((session) => (
                <div key={session.id} className="p-4 border rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center gap-2">
                      <span className="text-lg">{getSessionTypeIcon(session.type)}</span>
                      <span className="font-medium">{session.commandName}</span>
                      <Badge variant={session.status === 'completed' ? 'default' : 'secondary'}>
                        {session.status}
                      </Badge>
                    </div>
                    <div className="flex items-center gap-2 text-sm text-muted-foreground">
                      <Clock className="h-4 w-4" />
                      {session.duration} min
                    </div>
                  </div>
                  
                  <div className="flex items-center justify-between">
                    <span className="text-sm text-muted-foreground">
                      {session.scheduledTime.toLocaleString()}
                    </span>
                    {session.status === 'scheduled' && (
                      <Button 
                        size="sm" 
                        onClick={() => completeSession(session.id)}
                      >
                        Start Session
                      </Button>
                    )}
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="progress" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Training Progress & Results
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {progressMetrics.map((metric) => (
                <div key={metric.commandId} className="p-4 border rounded-lg space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{metric.commandName}</span>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="h-4 w-4 text-green-500" />
                      <span className="text-green-600 font-medium">
                        +{metric.improvement.toFixed(1)}%
                      </span>
                    </div>
                  </div>
                  
                  <div className="space-y-2">
                    <div className="flex justify-between text-sm">
                      <span>Accuracy Progress</span>
                      <span>{metric.currentAccuracy.toFixed(1)}%</span>
                    </div>
                    <Progress value={metric.currentAccuracy} className="h-2" />
                  </div>
                  
                  <div className="flex justify-between text-sm text-muted-foreground">
                    <span>Sessions completed: {metric.sessionsCompleted}</span>
                    <span>Last trained: {metric.lastTrained.toLocaleDateString()}</span>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};