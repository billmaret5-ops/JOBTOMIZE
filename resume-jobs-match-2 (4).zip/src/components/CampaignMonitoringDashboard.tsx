import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { 
  Play, 
  Pause, 
  Users, 
  Mail, 
  TrendingUp, 
  Clock,
  CheckCircle,
  XCircle,
  AlertCircle 
} from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'completed' | 'draft';
  totalRecipients: number;
  emailsSent: number;
  opensCount: number;
  clicksCount: number;
  repliesCount: number;
  startDate: string;
  nextSend?: string;
}

interface CampaignMonitoringDashboardProps {
  campaigns?: Campaign[];
}

export const CampaignMonitoringDashboard: React.FC<CampaignMonitoringDashboardProps> = ({
  campaigns: initialCampaigns,
}) => {
  const [campaigns, setCampaigns] = useState<Campaign[]>(initialCampaigns || [
    {
      id: '1',
      name: 'Software Engineer Follow-up',
      status: 'active',
      totalRecipients: 150,
      emailsSent: 120,
      opensCount: 85,
      clicksCount: 32,
      repliesCount: 8,
      startDate: '2024-01-15',
      nextSend: '2024-01-18T10:00:00Z',
    },
    {
      id: '2',
      name: 'Interview Thank You Sequence',
      status: 'active',
      totalRecipients: 75,
      emailsSent: 75,
      opensCount: 68,
      clicksCount: 25,
      repliesCount: 12,
      startDate: '2024-01-10',
      nextSend: '2024-01-19T14:00:00Z',
    },
    {
      id: '3',
      name: 'Cold Outreach - Tech Companies',
      status: 'paused',
      totalRecipients: 200,
      emailsSent: 45,
      opensCount: 28,
      clicksCount: 12,
      repliesCount: 3,
      startDate: '2024-01-12',
    },
  ]);

  const [realTimeData, setRealTimeData] = useState({
    totalEmailsSent: 0,
    totalOpens: 0,
    totalClicks: 0,
    totalReplies: 0,
  });

  useEffect(() => {
    // Simulate real-time updates
    const interval = setInterval(() => {
      const totals = campaigns.reduce((acc, campaign) => ({
        totalEmailsSent: acc.totalEmailsSent + campaign.emailsSent,
        totalOpens: acc.totalOpens + campaign.opensCount,
        totalClicks: acc.totalClicks + campaign.clicksCount,
        totalReplies: acc.totalReplies + campaign.repliesCount,
      }), { totalEmailsSent: 0, totalOpens: 0, totalClicks: 0, totalReplies: 0 });
      
      setRealTimeData(totals);
    }, 2000);

    return () => clearInterval(interval);
  }, [campaigns]);

  const toggleCampaignStatus = (id: string) => {
    setCampaigns(prev => prev.map(campaign => 
      campaign.id === id 
        ? { ...campaign, status: campaign.status === 'active' ? 'paused' : 'active' }
        : campaign
    ));
  };

  const getStatusIcon = (status: Campaign['status']) => {
    switch (status) {
      case 'active': return <Play className="w-4 h-4 text-green-600" />;
      case 'paused': return <Pause className="w-4 h-4 text-yellow-600" />;
      case 'completed': return <CheckCircle className="w-4 h-4 text-blue-600" />;
      case 'draft': return <AlertCircle className="w-4 h-4 text-gray-600" />;
      default: return null;
    }
  };

  const getStatusColor = (status: Campaign['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      {/* Real-time Overview Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Emails Sent</p>
                <p className="text-2xl font-bold">{realTimeData.totalEmailsSent}</p>
              </div>
              <Mail className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Opens</p>
                <p className="text-2xl font-bold">{realTimeData.totalOpens}</p>
                <p className="text-xs text-green-600">
                  {realTimeData.totalEmailsSent > 0 
                    ? `${((realTimeData.totalOpens / realTimeData.totalEmailsSent) * 100).toFixed(1)}%`
                    : '0%'
                  }
                </p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Clicks</p>
                <p className="text-2xl font-bold">{realTimeData.totalClicks}</p>
                <p className="text-xs text-blue-600">
                  {realTimeData.totalOpens > 0 
                    ? `${((realTimeData.totalClicks / realTimeData.totalOpens) * 100).toFixed(1)}%`
                    : '0%'
                  }
                </p>
              </div>
              <Users className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Replies</p>
                <p className="text-2xl font-bold">{realTimeData.totalReplies}</p>
                <p className="text-xs text-orange-600">
                  {realTimeData.totalEmailsSent > 0 
                    ? `${((realTimeData.totalReplies / realTimeData.totalEmailsSent) * 100).toFixed(1)}%`
                    : '0%'
                  }
                </p>
              </div>
              <Mail className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Campaign Details */}
      <Tabs defaultValue="active" className="space-y-4">
        <TabsList>
          <TabsTrigger value="active">Active Campaigns</TabsTrigger>
          <TabsTrigger value="all">All Campaigns</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          {campaigns.filter(c => c.status === 'active').map((campaign) => (
            <Card key={campaign.id}>
              <CardHeader className="pb-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(campaign.status)}
                    <CardTitle className="text-lg">{campaign.name}</CardTitle>
                    <Badge className={getStatusColor(campaign.status)}>
                      {campaign.status}
                    </Badge>
                  </div>
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => toggleCampaignStatus(campaign.id)}
                  >
                    {campaign.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
                  <div>
                    <p className="text-sm text-gray-600">Progress</p>
                    <Progress 
                      value={(campaign.emailsSent / campaign.totalRecipients) * 100} 
                      className="mt-1"
                    />
                    <p className="text-xs text-gray-500 mt-1">
                      {campaign.emailsSent} / {campaign.totalRecipients}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Open Rate</p>
                    <p className="text-lg font-semibold">
                      {campaign.emailsSent > 0 
                        ? `${((campaign.opensCount / campaign.emailsSent) * 100).toFixed(1)}%`
                        : '0%'
                      }
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Click Rate</p>
                    <p className="text-lg font-semibold">
                      {campaign.opensCount > 0 
                        ? `${((campaign.clicksCount / campaign.opensCount) * 100).toFixed(1)}%`
                        : '0%'
                      }
                    </p>
                  </div>
                  <div>
                    <p className="text-sm text-gray-600">Reply Rate</p>
                    <p className="text-lg font-semibold">
                      {campaign.emailsSent > 0 
                        ? `${((campaign.repliesCount / campaign.emailsSent) * 100).toFixed(1)}%`
                        : '0%'
                      }
                    </p>
                  </div>
                </div>
                {campaign.nextSend && (
                  <div className="flex items-center gap-2 text-sm text-gray-600">
                    <Clock className="w-4 h-4" />
                    Next send: {new Date(campaign.nextSend).toLocaleString()}
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="all" className="space-y-4">
          {campaigns.map((campaign) => (
            <Card key={campaign.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    {getStatusIcon(campaign.status)}
                    <div>
                      <h3 className="font-semibold">{campaign.name}</h3>
                      <p className="text-sm text-gray-600">
                        Started: {new Date(campaign.startDate).toLocaleDateString()}
                      </p>
                    </div>
                    <Badge className={getStatusColor(campaign.status)}>
                      {campaign.status}
                    </Badge>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600">
                      {campaign.emailsSent} / {campaign.totalRecipients} sent
                    </p>
                    <p className="text-xs text-gray-500">
                      {campaign.repliesCount} replies
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-gray-500">
                <TrendingUp className="w-12 h-12 mx-auto mb-2 opacity-50" />
                <p>Detailed analytics charts would be displayed here</p>
                <p className="text-sm">Including performance trends, A/B test results, and engagement metrics</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};