import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Progress } from '@/components/ui/progress';
import { AlertTriangle, Users, Shield, Mail, Clock, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { toast } from '@/components/ui/use-toast';

interface TwoFactorPolicy {
  id: string;
  role: string;
  enforced: boolean;
  grace_period_days: number;
  created_at: string;
  updated_at: string;
}

interface UserCompliance {
  id: string;
  email: string;
  role: string;
  two_factor_enabled: boolean;
  enforcement_date: string;
  grace_period_expires: string;
  compliant: boolean;
}

interface AdoptionStats {
  total_users: number;
  enabled_users: number;
  adoption_rate: number;
  by_role: Record<string, { total: number; enabled: number; rate: number }>;
}

export default function AdminTwoFactorPanel() {
  const [policies, setPolicies] = useState<TwoFactorPolicy[]>([]);
  const [users, setUsers] = useState<UserCompliance[]>([]);
  const [stats, setStats] = useState<AdoptionStats | null>(null);
  const [loading, setLoading] = useState(true);
  const [selectedUsers, setSelectedUsers] = useState<string[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [policiesRes, usersRes, statsRes] = await Promise.all([
        supabase.from('two_factor_policies').select('*'),
        supabase.from('user_compliance_view').select('*'),
        supabase.from('adoption_stats_view').select('*').single()
      ]);

      if (policiesRes.data) setPolicies(policiesRes.data);
      if (usersRes.data) setUsers(usersRes.data);
      if (statsRes.data) setStats(statsRes.data);
    } catch (error) {
      toast({ title: "Error loading data", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const updatePolicy = async (role: string, enforced: boolean, gracePeriod: number) => {
    try {
      await supabase.from('two_factor_policies').upsert({
        role,
        enforced,
        grace_period_days: gracePeriod
      });
      
      loadData();
      toast({ title: "Policy updated successfully" });
    } catch (error) {
      toast({ title: "Error updating policy", variant: "destructive" });
    }
  };

  const sendReminderEmails = async (userIds: string[]) => {
    try {
      const { data } = await supabase.functions.invoke('send-2fa-reminders', {
        body: { user_ids: userIds }
      });
      
      toast({ title: `Reminder emails sent to ${userIds.length} users` });
      setSelectedUsers([]);
    } catch (error) {
      toast({ title: "Error sending reminders", variant: "destructive" });
    }
  };

  if (loading) return <div>Loading...</div>;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Two-Factor Authentication Management</h1>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="policies">Policies</TabsTrigger>
          <TabsTrigger value="users">User Compliance</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {stats && (
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Users</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.total_users}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">2FA Enabled</CardTitle>
                  <Shield className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{stats.enabled_users}</div>
                  <Progress value={stats.adoption_rate} className="mt-2" />
                  <p className="text-xs text-muted-foreground mt-1">
                    {stats.adoption_rate.toFixed(1)}% adoption rate
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Non-Compliant</CardTitle>
                  <AlertTriangle className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">
                    {users.filter(u => !u.compliant).length}
                  </div>
                </CardContent>
              </Card>
            </div>
          )}

          <Card>
            <CardHeader>
              <CardTitle>Adoption by Role</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {stats && Object.entries(stats.by_role).map(([role, data]) => (
                  <div key={role} className="flex items-center justify-between">
                    <span className="font-medium capitalize">{role}</span>
                    <div className="flex items-center space-x-2">
                      <Progress value={data.rate} className="w-32" />
                      <span className="text-sm text-muted-foreground">
                        {data.enabled}/{data.total} ({data.rate.toFixed(1)}%)
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="policies" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Role-Based 2FA Policies</CardTitle>
              <CardDescription>Configure enforcement policies for different user roles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {['admin', 'manager', 'user'].map((role) => {
                  const policy = policies.find(p => p.role === role);
                  return (
                    <PolicyRow
                      key={role}
                      role={role}
                      policy={policy}
                      onUpdate={updatePolicy}
                    />
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="users" className="space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>User Compliance Status</CardTitle>
                <CardDescription>Monitor and manage user 2FA compliance</CardDescription>
              </div>
              <Button
                onClick={() => sendReminderEmails(selectedUsers)}
                disabled={selectedUsers.length === 0}
                className="flex items-center space-x-2"
              >
                <Mail className="h-4 w-4" />
                <span>Send Reminders ({selectedUsers.length})</span>
              </Button>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead className="w-12">
                      <input
                        type="checkbox"
                        onChange={(e) => {
                          if (e.target.checked) {
                            setSelectedUsers(users.filter(u => !u.compliant).map(u => u.id));
                          } else {
                            setSelectedUsers([]);
                          }
                        }}
                      />
                    </TableHead>
                    <TableHead>User</TableHead>
                    <TableHead>Role</TableHead>
                    <TableHead>2FA Status</TableHead>
                    <TableHead>Compliance</TableHead>
                    <TableHead>Grace Period</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id}>
                      <TableCell>
                        <input
                          type="checkbox"
                          checked={selectedUsers.includes(user.id)}
                          onChange={(e) => {
                            if (e.target.checked) {
                              setSelectedUsers([...selectedUsers, user.id]);
                            } else {
                              setSelectedUsers(selectedUsers.filter(id => id !== user.id));
                            }
                          }}
                        />
                      </TableCell>
                      <TableCell>{user.email}</TableCell>
                      <TableCell>
                        <Badge variant="outline" className="capitalize">{user.role}</Badge>
                      </TableCell>
                      <TableCell>
                        {user.two_factor_enabled ? (
                          <Badge variant="default" className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Enabled
                          </Badge>
                        ) : (
                          <Badge variant="destructive">
                            <XCircle className="h-3 w-3 mr-1" />
                            Disabled
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.compliant ? (
                          <Badge variant="default" className="bg-green-100 text-green-800">Compliant</Badge>
                        ) : (
                          <Badge variant="destructive">Non-Compliant</Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        {user.grace_period_expires && (
                          <div className="flex items-center space-x-1">
                            <Clock className="h-3 w-3" />
                            <span className="text-sm">
                              {new Date(user.grace_period_expires).toLocaleDateString()}
                            </span>
                          </div>
                        )}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

interface PolicyRowProps {
  role: string;
  policy?: TwoFactorPolicy;
  onUpdate: (role: string, enforced: boolean, gracePeriod: number) => void;
}

function PolicyRow({ role, policy, onUpdate }: PolicyRowProps) {
  const [enforced, setEnforced] = useState(policy?.enforced || false);
  const [gracePeriod, setGracePeriod] = useState(policy?.grace_period_days || 30);

  const handleUpdate = () => {
    onUpdate(role, enforced, gracePeriod);
  };

  return (
    <div className="flex items-center justify-between p-4 border rounded-lg">
      <div className="space-y-1">
        <h3 className="font-medium capitalize">{role}</h3>
        <p className="text-sm text-muted-foreground">
          Configure 2FA enforcement for {role} users
        </p>
      </div>
      <div className="flex items-center space-x-4">
        <div className="flex items-center space-x-2">
          <Label htmlFor={`enforce-${role}`}>Enforce 2FA</Label>
          <Switch
            id={`enforce-${role}`}
            checked={enforced}
            onCheckedChange={setEnforced}
          />
        </div>
        <div className="flex items-center space-x-2">
          <Label htmlFor={`grace-${role}`}>Grace Period (days)</Label>
          <Input
            id={`grace-${role}`}
            type="number"
            value={gracePeriod}
            onChange={(e) => setGracePeriod(parseInt(e.target.value))}
            className="w-20"
            min="0"
            max="365"
          />
        </div>
        <Button onClick={handleUpdate} size="sm">
          Update
        </Button>
      </div>
    </div>
  );
}