import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { 
  Activity, AlertTriangle, CheckCircle, XCircle, 
  RefreshCw, Power, RotateCcw, TrendingUp, TrendingDown
} from 'lucide-react';
import { circuitBreakerService, CircuitBreaker } from '@/services/circuitBreakerService';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export const CircuitBreakerDashboard: React.FC = () => {
  const [breakers, setBreakers] = useState<CircuitBreaker[]>([]);
  const [selectedBreaker, setSelectedBreaker] = useState<CircuitBreaker | null>(null);
  const [healthHistory, setHealthHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBreakers();
    const interval = setInterval(loadBreakers, 10000);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (selectedBreaker) {
      loadHealthHistory(selectedBreaker.id);
    }
  }, [selectedBreaker]);

  const loadBreakers = async () => {
    try {
      const data = await circuitBreakerService.getAllCircuitBreakers();
      setBreakers(data);
      if (!selectedBreaker && data.length > 0) {
        setSelectedBreaker(data[0]);
      }
    } catch (error) {
      console.error('Failed to load circuit breakers:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadHealthHistory = async (breakerId: string) => {
    try {
      const stats = await circuitBreakerService.getStatistics(breakerId, 7);
      setHealthHistory(stats);
    } catch (error) {
      console.error('Failed to load health history:', error);
    }
  };

  const handleOpenCircuit = async (breakerId: string) => {
    await circuitBreakerService.openCircuit(breakerId);
    loadBreakers();
  };

  const handleCloseCircuit = async (breakerId: string) => {
    await circuitBreakerService.closeCircuit(breakerId);
    loadBreakers();
  };

  const handleResetCircuit = async (breakerId: string) => {
    await circuitBreakerService.resetCircuit(breakerId);
    loadBreakers();
  };

  const getStateColor = (state: string) => {
    switch (state) {
      case 'closed': return 'bg-green-500';
      case 'open': return 'bg-red-500';
      case 'half_open': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getStateIcon = (state: string) => {
    switch (state) {
      case 'closed': return <CheckCircle className="h-5 w-5" />;
      case 'open': return <XCircle className="h-5 w-5" />;
      case 'half_open': return <AlertTriangle className="h-5 w-5" />;
      default: return <Activity className="h-5 w-5" />;
    }
  };

  const getHealthColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 50) return 'text-yellow-600';
    return 'text-red-600';
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading circuit breakers...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold">Circuit Breaker Dashboard</h2>
          <p className="text-muted-foreground">Monitor and manage webhook endpoint health</p>
        </div>
        <Button onClick={loadBreakers} variant="outline">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Overview Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Circuits</p>
                <p className="text-2xl font-bold">{breakers.length}</p>
              </div>
              <Activity className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Healthy (Closed)</p>
                <p className="text-2xl font-bold text-green-600">
                  {breakers.filter(b => b.state === 'closed').length}
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Failed (Open)</p>
                <p className="text-2xl font-bold text-red-600">
                  {breakers.filter(b => b.state === 'open').length}
                </p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Testing (Half-Open)</p>
                <p className="text-2xl font-bold text-yellow-600">
                  {breakers.filter(b => b.state === 'half_open').length}
                </p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Circuit Breakers List */}
      <Card>
        <CardHeader>
          <CardTitle>Circuit Breakers</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {breakers.map((breaker) => (
              <div
                key={breaker.id}
                className={`p-4 border rounded-lg cursor-pointer transition-colors ${
                  selectedBreaker?.id === breaker.id ? 'border-blue-500 bg-blue-50' : 'hover:bg-gray-50'
                }`}
                onClick={() => setSelectedBreaker(breaker)}
              >
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      {getStateIcon(breaker.state)}
                      <div>
                        <h3 className="font-semibold">{breaker.endpoint_url}</h3>
                        <p className="text-sm text-muted-foreground">
                          {breaker.endpoint_type.toUpperCase()}
                        </p>
                      </div>
                    </div>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-3">
                      <div>
                        <p className="text-xs text-muted-foreground">State</p>
                        <Badge className={getStateColor(breaker.state)}>
                          {breaker.state.replace('_', '-').toUpperCase()}
                        </Badge>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Health Score</p>
                        <p className={`text-lg font-bold ${getHealthColor(breaker.health_score)}`}>
                          {breaker.health_score.toFixed(1)}%
                        </p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Failures</p>
                        <p className="text-lg font-bold">{breaker.consecutive_failures}</p>
                      </div>
                      <div>
                        <p className="text-xs text-muted-foreground">Threshold</p>
                        <p className="text-lg font-bold">{breaker.failure_threshold}</p>
                      </div>
                    </div>

                    <div className="mt-3">
                      <Progress value={breaker.health_score} className="h-2" />
                    </div>
                  </div>

                  <div className="flex gap-2 ml-4">
                    {breaker.state === 'open' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleCloseCircuit(breaker.id);
                        }}
                      >
                        <Power className="h-4 w-4" />
                      </Button>
                    )}
                    {breaker.state === 'closed' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={(e) => {
                          e.stopPropagation();
                          handleOpenCircuit(breaker.id);
                        }}
                      >
                        <XCircle className="h-4 w-4" />
                      </Button>
                    )}
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={(e) => {
                        e.stopPropagation();
                        handleResetCircuit(breaker.id);
                      }}
                    >
                      <RotateCcw className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Health History Chart */}
      {selectedBreaker && (
        <Card>
          <CardHeader>
            <CardTitle>Health Score History - {selectedBreaker.endpoint_url}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={healthHistory}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis domain={[0, 100]} />
                <Tooltip />
                <Legend />
                <Line 
                  type="monotone" 
                  dataKey="successful_requests" 
                  stroke="#10b981" 
                  name="Successful"
                />
                <Line 
                  type="monotone" 
                  dataKey="failed_requests" 
                  stroke="#ef4444" 
                  name="Failed"
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
