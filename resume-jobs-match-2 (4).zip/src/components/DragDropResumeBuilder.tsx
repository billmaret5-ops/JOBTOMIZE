import React, { useState } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  GripVertical, 
  Plus, 
  Eye, 
  EyeOff, 
  Edit, 
  Trash2,
  User,
  FileText,
  Briefcase,
  GraduationCap,
  Award
} from 'lucide-react';

interface ResumeSection {
  id: string;
  type: 'personal' | 'summary' | 'experience' | 'education' | 'skills' | 'custom';
  title: string;
  content: any;
  order: number;
  visible: boolean;
}

interface Props {
  sections: ResumeSection[];
  onSectionUpdate: (sectionId: string, updates: Partial<ResumeSection>) => void;
  onSectionReorder: (sections: ResumeSection[]) => void;
  selectedSection: string | null;
  onSectionSelect: (sectionId: string | null) => void;
}

const sectionIcons = {
  personal: User,
  summary: FileText,
  experience: Briefcase,
  education: GraduationCap,
  skills: Award,
  custom: FileText
};

export function DragDropResumeBuilder({
  sections,
  onSectionUpdate,
  onSectionReorder,
  selectedSection,
  onSectionSelect
}: Props) {
  const [editingSection, setEditingSection] = useState<string | null>(null);

  const moveSection = (index: number, direction: 'up' | 'down') => {
    const newSections = [...sections];
    const targetIndex = direction === 'up' ? index - 1 : index + 1;
    
    if (targetIndex >= 0 && targetIndex < sections.length) {
      [newSections[index], newSections[targetIndex]] = [newSections[targetIndex], newSections[index]];
      onSectionReorder(newSections);
    }
  };

  const toggleSectionVisibility = (sectionId: string) => {
    const section = sections.find(s => s.id === sectionId);
    if (section) {
      onSectionUpdate(sectionId, { visible: !section.visible });
    }
  };

  const addNewSection = () => {
    const newSection: ResumeSection = {
      id: Date.now().toString(),
      type: 'custom',
      title: 'New Section',
      content: '',
      order: sections.length + 1,
      visible: true
    };
    onSectionReorder([...sections, newSection]);
  };

  const deleteSection = (sectionId: string) => {
    const updatedSections = sections.filter(s => s.id !== sectionId);
    onSectionReorder(updatedSections);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold">Resume Sections</h3>
        <Button size="sm" onClick={addNewSection}>
          <Plus className="h-4 w-4 mr-1" />
          Add Section
        </Button>
      </div>

      <div className="space-y-2">
        {sections.map((section, index) => {
          const IconComponent = sectionIcons[section.type];
          return (
            <Card
              key={section.id}
              className={`transition-all ${
                selectedSection === section.id ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => onSectionSelect(section.id)}
            >
              <CardContent className="p-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 flex-1">
                    <div className="flex flex-col gap-1">
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          moveSection(index, 'up');
                        }}
                        disabled={index === 0}
                      >
                        ↑
                      </Button>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={(e) => {
                          e.stopPropagation();
                          moveSection(index, 'down');
                        }}
                        disabled={index === sections.length - 1}
                      >
                        ↓
                      </Button>
                    </div>
                    <IconComponent className="h-4 w-4 text-gray-600" />
                    <span className="font-medium text-sm">{section.title}</span>
                    {!section.visible && (
                      <Badge variant="secondary" className="text-xs">Hidden</Badge>
                    )}
                  </div>
                  
                  <div className="flex items-center gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        toggleSectionVisibility(section.id);
                      }}
                    >
                      {section.visible ? <Eye className="h-3 w-3" /> : <EyeOff className="h-3 w-3" />}
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        setEditingSection(section.id);
                      }}
                    >
                      <Edit className="h-3 w-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={(e) => {
                        e.stopPropagation();
                        deleteSection(section.id);
                      }}
                    >
                      <Trash2 className="h-3 w-3" />
                    </Button>
                  </div>
                </div>
                
                {editingSection === section.id && (
                  <div className="mt-3 p-3 bg-gray-50 rounded-lg space-y-3">
                    <Input
                      value={section.title}
                      onChange={(e) => onSectionUpdate(section.id, { title: e.target.value })}
                      placeholder="Section title"
                      className="font-medium"
                    />
                    <Textarea
                      value={typeof section.content === 'string' ? section.content : JSON.stringify(section.content)}
                      onChange={(e) => onSectionUpdate(section.id, { content: e.target.value })}
                      placeholder="Section content"
                      rows={4}
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => setEditingSection(null)}>
                        Save
                      </Button>
                      <Button size="sm" variant="outline" onClick={() => setEditingSection(null)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
}