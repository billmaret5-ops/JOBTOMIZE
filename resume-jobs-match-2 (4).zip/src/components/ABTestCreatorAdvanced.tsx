import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { useRealTimeABTestAnalytics } from '@/hooks/useRealTimeABTestAnalytics';
import { X, Target, Users, Mail, BarChart3 } from 'lucide-react';

interface ABTestCreatorAdvancedProps {
  onClose: () => void;
  onTestCreated: () => void;
}

export default function ABTestCreatorAdvanced({ onClose, onTestCreated }: ABTestCreatorAdvancedProps) {
  const { createABTest, loading } = useRealTimeABTestAnalytics();
  const [testData, setTestData] = useState({
    name: '',
    description: '',
    test_type: 'subject_line',
    primary_metric: 'conversion_rate',
    confidence_level: 95,
    sample_size: 1000,
    traffic_split: { A: 50, B: 50 },
    variant_a_subject: '',
    variant_a_content: '',
    variant_b_subject: '',
    variant_b_content: '',
    auto_declare_winner: true,
    minimum_runtime_hours: 24
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await createABTest(testData);
      onTestCreated();
      onClose();
    } catch (error) {
      console.error('Failed to create A/B test:', error);
    }
  };

  const updateTrafficSplit = (value: number[]) => {
    const splitA = value[0];
    const splitB = 100 - splitA;
    setTestData(prev => ({
      ...prev,
      traffic_split: { A: splitA, B: splitB }
    }));
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-4xl max-h-[90vh] overflow-y-auto">
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center space-x-2">
              <BarChart3 className="h-5 w-5" />
              <span>Create Advanced A/B Test</span>
            </CardTitle>
            <Button variant="ghost" size="sm" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Basic Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Test Name</Label>
                <Input
                  id="name"
                  value={testData.name}
                  onChange={(e) => setTestData(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Email Subject Line Test"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="test_type">Test Type</Label>
                <Select
                  value={testData.test_type}
                  onValueChange={(value) => setTestData(prev => ({ ...prev, test_type: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="subject_line">Subject Line</SelectItem>
                    <SelectItem value="sender_name">Sender Name</SelectItem>
                    <SelectItem value="content">Email Content</SelectItem>
                    <SelectItem value="send_time">Send Time</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={testData.description}
                onChange={(e) => setTestData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Testing different subject lines to improve open rates"
              />
            </div>

            {/* Test Configuration */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label htmlFor="primary_metric">Primary Metric</Label>
                <Select
                  value={testData.primary_metric}
                  onValueChange={(value) => setTestData(prev => ({ ...prev, primary_metric: value }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open_rate">Open Rate</SelectItem>
                    <SelectItem value="click_rate">Click Rate</SelectItem>
                    <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
                    <SelectItem value="unsubscribe_rate">Unsubscribe Rate</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="confidence_level">Confidence Level (%)</Label>
                <Select
                  value={testData.confidence_level.toString()}
                  onValueChange={(value) => setTestData(prev => ({ ...prev, confidence_level: parseInt(value) }))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="90">90%</SelectItem>
                    <SelectItem value="95">95%</SelectItem>
                    <SelectItem value="99">99%</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label htmlFor="sample_size">Sample Size</Label>
                <Input
                  id="sample_size"
                  type="number"
                  value={testData.sample_size}
                  onChange={(e) => setTestData(prev => ({ ...prev, sample_size: parseInt(e.target.value) }))}
                  min="100"
                />
              </div>
            </div>

            {/* Traffic Split */}
            <div className="space-y-4">
              <Label>Traffic Split</Label>
              <div className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Variant A: {testData.traffic_split.A}%</span>
                  <span>Variant B: {testData.traffic_split.B}%</span>
                </div>
                <Slider
                  value={[testData.traffic_split.A]}
                  onValueChange={updateTrafficSplit}
                  min={10}
                  max={90}
                  step={5}
                  className="w-full"
                />
              </div>
            </div>

            {/* Variant Configuration */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variant A</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="variant_a_subject">Subject Line</Label>
                    <Input
                      id="variant_a_subject"
                      value={testData.variant_a_subject}
                      onChange={(e) => setTestData(prev => ({ ...prev, variant_a_subject: e.target.value }))}
                      placeholder="Original subject line"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="variant_a_content">Email Content</Label>
                    <Textarea
                      id="variant_a_content"
                      value={testData.variant_a_content}
                      onChange={(e) => setTestData(prev => ({ ...prev, variant_a_content: e.target.value }))}
                      placeholder="Original email content"
                      rows={4}
                    />
                  </div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Variant B</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="variant_b_subject">Subject Line</Label>
                    <Input
                      id="variant_b_subject"
                      value={testData.variant_b_subject}
                      onChange={(e) => setTestData(prev => ({ ...prev, variant_b_subject: e.target.value }))}
                      placeholder="Alternative subject line"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="variant_b_content">Email Content</Label>
                    <Textarea
                      id="variant_b_content"
                      value={testData.variant_b_content}
                      onChange={(e) => setTestData(prev => ({ ...prev, variant_b_content: e.target.value }))}
                      placeholder="Alternative email content"
                      rows={4}
                    />
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Advanced Options */}
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Advanced Options</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex items-center justify-between">
                  <div>
                    <Label htmlFor="auto_declare_winner">Auto-declare Winner</Label>
                    <p className="text-sm text-muted-foreground">
                      Automatically declare winner when significance is reached
                    </p>
                  </div>
                  <Switch
                    id="auto_declare_winner"
                    checked={testData.auto_declare_winner}
                    onCheckedChange={(checked) => setTestData(prev => ({ ...prev, auto_declare_winner: checked }))}
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="minimum_runtime">Minimum Runtime (hours)</Label>
                  <Input
                    id="minimum_runtime"
                    type="number"
                    value={testData.minimum_runtime_hours}
                    onChange={(e) => setTestData(prev => ({ ...prev, minimum_runtime_hours: parseInt(e.target.value) }))}
                    min="1"
                    max="168"
                  />
                  <p className="text-sm text-muted-foreground">
                    Test will run for at least this duration before declaring a winner
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Action Buttons */}
            <div className="flex justify-end space-x-2 pt-4 border-t">
              <Button type="button" variant="outline" onClick={onClose}>
                Cancel
              </Button>
              <Button type="submit" disabled={loading}>
                {loading ? 'Creating...' : 'Create A/B Test'}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}