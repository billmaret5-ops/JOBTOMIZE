import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Activity, TrendingUp, Clock, AlertTriangle, Users, CheckCircle } from 'lucide-react';
import { alertAnalyticsService } from '@/services/alertAnalyticsService';

const COLORS = ['#ef4444', '#f97316', '#eab308', '#22c55e'];

export default function AlertAnalyticsDashboard() {
  const [timeRange, setTimeRange] = useState('30');
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState<any>({});

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      const days = parseInt(timeRange);
      const [
        volumeMetrics,
        channelPerformance,
        falsePositiveRate,
        mttaAndMttr,
        escalationFrequency,
        alertPatterns,
        severityDistribution,
        resolutionTrends,
        onCallWorkload
      ] = await Promise.all([
        alertAnalyticsService.getAlertVolumeMetrics(days),
        alertAnalyticsService.getChannelPerformance(),
        alertAnalyticsService.getFalsePositiveRate(days),
        alertAnalyticsService.getMTTAAndMTTR(),
        alertAnalyticsService.getEscalationFrequency(),
        alertAnalyticsService.getAlertPatternsByTimeOfDay(),
        alertAnalyticsService.getSeverityDistribution(),
        alertAnalyticsService.getResolutionTrends(days),
        alertAnalyticsService.getOnCallWorkload()
      ]);

      setMetrics({
        volumeMetrics,
        channelPerformance,
        falsePositiveRate,
        mttaAndMttr,
        escalationFrequency,
        alertPatterns,
        severityDistribution,
        resolutionTrends,
        onCallWorkload
      });
    } catch (error) {
      console.error('Failed to load analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <div className="flex items-center justify-center h-64">Loading analytics...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Alert Routing Analytics</h2>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7">Last 7 days</SelectItem>
            <SelectItem value="30">Last 30 days</SelectItem>
            <SelectItem value="90">Last 90 days</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">MTTA</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.mttaAndMttr?.mtta?.toFixed(1) || 0} min
            </div>
            <p className="text-xs text-muted-foreground">Mean Time To Acknowledge</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">MTTR</CardTitle>
            <CheckCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.mttaAndMttr?.mttr?.toFixed(1) || 0} min
            </div>
            <p className="text-xs text-muted-foreground">Mean Time To Resolve</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">False Positive Rate</CardTitle>
            <AlertTriangle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.falsePositiveRate?.toFixed(1) || 0}%
            </div>
            <p className="text-xs text-muted-foreground">Alert accuracy</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Escalation Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {metrics.escalationFrequency?.rate?.toFixed(1) || 0}%
            </div>
            <p className="text-xs text-muted-foreground">
              {metrics.escalationFrequency?.escalated || 0} of {metrics.escalationFrequency?.total || 0} alerts
            </p>
          </CardContent>
        </Card>
      </div>

      {/* Alert Volume Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Volume Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={metrics.volumeMetrics || []}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="critical" stroke="#ef4444" strokeWidth={2} />
              <Line type="monotone" dataKey="high" stroke="#f97316" strokeWidth={2} />
              <Line type="monotone" dataKey="medium" stroke="#eab308" strokeWidth={2} />
              <Line type="monotone" dataKey="low" stroke="#22c55e" strokeWidth={2} />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Channel Performance */}
        <Card>
          <CardHeader>
            <CardTitle>Channel Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {metrics.channelPerformance?.map((channel: any) => (
                <div key={channel.channel} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium capitalize">{channel.channel}</span>
                    <span className="text-sm text-muted-foreground">
                      {channel.deliveryRate.toFixed(1)}% delivery
                    </span>
                  </div>
                  <div className="flex items-center gap-4 text-sm">
                    <span>Sent: {channel.totalSent}</span>
                    <span className="text-green-600">Delivered: {channel.delivered}</span>
                    <span className="text-red-600">Failed: {channel.failed}</span>
                    <span>Avg Response: {channel.avgResponseTime.toFixed(1)}m</span>
                  </div>
                  <div className="w-full bg-gray-200 rounded-full h-2">
                    <div
                      className="bg-blue-600 h-2 rounded-full"
                      style={{ width: `${channel.deliveryRate}%` }}
                    />
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Severity Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Severity Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie
                  data={metrics.severityDistribution || []}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={(entry) => `${entry.severity}: ${entry.percentage.toFixed(1)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="count"
                >
                  {(metrics.severityDistribution || []).map((_: any, index: number) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Alert Patterns by Time of Day */}
      <Card>
        <CardHeader>
          <CardTitle>Alert Patterns by Time of Day</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <BarChart data={metrics.alertPatterns || []}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="hour" label={{ value: 'Hour of Day', position: 'insideBottom', offset: -5 }} />
              <YAxis />
              <Tooltip />
              <Legend />
              <Bar dataKey="count" fill="#3b82f6" name="Alert Count" />
            </BarChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Resolution Trends */}
      <Card>
        <CardHeader>
          <CardTitle>Incident Resolution Trends</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={metrics.resolutionTrends || []}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="date" />
              <YAxis yAxisId="left" />
              <YAxis yAxisId="right" orientation="right" />
              <Tooltip />
              <Legend />
              <Line yAxisId="left" type="monotone" dataKey="resolved" stroke="#22c55e" strokeWidth={2} name="Resolved Count" />
              <Line yAxisId="right" type="monotone" dataKey="avgMTTR" stroke="#3b82f6" strokeWidth={2} name="Avg MTTR (min)" />
              <Line yAxisId="right" type="monotone" dataKey="avgMTTA" stroke="#f97316" strokeWidth={2} name="Avg MTTA (min)" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* On-Call Workload Distribution */}
      <Card>
        <CardHeader>
          <CardTitle>On-Call Workload Distribution</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {metrics.onCallWorkload?.map((user: any) => (
              <div key={user.userId} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Users className="h-4 w-4" />
                    <span className="font-medium">{user.userName}</span>
                  </div>
                  <span className="text-sm text-muted-foreground">
                    {user.hoursOnCall.toFixed(1)} hours on-call
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-4 text-sm">
                  <div>
                    <div className="text-muted-foreground">Alerts Received</div>
                    <div className="text-lg font-semibold">{user.alertsReceived}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Incidents Handled</div>
                    <div className="text-lg font-semibold">{user.incidentsHandled}</div>
                  </div>
                  <div>
                    <div className="text-muted-foreground">Avg Response Time</div>
                    <div className="text-lg font-semibold">{user.avgResponseTime.toFixed(1)}m</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
