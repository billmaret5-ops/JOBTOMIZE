import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { backupReplicationService, Region } from '@/services/backupReplicationService';
import { Shield, AlertTriangle, ArrowRight, Play, CheckCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function DisasterRecoveryOrchestrator() {
  const [regions, setRegions] = useState<Region[]>([]);
  const [sourceRegion, setSourceRegion] = useState('');
  const [targetRegion, setTargetRegion] = useState('');
  const [failoverInProgress, setFailoverInProgress] = useState(false);
  const [drTests, setDrTests] = useState<any[]>([]);
  const { toast } = useToast();

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const regionsData = await backupReplicationService.getRegions();
    setRegions(regionsData);
    
    // Mock DR test history
    setDrTests([
      { id: 1, date: '2025-01-20', source: 'us-east-1', target: 'us-west-2', status: 'success', duration: '12m' },
      { id: 2, date: '2025-01-15', source: 'eu-west-1', target: 'us-east-1', status: 'success', duration: '15m' },
      { id: 3, date: '2025-01-10', source: 'ap-southeast-1', target: 'eu-west-1', status: 'failed', duration: '8m' },
    ]);
  };

  const handleFailover = async () => {
    if (!sourceRegion || !targetRegion) {
      toast({ title: 'Error', description: 'Select source and target regions', variant: 'destructive' });
      return;
    }

    setFailoverInProgress(true);
    try {
      await backupReplicationService.triggerFailover(sourceRegion, targetRegion);
      toast({ title: 'Success', description: 'Failover initiated successfully' });
      loadData();
    } catch (error) {
      toast({ title: 'Error', description: 'Failover failed', variant: 'destructive' });
    } finally {
      setFailoverInProgress(false);
    }
  };

  const degradedRegions = regions.filter(r => r.status === 'degraded' || r.status === 'offline');

  return (
    <div className="space-y-6">
      {degradedRegions.length > 0 && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            {degradedRegions.length} region(s) experiencing issues: {degradedRegions.map(r => r.code).join(', ')}
          </AlertDescription>
        </Alert>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="w-5 h-5" />
            Disaster Recovery Failover
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Source Region (Failed)</label>
              <Select value={sourceRegion} onValueChange={setSourceRegion}>
                <SelectTrigger>
                  <SelectValue placeholder="Select source region" />
                </SelectTrigger>
                <SelectContent>
                  {regions.map(region => (
                    <SelectItem key={region.id} value={region.id}>
                      {region.name} ({region.code}) - {region.status}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Target Region (Failover To)</label>
              <Select value={targetRegion} onValueChange={setTargetRegion}>
                <SelectTrigger>
                  <SelectValue placeholder="Select target region" />
                </SelectTrigger>
                <SelectContent>
                  {regions.filter(r => r.id !== sourceRegion && r.status === 'healthy').map(region => (
                    <SelectItem key={region.id} value={region.id}>
                      {region.name} ({region.code})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {sourceRegion && targetRegion && (
            <div className="flex items-center justify-center gap-4 p-4 bg-slate-50 rounded-lg">
              <Badge variant="destructive">{regions.find(r => r.id === sourceRegion)?.code}</Badge>
              <ArrowRight className="w-6 h-6" />
              <Badge variant="default">{regions.find(r => r.id === targetRegion)?.code}</Badge>
            </div>
          )}

          <Button 
            onClick={handleFailover} 
            disabled={!sourceRegion || !targetRegion || failoverInProgress}
            className="w-full"
            variant="destructive"
          >
            <Play className="w-4 h-4 mr-2" />
            {failoverInProgress ? 'Initiating Failover...' : 'Initiate Failover'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>DR Test History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {drTests.map(test => (
              <div key={test.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  {test.status === 'success' ? 
                    <CheckCircle className="w-4 h-4 text-green-500" /> :
                    <AlertTriangle className="w-4 h-4 text-red-500" />
                  }
                  <div>
                    <div className="text-sm font-medium">
                      {test.source} → {test.target}
                    </div>
                    <div className="text-xs text-muted-foreground">
                      {test.date} • Duration: {test.duration}
                    </div>
                  </div>
                </div>
                <Badge variant={test.status === 'success' ? 'default' : 'destructive'}>
                  {test.status}
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
