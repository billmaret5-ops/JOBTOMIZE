import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Play, Pause, BarChart3, TrendingUp, Users, Target } from 'lucide-react';

interface ABTest {
  id: string;
  name: string;
  status: 'draft' | 'running' | 'completed' | 'paused';
  templateA: string;
  templateB: string;
  trafficSplit: number;
  startDate: string;
  endDate?: string;
  participants: number;
  conversions: {
    a: { sent: number; opens: number; clicks: number; responses: number };
    b: { sent: number; opens: number; clicks: number; responses: number };
  };
  winner?: 'a' | 'b' | null;
  confidence: number;
}

const ABTestingManager: React.FC = () => {
  const [tests, setTests] = useState<ABTest[]>([]);
  const [selectedTest, setSelectedTest] = useState<ABTest | null>(null);

  useEffect(() => {
    // Mock A/B test data
    const mockTests: ABTest[] = [
      {
        id: '1',
        name: 'Subject Line Test - Software Engineer',
        status: 'running',
        templateA: 'Professional Application Template',
        templateB: 'Casual Application Template',
        trafficSplit: 50,
        startDate: '2024-01-15',
        participants: 156,
        conversions: {
          a: { sent: 78, opens: 68, clicks: 23, responses: 12 },
          b: { sent: 78, opens: 71, clicks: 28, responses: 15 }
        },
        winner: null,
        confidence: 73
      },
      {
        id: '2',
        name: 'CTA Button Test - Follow-up',
        status: 'completed',
        templateA: 'Standard Follow-up',
        templateB: 'Urgent Follow-up',
        trafficSplit: 50,
        startDate: '2024-01-01',
        endDate: '2024-01-14',
        participants: 240,
        conversions: {
          a: { sent: 120, opens: 108, clicks: 34, responses: 18 },
          b: { sent: 120, opens: 114, clicks: 45, responses: 28 }
        },
        winner: 'b',
        confidence: 95
      }
    ];
    setTests(mockTests);
  }, []);

  const calculateRate = (numerator: number, denominator: number) => {
    return denominator > 0 ? ((numerator / denominator) * 100).toFixed(1) : '0.0';
  };

  const getStatusColor = (status: ABTest['status']) => {
    switch (status) {
      case 'running': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold">A/B Testing Manager</h2>
        <Button>Create New Test</Button>
      </div>

      <Tabs defaultValue="active" className="w-full">
        <TabsList>
          <TabsTrigger value="active">Active Tests</TabsTrigger>
          <TabsTrigger value="completed">Completed Tests</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="active" className="space-y-4">
          <div className="grid gap-4">
            {tests.filter(test => test.status === 'running' || test.status === 'paused').map(test => (
              <Card key={test.id} className="cursor-pointer hover:shadow-lg transition-shadow"
                    onClick={() => setSelectedTest(test)}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">{test.name}</h3>
                      <p className="text-gray-600 text-sm">
                        Started {new Date(test.startDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(test.status)}>
                        {test.status.charAt(0).toUpperCase() + test.status.slice(1)}
                      </Badge>
                      <div className="flex gap-1">
                        <Button size="sm" variant="outline">
                          <Play className="h-4 w-4" />
                        </Button>
                        <Button size="sm" variant="outline">
                          <Pause className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>

                  <div className="grid grid-cols-2 gap-6">
                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Variant A</span>
                        <span className="text-sm text-gray-500">{test.conversions.a.sent} sent</span>
                      </div>
                      <div className="text-sm text-gray-600">{test.templateA}</div>
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div className="text-center p-2 bg-blue-50 rounded">
                          <div className="font-semibold text-blue-600">
                            {calculateRate(test.conversions.a.opens, test.conversions.a.sent)}%
                          </div>
                          <div className="text-blue-600">Opens</div>
                        </div>
                        <div className="text-center p-2 bg-green-50 rounded">
                          <div className="font-semibold text-green-600">
                            {calculateRate(test.conversions.a.clicks, test.conversions.a.sent)}%
                          </div>
                          <div className="text-green-600">Clicks</div>
                        </div>
                        <div className="text-center p-2 bg-purple-50 rounded">
                          <div className="font-semibold text-purple-600">
                            {calculateRate(test.conversions.a.responses, test.conversions.a.sent)}%
                          </div>
                          <div className="text-purple-600">Responses</div>
                        </div>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">Variant B</span>
                        <span className="text-sm text-gray-500">{test.conversions.b.sent} sent</span>
                      </div>
                      <div className="text-sm text-gray-600">{test.templateB}</div>
                      <div className="grid grid-cols-3 gap-2 text-sm">
                        <div className="text-center p-2 bg-blue-50 rounded">
                          <div className="font-semibold text-blue-600">
                            {calculateRate(test.conversions.b.opens, test.conversions.b.sent)}%
                          </div>
                          <div className="text-blue-600">Opens</div>
                        </div>
                        <div className="text-center p-2 bg-green-50 rounded">
                          <div className="font-semibold text-green-600">
                            {calculateRate(test.conversions.b.clicks, test.conversions.b.sent)}%
                          </div>
                          <div className="text-green-600">Clicks</div>
                        </div>
                        <div className="text-center p-2 bg-purple-50 rounded">
                          <div className="font-semibold text-purple-600">
                            {calculateRate(test.conversions.b.responses, test.conversions.b.sent)}%
                          </div>
                          <div className="text-purple-600">Responses</div>
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="mt-4 pt-4 border-t">
                    <div className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">Statistical Confidence</span>
                      <span className="text-sm font-medium">{test.confidence}%</span>
                    </div>
                    <Progress value={test.confidence} className="mt-2" />
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="completed" className="space-y-4">
          <div className="grid gap-4">
            {tests.filter(test => test.status === 'completed').map(test => (
              <Card key={test.id}>
                <CardContent className="p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="font-semibold text-lg">{test.name}</h3>
                      <p className="text-gray-600 text-sm">
                        {new Date(test.startDate).toLocaleDateString()} - {test.endDate && new Date(test.endDate).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className="bg-green-100 text-green-800">
                        Winner: Variant {test.winner?.toUpperCase()}
                      </Badge>
                      <Badge className={getStatusColor(test.status)}>
                        Completed
                      </Badge>
                    </div>
                  </div>

                  <div className="grid grid-cols-4 gap-4 text-center">
                    <div className="p-3 bg-gray-50 rounded-lg">
                      <div className="text-2xl font-bold">{test.participants}</div>
                      <div className="text-sm text-gray-600">Total Participants</div>
                    </div>
                    <div className="p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{test.confidence}%</div>
                      <div className="text-sm text-blue-600">Confidence</div>
                    </div>
                    <div className="p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        +{((parseFloat(calculateRate(test.conversions.b.responses, test.conversions.b.sent)) - 
                            parseFloat(calculateRate(test.conversions.a.responses, test.conversions.a.sent)))).toFixed(1)}%
                      </div>
                      <div className="text-sm text-green-600">Improvement</div>
                    </div>
                    <div className="p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">14</div>
                      <div className="text-sm text-purple-600">Days Duration</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Key Insights
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-3 bg-green-50 border border-green-200 rounded-lg">
                    <div className="font-semibold text-green-800">Subject Line Impact</div>
                    <p className="text-sm text-green-700">
                      Personalized subject lines increase open rates by 23% on average
                    </p>
                  </div>
                  <div className="p-3 bg-blue-50 border border-blue-200 rounded-lg">
                    <div className="font-semibold text-blue-800">CTA Optimization</div>
                    <p className="text-sm text-blue-700">
                      Action-oriented CTAs perform 18% better than generic ones
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <BarChart3 className="h-5 w-5" />
                  Test Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="p-3 border rounded-lg">
                    <div className="font-semibold mb-1">Test Email Length</div>
                    <p className="text-sm text-gray-600">
                      Compare short vs. detailed email templates
                    </p>
                    <Button size="sm" className="mt-2">Create Test</Button>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="font-semibold mb-1">Send Time Optimization</div>
                    <p className="text-sm text-gray-600">
                      Test different send times for better engagement
                    </p>
                    <Button size="sm" className="mt-2">Create Test</Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export { ABTestingManager };
export default ABTestingManager;