import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Brain, GraduationCap, Sparkles, BarChart3, Settings } from 'lucide-react';
import AIEmailClassifier from './AIEmailClassifier';
import ClassificationTrainingDashboard from './ClassificationTrainingDashboard';
import EmailEntityExtractor from './EmailEntityExtractor';
import EmailSentimentAnalyzer from './EmailSentimentAnalyzer';

export default function AIEmailClassificationSystem() {
  const [activeTab, setActiveTab] = useState('classifier');

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        <div className="text-center space-y-2">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
            AI Email Classification System
          </h1>
          <p className="text-gray-600 text-lg">
            Machine learning-powered email analysis with continuous improvement
          </p>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-5 lg:w-auto">
            <TabsTrigger value="classifier" className="flex items-center gap-2">
              <Brain className="h-4 w-4" />
              <span className="hidden sm:inline">Classifier</span>
            </TabsTrigger>
            <TabsTrigger value="training" className="flex items-center gap-2">
              <GraduationCap className="h-4 w-4" />
              <span className="hidden sm:inline">Training</span>
            </TabsTrigger>
            <TabsTrigger value="entities" className="flex items-center gap-2">
              <Sparkles className="h-4 w-4" />
              <span className="hidden sm:inline">Entities</span>
            </TabsTrigger>
            <TabsTrigger value="sentiment" className="flex items-center gap-2">
              <BarChart3 className="h-4 w-4" />
              <span className="hidden sm:inline">Sentiment</span>
            </TabsTrigger>
            <TabsTrigger value="settings" className="flex items-center gap-2">
              <Settings className="h-4 w-4" />
              <span className="hidden sm:inline">Settings</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="classifier" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Email Classification</CardTitle>
                <CardDescription>
                  AI-powered classification of job-related emails with confidence scores
                </CardDescription>
              </CardHeader>
              <CardContent>
                <AIEmailClassifier />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="training" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Training Dashboard</CardTitle>
                <CardDescription>
                  Correct misclassifications to improve model accuracy over time
                </CardDescription>
              </CardHeader>
              <CardContent>
                <ClassificationTrainingDashboard />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="entities" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Entity Extraction</CardTitle>
                <CardDescription>
                  Extract companies, positions, keywords, dates, and locations from emails
                </CardDescription>
              </CardHeader>
              <CardContent>
                <EmailEntityExtractor />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="sentiment" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Sentiment Analysis</CardTitle>
                <CardDescription>
                  Detect positive (interview/offer) vs negative (rejection) emails with emotion breakdown
                </CardDescription>
              </CardHeader>
              <CardContent>
                <EmailSentimentAnalyzer />
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Model Settings</CardTitle>
                <CardDescription>
                  Configure classification thresholds and training parameters
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">Classification Confidence Threshold</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      Minimum confidence score required for automatic classification
                    </p>
                    <input type="range" min="0" max="100" defaultValue="80" className="w-full" />
                    <p className="text-sm text-gray-500 mt-1">Current: 80%</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <h3 className="font-semibold mb-2">Auto-Training</h3>
                    <p className="text-sm text-gray-600 mb-2">
                      Automatically retrain model after collecting corrections
                    </p>
                    <label className="flex items-center gap-2">
                      <input type="checkbox" defaultChecked />
                      <span className="text-sm">Enable auto-training</span>
                    </label>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
