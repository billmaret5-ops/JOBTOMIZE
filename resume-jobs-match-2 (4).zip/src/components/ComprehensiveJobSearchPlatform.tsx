import React, { useState, useMemo } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Search, MapPin, Briefcase, TrendingUp, Star, Users, Bell, BookmarkCheck, Filter, Sparkles, Target } from 'lucide-react';
import JobCard from './JobCard';
import JobFilters from './JobFilters';

export const ComprehensiveJobSearchPlatform: React.FC = () => {
  const [activeTab, setActiveTab] = useState('search');
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');
  const [sortBy, setSortBy] = useState('relevance');
  const [filters, setFilters] = useState<any>({});
  const [savedJobs, setSavedJobs] = useState<number[]>([]);
  const [savedSearches, setSavedSearches] = useState<any[]>([]);
  const [showFilters, setShowFilters] = useState(true);

  const jobListings = [
    { id: 1, title: 'Senior Frontend Developer', company: 'TechCorp Inc.', location: 'San Francisco, CA', type: 'Full-time', salary: '$120,000 - $160,000', description: 'Join our dynamic team to build cutting-edge web applications.', posted: '2 days ago', logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758783150041_11dd55b5.webp', tags: ['React', 'TypeScript'], matchScore: 95 },
    { id: 2, title: 'Full Stack Engineer', company: 'StartupXYZ', location: 'Remote', type: 'Full-time', salary: '$100,000 - $140,000', description: 'Work on exciting projects with modern technologies.', posted: '1 day ago', logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758783151917_1c006b61.webp', tags: ['Node.js', 'React'], matchScore: 88 },
    { id: 3, title: 'DevOps Engineer', company: 'CloudTech', location: 'Austin, TX', type: 'Full-time', salary: '$110,000 - $150,000', description: 'Manage cloud infrastructure and CI/CD pipelines.', posted: '3 days ago', logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758783154040_59c84884.webp', tags: ['AWS', 'Docker'], matchScore: 82 },
  ];

  const filteredJobs = useMemo(() => {
    return jobListings.filter(job => {
      const matchesSearch = !searchTerm || 
        job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
        job.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesLocation = !location || 
        job.location.toLowerCase().includes(location.toLowerCase());
      return matchesSearch && matchesLocation;
    });
  }, [searchTerm, location]);

  const handleSaveSearch = () => {
    if (searchTerm || location) {
      setSavedSearches([...savedSearches, { searchTerm, location, date: new Date() }]);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white py-16">
        <div className="max-w-7xl mx-auto px-4">
          <h1 className="text-5xl font-bold mb-4">Find Your Dream Job</h1>
          <p className="text-xl mb-8">Personalized job recommendations powered by AI</p>
          <div className="flex flex-col md:flex-row gap-4 max-w-4xl">
            <Input placeholder="Job title or keyword" value={searchTerm} onChange={(e) => setSearchTerm(e.target.value)} className="text-gray-900" />
            <Input placeholder="Location" value={location} onChange={(e) => setLocation(e.target.value)} className="text-gray-900" />
            <Button onClick={handleSaveSearch} className="bg-white text-blue-600 hover:bg-gray-100">Search Jobs</Button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-6 mb-8">
            <TabsTrigger value="search"><Search className="w-4 h-4 mr-2" />Search</TabsTrigger>
            <TabsTrigger value="recommended"><Sparkles className="w-4 h-4 mr-2" />For You</TabsTrigger>
            <TabsTrigger value="saved"><Star className="w-4 h-4 mr-2" />Saved ({savedJobs.length})</TabsTrigger>
            <TabsTrigger value="alerts"><Bell className="w-4 h-4 mr-2" />Alerts</TabsTrigger>
            <TabsTrigger value="searches"><BookmarkCheck className="w-4 h-4 mr-2" />Searches</TabsTrigger>
            <TabsTrigger value="matching"><Target className="w-4 h-4 mr-2" />Matching</TabsTrigger>
          </TabsList>

          <TabsContent value="search">
            <div className="flex gap-6">
              {showFilters && <div className="w-80"><JobFilters onFiltersChange={setFilters} /></div>}
              <div className="flex-1">
                <div className="flex justify-between mb-4">
                  <p className="text-gray-600">{filteredJobs.length} jobs found</p>
                  <Select value={sortBy} onValueChange={setSortBy}>
                    <SelectTrigger className="w-48"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="relevance">Most Relevant</SelectItem>
                      <SelectItem value="date">Most Recent</SelectItem>
                      <SelectItem value="salary">Highest Salary</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-4">
                  {filteredJobs.map(job => <JobCard key={job.id} job={job} onApply={() => {}} onSave={() => setSavedJobs([...savedJobs, job.id])} />)}
                </div>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="recommended">
            <div className="grid gap-6">
              <Card><CardHeader><CardTitle className="flex items-center gap-2"><Sparkles className="w-5 h-5 text-purple-600" />Top Matches Based on Your Profile</CardTitle></CardHeader><CardContent><div className="space-y-4">{jobListings.map(job => <JobCard key={job.id} job={job} onApply={() => {}} onSave={() => {}} />)}</div></CardContent></Card>
            </div>
          </TabsContent>

          <TabsContent value="saved">
            <Card><CardContent className="pt-6">{savedJobs.length === 0 ? <div className="text-center py-12"><Star className="w-16 h-16 mx-auto text-gray-400 mb-4" /><h3 className="text-xl font-semibold mb-2">No saved jobs yet</h3></div> : <div className="space-y-4">{jobListings.filter(j => savedJobs.includes(j.id)).map(job => <JobCard key={job.id} job={job} onApply={() => {}} onSave={() => {}} />)}</div>}</CardContent></Card>
          </TabsContent>

          <TabsContent value="alerts">
            <Card><CardHeader><CardTitle>Job Alerts</CardTitle></CardHeader><CardContent><p className="text-gray-600">Set up alerts to get notified about new jobs matching your criteria.</p><Button className="mt-4">Create Alert</Button></CardContent></Card>
          </TabsContent>

          <TabsContent value="searches">
            <Card><CardHeader><CardTitle>Saved Searches</CardTitle></CardHeader><CardContent>{savedSearches.length === 0 ? <p className="text-gray-600">No saved searches yet</p> : <div className="space-y-2">{savedSearches.map((s, i) => <div key={i} className="p-4 border rounded-lg"><p className="font-medium">{s.searchTerm} in {s.location}</p></div>)}</div>}</CardContent></Card>
          </TabsContent>

          <TabsContent value="matching">
            <Card><CardHeader><CardTitle>Job Matching Dashboard</CardTitle></CardHeader><CardContent><p className="text-gray-600 mb-4">See how well jobs match your skills and experience</p><div className="space-y-4">{jobListings.map(job => <div key={job.id} className="p-4 border rounded-lg"><div className="flex justify-between items-center"><div><h3 className="font-semibold">{job.title}</h3><p className="text-sm text-gray-600">{job.company}</p></div><Badge className="bg-green-100 text-green-800">{job.matchScore}% Match</Badge></div></div>)}</div></CardContent></Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default ComprehensiveJobSearchPlatform;
