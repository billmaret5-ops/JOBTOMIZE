import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { supabase } from '@/lib/supabase';
import { Bell, Plus, Edit, Trash2, AlertTriangle } from 'lucide-react';

export const AlertRoutingDashboard: React.FC = () => {
  const [rules, setRules] = useState<any[]>([]);
  const [incidents, setIncidents] = useState<any[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    severityLevels: ['high', 'critical'],
    confidenceThreshold: 80,
    channels: ['email'],
    recipients: { email: [], phone: [], slackChannels: [], teamsChannels: [] }
  });

  useEffect(() => {
    loadRules();
    loadIncidents();
  }, []);

  const loadRules = async () => {
    const { data } = await supabase
      .from('alert_routing_rules')
      .select('*')
      .order('created_at', { ascending: false });
    if (data) setRules(data);
  };

  const loadIncidents = async () => {
    const { data } = await supabase
      .from('incidents')
      .select('*')
      .order('created_at', { ascending: false })
      .limit(10);
    if (data) setIncidents(data);
  };

  const saveRule = async () => {
    const { error } = await supabase.from('alert_routing_rules').insert({
      name: formData.name,
      severity_levels: formData.severityLevels,
      confidence_threshold: formData.confidenceThreshold,
      channels: formData.channels,
      recipients: formData.recipients,
      enabled: true
    });

    if (!error) {
      setShowForm(false);
      loadRules();
    }
  };

  const toggleRule = async (id: string, enabled: boolean) => {
    await supabase.from('alert_routing_rules').update({ enabled }).eq('id', id);
    loadRules();
  };

  const deleteRule = async (id: string) => {
    await supabase.from('alert_routing_rules').delete().eq('id', id);
    loadRules();
  };

  const getSeverityColor = (severity: string) => {
    const colors: any = {
      low: 'bg-blue-500',
      medium: 'bg-yellow-500',
      high: 'bg-orange-500',
      critical: 'bg-red-500'
    };
    return colors[severity] || 'bg-gray-500';
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Alert Routing</h2>
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="w-4 h-4 mr-2" />
          New Rule
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardHeader>
            <CardTitle>Create Alert Routing Rule</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Rule Name</label>
              <Input
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                placeholder="e.g., Critical Alerts to Team"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Severity Levels</label>
              <div className="flex gap-2">
                {['low', 'medium', 'high', 'critical'].map(level => (
                  <label key={level} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.severityLevels.includes(level)}
                      onChange={(e) => {
                        const levels = e.target.checked
                          ? [...formData.severityLevels, level]
                          : formData.severityLevels.filter(l => l !== level);
                        setFormData({ ...formData, severityLevels: levels });
                      }}
                    />
                    {level}
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Confidence Threshold (%)</label>
              <Input
                type="number"
                value={formData.confidenceThreshold}
                onChange={(e) => setFormData({ ...formData, confidenceThreshold: parseInt(e.target.value) })}
                min="0"
                max="100"
              />
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">Notification Channels</label>
              <div className="flex gap-2">
                {['email', 'sms', 'slack', 'teams', 'push'].map(channel => (
                  <label key={channel} className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={formData.channels.includes(channel)}
                      onChange={(e) => {
                        const channels = e.target.checked
                          ? [...formData.channels, channel]
                          : formData.channels.filter(c => c !== channel);
                        setFormData({ ...formData, channels });
                      }}
                    />
                    {channel}
                  </label>
                ))}
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={saveRule}>Save Rule</Button>
              <Button variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Active Routing Rules</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rules.map(rule => (
              <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <h3 className="font-semibold">{rule.name}</h3>
                  <div className="flex gap-2 mt-2">
                    {rule.severity_levels.map((level: string) => (
                      <Badge key={level} className={getSeverityColor(level)}>{level}</Badge>
                    ))}
                  </div>
                  <p className="text-sm text-gray-600 mt-1">
                    Confidence: {rule.confidence_threshold}% | Channels: {rule.channels.join(', ')}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={rule.enabled}
                    onCheckedChange={(checked) => toggleRule(rule.id, checked)}
                  />
                  <Button variant="ghost" size="sm" onClick={() => deleteRule(rule.id)}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Incidents</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-2">
            {incidents.map(incident => (
              <div key={incident.id} className="flex items-center justify-between p-3 border rounded">
                <div className="flex items-center gap-3">
                  <AlertTriangle className={`w-5 h-5 ${getSeverityColor(incident.severity)}`} />
                  <div>
                    <p className="font-medium">{incident.title}</p>
                    <p className="text-sm text-gray-600">{new Date(incident.created_at).toLocaleString()}</p>
                  </div>
                </div>
                <Badge>{incident.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
