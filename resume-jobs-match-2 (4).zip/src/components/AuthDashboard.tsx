import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Shield, Users, Key, Mail, Settings, Lock } from 'lucide-react';
import { useAuth } from '@/contexts/AuthContext';
import { UserRoleManager } from './UserRoleManager';
import { AccountSettings } from './AccountSettings';
import { AuthModal } from './auth/AuthModal';

interface AuthStats {
  totalUsers: number;
  activeUsers: number;
  verifiedEmails: number;
  apiUsers: number;
}

export function AuthDashboard() {
  const { user, profile, emailVerified } = useAuth();
  const [stats, setStats] = useState<AuthStats>({
    totalUsers: 0,
    activeUsers: 0,
    verifiedEmails: 0,
    apiUsers: 0
  });
  const [showAuthModal, setShowAuthModal] = useState(false);

  useEffect(() => {
    // Mock stats - in real app, fetch from API
    setStats({
      totalUsers: 1247,
      activeUsers: 892,
      verifiedEmails: 1156,
      apiUsers: 234
    });
  }, []);

  if (!user) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center">
        <Card className="w-full max-w-md">
          <CardHeader className="text-center">
            <CardTitle className="flex items-center justify-center gap-2">
              <Shield className="h-6 w-6" />
              Authentication Required
            </CardTitle>
          </CardHeader>
          <CardContent className="text-center space-y-4">
            <p className="text-gray-600">Please sign in to access the authentication dashboard</p>
            <Button onClick={() => setShowAuthModal(true)} className="w-full">
              Sign In
            </Button>
          </CardContent>
        </Card>
        <AuthModal isOpen={showAuthModal} onClose={() => setShowAuthModal(false)} />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* User Status Card */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Authentication Status
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="text-center p-4 bg-blue-50 rounded-lg">
              <Users className="h-8 w-8 text-blue-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-blue-600">{stats.totalUsers}</div>
              <div className="text-sm text-gray-600">Total Users</div>
            </div>
            <div className="text-center p-4 bg-green-50 rounded-lg">
              <Shield className="h-8 w-8 text-green-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-green-600">{stats.activeUsers}</div>
              <div className="text-sm text-gray-600">Active Users</div>
            </div>
            <div className="text-center p-4 bg-purple-50 rounded-lg">
              <Mail className="h-8 w-8 text-purple-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-purple-600">{stats.verifiedEmails}</div>
              <div className="text-sm text-gray-600">Verified Emails</div>
            </div>
            <div className="text-center p-4 bg-orange-50 rounded-lg">
              <Key className="h-8 w-8 text-orange-600 mx-auto mb-2" />
              <div className="text-2xl font-bold text-orange-600">{stats.apiUsers}</div>
              <div className="text-sm text-gray-600">API Users</div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Current User Info */}
      <Card>
        <CardHeader>
          <CardTitle>Current User Profile</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
              <Shield className="h-6 w-6 text-blue-600" />
            </div>
            <div className="flex-1">
              <p className="font-medium">{profile?.full_name || user.email}</p>
              <p className="text-sm text-gray-600">{user.email}</p>
              <div className="flex items-center gap-2 mt-1">
                <Badge variant={emailVerified ? "default" : "secondary"}>
                  {emailVerified ? "Verified" : "Unverified"}
                </Badge>
                <Badge variant="outline">User</Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Management Tabs */}
      <Tabs defaultValue="settings" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="settings">Account Settings</TabsTrigger>
          <TabsTrigger value="users">User Management</TabsTrigger>
        </TabsList>
        
        <TabsContent value="settings" className="mt-6">
          <AccountSettings />
        </TabsContent>
        
        <TabsContent value="users" className="mt-6">
          <UserRoleManager />
        </TabsContent>
      </Tabs>
    </div>
  );
}