import React, { useState } from 'react';
import { supabase } from '@/lib/supabase';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Upload, FileText, X, Download } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '@/contexts/AuthContext';

interface CoverLetterUploadProps {
  applicationId?: string;
  existingCoverLetterUrl?: string;
  onUploadComplete?: (url: string) => void;
}

export function CoverLetterUpload({
  applicationId, 
  existingCoverLetterUrl, 
  onUploadComplete 
}: CoverLetterUploadProps) {
  const { user } = useAuth();
  const [uploading, setUploading] = useState(false);
  const [coverLetterUrl, setCoverLetterUrl] = useState(existingCoverLetterUrl || '');

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    try {
      setUploading(true);
      const file = event.target.files?.[0];
      if (!file || !user) return;

      if (file.type !== 'application/pdf' && !file.type.startsWith('text/')) {
        toast.error('Please upload a PDF or text file');
        return;
      }

      const fileExt = file.name.split('.').pop();
      const fileName = `${user.id}/${applicationId || 'general'}_${Date.now()}.${fileExt}`;

      const { error: uploadError } = await supabase.storage
        .from('cover-letters')
        .upload(fileName, file);

      if (uploadError) throw uploadError;

      const { data } = supabase.storage
        .from('cover-letters')
        .getPublicUrl(fileName);

      setCoverLetterUrl(data.publicUrl);
      onUploadComplete?.(data.publicUrl);
      toast.success('Cover letter uploaded successfully');

    } catch (error) {
      console.error('Upload error:', error);
      toast.error('Failed to upload cover letter');
    } finally {
      setUploading(false);
    }
  };

  const handleRemove = async () => {
    if (!coverLetterUrl) return;
    
    try {
      const fileName = coverLetterUrl.split('/').pop();
      if (fileName) {
        await supabase.storage
          .from('cover-letters')
          .remove([`${user?.id}/${fileName}`]);
      }
      
      setCoverLetterUrl('');
      onUploadComplete?.('');
      toast.success('Cover letter removed');
    } catch (error) {
      toast.error('Failed to remove cover letter');
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="w-5 h-5" />
          Cover Letter
        </CardTitle>
      </CardHeader>
      <CardContent>
        {coverLetterUrl ? (
          <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
            <div className="flex items-center gap-2">
              <FileText className="w-4 h-4 text-blue-500" />
              <span className="text-sm">Cover letter uploaded</span>
            </div>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(coverLetterUrl, '_blank')}
              >
                <Download className="w-4 h-4" />
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={handleRemove}
              >
                <X className="w-4 h-4" />
              </Button>
            </div>
          </div>
        ) : (
          <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
            <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
            <p className="text-sm text-gray-600 mb-4">Upload your cover letter</p>
            <input
              type="file"
              accept=".pdf,.txt,.doc,.docx"
              onChange={handleFileUpload}
              disabled={uploading}
              className="hidden"
              id="cover-letter-upload"
            />
            <Button
              variant="outline"
              disabled={uploading}
              onClick={() => document.getElementById('cover-letter-upload')?.click()}
            >
              {uploading ? 'Uploading...' : 'Choose File'}
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
}