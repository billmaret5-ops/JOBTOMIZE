import React, { useEffect } from 'react';
import { useRealTimeNotifications } from '@/hooks/useRealTimeNotifications';
import { supabase } from '@/lib/supabase';

export default function EmailNotificationIntegration() {
  const { createNotification } = useRealTimeNotifications();

  useEffect(() => {
    // Listen for email tracking events from the database
    const channel = supabase
      .channel('email_analytics')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'email_analytics'
      }, async (payload) => {
        const event = payload.new;
        
        // Create real-time notification based on email event
        if (event.event_type === 'open') {
          await createNotification(
            'email_opened',
            '📧 Email Opened',
            `Your email was opened by ${event.recipient_email}`,
            {
              email: event.recipient_email,
              timestamp: event.timestamp,
              campaign_id: event.campaign_id
            },
            'medium'
          );
        }

        if (event.event_type === 'click') {
          await createNotification(
            'email_clicked',
            '🔗 Email Link Clicked',
            `Someone clicked a link in your email to ${event.recipient_email}`,
            {
              email: event.recipient_email,
              timestamp: event.timestamp,
              url: event.metadata?.url,
              campaign_id: event.campaign_id
            },
            'medium'
          );
        }

        if (event.event_type === 'bounce') {
          await createNotification(
            'email_bounce',
            '⚠️ Email Bounced',
            `Email to ${event.recipient_email} bounced`,
            {
              email: event.recipient_email,
              reason: event.metadata?.reason
            },
            'high'
          );
        }
      })
      .subscribe();

    // Listen for interview invitations
    const interviewChannel = supabase
      .channel('interviews')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'interviews'
      }, async (payload) => {
        const interview = payload.new;
        
        await createNotification(
          'interview_invitation',
          '📅 New Interview Invitation',
          `You have a new interview scheduled for ${new Date(interview.scheduled_at).toLocaleDateString()}`,
          {
            interview_id: interview.id,
            company: interview.company,
            position: interview.position,
            scheduled_at: interview.scheduled_at
          },
          'high'
        );
      })
      .subscribe();

    // Listen for job application updates
    const applicationChannel = supabase
      .channel('job_applications')
      .on('postgres_changes', {
        event: 'UPDATE',
        schema: 'public',
        table: 'job_applications'
      }, async (payload) => {
        const application = payload.new;
        const oldApplication = payload.old;
        
        // Check if status changed
        if (application.status !== oldApplication.status) {
          let title = '📝 Application Update';
          let message = `Your application status changed to ${application.status}`;
          let priority: 'low' | 'medium' | 'high' | 'urgent' = 'medium';

          if (application.status === 'interview') {
            title = '🎉 Interview Invitation!';
            message = `Great news! You've been invited for an interview`;
            priority = 'high';
          } else if (application.status === 'rejected') {
            title = '❌ Application Update';
            message = `Your application was not selected this time`;
            priority = 'medium';
          } else if (application.status === 'offer') {
            title = '🎊 Job Offer!';
            message = `Congratulations! You received a job offer`;
            priority = 'urgent';
          }

          await createNotification(
            'application_update',
            title,
            message,
            {
              application_id: application.id,
              job_title: application.job_title,
              company: application.company,
              old_status: oldApplication.status,
              new_status: application.status
            },
            priority
          );
        }
      })
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
      supabase.removeChannel(interviewChannel);
      supabase.removeChannel(applicationChannel);
    };
  }, [createNotification]);

  // This component doesn't render anything visible
  return null;
}