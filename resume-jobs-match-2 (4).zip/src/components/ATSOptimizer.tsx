import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, AlertTriangle, XCircle, Target, TrendingUp, FileText } from 'lucide-react';
import { generateAIContent } from '@/lib/aiService';


interface ATSAnalysis {
  overallScore: number;
  keywordDensity: number;
  formatScore: number;
  readabilityScore: number;
  sectionScore: number;
  issues: Array<{
    type: 'error' | 'warning' | 'success';
    message: string;
    suggestion: string;
  }>;
  keywords: Array<{
    word: string;
    frequency: number;
    importance: 'high' | 'medium' | 'low';
    found: boolean;
  }>;
  improvements: string[];
}

interface ATSOptimizerProps {
  resumeContent: any;
  jobDescription: string;
  onOptimize: (optimizedContent: any) => void;
}

export function ATSOptimizer({ resumeContent, jobDescription, onOptimize }: ATSOptimizerProps) {
  const [analysis, setAnalysis] = useState<ATSAnalysis | null>(null);
  const [loading, setLoading] = useState(false);
  const [activeTab, setActiveTab] = useState('analysis');

  const analyzeATS = async () => {
    setLoading(true);
    try {
      // Use AI to analyze resume
      const content = await generateAIContent({
        action: 'improve_writing',
        data: {
          text: JSON.stringify(resumeContent),
          tone: 'professional'
        }
      });

      // Mock analysis with AI suggestions
      const analysis: ATSAnalysis = {
        overallScore: 87,
        keywordDensity: 92,
        formatScore: 85,
        readabilityScore: 88,
        sectionScore: 90,
        issues: [
          { type: 'success', message: 'Contact information is properly formatted', suggestion: 'Keep current format' },
          { type: 'warning', message: 'Missing quantified achievements', suggestion: 'Add numbers and metrics' }
        ],
        keywords: [
          { word: 'JavaScript', frequency: 5, importance: 'high', found: true },
          { word: 'React', frequency: 3, importance: 'high', found: true }
        ],
        improvements: content.split('\n').filter(s => s.trim()).slice(0, 5)
      };
      
      setAnalysis(analysis);
      setActiveTab('results');
    } catch (error) {
      console.error('ATS analysis failed:', error);
      alert('ATS analysis failed. Please try again.');
    } finally {
      setLoading(false);
    }
  };


  const applyOptimizations = () => {
    if (!analysis || !resumeContent) return;
    
    // Apply automatic optimizations
    const optimized = { ...resumeContent };
    
    // Add missing keywords to skills
    const missingKeywords = analysis.keywords
      .filter(k => !k.found && k.importance === 'high')
      .map(k => k.word);
    
    if (optimized.skills && missingKeywords.length > 0) {
      optimized.skills = [...optimized.skills, ...missingKeywords];
    }
    
    // Enhance summary with keywords
    if (optimized.summary) {
      optimized.summary += ` Experienced in ${missingKeywords.join(', ')}.`;
    }
    
    onOptimize(optimized);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 70) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getIssueIcon = (type: string) => {
    switch (type) {
      case 'success': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-600" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <div className="flex items-center justify-center gap-2 mb-4">
          <Target className="h-8 w-8 text-red-600" />
          <h2 className="text-2xl font-bold">Beat The Hiring Robots</h2>
        </div>
        <p className="text-gray-600">
          Companies use robots to auto-reject 75% of applicants. We reverse-engineer their AI to get YOU the interview.
        </p>

      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="analysis">Analysis</TabsTrigger>
          <TabsTrigger value="results" disabled={!analysis}>Results</TabsTrigger>
          <TabsTrigger value="optimize" disabled={!analysis}>Optimize</TabsTrigger>
        </TabsList>

        <TabsContent value="analysis" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>ATS Compatibility Check</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <p className="text-gray-600">
                Analyze your resume against the job description to identify ATS optimization opportunities.
              </p>
              <Button 
                onClick={analyzeATS}
                disabled={loading || !resumeContent}
                className="w-full"
              >
                {loading ? 'Analyzing...' : 'Run ATS Analysis'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-6">
          {analysis && (
            <>
              <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-4">
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(analysis.overallScore)}`}>
                      {analysis.overallScore}%
                    </div>
                    <div className="text-sm text-gray-600">Overall Score</div>
                    <Progress value={analysis.overallScore} className="mt-2" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(analysis.keywordDensity)}`}>
                      {analysis.keywordDensity}%
                    </div>
                    <div className="text-sm text-gray-600">Keywords</div>
                    <Progress value={analysis.keywordDensity} className="mt-2" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(analysis.formatScore)}`}>
                      {analysis.formatScore}%
                    </div>
                    <div className="text-sm text-gray-600">Format</div>
                    <Progress value={analysis.formatScore} className="mt-2" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(analysis.readabilityScore)}`}>
                      {analysis.readabilityScore}%
                    </div>
                    <div className="text-sm text-gray-600">Readability</div>
                    <Progress value={analysis.readabilityScore} className="mt-2" />
                  </CardContent>
                </Card>
                
                <Card>
                  <CardContent className="p-4 text-center">
                    <div className={`text-2xl font-bold ${getScoreColor(analysis.sectionScore)}`}>
                      {analysis.sectionScore}%
                    </div>
                    <div className="text-sm text-gray-600">Structure</div>
                    <Progress value={analysis.sectionScore} className="mt-2" />
                  </CardContent>
                </Card>
              </div>

              <div className="grid lg:grid-cols-2 gap-6">
                <Card>
                  <CardHeader>
                    <CardTitle>Issues & Recommendations</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {analysis.issues.map((issue, index) => (
                      <div key={index} className="flex items-start gap-3 p-3 border rounded-lg">
                        {getIssueIcon(issue.type)}
                        <div className="flex-1">
                          <div className="font-medium text-sm">{issue.message}</div>
                          <div className="text-xs text-gray-600 mt-1">{issue.suggestion}</div>
                        </div>
                      </div>
                    ))}
                  </CardContent>
                </Card>

                <Card>
                  <CardHeader>
                    <CardTitle>Keyword Analysis</CardTitle>
                  </CardHeader>
                  <CardContent className="space-y-2">
                    {analysis.keywords.map((keyword, index) => (
                      <div key={index} className="flex items-center justify-between p-2 border rounded">
                        <div className="flex items-center gap-2">
                          <Badge variant={keyword.found ? "default" : "destructive"}>
                            {keyword.word}
                          </Badge>
                          <span className="text-xs text-gray-600">
                            {keyword.frequency}x
                          </span>
                        </div>
                        <Badge variant="outline" className="text-xs">
                          {keyword.importance}
                        </Badge>
                      </div>
                    ))}
                  </CardContent>
                </Card>
              </div>
            </>
          )}
        </TabsContent>

        <TabsContent value="optimize" className="space-y-6">
          {analysis && (
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5" />
                  Optimization Recommendations
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="space-y-2">
                  {analysis.improvements.map((improvement, index) => (
                    <div key={index} className="flex items-start gap-2 p-3 bg-blue-50 rounded-lg">
                      <span className="text-blue-600 font-bold">{index + 1}.</span>
                      <span className="text-sm">{improvement}</span>
                    </div>
                  ))}
                </div>
                
                <div className="flex gap-4 pt-4">
                  <Button onClick={applyOptimizations} className="flex-1">
                    <FileText className="h-4 w-4 mr-2" />
                    Apply Auto-Optimizations
                  </Button>
                  <Button variant="outline" className="flex-1">
                    Download Report
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}