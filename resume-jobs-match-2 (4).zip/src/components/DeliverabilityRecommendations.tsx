import React from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { CheckCircle, AlertTriangle, XCircle, Lightbulb, TrendingUp, Shield, Mail } from 'lucide-react';

const DeliverabilityRecommendations = () => {
  const recommendations = [
    {
      id: 1,
      priority: 'high',
      category: 'Authentication',
      title: 'Implement BIMI Record',
      description: 'Add Brand Indicators for Message Identification to improve brand recognition',
      impact: 'High',
      effort: 'Medium',
      steps: [
        'Create verified mark certificate',
        'Add BIMI DNS record',
        'Test implementation'
      ]
    },
    {
      id: 2,
      priority: 'medium',
      category: 'Content',
      title: 'Optimize Subject Lines',
      description: 'Current subject lines trigger spam filters. Use A/B testing for optimization',
      impact: 'Medium',
      effort: 'Low',
      steps: [
        'Avoid spam trigger words',
        'Test subject line variations',
        'Monitor open rates'
      ]
    },
    {
      id: 3,
      priority: 'high',
      category: 'List Hygiene',
      title: 'Clean Inactive Subscribers',
      description: 'Remove subscribers who haven\'t engaged in 6+ months',
      impact: 'High',
      effort: 'Low',
      steps: [
        'Identify inactive subscribers',
        'Send re-engagement campaign',
        'Remove non-responsive contacts'
      ]
    },
    {
      id: 4,
      priority: 'low',
      category: 'Infrastructure',
      title: 'Dedicated IP Warmup',
      description: 'Gradually increase sending volume on dedicated IP',
      impact: 'Medium',
      effort: 'High',
      steps: [
        'Start with low volume',
        'Gradually increase daily sends',
        'Monitor reputation metrics'
      ]
    }
  ];

  const insights = [
    {
      metric: 'Bounce Rate',
      current: '2.1%',
      benchmark: '<2%',
      status: 'warning',
      suggestion: 'Implement real-time email validation'
    },
    {
      metric: 'Spam Rate',
      current: '0.8%',
      benchmark: '<0.5%',
      status: 'warning',
      suggestion: 'Review content and authentication'
    },
    {
      metric: 'Unsubscribe Rate',
      current: '0.3%',
      benchmark: '<0.5%',
      status: 'good',
      suggestion: 'Maintain current practices'
    },
    {
      metric: 'Open Rate',
      current: '24.7%',
      benchmark: '>20%',
      status: 'good',
      suggestion: 'Continue optimizing subject lines'
    }
  ];

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'good': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-500" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <AlertTriangle className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Deliverability Recommendations</h2>
          <p className="text-gray-600">AI-powered insights to improve your email delivery</p>
        </div>
        <Button variant="outline">
          <TrendingUp className="h-4 w-4 mr-2" />
          Generate Report
        </Button>
      </div>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Lightbulb className="h-5 w-5 text-yellow-500" />
            Performance Insights
          </CardTitle>
          <CardDescription>Compare your metrics against industry benchmarks</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {insights.map((insight, index) => (
              <div key={index} className="p-4 border rounded-lg">
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium text-sm">{insight.metric}</h4>
                  {getStatusIcon(insight.status)}
                </div>
                <div className="space-y-1">
                  <div className="flex justify-between text-sm">
                    <span>Current:</span>
                    <span className="font-medium">{insight.current}</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Benchmark:</span>
                    <span className="text-gray-600">{insight.benchmark}</span>
                  </div>
                  <p className="text-xs text-gray-600 mt-2">{insight.suggestion}</p>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recommendations */}
      <Card>
        <CardHeader>
          <CardTitle>Action Items</CardTitle>
          <CardDescription>Prioritized recommendations to improve deliverability</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.map((rec) => (
              <div key={rec.id} className="p-6 border rounded-lg hover:shadow-md transition-shadow">
                <div className="flex items-start justify-between mb-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <Badge className={getPriorityColor(rec.priority)}>
                        {rec.priority.toUpperCase()}
                      </Badge>
                      <Badge variant="outline">{rec.category}</Badge>
                    </div>
                    <h3 className="text-lg font-semibold mb-2">{rec.title}</h3>
                    <p className="text-gray-600 mb-4">{rec.description}</p>
                    
                    <div className="flex gap-4 mb-4">
                      <div className="text-sm">
                        <span className="text-gray-500">Impact:</span>
                        <span className="ml-1 font-medium">{rec.impact}</span>
                      </div>
                      <div className="text-sm">
                        <span className="text-gray-500">Effort:</span>
                        <span className="ml-1 font-medium">{rec.effort}</span>
                      </div>
                    </div>

                    <div>
                      <h4 className="font-medium mb-2">Implementation Steps:</h4>
                      <ul className="space-y-1">
                        {rec.steps.map((step, stepIndex) => (
                          <li key={stepIndex} className="text-sm text-gray-600 flex items-center gap-2">
                            <div className="w-1.5 h-1.5 bg-blue-500 rounded-full"></div>
                            {step}
                          </li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  
                  <Button size="sm" className="ml-4">
                    Implement
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Quick Actions */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <Shield className="h-8 w-8 text-blue-500" />
              <div>
                <h3 className="font-semibold">Authentication Check</h3>
                <p className="text-sm text-gray-600">Verify SPF, DKIM, DMARC</p>
              </div>
            </div>
            <Button className="w-full" variant="outline">Run Check</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <Mail className="h-8 w-8 text-green-500" />
              <div>
                <h3 className="font-semibold">List Cleanup</h3>
                <p className="text-sm text-gray-600">Remove invalid emails</p>
              </div>
            </div>
            <Button className="w-full" variant="outline">Start Cleanup</Button>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <TrendingUp className="h-8 w-8 text-purple-500" />
              <div>
                <h3 className="font-semibold">Warmup Plan</h3>
                <p className="text-sm text-gray-600">Improve sender reputation</p>
              </div>
            </div>
            <Button className="w-full" variant="outline">Create Plan</Button>
          </CardContent>
        </Card>
      </div>

      <Alert>
        <Lightbulb className="h-4 w-4" />
        <AlertDescription>
          <strong>Pro Tip:</strong> Focus on high-priority recommendations first. 
          Implementing list hygiene and authentication improvements can boost your sender score by 10-15 points.
        </AlertDescription>
      </Alert>
    </div>
  );
};

export default DeliverabilityRecommendations;