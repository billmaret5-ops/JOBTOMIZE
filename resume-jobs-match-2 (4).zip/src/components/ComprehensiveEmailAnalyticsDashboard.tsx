import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { EmailMetricsOverview } from './analytics/EmailMetricsOverview';
import { EngagementMetricsChart } from './analytics/EngagementMetricsChart';
import { ConversionFunnelChart } from './analytics/ConversionFunnelChart';
import { ABTestComparisonChart } from './analytics/ABTestComparisonChart';
import { RecipientBehaviorAnalysis } from './analytics/RecipientBehaviorAnalysis';
import { ExportManager } from './analytics/ExportManager';
import { 
  BarChart3, 
  TrendingUp, 
  Users, 
  Mail, 
  RefreshCw,
  Filter,
  Calendar,
  Download
} from 'lucide-react';

interface EmailAnalyticsDashboardProps {
  campaignId?: string;
}

export const ComprehensiveEmailAnalyticsDashboard: React.FC<EmailAnalyticsDashboardProps> = ({ campaignId }) => {
  const [isRealTime, setIsRealTime] = useState(false);
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | '1y'>('30d');
  const [selectedCampaign, setSelectedCampaign] = useState<string>('all');
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // Mock data - in real app, this would come from API
  const [metrics, setMetrics] = useState({
    totalSent: 15420,
    openRate: 24.8,
    clickRate: 3.2,
    bounceRate: 2.1,
    unsubscribeRate: 0.3,
    conversions: 156
  });

  const previousMetrics = {
    openRate: 22.1,
    clickRate: 2.8,
    bounceRate: 2.5,
    conversions: 142
  };

  const engagementData = [
    { date: '2024-01-01', opens: 25.2, clicks: 3.4, bounces: 2.0, conversions: 12 },
    { date: '2024-01-02', opens: 23.8, clicks: 3.1, bounces: 2.2, conversions: 10 },
    { date: '2024-01-03', opens: 26.1, clicks: 3.6, bounces: 1.9, conversions: 14 },
    { date: '2024-01-04', opens: 24.5, clicks: 3.2, bounces: 2.1, conversions: 11 },
    { date: '2024-01-05', opens: 27.3, clicks: 3.8, bounces: 1.8, conversions: 16 }
  ];

  const funnelData = [
    { stage: 'Sent', count: 15420, percentage: 100, color: '#3b82f6' },
    { stage: 'Delivered', count: 15096, percentage: 97.9, color: '#10b981' },
    { stage: 'Opened', count: 3824, percentage: 24.8, color: '#f59e0b' },
    { stage: 'Clicked', count: 493, percentage: 3.2, color: '#8b5cf6' },
    { stage: 'Converted', count: 156, percentage: 1.0, color: '#ef4444' }
  ];

  const abTestData = [
    {
      name: 'Variant A',
      openRate: 24.8,
      clickRate: 3.2,
      conversionRate: 1.0,
      sampleSize: 7710,
      confidence: 95.2,
      isWinner: true
    },
    {
      name: 'Variant B',
      openRate: 22.1,
      clickRate: 2.8,
      conversionRate: 0.8,
      sampleSize: 7710,
      confidence: 95.2
    }
  ];

  const recipientData = [
    {
      id: '1',
      email: 'john.doe@example.com',
      name: 'John Doe',
      totalEmails: 45,
      opens: 32,
      clicks: 8,
      lastActivity: '2024-01-15',
      location: 'New York, NY',
      device: 'desktop' as const,
      engagementScore: 85,
      segments: ['High Engagement', 'VIP'],
      clickHeatmap: [
        { link: 'Apply Now Button', clicks: 5 },
        { link: 'Company Website', clicks: 2 },
        { link: 'Job Description', clicks: 1 }
      ]
    },
    {
      id: '2',
      email: 'jane.smith@example.com',
      name: 'Jane Smith',
      totalEmails: 38,
      opens: 28,
      clicks: 12,
      lastActivity: '2024-01-14',
      location: 'San Francisco, CA',
      device: 'mobile' as const,
      engagementScore: 92,
      segments: ['High Engagement', 'Mobile Users'],
      clickHeatmap: [
        { link: 'Apply Now Button', clicks: 8 },
        { link: 'Salary Information', clicks: 3 },
        { link: 'Benefits Page', clicks: 1 }
      ]
    }
  ];

  // Simulate real-time updates
  useEffect(() => {
    if (isRealTime) {
      const interval = setInterval(() => {
        setMetrics(prev => ({
          ...prev,
          totalSent: prev.totalSent + Math.floor(Math.random() * 10),
          openRate: prev.openRate + (Math.random() - 0.5) * 0.2,
          clickRate: prev.clickRate + (Math.random() - 0.5) * 0.1
        }));
        setLastUpdated(new Date());
      }, 5000);

      return () => clearInterval(interval);
    }
  }, [isRealTime]);

  const handleExport = async (config: any) => {
    console.log('Exporting data with config:', config);
    // Simulate export process
    await new Promise(resolve => setTimeout(resolve, 2000));
  };

  const campaigns = [
    { id: 'all', name: 'All Campaigns' },
    { id: 'welcome', name: 'Welcome Series' },
    { id: 'followup', name: 'Job Application Follow-up' },
    { id: 'interview', name: 'Interview Preparation' },
    { id: 'thankyou', name: 'Thank You Notes' }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Email Analytics Dashboard</h1>
          <p className="text-gray-600 mt-1">
            Comprehensive email performance tracking and analysis
          </p>
        </div>
        <div className="flex items-center gap-4">
          <Badge variant={isRealTime ? "default" : "outline"}>
            {isRealTime ? 'Live' : 'Static'}
          </Badge>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setIsRealTime(!isRealTime)}
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${isRealTime ? 'animate-spin' : ''}`} />
            {isRealTime ? 'Stop Live Updates' : 'Enable Live Updates'}
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex flex-wrap items-center gap-4">
            <div className="flex items-center gap-2">
              <Filter className="w-4 h-4 text-gray-500" />
              <select
                value={selectedCampaign}
                onChange={(e) => setSelectedCampaign(e.target.value)}
                className="px-3 py-2 border rounded-md"
              >
                {campaigns.map(campaign => (
                  <option key={campaign.id} value={campaign.id}>
                    {campaign.name}
                  </option>
                ))}
              </select>
            </div>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-gray-500" />
              <select
                value={timeRange}
                onChange={(e) => setTimeRange(e.target.value as any)}
                className="px-3 py-2 border rounded-md"
              >
                <option value="7d">Last 7 Days</option>
                <option value="30d">Last 30 Days</option>
                <option value="90d">Last 90 Days</option>
                <option value="1y">Last Year</option>
              </select>
            </div>
            <div className="text-sm text-gray-500">
              Last updated: {lastUpdated.toLocaleTimeString()}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Main Content */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Overview
          </TabsTrigger>
          <TabsTrigger value="engagement" className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4" />
            Engagement
          </TabsTrigger>
          <TabsTrigger value="funnel" className="flex items-center gap-2">
            <Mail className="w-4 h-4" />
            Funnel
          </TabsTrigger>
          <TabsTrigger value="abtest" className="flex items-center gap-2">
            A/B Tests
          </TabsTrigger>
          <TabsTrigger value="recipients" className="flex items-center gap-2">
            <Users className="w-4 h-4" />
            Recipients
          </TabsTrigger>
          <TabsTrigger value="export" className="flex items-center gap-2">
            <Download className="w-4 h-4" />
            Export
          </TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <EmailMetricsOverview metrics={metrics} previousMetrics={previousMetrics} />
          <EngagementMetricsChart 
            data={engagementData} 
            timeRange={timeRange}
            onTimeRangeChange={setTimeRange}
          />
        </TabsContent>

        <TabsContent value="engagement" className="space-y-6">
          <EngagementMetricsChart 
            data={engagementData} 
            timeRange={timeRange}
            onTimeRangeChange={setTimeRange}
          />
        </TabsContent>

        <TabsContent value="funnel" className="space-y-6">
          <ConversionFunnelChart 
            data={funnelData} 
            campaignName={selectedCampaign !== 'all' ? campaigns.find(c => c.id === selectedCampaign)?.name : undefined}
          />
        </TabsContent>

        <TabsContent value="abtest" className="space-y-6">
          <ABTestComparisonChart
            variants={abTestData}
            testName="Subject Line Test"
            status="completed"
            startDate="2024-01-01"
            endDate="2024-01-15"
          />
        </TabsContent>

        <TabsContent value="recipients" className="space-y-6">
          <RecipientBehaviorAnalysis recipients={recipientData} />
        </TabsContent>

        <TabsContent value="export" className="space-y-6">
          <ExportManager onExport={handleExport} />
        </TabsContent>
      </Tabs>
    </div>
  );
};