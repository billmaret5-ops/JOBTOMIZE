import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { RealTimeAnalyticsDashboard } from './RealTimeAnalyticsDashboard';
import { EngagementHeatmap } from './EngagementHeatmap';
import { AnalyticsFilters } from './AnalyticsFilters';
import { analyticsService, CampaignMetrics, AnalyticsFilters as FilterType } from '@/services/analyticsService';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { DateRange } from 'react-day-picker';
import { 
  TrendingUp, 
  BarChart3, 
  PieChart as PieChartIcon, 
  Activity,
  Target,
  DollarSign
} from 'lucide-react';

export const ComprehensiveAnalyticsDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<CampaignMetrics[]>([]);
  const [dateRange, setDateRange] = useState<DateRange | undefined>();
  const [selectedCampaign, setSelectedCampaign] = useState('all');
  const [selectedSegment, setSelectedSegment] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  const loadAnalytics = async () => {
    setIsLoading(true);
    try {
      const filters: FilterType = {
        startDate: dateRange?.from?.toISOString(),
        endDate: dateRange?.to?.toISOString(),
        campaignId: selectedCampaign !== 'all' ? selectedCampaign : undefined,
        segmentId: selectedSegment !== 'all' ? selectedSegment : undefined
      };
      
      const data = await analyticsService.getCampaignMetrics(filters);
      setMetrics(data);
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadAnalytics();
  }, [dateRange, selectedCampaign, selectedSegment]);

  const handleExport = async (format: 'csv' | 'pdf') => {
    try {
      const filters: FilterType = {
        startDate: dateRange?.from?.toISOString(),
        endDate: dateRange?.to?.toISOString(),
        campaignId: selectedCampaign !== 'all' ? selectedCampaign : undefined
      };
      
      const blob = await analyticsService.exportAnalyticsReport(filters, format);
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `analytics-report.${format}`;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
    }
  };

  const totalMetrics = metrics.reduce((acc, metric) => ({
    sent: acc.sent + metric.sent,
    opened: acc.opened + metric.opened,
    clicked: acc.clicked + metric.clicked,
    conversions: acc.conversions + metric.conversions,
    revenue: acc.revenue + metric.revenue
  }), { sent: 0, opened: 0, clicked: 0, conversions: 0, revenue: 0 });

  const avgOpenRate = metrics.length > 0 ? metrics.reduce((acc, m) => acc + m.open_rate, 0) / metrics.length : 0;
  const avgClickRate = metrics.length > 0 ? metrics.reduce((acc, m) => acc + m.click_rate, 0) / metrics.length : 0;
  const avgConversionRate = metrics.length > 0 ? metrics.reduce((acc, m) => acc + m.conversion_rate, 0) / metrics.length : 0;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
          <p className="text-muted-foreground">Comprehensive email campaign analytics and insights</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <AnalyticsFilters
            dateRange={dateRange}
            onDateRangeChange={setDateRange}
            selectedCampaign={selectedCampaign}
            onCampaignChange={setSelectedCampaign}
            selectedSegment={selectedSegment}
            onSegmentChange={setSelectedSegment}
            onExport={handleExport}
            onRefresh={loadAnalytics}
            isLoading={isLoading}
          />
        </div>

        <div className="lg:col-span-3">
          <Tabs defaultValue="overview" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="overview">Overview</TabsTrigger>
              <TabsTrigger value="realtime">Real-time</TabsTrigger>
              <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
              <TabsTrigger value="engagement">Engagement</TabsTrigger>
              <TabsTrigger value="roi">ROI</TabsTrigger>
            </TabsList>

            <TabsContent value="overview" className="space-y-4">
              {/* Summary Cards */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <BarChart3 className="h-4 w-4 text-blue-500" />
                      <span className="text-sm font-medium">Total Sent</span>
                    </div>
                    <div className="text-2xl font-bold">{totalMetrics.sent.toLocaleString()}</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Activity className="h-4 w-4 text-green-500" />
                      <span className="text-sm font-medium">Avg Open Rate</span>
                    </div>
                    <div className="text-2xl font-bold">{avgOpenRate.toFixed(1)}%</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <Target className="h-4 w-4 text-purple-500" />
                      <span className="text-sm font-medium">Avg Click Rate</span>
                    </div>
                    <div className="text-2xl font-bold">{avgClickRate.toFixed(1)}%</div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <div className="flex items-center gap-2 mb-2">
                      <DollarSign className="h-4 w-4 text-green-600" />
                      <span className="text-sm font-medium">Total Revenue</span>
                    </div>
                    <div className="text-2xl font-bold">${totalMetrics.revenue.toLocaleString()}</div>
                  </CardContent>
                </Card>
              </div>

              {/* Performance Chart */}
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Performance</CardTitle>
                </CardHeader>
                <CardContent>
                  <ResponsiveContainer width="100%" height={300}>
                    <BarChart data={metrics.slice(0, 10)}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis dataKey="name" />
                      <YAxis />
                      <Tooltip />
                      <Bar dataKey="open_rate" fill="#8884d8" name="Open Rate %" />
                      <Bar dataKey="click_rate" fill="#82ca9d" name="Click Rate %" />
                      <Bar dataKey="conversion_rate" fill="#ffc658" name="Conversion Rate %" />
                    </BarChart>
                  </ResponsiveContainer>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="realtime">
              <RealTimeAnalyticsDashboard />
            </TabsContent>

            <TabsContent value="campaigns" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>Campaign Comparison</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {metrics.slice(0, 5).map((campaign, index) => (
                      <div key={campaign.id} className="flex items-center justify-between p-4 border rounded-lg">
                        <div>
                          <h3 className="font-semibold">{campaign.name}</h3>
                          <p className="text-sm text-muted-foreground">
                            {campaign.sent.toLocaleString()} sent • {campaign.open_rate.toFixed(1)}% open rate
                          </p>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-bold">${campaign.revenue.toLocaleString()}</div>
                          <div className="text-sm text-muted-foreground">Revenue</div>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="engagement">
              <EngagementHeatmap />
            </TabsContent>

            <TabsContent value="roi" className="space-y-4">
              <Card>
                <CardHeader>
                  <CardTitle>ROI Analysis</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {totalMetrics.revenue > 0 ? ((totalMetrics.revenue / (totalMetrics.sent * 0.05)) * 100).toFixed(0) : 0}%
                      </div>
                      <div className="text-sm text-muted-foreground">ROI</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold">
                        ${totalMetrics.conversions > 0 ? (totalMetrics.revenue / totalMetrics.conversions).toFixed(2) : '0.00'}
                      </div>
                      <div className="text-sm text-muted-foreground">Revenue per Conversion</div>
                    </div>
                    <div className="text-center p-4 border rounded-lg">
                      <div className="text-2xl font-bold">
                        ${totalMetrics.sent > 0 ? (totalMetrics.revenue / totalMetrics.sent).toFixed(3) : '0.000'}
                      </div>
                      <div className="text-sm text-muted-foreground">Revenue per Email</div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};