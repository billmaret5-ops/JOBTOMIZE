import React, { useState, useEffect } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { DashboardBuilder } from './visualization/DashboardBuilder';
import { ScheduledReportManager } from './ScheduledReportManager';
import { DashboardSharingManager } from './DashboardSharingManager';
import { RealTimeDataDashboard } from './RealTimeDataDashboard';
import { SecureWebSocketDashboard } from './SecureWebSocketDashboard';

import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { dashboardBuilderService, CustomDashboard } from '@/services/dashboardBuilderService';
import { LayoutDashboard, Calendar, Share2, Settings, Radio, Shield } from 'lucide-react';


export const CustomDashboardManager: React.FC = () => {
  const [currentDashboard, setCurrentDashboard] = useState<CustomDashboard | null>(null);
  const [dashboards, setDashboards] = useState<CustomDashboard[]>([]);

  useEffect(() => {
    loadDashboards();
  }, []);

  const loadDashboards = async () => {
    try {
      const data = await dashboardBuilderService.getDashboards();
      setDashboards(data);
      if (data.length > 0 && !currentDashboard) {
        setCurrentDashboard(data[0]);
      }
    } catch (error) {
      console.error('Failed to load dashboards:', error);
    }
  };

  return (
    <div className="p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Custom Alert Dashboards</h1>
          <p className="text-muted-foreground mt-1">
            Create personalized views with drag-and-drop widgets and custom metrics
          </p>
        </div>
      </div>

      <Tabs defaultValue="realtime" className="space-y-6">
        <TabsList>
          <TabsTrigger value="realtime">
            <Radio className="h-4 w-4 mr-2" />
            Live Monitoring
          </TabsTrigger>
          <TabsTrigger value="security">
            <Shield className="h-4 w-4 mr-2" />
            Security
          </TabsTrigger>
          <TabsTrigger value="builder">
            <LayoutDashboard className="h-4 w-4 mr-2" />
            Dashboard Builder
          </TabsTrigger>
          <TabsTrigger value="schedule" disabled={!currentDashboard}>
            <Calendar className="h-4 w-4 mr-2" />
            Scheduled Reports
          </TabsTrigger>
          <TabsTrigger value="sharing" disabled={!currentDashboard}>
            <Share2 className="h-4 w-4 mr-2" />
            Sharing
          </TabsTrigger>
          <TabsTrigger value="settings" disabled={!currentDashboard}>
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </TabsTrigger>
        </TabsList>


        <TabsContent value="realtime">
          <RealTimeDataDashboard />
        </TabsContent>

        <TabsContent value="security">
          <SecureWebSocketDashboard />
        </TabsContent>

        <TabsContent value="builder">
          <DashboardBuilder />
        </TabsContent>

        <TabsContent value="schedule">
          {currentDashboard && (
            <ScheduledReportManager dashboardId={currentDashboard.id} />
          )}
        </TabsContent>

        <TabsContent value="sharing">
          {currentDashboard && (
            <DashboardSharingManager dashboardId={currentDashboard.id} />
          )}
        </TabsContent>

        <TabsContent value="settings">
          <Card>
            <CardHeader>
              <CardTitle>Dashboard Settings</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium">Dashboard Name</label>
                  <p className="text-muted-foreground">{currentDashboard?.name}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Description</label>
                  <p className="text-muted-foreground">
                    {currentDashboard?.description || 'No description'}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Created</label>
                  <p className="text-muted-foreground">
                    {currentDashboard && new Date(currentDashboard.created_at).toLocaleString()}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Last Updated</label>
                  <p className="text-muted-foreground">
                    {currentDashboard && new Date(currentDashboard.updated_at).toLocaleString()}
                  </p>
                </div>
                <div>
                  <label className="text-sm font-medium">Widgets</label>
                  <p className="text-muted-foreground">
                    {currentDashboard?.layout.length || 0} widgets configured
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};
