import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Link2, Plus, Trash2, ArrowRight, Play } from 'lucide-react';
import { toast } from 'sonner';

interface BackupChain {
  id: string;
  name: string;
  steps: ChainStep[];
}

interface ChainStep {
  id: string;
  backupName: string;
  waitForPrevious: boolean;
  retryOnFailure: boolean;
  order: number;
}

export default function BackupChainManager() {
  const [chains, setChains] = useState<BackupChain[]>([]);
  const [chainName, setChainName] = useState('');
  const [currentSteps, setCurrentSteps] = useState<ChainStep[]>([]);
  const [stepName, setStepName] = useState('');

  const addStep = () => {
    if (!stepName) return;
    
    const newStep: ChainStep = {
      id: Date.now().toString(),
      backupName: stepName,
      waitForPrevious: true,
      retryOnFailure: true,
      order: currentSteps.length
    };
    
    setCurrentSteps([...currentSteps, newStep]);
    setStepName('');
  };

  const removeStep = (id: string) => {
    setCurrentSteps(currentSteps.filter(s => s.id !== id));
  };

  const saveChain = () => {
    if (!chainName || currentSteps.length === 0) {
      toast.error('Chain name and at least one step required');
      return;
    }

    const newChain: BackupChain = {
      id: Date.now().toString(),
      name: chainName,
      steps: currentSteps
    };

    setChains([...chains, newChain]);
    setChainName('');
    setCurrentSteps([]);
    toast.success('Backup chain created successfully');
  };

  const executeChain = async (chain: BackupChain) => {
    toast.info(`Executing chain: ${chain.name}`);
    
    for (const step of chain.steps) {
      await new Promise(resolve => setTimeout(resolve, 1000));
      toast.success(`Completed: ${step.backupName}`);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h3 className="text-lg font-semibold mb-4 flex items-center gap-2">
          <Link2 className="h-5 w-5" />
          Create Backup Chain
        </h3>
        
        <div className="space-y-4">
          <div>
            <Label>Chain Name</Label>
            <Input 
              value={chainName} 
              onChange={(e) => setChainName(e.target.value)}
              placeholder="e.g., Full Database Backup Chain"
            />
          </div>

          <div>
            <Label>Add Backup Step</Label>
            <div className="flex gap-2">
              <Input 
                value={stepName} 
                onChange={(e) => setStepName(e.target.value)}
                placeholder="Backup name"
              />
              <Button onClick={addStep}>
                <Plus className="h-4 w-4" />
              </Button>
            </div>
          </div>

          {currentSteps.length > 0 && (
            <div className="space-y-2">
              <Label>Chain Steps</Label>
              {currentSteps.map((step, idx) => (
                <div key={step.id} className="flex items-center gap-2 p-3 border rounded-lg">
                  <Badge variant="outline">{idx + 1}</Badge>
                  <span className="flex-1">{step.backupName}</span>
                  {idx < currentSteps.length - 1 && (
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  )}
                  <Button 
                    variant="ghost" 
                    size="sm"
                    onClick={() => removeStep(step.id)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}

          <Button onClick={saveChain} className="w-full">
            Save Chain
          </Button>
        </div>
      </Card>

      <div className="space-y-4">
        <h3 className="text-lg font-semibold">Existing Chains</h3>
        {chains.map(chain => (
          <Card key={chain.id} className="p-6">
            <div className="flex items-center justify-between mb-4">
              <h4 className="font-semibold">{chain.name}</h4>
              <Button size="sm" onClick={() => executeChain(chain)}>
                <Play className="h-4 w-4 mr-2" />
                Execute
              </Button>
            </div>
            <div className="flex items-center gap-2 flex-wrap">
              {chain.steps.map((step, idx) => (
                <div key={step.id} className="flex items-center gap-2">
                  <Badge>{step.backupName}</Badge>
                  {idx < chain.steps.length - 1 && (
                    <ArrowRight className="h-4 w-4 text-muted-foreground" />
                  )}
                </div>
              ))}
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}
