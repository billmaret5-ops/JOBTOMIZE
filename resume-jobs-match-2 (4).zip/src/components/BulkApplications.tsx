import React, { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Checkbox } from '@/components/ui/checkbox';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Send, Clock, CheckCircle, XCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary_min?: number;
  salary_max?: number;
}

interface Template {
  id: string;
  name: string;
  template_type: string;
}

interface BulkBatch {
  id: string;
  name: string;
  status: string;
  total_jobs: number;
  completed_jobs: number;
  failed_jobs: number;
  created_at: string;
}

export function BulkApplications() {
  const { user } = useAuth();
  const [jobs, setJobs] = useState<Job[]>([]);
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedJobs, setSelectedJobs] = useState<string[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [batchName, setBatchName] = useState('');
  const [batches, setBatches] = useState<BulkBatch[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (user) {
      fetchJobs();
      fetchTemplates();
      fetchBatches();
    }
  }, [user]);

  const fetchJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('jobs')
        .select('id, title, company, location, salary_min, salary_max')
        .limit(50);
      
      if (error) throw error;
      setJobs(data || []);
    } catch (error) {
      toast.error('Failed to fetch jobs');
    }
  };

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('application_templates')
        .select('id, name, template_type')
        .eq('user_id', user?.id);
      
      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      toast.error('Failed to fetch templates');
    }
  };

  const fetchBatches = async () => {
    try {
      const { data, error } = await supabase
        .from('bulk_application_batches')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });
      
      if (error) throw error;
      setBatches(data || []);
    } catch (error) {
      toast.error('Failed to fetch batches');
    }
  };

  const toggleJobSelection = (jobId: string) => {
    setSelectedJobs(prev => 
      prev.includes(jobId) 
        ? prev.filter(id => id !== jobId)
        : [...prev, jobId]
    );
  };

  const selectAllJobs = () => {
    setSelectedJobs(jobs.map(job => job.id));
  };

  const clearSelection = () => {
    setSelectedJobs([]);
  };

  const createBulkBatch = async () => {
    if (!selectedJobs.length || !selectedTemplate || !batchName) {
      toast.error('Please select jobs, template, and provide a batch name');
      return;
    }

    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('bulk_application_batches')
        .insert([{
          user_id: user?.id,
          name: batchName,
          template_id: selectedTemplate,
          job_ids: selectedJobs,
          total_jobs: selectedJobs.length,
          status: 'pending'
        }])
        .select()
        .single();

      if (error) throw error;

      // Process applications in background
      await processBulkApplications(data.id, selectedJobs, selectedTemplate);
      
      toast.success('Bulk application batch created successfully');
      setBatchName('');
      setSelectedJobs([]);
      setSelectedTemplate('');
      fetchBatches();
    } catch (error) {
      toast.error('Failed to create bulk batch');
    } finally {
      setLoading(false);
    }
  };

  const processBulkApplications = async (batchId: string, jobIds: string[], templateId: string) => {
    try {
      // Update batch status to processing
      await supabase
        .from('bulk_application_batches')
        .update({ status: 'processing' })
        .eq('id', batchId);

      // Get template data
      const { data: template } = await supabase
        .from('application_templates')
        .select('*')
        .eq('id', templateId)
        .single();

      let completed = 0;
      let failed = 0;

      // Process each job application
      for (const jobId of jobIds) {
        try {
          const { error } = await supabase
            .from('job_applications')
            .insert([{
              user_id: user?.id,
              job_id: jobId,
              status: 'applied',
              cover_letter: template?.cover_letter_template || '',
              custom_fields: template?.custom_fields || {},
              applied_at: new Date().toISOString(),
              source: 'bulk_application'
            }]);

          if (error) throw error;
          completed++;
        } catch {
          failed++;
        }

        // Update progress
        await supabase
          .from('bulk_application_batches')
          .update({ 
            completed_jobs: completed,
            failed_jobs: failed 
          })
          .eq('id', batchId);
      }

      // Mark as completed
      await supabase
        .from('bulk_application_batches')
        .update({ status: 'completed' })
        .eq('id', batchId);

    } catch (error) {
      await supabase
        .from('bulk_application_batches')
        .update({ status: 'failed' })
        .eq('id', batchId);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
      case 'processing': return <Clock className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'failed': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Bulk Applications</h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Create Bulk Application Batch</CardTitle>
          <CardDescription>
            Apply to multiple jobs at once using a template
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="batch-name">Batch Name</Label>
              <Input
                id="batch-name"
                value={batchName}
                onChange={(e) => setBatchName(e.target.value)}
                placeholder="e.g., Software Engineer Applications"
              />
            </div>
            <div>
              <Label htmlFor="template">Application Template</Label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name} ({template.template_type})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" onClick={selectAllJobs}>
              Select All ({jobs.length})
            </Button>
            <Button variant="outline" onClick={clearSelection}>
              Clear Selection
            </Button>
            <div className="ml-auto">
              <Badge variant="secondary">
                {selectedJobs.length} jobs selected
              </Badge>
            </div>
          </div>

          <div className="max-h-60 overflow-y-auto space-y-2">
            {jobs.map((job) => (
              <div key={job.id} className="flex items-center space-x-2 p-2 border rounded">
                <Checkbox
                  checked={selectedJobs.includes(job.id)}
                  onCheckedChange={() => toggleJobSelection(job.id)}
                />
                <div className="flex-1">
                  <p className="font-medium">{job.title}</p>
                  <p className="text-sm text-gray-600">{job.company} • {job.location}</p>
                </div>
                {job.salary_min && (
                  <Badge variant="outline">
                    ${job.salary_min.toLocaleString()}{job.salary_max && ` - $${job.salary_max.toLocaleString()}`}
                  </Badge>
                )}
              </div>
            ))}
          </div>

          <Button 
            onClick={createBulkBatch} 
            disabled={loading || !selectedJobs.length || !selectedTemplate || !batchName}
            className="w-full"
          >
            <Send className="h-4 w-4 mr-2" />
            Create Bulk Application Batch
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Bulk Application History</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {batches.map((batch) => (
              <div key={batch.id} className="border rounded p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h4 className="font-semibold">{batch.name}</h4>
                    <p className="text-sm text-gray-600">
                      Created {new Date(batch.created_at).toLocaleDateString()}
                    </p>
                  </div>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(batch.status)}
                    <Badge variant={batch.status === 'completed' ? 'default' : 'secondary'}>
                      {batch.status}
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Progress</span>
                    <span>{batch.completed_jobs}/{batch.total_jobs} completed</span>
                  </div>
                  <Progress 
                    value={(batch.completed_jobs / batch.total_jobs) * 100} 
                    className="h-2"
                  />
                  {batch.failed_jobs > 0 && (
                    <p className="text-sm text-red-600">
                      {batch.failed_jobs} applications failed
                    </p>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}