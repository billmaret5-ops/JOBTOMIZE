import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { AlertTriangle, Eye, CheckCircle, X, Flag, MessageSquare, FileText, Image } from 'lucide-react';

interface ContentItem {
  id: string;
  type: 'comment' | 'post' | 'image' | 'template';
  content: string;
  author: string;
  reportCount: number;
  status: 'pending' | 'approved' | 'rejected';
  createdAt: string;
  flaggedFor: string[];
}

export const ContentModerationPanel: React.FC = () => {
  const [filterStatus, setFilterStatus] = useState('pending');
  const [filterType, setFilterType] = useState('all');

  const contentItems: ContentItem[] = [
    {
      id: '1',
      type: 'comment',
      content: 'This is a sample comment that needs moderation review...',
      author: 'user@example.com',
      reportCount: 3,
      status: 'pending',
      createdAt: '2024-01-15T10:30:00Z',
      flaggedFor: ['spam', 'inappropriate']
    },
    {
      id: '2',
      type: 'template',
      content: 'Email template: "Special Offer - Limited Time Only!"',
      author: 'marketer@company.com',
      reportCount: 1,
      status: 'pending',
      createdAt: '2024-01-15T09:15:00Z',
      flaggedFor: ['misleading']
    },
    {
      id: '3',
      type: 'post',
      content: 'Job posting for Senior Developer position at TechCorp...',
      author: 'hr@techcorp.com',
      reportCount: 0,
      status: 'approved',
      createdAt: '2024-01-14T14:20:00Z',
      flaggedFor: []
    },
    {
      id: '4',
      type: 'image',
      content: 'Profile image upload - avatar.jpg',
      author: 'newuser@example.com',
      reportCount: 2,
      status: 'pending',
      createdAt: '2024-01-15T11:45:00Z',
      flaggedFor: ['inappropriate', 'copyright']
    }
  ];

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'comment': return <MessageSquare className="h-4 w-4" />;
      case 'post': return <FileText className="h-4 w-4" />;
      case 'template': return <FileText className="h-4 w-4" />;
      case 'image': return <Image className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getFlagColor = (flag: string) => {
    switch (flag) {
      case 'spam': return 'bg-red-100 text-red-800';
      case 'inappropriate': return 'bg-orange-100 text-orange-800';
      case 'misleading': return 'bg-yellow-100 text-yellow-800';
      case 'copyright': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleApprove = (id: string) => {
    console.log('Approving content:', id);
  };

  const handleReject = (id: string) => {
    console.log('Rejecting content:', id);
  };

  const filteredItems = contentItems.filter(item => {
    const statusMatch = filterStatus === 'all' || item.status === filterStatus;
    const typeMatch = filterType === 'all' || item.type === filterType;
    return statusMatch && typeMatch;
  });

  const pendingCount = contentItems.filter(item => item.status === 'pending').length;
  const reportedCount = contentItems.filter(item => item.reportCount > 0).length;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Flag className="h-5 w-5" />
          Content Moderation
          {pendingCount > 0 && (
            <Badge variant="destructive" className="ml-2">
              {pendingCount} pending
            </Badge>
          )}
        </CardTitle>
        <CardDescription>
          Review and moderate user-generated content across the platform
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div className="bg-yellow-50 p-4 rounded-lg">
            <div className="flex items-center gap-2">
              <AlertTriangle className="h-5 w-5 text-yellow-600" />
              <span className="font-medium">Pending Review</span>
            </div>
            <div className="text-2xl font-bold text-yellow-700 mt-1">{pendingCount}</div>
          </div>
          <div className="bg-red-50 p-4 rounded-lg">
            <div className="flex items-center gap-2">
              <Flag className="h-5 w-5 text-red-600" />
              <span className="font-medium">Reported Items</span>
            </div>
            <div className="text-2xl font-bold text-red-700 mt-1">{reportedCount}</div>
          </div>
          <div className="bg-green-50 p-4 rounded-lg">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-600" />
              <span className="font-medium">Approved Today</span>
            </div>
            <div className="text-2xl font-bold text-green-700 mt-1">12</div>
          </div>
          <div className="bg-blue-50 p-4 rounded-lg">
            <div className="flex items-center gap-2">
              <Eye className="h-5 w-5 text-blue-600" />
              <span className="font-medium">Total Reviews</span>
            </div>
            <div className="text-2xl font-bold text-blue-700 mt-1">156</div>
          </div>
        </div>

        {/* Filters */}
        <div className="flex flex-col sm:flex-row gap-4">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-full sm:w-48">
              <SelectValue placeholder="Filter by type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="comment">Comments</SelectItem>
              <SelectItem value="post">Posts</SelectItem>
              <SelectItem value="template">Templates</SelectItem>
              <SelectItem value="image">Images</SelectItem>
            </SelectContent>
          </Select>
        </div>

        {/* Content Items */}
        <div className="space-y-4">
          {filteredItems.map((item) => (
            <div key={item.id} className="border rounded-lg p-4 space-y-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  {getTypeIcon(item.type)}
                  <div>
                    <div className="font-medium capitalize">{item.type}</div>
                    <div className="text-sm text-gray-500">by {item.author}</div>
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {item.reportCount > 0 && (
                    <Badge variant="destructive">
                      {item.reportCount} report{item.reportCount > 1 ? 's' : ''}
                    </Badge>
                  )}
                  <Badge className={getStatusColor(item.status)}>
                    {item.status}
                  </Badge>
                </div>
              </div>

              <div className="bg-gray-50 p-3 rounded text-sm">
                {item.content}
              </div>

              {item.flaggedFor.length > 0 && (
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Flagged for:</span>
                  <div className="flex gap-1">
                    {item.flaggedFor.map((flag) => (
                      <Badge key={flag} className={getFlagColor(flag)}>
                        {flag}
                      </Badge>
                    ))}
                  </div>
                </div>
              )}

              <div className="flex items-center justify-between">
                <div className="text-sm text-gray-500">
                  Created: {new Date(item.createdAt).toLocaleDateString()}
                </div>
                {item.status === 'pending' && (
                  <div className="flex gap-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleReject(item.id)}
                    >
                      <X className="h-4 w-4 mr-1" />
                      Reject
                    </Button>
                    <Button
                      size="sm"
                      onClick={() => handleApprove(item.id)}
                    >
                      <CheckCircle className="h-4 w-4 mr-1" />
                      Approve
                    </Button>
                  </div>
                )}
              </div>
            </div>
          ))}
        </div>

        {filteredItems.length === 0 && (
          <div className="text-center py-8 text-gray-500">
            No content items match the current filters.
          </div>
        )}
      </CardContent>
    </Card>
  );
};