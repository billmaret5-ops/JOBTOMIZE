import { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { SmartAutoFill } from './SmartAutoFill';
import { CoverLetterUpload } from './CoverLetterUpload';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
interface Application {
  id?: string;
  job_title: string;
  company_name: string;
  location?: string;
  salary_range?: string;
  status: string;
  job_url?: string;
  notes?: string;
  follow_up_date?: string;
  interview_date?: string;
  interview_type?: string;
  cover_letter?: string;
  custom_fields?: Record<string, any>;
}

interface ApplicationFormProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (application: Omit<Application, 'id'>) => void;
  application?: Application;
  jobDescription?: string;
}

interface Template {
  id: string;
  name: string;
  cover_letter_template: string;
  custom_fields: Record<string, any>;
  default_answers: Record<string, any>;
}

export default function ApplicationForm({ isOpen, onClose, onSave, application, jobDescription }: ApplicationFormProps) {
  const { user } = useAuth();
  const [templates, setTemplates] = useState<Template[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [coverLetterUrl, setCoverLetterUrl] = useState('');
  
  const [formData, setFormData] = useState<Omit<Application, 'id'>>({
    job_title: application?.job_title || '',
    company_name: application?.company_name || '',
    location: application?.location || '',
    salary_range: application?.salary_range || '',
    status: application?.status || 'saved',
    job_url: application?.job_url || '',
    notes: application?.notes || '',
    follow_up_date: application?.follow_up_date || '',
    interview_date: application?.interview_date || '',
    interview_type: application?.interview_type || '',
    cover_letter: application?.cover_letter || '',
    custom_fields: application?.custom_fields || {}
  });

  useEffect(() => {
    if (user && isOpen) {
      fetchTemplates();
    }
  }, [user, isOpen]);

  const fetchTemplates = async () => {
    try {
      const { data, error } = await supabase
        .from('application_templates')
        .select('*')
        .eq('user_id', user?.id);
      
      if (error) throw error;
      setTemplates(data || []);
    } catch (error) {
      console.error('Error fetching templates:', error);
    }
  };

  const applyTemplate = (templateId: string) => {
    const template = templates.find(t => t.id === templateId);
    if (template) {
      setFormData(prev => ({
        ...prev,
        cover_letter: template.cover_letter_template,
        custom_fields: { ...prev.custom_fields, ...template.custom_fields },
        ...template.default_answers
      }));
    }
  };

  const handleAutoFillSuggestions = (suggestions: any) => {
    setFormData(prev => ({
      ...prev,
      cover_letter: suggestions.coverLetter,
      notes: prev.notes + '\n\nAI Suggestions:\n' + suggestions.interest,
      custom_fields: {
        ...prev.custom_fields,
        suggested_skills: suggestions.skills,
        relevant_experience: suggestions.experience
      }
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(formData);
    onClose();
  };

  const handleChange = (field: keyof typeof formData, value: string) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{application ? 'Edit Application' : 'Add New Application'}</DialogTitle>
          <DialogDescription>
            Fill in application details, upload documents, and use smart templates to track your job application
          </DialogDescription>
        </DialogHeader>
        
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="basic">Basic Info</TabsTrigger>
            <TabsTrigger value="template">Templates</TabsTrigger>
            <TabsTrigger value="autofill">Smart Fill</TabsTrigger>
            <TabsTrigger value="documents">Documents</TabsTrigger>
          </TabsList>

          <TabsContent value="basic" className="space-y-4">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="job_title">Job Title *</Label>
                  <Input
                    id="job_title"
                    value={formData.job_title}
                    onChange={(e) => handleChange('job_title', e.target.value)}
                    required
                  />
                </div>
                <div>
                  <Label htmlFor="company_name">Company *</Label>
                  <Input
                    id="company_name"
                    value={formData.company_name}
                    onChange={(e) => handleChange('company_name', e.target.value)}
                    required
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="location">Location</Label>
                  <Input
                    id="location"
                    value={formData.location}
                    onChange={(e) => handleChange('location', e.target.value)}
                  />
                </div>
                <div>
                  <Label htmlFor="salary_range">Salary Range</Label>
                  <Input
                    id="salary_range"
                    value={formData.salary_range}
                    onChange={(e) => handleChange('salary_range', e.target.value)}
                    placeholder="e.g., $80k - $100k"
                  />
                </div>
              </div>

              <div>
                <Label htmlFor="job_url">Job URL</Label>
                <Input
                  id="job_url"
                  type="url"
                  value={formData.job_url}
                  onChange={(e) => handleChange('job_url', e.target.value)}
                />
              </div>

              <div>
                <Label htmlFor="status">Status</Label>
                <Select value={formData.status} onValueChange={(value) => handleChange('status', value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="saved">Saved</SelectItem>
                    <SelectItem value="applied">Applied</SelectItem>
                    <SelectItem value="interviewing">Interviewing</SelectItem>
                    <SelectItem value="rejected">Rejected</SelectItem>
                    <SelectItem value="offer">Offer</SelectItem>
                    <SelectItem value="accepted">Accepted</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <Label htmlFor="cover_letter">Cover Letter</Label>
                <Textarea
                  id="cover_letter"
                  value={formData.cover_letter}
                  onChange={(e) => handleChange('cover_letter', e.target.value)}
                  rows={6}
                  placeholder="Your cover letter content..."
                />
              </div>

              <div>
                <Label htmlFor="notes">Notes</Label>
                <Textarea
                  id="notes"
                  value={formData.notes}
                  onChange={(e) => handleChange('notes', e.target.value)}
                  rows={3}
                />
              </div>
            </form>
          </TabsContent>

          <TabsContent value="template" className="space-y-4">
            <div>
              <Label htmlFor="template-select">Apply Template</Label>
              <Select value={selectedTemplate} onValueChange={(value) => {
                setSelectedTemplate(value);
                applyTemplate(value);
              }}>
                <SelectTrigger>
                  <SelectValue placeholder="Select a template" />
                </SelectTrigger>
                <SelectContent>
                  {templates.map((template) => (
                    <SelectItem key={template.id} value={template.id}>
                      {template.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="autofill" className="space-y-4">
            {jobDescription && (
              <SmartAutoFill
                jobDescription={jobDescription}
                onApplySuggestions={handleAutoFillSuggestions}
              />
            )}
          </TabsContent>

          <TabsContent value="documents" className="space-y-4">
            <CoverLetterUpload
              onUploadComplete={(url) => setCoverLetterUrl(url)}
              currentUrl={coverLetterUrl}
            />
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 mt-6">
          <Button type="button" variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <Button onClick={handleSubmit}>
            {application ? 'Update' : 'Save'} Application
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}