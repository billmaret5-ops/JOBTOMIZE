import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  FileText, 
  Sparkles, 
  Target, 
  Mail, 
  BarChart3, 
  Plus,
  Edit,
  Download,
  Eye,
  Upload
} from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';
import AIResumeBuilder from './AIResumeBuilder';

import { JobTailoredResume } from './JobTailoredResume';
import { ResumeEmailIntegrator } from './ResumeEmailIntegrator';
import { ATSOptimizer } from './ATSOptimizer';
import { ResumeUpload } from './ResumeUpload';


interface Resume {
  id: string;
  generated_content: any;
  keywords_used: string[];
  ats_score: number;
  relevance_score: number;
  job_description: string;
  created_at: string;
  template_id: string;
}

interface ResumeStats {
  totalResumes: number;
  avgATSScore: number;
  totalVersions: number;
  emailIntegrations: number;
}

export function AIResumeBuilderDashboard() {
  const { user } = useAuth();
  const [resumes, setResumes] = useState<Resume[]>([]);
  const [stats, setStats] = useState<ResumeStats>({
    totalResumes: 0,
    avgATSScore: 0,
    totalVersions: 0,
    emailIntegrations: 0
  });
  const [selectedResume, setSelectedResume] = useState<string>('');
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchResumes();
    fetchStats();
  }, []);

  const fetchResumes = async () => {
    if (!user) return;
    
    const { data } = await supabase
      .from('ai_generated_resumes')
      .select('*')
      .eq('user_id', user.id)
      .eq('is_active', true)
      .order('created_at', { ascending: false });
    
    if (data) setResumes(data);
    setLoading(false);
  };

  const fetchStats = async () => {
    if (!user) return;
    
    try {
      // Get total resumes
      const { count: resumeCount } = await supabase
        .from('ai_generated_resumes')
        .select('*', { count: 'exact', head: true })
        .eq('user_id', user.id)
        .eq('is_active', true);

      // Get average ATS score
      const { data: resumeData } = await supabase
        .from('ai_generated_resumes')
        .select('ats_score')
        .eq('user_id', user.id)
        .eq('is_active', true);

      const avgScore = resumeData && resumeData.length > 0 
        ? resumeData.reduce((sum, r) => sum + r.ats_score, 0) / resumeData.length 
        : 0;

      // Get total versions
      const { count: versionCount } = await supabase
        .from('resume_versions')
        .select('*', { count: 'exact', head: true })
        .in('resume_id', resumes.map(r => r.id));

      // Get email integrations
      const { count: integrationCount } = await supabase
        .from('resume_email_integrations')
        .select('*', { count: 'exact', head: true })
        .in('resume_id', resumes.map(r => r.id));

      setStats({
        totalResumes: resumeCount || 0,
        avgATSScore: Math.round(avgScore),
        totalVersions: versionCount || 0,
        emailIntegrations: integrationCount || 0
      });
    } catch (error) {
      console.error('Failed to fetch stats:', error);
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600 bg-green-50';
    if (score >= 70) return 'text-yellow-600 bg-yellow-50';
    return 'text-red-600 bg-red-50';
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="text-center space-y-4">
        <div className="flex items-center justify-center gap-2">
          <Sparkles className="h-8 w-8 text-blue-600" />
          <h1 className="text-3xl font-bold">AI Resume Builder Dashboard</h1>
        </div>
        <p className="text-gray-600 max-w-2xl mx-auto">
          Manage your AI-generated resumes, create job-tailored versions, and integrate with email templates.
        </p>
      </div>

      {/* Stats Cards */}
      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <FileText className="h-8 w-8 mx-auto mb-2 text-blue-600" />
            <div className="text-2xl font-bold">{stats.totalResumes}</div>
            <div className="text-sm text-gray-600">Total Resumes</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 mx-auto mb-2 text-green-600" />
            <div className="text-2xl font-bold">{stats.avgATSScore}%</div>
            <div className="text-sm text-gray-600">Avg ATS Score</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <BarChart3 className="h-8 w-8 mx-auto mb-2 text-purple-600" />
            <div className="text-2xl font-bold">{stats.totalVersions}</div>
            <div className="text-sm text-gray-600">Resume Versions</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Mail className="h-8 w-8 mx-auto mb-2 text-orange-600" />
            <div className="text-2xl font-bold">{stats.emailIntegrations}</div>
            <div className="text-sm text-gray-600">Email Integrations</div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="upload">Upload</TabsTrigger>
          <TabsTrigger value="builder">AI Builder</TabsTrigger>
          <TabsTrigger value="tailor">Job Tailor</TabsTrigger>
          <TabsTrigger value="integrate">Email</TabsTrigger>
          <TabsTrigger value="optimize">ATS</TabsTrigger>
        </TabsList>


        <TabsContent value="overview" className="space-y-6">
          <div className="flex justify-between items-center">
            <h2 className="text-2xl font-bold">Your Resumes</h2>
            <Button onClick={() => setActiveTab('builder')}>
              <Plus className="h-4 w-4 mr-2" />
              Create New Resume
            </Button>
          </div>

          <div className="grid gap-4">
            {resumes.length === 0 ? (
              <Card>
                <CardContent className="p-8 text-center">
                  <FileText className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                  <h3 className="text-lg font-semibold mb-2">No resumes yet</h3>
                  <p className="text-gray-600 mb-4">
                    Create your first AI-powered resume to get started
                  </p>
                  <Button onClick={() => setActiveTab('builder')}>
                    <Sparkles className="h-4 w-4 mr-2" />
                    Create Resume
                  </Button>
                </CardContent>
              </Card>
            ) : (
              resumes.map((resume) => (
                <Card key={resume.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="flex items-center gap-3 mb-2">
                          <h3 className="font-semibold">
                            {resume.generated_content.personalInfo?.name || 'Resume'}
                          </h3>
                          <Badge className={getScoreColor(resume.ats_score)}>
                            ATS: {resume.ats_score}%
                          </Badge>
                          <Badge variant="outline">
                            Relevance: {resume.relevance_score}%
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">
                          Created: {formatDate(resume.created_at)}
                        </p>
                        <div className="flex flex-wrap gap-1">
                          {resume.keywords_used.slice(0, 5).map((keyword, index) => (
                            <Badge key={index} variant="secondary" className="text-xs">
                              {keyword}
                            </Badge>
                          ))}
                        </div>
                      </div>
                      <div className="flex gap-2">
                        <Button 
                          variant="outline" 
                          size="sm"
                          onClick={() => {
                            setSelectedResume(resume.id);
                            setActiveTab('tailor');
                          }}
                        >
                          <Edit className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Eye className="h-4 w-4" />
                        </Button>
                        <Button variant="outline" size="sm">
                          <Download className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="upload">
          <ResumeUpload />
        </TabsContent>

        <TabsContent value="builder">
          <AIResumeBuilder onContentGenerated={(content) => {
            console.log('Generated content:', content);
          }} />
        </TabsContent>



        <TabsContent value="tailor">
          <JobTailoredResume baseResumeId={selectedResume} />
        </TabsContent>

        <TabsContent value="integrate">
          <ResumeEmailIntegrator />
        </TabsContent>

        <TabsContent value="optimize">
          {selectedResume ? (
            <ATSOptimizer
              resumeContent={resumes.find(r => r.id === selectedResume)?.generated_content}
              jobDescription=""
              onOptimize={(optimized) => {
                console.log('Optimized resume:', optimized);
              }}
            />
          ) : (
            <Card>
              <CardContent className="p-8 text-center">
                <Target className="h-16 w-16 mx-auto mb-4 text-gray-400" />
                <h3 className="text-lg font-semibold mb-2">Select a resume to optimize</h3>
                <p className="text-gray-600">
                  Choose a resume from your overview to run ATS optimization analysis
                </p>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}