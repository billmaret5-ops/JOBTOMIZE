import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  FileText, 
  Send, 
  Users, 
  CheckCircle, 
  XCircle, 
  Clock,
  TrendingUp,
  Target
} from 'lucide-react';

interface PipelineStage {
  id: string;
  name: string;
  count: number;
  color: string;
  icon: React.ReactNode;
  applications: Array<{
    id: string;
    jobTitle: string;
    company: string;
    daysInStage: number;
    priority: 'high' | 'medium' | 'low';
  }>;
}

interface ApplicationPipelineProps {
  applications: any[];
}

export function ApplicationPipeline({ applications }: ApplicationPipelineProps) {
  const stages: PipelineStage[] = [
    {
      id: 'saved',
      name: 'Saved',
      count: applications.filter(app => app.status === 'saved').length,
      color: 'bg-gray-100 text-gray-800',
      icon: <FileText className="w-4 h-4" />,
      applications: applications
        .filter(app => app.status === 'saved')
        .map(app => ({
          id: app.id,
          jobTitle: app.job_title,
          company: app.company_name,
          daysInStage: Math.floor((Date.now() - new Date(app.created_at).getTime()) / (1000 * 60 * 60 * 24)),
          priority: app.priority || 'medium'
        }))
    },
    {
      id: 'applied',
      name: 'Applied',
      count: applications.filter(app => app.status === 'applied').length,
      color: 'bg-blue-100 text-blue-800',
      icon: <Send className="w-4 h-4" />,
      applications: applications
        .filter(app => app.status === 'applied')
        .map(app => ({
          id: app.id,
          jobTitle: app.job_title,
          company: app.company_name,
          daysInStage: Math.floor((Date.now() - new Date(app.applied_date || app.created_at).getTime()) / (1000 * 60 * 60 * 24)),
          priority: app.priority || 'medium'
        }))
    },
    {
      id: 'interviewing',
      name: 'Interviewing',
      count: applications.filter(app => app.status === 'interviewing').length,
      color: 'bg-yellow-100 text-yellow-800',
      icon: <Users className="w-4 h-4" />,
      applications: applications
        .filter(app => app.status === 'interviewing')
        .map(app => ({
          id: app.id,
          jobTitle: app.job_title,
          company: app.company_name,
          daysInStage: Math.floor((Date.now() - new Date(app.interview_date || app.created_at).getTime()) / (1000 * 60 * 60 * 24)),
          priority: app.priority || 'high'
        }))
    },
    {
      id: 'offer',
      name: 'Offers',
      count: applications.filter(app => app.status === 'offer').length,
      color: 'bg-green-100 text-green-800',
      icon: <CheckCircle className="w-4 h-4" />,
      applications: applications
        .filter(app => app.status === 'offer')
        .map(app => ({
          id: app.id,
          jobTitle: app.job_title,
          company: app.company_name,
          daysInStage: Math.floor((Date.now() - new Date(app.updated_at || app.created_at).getTime()) / (1000 * 60 * 60 * 24)),
          priority: 'high'
        }))
    },
    {
      id: 'rejected',
      name: 'Rejected',
      count: applications.filter(app => app.status === 'rejected').length,
      color: 'bg-red-100 text-red-800',
      icon: <XCircle className="w-4 h-4" />,
      applications: applications
        .filter(app => app.status === 'rejected')
        .map(app => ({
          id: app.id,
          jobTitle: app.job_title,
          company: app.company_name,
          daysInStage: Math.floor((Date.now() - new Date(app.updated_at || app.created_at).getTime()) / (1000 * 60 * 60 * 24)),
          priority: 'low'
        }))
    }
  ];

  const totalApplications = applications.length;
  const conversionRate = totalApplications > 0 ? Math.round((stages.find(s => s.id === 'offer')?.count || 0) / totalApplications * 100) : 0;

  return (
    <div className="space-y-6">
      {/* Pipeline Overview */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Total Apps</p>
                <p className="text-2xl font-bold">{totalApplications}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold">{conversionRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-sm text-gray-600">Active</p>
                <p className="text-2xl font-bold">{stages.find(s => s.id === 'interviewing')?.count || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Offers</p>
                <p className="text-2xl font-bold">{stages.find(s => s.id === 'offer')?.count || 0}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Pipeline Stages */}
      <div className="grid grid-cols-1 lg:grid-cols-5 gap-4">
        {stages.map((stage) => (
          <Card key={stage.id} className="h-fit">
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center justify-between text-sm">
                <div className="flex items-center gap-2">
                  {stage.icon}
                  {stage.name}
                </div>
                <Badge className={stage.color}>
                  {stage.count}
                </Badge>
              </CardTitle>
              <Progress 
                value={totalApplications > 0 ? (stage.count / totalApplications) * 100 : 0} 
                className="h-2" 
              />
            </CardHeader>
            <CardContent className="space-y-2 max-h-96 overflow-y-auto">
              {stage.applications.slice(0, 10).map((app) => (
                <div 
                  key={app.id} 
                  className="p-3 bg-gray-50 rounded-lg border hover:bg-gray-100 transition-colors"
                >
                  <div className="flex items-start justify-between mb-1">
                    <h4 className="font-medium text-sm truncate">{app.jobTitle}</h4>
                    <Badge 
                      variant={app.priority === 'high' ? 'destructive' : app.priority === 'medium' ? 'default' : 'secondary'}
                      className="text-xs"
                    >
                      {app.priority}
                    </Badge>
                  </div>
                  <p className="text-xs text-gray-600 mb-2">{app.company}</p>
                  <div className="flex items-center gap-1 text-xs text-gray-500">
                    <Clock className="w-3 h-3" />
                    {app.daysInStage} days
                  </div>
                </div>
              ))}
              {stage.applications.length > 10 && (
                <p className="text-xs text-gray-500 text-center py-2">
                  +{stage.applications.length - 10} more
                </p>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}