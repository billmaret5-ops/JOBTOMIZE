import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ArrowLeft, Trophy, Target, Clock, Code, Brain, Zap } from 'lucide-react';
import { CodingChallengeList } from './CodingChallengeList';
import { CodingChallengeEditor } from './CodingChallengeEditor';

interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: 'Easy' | 'Medium' | 'Hard';
  category: 'Algorithm' | 'Data Structure' | 'System Design';
  timeLimit: number;
  completionRate: number;
  tags: string[];
  solved: boolean;
  attempts: number;
  problemStatement?: string;
  examples?: Array<{
    input: string;
    output: string;
    explanation?: string;
  }>;
  constraints?: string[];
}

export const CodingChallengePlatform: React.FC = () => {
  const [selectedChallenge, setSelectedChallenge] = useState<Challenge | null>(null);
  const [userStats, setUserStats] = useState({
    totalSolved: 12,
    easyCount: 8,
    mediumCount: 3,
    hardCount: 1,
    streak: 5,
    rank: 1247
  });

  const handleChallengeSelect = (challenge: Challenge) => {
    // Add detailed problem information
    const detailedChallenge = {
      ...challenge,
      problemStatement: getDetailedProblem(challenge.id),
      examples: getExamples(challenge.id),
      constraints: getConstraints(challenge.id)
    };
    setSelectedChallenge(detailedChallenge);
  };

  const handleBackToList = () => {
    setSelectedChallenge(null);
  };

  const handleSubmitSolution = (code: string, results: any) => {
    console.log('Solution submitted:', { code, results });
    
    // Update user stats (mock)
    if (results.testResults?.every((test: any) => test.passed)) {
      setUserStats(prev => ({
        ...prev,
        totalSolved: prev.totalSolved + (selectedChallenge?.solved ? 0 : 1),
        streak: prev.streak + 1
      }));
    }
  };

  const getDetailedProblem = (challengeId: string) => {
    const problems = {
      '1': `Given an array of integers nums and an integer target, return indices of the two numbers such that they add up to target.

You may assume that each input would have exactly one solution, and you may not use the same element twice.

You can return the answer in any order.`,
      '2': `Given the root of a binary tree, return the inorder traversal of its nodes' values.

Inorder traversal visits nodes in this order: left subtree, root, right subtree.`,
      '3': `Design a URL shortening service like TinyURL that can:
1. Encode a URL to a shortened URL
2. Decode a shortened URL to its original URL

Consider scalability, availability, and consistency requirements.`
    };
    return problems[challengeId] || 'Problem statement not available.';
  };

  const getExamples = (challengeId: string) => {
    const examples = {
      '1': [
        {
          input: 'nums = [2,7,11,15], target = 9',
          output: '[0,1]',
          explanation: 'Because nums[0] + nums[1] == 9, we return [0, 1].'
        },
        {
          input: 'nums = [3,2,4], target = 6',
          output: '[1,2]'
        }
      ],
      '2': [
        {
          input: 'root = [1,null,2,3]',
          output: '[1,3,2]'
        }
      ]
    };
    return examples[challengeId] || [];
  };

  const getConstraints = (challengeId: string) => {
    const constraints = {
      '1': [
        '2 ≤ nums.length ≤ 10⁴',
        '-10⁹ ≤ nums[i] ≤ 10⁹',
        '-10⁹ ≤ target ≤ 10⁹',
        'Only one valid answer exists.'
      ],
      '2': [
        'The number of nodes in the tree is in the range [0, 100].',
        '-100 ≤ Node.val ≤ 100'
      ]
    };
    return constraints[challengeId] || [];
  };

  if (selectedChallenge) {
    return (
      <div className="h-screen flex flex-col">
        {/* Challenge Header */}
        <div className="bg-white border-b px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-4">
              <Button variant="ghost" onClick={handleBackToList}>
                <ArrowLeft className="h-4 w-4 mr-2" />
                Back to Challenges
              </Button>
              <div>
                <h1 className="text-xl font-semibold">{selectedChallenge.title}</h1>
                <div className="flex items-center space-x-2 mt-1">
                  <Badge className={
                    selectedChallenge.difficulty === 'Easy' ? 'bg-green-100 text-green-800' :
                    selectedChallenge.difficulty === 'Medium' ? 'bg-yellow-100 text-yellow-800' :
                    'bg-red-100 text-red-800'
                  }>
                    {selectedChallenge.difficulty}
                  </Badge>
                  <Badge variant="outline">{selectedChallenge.category}</Badge>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-1" />
                    {selectedChallenge.timeLimit} min
                  </div>
                </div>
              </div>
            </div>
            
            <div className="text-right">
              <div className="text-sm text-gray-500">Completion Rate</div>
              <div className="text-lg font-semibold">{selectedChallenge.completionRate}%</div>
            </div>
          </div>
        </div>

        {/* Challenge Content */}
        <div className="flex-1 flex">
          {/* Problem Description */}
          <div className="w-1/2 border-r overflow-auto">
            <div className="p-6 space-y-6">
              <div>
                <h2 className="text-lg font-semibold mb-3">Problem</h2>
                <p className="text-gray-700 whitespace-pre-line">{selectedChallenge.problemStatement}</p>
              </div>
              
              {selectedChallenge.examples && selectedChallenge.examples.length > 0 && (
                <div>
                  <h2 className="text-lg font-semibold mb-3">Examples</h2>
                  {selectedChallenge.examples.map((example, index) => (
                    <div key={index} className="bg-gray-50 p-4 rounded-lg mb-3">
                      <div className="font-mono text-sm space-y-2">
                        <div><strong>Input:</strong> {example.input}</div>
                        <div><strong>Output:</strong> {example.output}</div>
                        {example.explanation && (
                          <div><strong>Explanation:</strong> {example.explanation}</div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              )}
              
              {selectedChallenge.constraints && selectedChallenge.constraints.length > 0 && (
                <div>
                  <h2 className="text-lg font-semibold mb-3">Constraints</h2>
                  <ul className="list-disc list-inside space-y-1 text-gray-700">
                    {selectedChallenge.constraints.map((constraint, index) => (
                      <li key={index} className="font-mono text-sm">{constraint}</li>
                    ))}
                  </ul>
                </div>
              )}
              
              <div>
                <h2 className="text-lg font-semibold mb-3">Tags</h2>
                <div className="flex flex-wrap gap-2">
                  {selectedChallenge.tags.map((tag) => (
                    <Badge key={tag} variant="secondary">{tag}</Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Code Editor */}
          <div className="w-1/2">
            <CodingChallengeEditor
              challengeId={selectedChallenge.id}
              onSubmit={handleSubmitSolution}
            />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Stats Dashboard */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.totalSolved}</div>
            <div className="text-sm text-gray-600">Total Solved</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Target className="h-8 w-8 text-green-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.easyCount}</div>
            <div className="text-sm text-gray-600">Easy</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Code className="h-8 w-8 text-yellow-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.mediumCount}</div>
            <div className="text-sm text-gray-600">Medium</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Brain className="h-8 w-8 text-red-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.hardCount}</div>
            <div className="text-sm text-gray-600">Hard</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Zap className="h-8 w-8 text-blue-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">{userStats.streak}</div>
            <div className="text-sm text-gray-600">Day Streak</div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-4 text-center">
            <Trophy className="h-8 w-8 text-purple-500 mx-auto mb-2" />
            <div className="text-2xl font-bold">#{userStats.rank}</div>
            <div className="text-sm text-gray-600">Global Rank</div>
          </CardContent>
        </Card>
      </div>

      {/* Challenge List */}
      <CodingChallengeList onSelectChallenge={handleChallengeSelect} />
    </div>
  );
};