import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, Loader2, AlertCircle } from 'lucide-react';
import { AdminAuthService } from '@/services/adminAuthService';
import { supabase } from '@/lib/supabase';

interface TestResult {
  test: string;

  status: 'pending' | 'success' | 'error';
  message: string;
  details?: any;
}

export default function AuthFlowTester() {
  const [email, setEmail] = useState('test@example.com');
  const [password, setPassword] = useState('TestPass123!');
  const [results, setResults] = useState<TestResult[]>([]);
  const [loading, setLoading] = useState(false);

  const addResult = (result: TestResult) => {
    setResults(prev => [...prev, result]);
  };

  const runFullTest = async () => {
    setResults([]);
    setLoading(true);
    const testEmail = `test${Date.now()}@example.com`;

    try {
      // Test 1: Signup using AdminAuthService (service_role key via Edge Function)
      addResult({ test: 'Signup', status: 'pending', message: 'Creating account via Edge Function...' });
      const { data: signupData, error: signupError } = await AdminAuthService.createUser({
        email: testEmail,
        password,
        full_name: 'Test User',
        user_type: 'job_seeker'
      });

      if (signupError) {
        addResult({ test: 'Signup', status: 'error', message: signupError.message, details: signupError });
        setLoading(false);
        return; // Stop if signup fails
      } else {
        addResult({ 
          test: 'Signup', 
          status: 'success', 
          message: `✅ Account created with service_role key: ${testEmail}`,
          details: signupData 
        });
      }


      // Test 2: Check session
      addResult({ test: 'Session Check', status: 'pending', message: 'Checking session...' });
      const { data: sessionData, error: sessionError } = await supabase.auth.getSession();
      
      if (sessionError) {
        addResult({ test: 'Session Check', status: 'error', message: sessionError.message });
      } else if (sessionData.session) {
        addResult({ test: 'Session Check', status: 'success', message: 'Session active' });
      } else {
        addResult({ test: 'Session Check', status: 'error', message: 'No active session' });
      }

      // Test 3: Logout
      addResult({ test: 'Logout', status: 'pending', message: 'Signing out...' });
      const { error: logoutError } = await supabase.auth.signOut();
      
      if (logoutError) {
        addResult({ test: 'Logout', status: 'error', message: logoutError.message });
      } else {
        addResult({ test: 'Logout', status: 'success', message: 'Logged out successfully' });
      }

      // Test 4: Login
      addResult({ test: 'Login', status: 'pending', message: 'Logging in...' });
      const { data: loginData, error: loginError } = await supabase.auth.signInWithPassword({
        email: testEmail,
        password
      });

      if (loginError) {
        addResult({ test: 'Login', status: 'error', message: loginError.message });
      } else {
        addResult({ test: 'Login', status: 'success', message: `Logged in: ${loginData.user?.email}` });
      }

      // Test 5: Password Reset
      addResult({ test: 'Password Reset', status: 'pending', message: 'Requesting reset...' });
      const { error: resetError } = await supabase.auth.resetPasswordForEmail(testEmail);
      
      if (resetError) {
        addResult({ test: 'Password Reset', status: 'error', message: resetError.message });
      } else {
        addResult({ test: 'Password Reset', status: 'success', message: 'Reset email sent' });
      }

    } catch (error: any) {
      addResult({ test: 'System Error', status: 'error', message: error.message });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <Card className="border-purple-200 shadow-lg">
        <CardHeader className="bg-gradient-to-r from-purple-50 to-blue-50">
          <CardTitle className="text-2xl text-purple-900">🔐 Authentication Flow Tester</CardTitle>
          <CardDescription className="text-purple-700">
            Tests user creation with <Badge variant="outline" className="ml-2">service_role key</Badge> via Edge Function
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6 pt-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
            <div className="flex items-start gap-2">
              <AlertCircle className="h-5 w-5 text-blue-600 mt-0.5" />
              <div className="text-sm text-blue-900">
                <strong>Using Correct Key:</strong> This test uses the Edge Function with 
                <code className="mx-1 px-2 py-0.5 bg-blue-100 rounded">service_role key</code>
                for admin user creation, not the anon key.
              </div>
            </div>
          </div>

          <Button 
            onClick={runFullTest} 
            disabled={loading}
            className="w-full bg-purple-600 hover:bg-purple-700"
            size="lg"
          >
            {loading ? (
              <>
                <Loader2 className="animate-spin mr-2 h-5 w-5" />
                Running Tests...
              </>
            ) : (
              '▶ Run Complete Auth Flow Test'
            )}
          </Button>

          {results.length > 0 && (
            <div className="space-y-3 mt-6">
              <h3 className="font-semibold text-lg text-gray-900">Test Results:</h3>
              {results.map((result, idx) => (
                <div
                  key={idx}
                  className={`border rounded-lg p-4 ${
                    result.status === 'error'
                      ? 'border-red-200 bg-red-50'
                      : result.status === 'success'
                      ? 'border-green-200 bg-green-50'
                      : 'border-gray-200 bg-gray-50'
                  }`}
                >
                  <div className="flex items-start gap-3">
                    {result.status === 'success' && (
                      <CheckCircle2 className="h-6 w-6 text-green-600 flex-shrink-0 mt-0.5" />
                    )}
                    {result.status === 'error' && (
                      <XCircle className="h-6 w-6 text-red-600 flex-shrink-0 mt-0.5" />
                    )}
                    {result.status === 'pending' && (
                      <Loader2 className="h-6 w-6 text-gray-600 animate-spin flex-shrink-0 mt-0.5" />
                    )}
                    <div className="flex-1 min-w-0">
                      <div className="font-semibold text-gray-900 mb-1">{result.test}</div>
                      <div className="text-sm text-gray-700">{result.message}</div>
                      {result.details && (
                        <details className="mt-2">
                          <summary className="text-xs text-gray-600 cursor-pointer hover:text-gray-900">
                            View Details
                          </summary>
                          <pre className="text-xs mt-2 bg-white p-3 rounded border overflow-auto max-h-40">
                            {JSON.stringify(result.details, null, 2)}
                          </pre>
                        </details>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
