import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { CheckCircle, Clock, AlertCircle } from 'lucide-react';

interface TimelineEvent {
  id: string;
  title: string;
  description: string;
  date: string;
  type: 'success' | 'pending' | 'warning';
}

interface ApplicationLifecycleTimelineProps {
  application: any;
}

export function ApplicationLifecycleTimeline({ application }: ApplicationLifecycleTimelineProps) {
  const events: TimelineEvent[] = [];

  if (application.created_at) {
    events.push({
      id: '1',
      title: 'Job Saved',
      description: `Saved ${application.job_title} at ${application.company_name}`,
      date: application.created_at,
      type: 'success'
    });
  }

  if (application.applied_date) {
    events.push({
      id: '2',
      title: 'Application Submitted',
      description: 'Successfully submitted application',
      date: application.applied_date,
      type: 'success'
    });
  }

  if (application.interview_date) {
    const isPast = new Date(application.interview_date) < new Date();
    events.push({
      id: '3',
      title: isPast ? 'Interview Completed' : 'Interview Scheduled',
      description: `Interview ${isPast ? 'was' : 'scheduled for'} ${new Date(application.interview_date).toLocaleDateString()}`,
      date: application.interview_date,
      type: isPast ? 'success' : 'pending'
    });
  }

  if (application.follow_up_date) {
    const isPast = new Date(application.follow_up_date) < new Date();
    events.push({
      id: '4',
      title: 'Follow-up',
      description: isPast ? 'Follow-up was due' : 'Follow-up scheduled',
      date: application.follow_up_date,
      type: isPast ? 'warning' : 'pending'
    });
  }

  if (application.status === 'offer') {
    events.push({
      id: '5',
      title: 'Offer Received',
      description: 'Congratulations! You received an offer',
      date: application.updated_at,
      type: 'success'
    });
  }

  if (application.status === 'rejected') {
    events.push({
      id: '6',
      title: 'Application Closed',
      description: 'Application was not successful',
      date: application.updated_at,
      type: 'warning'
    });
  }

  events.sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

  return (
    <Card>
      <CardContent className="p-6">
        <h3 className="font-semibold text-lg mb-4">Application Timeline</h3>
        <div className="space-y-4">
          {events.map((event, index) => (
            <div key={event.id} className="flex gap-4">
              <div className="flex flex-col items-center">
                <div className={`rounded-full p-2 ${
                  event.type === 'success' ? 'bg-green-100' :
                  event.type === 'pending' ? 'bg-blue-100' :
                  'bg-yellow-100'
                }`}>
                  {event.type === 'success' && <CheckCircle className="w-4 h-4 text-green-600" />}
                  {event.type === 'pending' && <Clock className="w-4 h-4 text-blue-600" />}
                  {event.type === 'warning' && <AlertCircle className="w-4 h-4 text-yellow-600" />}
                </div>
                {index < events.length - 1 && (
                  <div className="w-0.5 h-12 bg-gray-200 my-1" />
                )}
              </div>
              <div className="flex-1 pb-4">
                <h4 className="font-medium">{event.title}</h4>
                <p className="text-sm text-gray-600">{event.description}</p>
                <p className="text-xs text-gray-500 mt-1">
                  {new Date(event.date).toLocaleDateString('en-US', { 
                    month: 'short', 
                    day: 'numeric', 
                    year: 'numeric',
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </p>
              </div>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}