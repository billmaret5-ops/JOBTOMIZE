import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';
import { GripVertical } from 'lucide-react';
import { Card } from '@/components/ui/card';

interface DraggableResumeSectionProps {
  id: string;
  title: string;
  children: React.ReactNode;
}

export default function DraggableResumeSection({ id, title, children }: DraggableResumeSectionProps) {
  const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({ id });
  
  const style = {
    transform: CSS.Transform.toString(transform),
    transition,
    opacity: isDragging ? 0.5 : 1,
  };

  return (
    <div ref={setNodeRef} style={style}>
      <Card className="p-4 bg-white">
        <div className="flex items-center gap-2 mb-4">
          <div {...attributes} {...listeners} className="cursor-move">
            <GripVertical className="h-5 w-5 text-gray-400" />
          </div>
          <h3 className="text-lg font-semibold">{title}</h3>
        </div>
        {children}
      </Card>
    </div>
  );
}
