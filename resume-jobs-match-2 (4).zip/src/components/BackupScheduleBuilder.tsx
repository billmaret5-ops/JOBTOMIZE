import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Save, Play } from 'lucide-react';
import BackupScheduleTemplates from './BackupScheduleTemplates';
import BackupScheduleCalendar from './BackupScheduleCalendar';
import BackupScheduleSimulator from './BackupScheduleSimulator';
import { backupSchedulingService } from '@/services/backupSchedulingService';
import { toast } from 'sonner';

export default function BackupScheduleBuilder() {
  const [scheduleName, setScheduleName] = useState('');
  const [cronExpression, setCronExpression] = useState('0 2 * * *');
  const [timezone, setTimezone] = useState('UTC');
  const [enabled, setEnabled] = useState(true);
  const [windowStart, setWindowStart] = useState('00:00');
  const [windowEnd, setWindowEnd] = useState('06:00');
  const [priority, setPriority] = useState(5);
  const [schedules, setSchedules] = useState<any[]>([]);

  const handleTemplateSelect = (template: any) => {
    setCronExpression(template.cronExpression);
    setScheduleName(template.name);
    toast.success(`Template "${template.name}" applied`);
  };

  const handleSave = async () => {
    try {
      const schedule = {
        name: scheduleName,
        cronExpression,
        timezone,
        enabled,
        backupWindow: { start: windowStart, end: windowEnd },
        priority
      };
      
      await backupSchedulingService.createSchedule(schedule);
      setSchedules([...schedules, schedule]);
      toast.success('Schedule created successfully');
    } catch (error) {
      toast.error('Failed to create schedule');
    }
  };

  const calendarEvents = schedules.flatMap(s => 
    backupSchedulingService.parseCronExpression(s.cronExpression).map(date => ({
      date,
      scheduleName: s.name,
      time: date.toLocaleTimeString(),
      type: 'backup'
    }))
  );

  return (
    <div className="space-y-6">
      <Tabs defaultValue="builder" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="builder">Schedule Builder</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="calendar">Calendar View</TabsTrigger>
          <TabsTrigger value="simulation">Simulation</TabsTrigger>
        </TabsList>

        <TabsContent value="builder">
          <Card className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-4">
                <div>
                  <Label>Schedule Name</Label>
                  <Input value={scheduleName} onChange={(e) => setScheduleName(e.target.value)} />
                </div>
                <div>
                  <Label>Cron Expression</Label>
                  <Input value={cronExpression} onChange={(e) => setCronExpression(e.target.value)} />
                  <p className="text-xs text-muted-foreground mt-1">Format: minute hour day month weekday</p>
                </div>
                <div>
                  <Label>Timezone</Label>
                  <Select value={timezone} onValueChange={setTimezone}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="UTC">UTC</SelectItem>
                      <SelectItem value="America/New_York">Eastern Time</SelectItem>
                      <SelectItem value="America/Chicago">Central Time</SelectItem>
                      <SelectItem value="America/Los_Angeles">Pacific Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <Label>Backup Window</Label>
                  <div className="flex gap-2">
                    <Input type="time" value={windowStart} onChange={(e) => setWindowStart(e.target.value)} />
                    <Input type="time" value={windowEnd} onChange={(e) => setWindowEnd(e.target.value)} />
                  </div>
                </div>
                <div>
                  <Label>Priority (1-10)</Label>
                  <Input type="number" min="1" max="10" value={priority} onChange={(e) => setPriority(Number(e.target.value))} />
                </div>
                <div className="flex items-center justify-between">
                  <Label>Enabled</Label>
                  <Switch checked={enabled} onCheckedChange={setEnabled} />
                </div>
              </div>
            </div>

            <div className="flex gap-2 mt-6">
              <Button onClick={handleSave} className="flex-1">
                <Save className="h-4 w-4 mr-2" />
                Save Schedule
              </Button>
              <Button variant="outline">
                <Play className="h-4 w-4 mr-2" />
                Test Run
              </Button>
            </div>
          </Card>
        </TabsContent>

        <TabsContent value="templates">
          <BackupScheduleTemplates onSelect={handleTemplateSelect} />
        </TabsContent>

        <TabsContent value="calendar">
          <BackupScheduleCalendar events={calendarEvents} />
        </TabsContent>

        <TabsContent value="simulation">
          <BackupScheduleSimulator schedules={schedules} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
