import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { supabase } from '@/lib/supabase';
import { Users, Activity, Settings, BarChart3, Shield, LogOut, Database, FileText } from 'lucide-react';
import AdminTwoFactorPanel from './admin/AdminTwoFactorPanel';

export default function ComprehensiveAdminDashboard() {
  const navigate = useNavigate();
  const [activeTab, setActiveTab] = useState('overview');

  const handleLogout = async () => {
    await supabase.auth.signOut();
    navigate('/admin-login');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto p-6 space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
            <p className="text-gray-600 mt-1">Full system access</p>
          </div>
          <div className="flex items-center gap-3">
            <Badge variant="secondary" className="text-sm">
              <Shield className="h-4 w-4 mr-1" />
              Super Admin
            </Badge>
            <Button variant="outline" onClick={handleLogout}>
              <LogOut className="h-4 w-4 mr-2" />
              Logout
            </Button>
          </div>
        </div>

        <div className="grid md:grid-cols-4 gap-4">
          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-blue-100">Total Users</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">2,847</div>
              <p className="text-xs text-blue-100">+12% from last month</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-green-100">Active Jobs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">15,234</div>
              <p className="text-xs text-green-100">+8% from last week</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-purple-100">Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">48,392</div>
              <p className="text-xs text-purple-100">+23% this month</p>
            </CardContent>
          </Card>
          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardHeader className="pb-2">
              <CardTitle className="text-sm font-medium text-orange-100">System Health</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">99.8%</div>
              <p className="text-xs text-orange-100">Uptime this month</p>
            </CardContent>
          </Card>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="overview"><BarChart3 className="w-4 h-4 mr-2" />Overview</TabsTrigger>
            <TabsTrigger value="users"><Users className="w-4 h-4 mr-2" />Users</TabsTrigger>
            <TabsTrigger value="database"><Database className="w-4 h-4 mr-2" />Database</TabsTrigger>
            <TabsTrigger value="health"><Activity className="w-4 h-4 mr-2" />Health</TabsTrigger>
            <TabsTrigger value="logs"><FileText className="w-4 h-4 mr-2" />Logs</TabsTrigger>
            <TabsTrigger value="settings"><Settings className="w-4 h-4 mr-2" />Settings</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6 mt-6">
            <Card><CardHeader><CardTitle>System Overview</CardTitle></CardHeader>
            <CardContent><p className="text-gray-600">Platform analytics and insights</p></CardContent></Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6 mt-6">
            <Card><CardHeader><CardTitle>User Management</CardTitle></CardHeader>
            <CardContent><p className="text-gray-600">Manage platform users</p></CardContent></Card>
          </TabsContent>

          <TabsContent value="database" className="space-y-6 mt-6">
            <Card><CardHeader><CardTitle>Database Management</CardTitle></CardHeader>
            <CardContent><p className="text-gray-600">Database tools and management</p></CardContent></Card>
          </TabsContent>

          <TabsContent value="health" className="space-y-6 mt-6">
            <Card><CardHeader><CardTitle>System Health</CardTitle></CardHeader>
            <CardContent><p className="text-gray-600">Monitor system performance</p></CardContent></Card>
          </TabsContent>

          <TabsContent value="logs" className="space-y-6 mt-6">
            <Card><CardHeader><CardTitle>Activity Logs</CardTitle></CardHeader>
            <CardContent><p className="text-gray-600">View system activity</p></CardContent></Card>
          </TabsContent>

          <TabsContent value="settings" className="space-y-6 mt-6">
            <div className="grid gap-6">
              <AdminTwoFactorPanel />
              <Card>
                <CardHeader>
                  <CardTitle>System Settings</CardTitle>
                  <CardDescription>Configure platform-wide settings</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                      <div>
                        <p className="font-medium">Maintenance Mode</p>
                        <p className="text-sm text-gray-600">Temporarily disable user access</p>
                      </div>
                      <Button variant="outline">Configure</Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}