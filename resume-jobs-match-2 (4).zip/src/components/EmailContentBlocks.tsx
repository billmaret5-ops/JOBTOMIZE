import React from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Type, Image as ImageIcon, Link, Palette, Users, Star } from 'lucide-react';

const contentBlocks = [
  { type: 'text', label: 'Text Block', icon: Type },
  { type: 'image', label: 'Image', icon: ImageIcon },
  { type: 'button', label: 'CTA Button', icon: Link },
  { type: 'divider', label: 'Divider', icon: Palette },
  { type: 'social', label: 'Social Links', icon: Users },
  { type: 'rating', label: 'Rating', icon: Star }
];

export const EmailContentBlocks = ({ onBlockAdd }) => {
  return (
    <Card className="p-4">
      <h3 className="font-semibold mb-3">Content Blocks</h3>
      <div className="space-y-2">
        {contentBlocks.map((block) => (
          <Button
            key={block.type}
            variant="ghost"
            className="w-full justify-start"
            onClick={() => onBlockAdd(block.type)}
          >
            <block.icon className="w-4 h-4 mr-2" />
            {block.label}
          </Button>
        ))}
      </div>
    </Card>
  );
};