import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Shield, AlertTriangle, Zap, Activity } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface DDoSPattern {
  id: string;
  pattern_name: string;
  pattern_type: string;
  severity_threshold: number;
  auto_response_enabled: boolean;
  detection_count: number;
  last_detected_at?: string;
  is_active: boolean;
}

export const DDoSPatternDetector: React.FC = () => {
  const [patterns, setPatterns] = useState<DDoSPattern[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadPatterns();
    const interval = setInterval(loadPatterns, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadPatterns = async () => {
    try {
      const { data, error } = await supabase
        .from('websocket_ddos_patterns')
        .select('*')
        .order('detection_count', { ascending: false });

      if (error) throw error;
      setPatterns(data || []);
    } catch (error) {
      console.error('Failed to load DDoS patterns:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleAutoResponse = async (patternId: string, enabled: boolean) => {
    try {
      const { error } = await supabase
        .from('websocket_ddos_patterns')
        .update({ auto_response_enabled: enabled })
        .eq('id', patternId);

      if (error) throw error;
      loadPatterns();
    } catch (error) {
      console.error('Failed to toggle auto response:', error);
    }
  };

  const getPatternIcon = (type: string) => {
    switch (type) {
      case 'connection_flood': return <Zap className="h-5 w-5 text-red-500" />;
      case 'message_flood': return <Activity className="h-5 w-5 text-orange-500" />;
      case 'distributed': return <Shield className="h-5 w-5 text-yellow-500" />;
      default: return <AlertTriangle className="h-5 w-5 text-blue-500" />;
    }
  };

  if (loading) {
    return <div>Loading DDoS patterns...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-2xl font-bold">DDoS Pattern Detection</h3>
        <p className="text-muted-foreground">Automated threat pattern recognition</p>
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {patterns.map((pattern) => (
          <Card key={pattern.id}>
            <CardHeader>
              <CardTitle className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  {getPatternIcon(pattern.pattern_type)}
                  <span>{pattern.pattern_name}</span>
                </div>
                <Badge variant={pattern.is_active ? 'default' : 'secondary'}>
                  {pattern.is_active ? 'Active' : 'Inactive'}
                </Badge>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4 text-sm">
                <div>
                  <p className="text-muted-foreground">Pattern Type</p>
                  <p className="font-medium capitalize">{pattern.pattern_type.replace('_', ' ')}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Detections</p>
                  <p className="font-medium">{pattern.detection_count}</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Threshold</p>
                  <p className="font-medium">{(pattern.severity_threshold * 100).toFixed(0)}%</p>
                </div>
                <div>
                  <p className="text-muted-foreground">Last Detected</p>
                  <p className="font-medium">
                    {pattern.last_detected_at 
                      ? new Date(pattern.last_detected_at).toLocaleDateString()
                      : 'Never'}
                  </p>
                </div>
              </div>

              <div className="flex items-center justify-between pt-4 border-t">
                <span className="text-sm font-medium">Auto Response</span>
                <Switch
                  checked={pattern.auto_response_enabled}
                  onCheckedChange={(checked) => toggleAutoResponse(pattern.id, checked)}
                />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {patterns.length === 0 && (
        <Card>
          <CardContent className="py-12 text-center">
            <Shield className="h-12 w-12 mx-auto text-muted-foreground mb-4" />
            <h3 className="text-lg font-semibold mb-2">No Patterns Configured</h3>
            <p className="text-muted-foreground">
              DDoS detection patterns will appear here once configured
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
};
