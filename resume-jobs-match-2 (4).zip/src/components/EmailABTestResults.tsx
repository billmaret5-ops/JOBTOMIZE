import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Trophy, TrendingUp, Mail, MousePointer, Reply } from 'lucide-react';

interface Variant {
  id: string;
  name: string;
  sends: number;
  opens: number;
  clicks: number;
  replies: number;
  openRate: number;
  clickRate: number;
  replyRate: number;
}

interface TestResultsProps {
  testName: string;
  variants: Variant[];
  winner?: string;
  confidenceLevel?: number;
  status: 'active' | 'completed' | 'paused';
}

export default function EmailABTestResults({ testName, variants, winner, confidenceLevel, status }: TestResultsProps) {
  const calculateConfidence = (v1: Variant, v2: Variant) => {
    const p1 = v1.openRate / 100;
    const p2 = v2.openRate / 100;
    const n1 = v1.sends;
    const n2 = v2.sends;
    
    if (n1 < 30 || n2 < 30) return 0;
    
    const pooled = ((p1 * n1) + (p2 * n2)) / (n1 + n2);
    const se = Math.sqrt(pooled * (1 - pooled) * (1/n1 + 1/n2));
    const z = Math.abs(p1 - p2) / se;
    
    if (z > 2.576) return 99;
    if (z > 1.96) return 95;
    if (z > 1.645) return 90;
    return Math.round(z * 50);
  };

  const confidence = variants.length === 2 ? calculateConfidence(variants[0], variants[1]) : confidenceLevel || 0;
  const bestVariant = variants.reduce((best, v) => v.openRate > best.openRate ? v : best, variants[0]);

  return (
    <Card>
      <CardHeader>
        <div className="flex justify-between items-start">
          <div>
            <CardTitle>{testName}</CardTitle>
            <p className="text-sm text-muted-foreground mt-1">
              Statistical Analysis & Performance Metrics
            </p>
          </div>
          <Badge variant={status === 'completed' ? 'default' : status === 'active' ? 'secondary' : 'outline'}>
            {status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-6">
        {confidence >= 95 && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4">
            <div className="flex items-center gap-2 mb-2">
              <Trophy className="h-5 w-5 text-green-600" />
              <h4 className="font-semibold text-green-900">Winner Declared!</h4>
            </div>
            <p className="text-sm text-green-700">
              {bestVariant.name} is the winner with {confidence}% confidence
            </p>
          </div>
        )}

        <div className="grid gap-4">
          {variants.map((variant) => (
            <Card key={variant.id} className={variant.id === bestVariant.id && confidence >= 95 ? 'border-green-500 border-2' : ''}>
              <CardContent className="pt-6">
                <div className="flex justify-between items-start mb-4">
                  <div>
                    <h4 className="font-semibold text-lg">{variant.name}</h4>
                    <p className="text-sm text-muted-foreground">{variant.sends} emails sent</p>
                  </div>
                  {variant.id === bestVariant.id && confidence >= 95 && (
                    <Badge className="bg-green-600">
                      <Trophy className="h-3 w-3 mr-1" />
                      Winner
                    </Badge>
                  )}
                </div>

                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="flex items-center gap-1">
                        <Mail className="h-4 w-4" />
                        Open Rate
                      </span>
                      <span className="font-semibold">{variant.openRate.toFixed(1)}%</span>
                    </div>
                    <Progress value={variant.openRate} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-1">{variant.opens} opens</p>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="flex items-center gap-1">
                        <MousePointer className="h-4 w-4" />
                        Click Rate
                      </span>
                      <span className="font-semibold">{variant.clickRate.toFixed(1)}%</span>
                    </div>
                    <Progress value={variant.clickRate} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-1">{variant.clicks} clicks</p>
                  </div>

                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span className="flex items-center gap-1">
                        <Reply className="h-4 w-4" />
                        Reply Rate
                      </span>
                      <span className="font-semibold">{variant.replyRate.toFixed(1)}%</span>
                    </div>
                    <Progress value={variant.replyRate} className="h-2" />
                    <p className="text-xs text-muted-foreground mt-1">{variant.replies} replies</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        <Card className="bg-blue-50 border-blue-200">
          <CardContent className="pt-6">
            <div className="flex items-center gap-2 mb-3">
              <TrendingUp className="h-5 w-5 text-blue-600" />
              <h4 className="font-semibold">Statistical Confidence</h4>
            </div>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span>Confidence Level</span>
                <span className="font-semibold">{confidence}%</span>
              </div>
              <Progress value={confidence} className="h-3" />
              <p className="text-xs text-muted-foreground">
                {confidence < 90 && 'Need more data for statistical significance (90%+ required)'}
                {confidence >= 90 && confidence < 95 && 'Approaching significance. Continue testing.'}
                {confidence >= 95 && 'Statistically significant! Safe to declare winner.'}
              </p>
            </div>
          </CardContent>
        </Card>
      </CardContent>
    </Card>
  );
}