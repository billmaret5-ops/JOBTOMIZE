import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ComponentLibrary } from './email-campaign/ComponentLibrary';
import { DragDropEditor } from './email-campaign/DragDropEditor';
import { ComponentEditor } from './email-campaign/ComponentEditor';
import { RecipientManager } from './RecipientManager';
import { ABTestSetup } from './ABTestSetup';
import { CampaignScheduler } from './CampaignScheduler';

import { Calendar, Users, TestTube, Send } from 'lucide-react';

interface EmailComponentData {
  id: string;
  type: 'text' | 'image' | 'button' | 'divider' | 'spacer';
  content: any;
}

export const CampaignBuilder: React.FC = () => {
  const [campaignName, setCampaignName] = useState('');
  const [subject, setSubject] = useState('');
  const [components, setComponents] = useState<EmailComponentData[]>([]);
  const [editingComponent, setEditingComponent] = useState<EmailComponentData | null>(null);
  const [activeTab, setActiveTab] = useState('design');

  const addComponent = (type: string) => {
    const newComponent: EmailComponentData = {
      id: `component-${Date.now()}`,
      type: type as any,
      content: getDefaultContent(type)
    };
    setComponents([...components, newComponent]);
  };

  const getDefaultContent = (type: string) => {
    switch (type) {
      case 'text':
        return { html: 'Your text here...', fontSize: '16px', color: '#000000', align: 'left' };
      case 'image':
        return { src: '', alt: 'Image', width: 'auto' };
      case 'button':
        return { text: 'Click Here', url: '', backgroundColor: '#007bff', textColor: '#ffffff' };
      case 'divider':
        return { color: '#cccccc', thickness: '1px' };
      case 'spacer':
        return { height: '20px' };
      default:
        return {};
    }
  };

  const handleEditComponent = (id: string) => {
    const component = components.find(c => c.id === id);
    if (component) {
      setEditingComponent(component);
    }
  };

  const handleSaveComponent = (content: any) => {
    if (editingComponent) {
      const updatedComponents = components.map(c =>
        c.id === editingComponent.id ? { ...c, content } : c
      );
      setComponents(updatedComponents);
      setEditingComponent(null);
    }
  };

  return (
    <div className="h-screen flex flex-col">
      <div className="border-b p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Input
              placeholder="Campaign Name"
              value={campaignName}
              onChange={(e) => setCampaignName(e.target.value)}
              className="w-64"
            />
            <Input
              placeholder="Email Subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              className="w-64"
            />
          </div>
          <div className="flex gap-2">
            <Button variant="outline">Preview</Button>
            <Button>Save Campaign</Button>
          </div>
        </div>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="flex-1 flex flex-col">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="design" className="flex items-center gap-2">
            <TestTube className="h-4 w-4" />
            Design
          </TabsTrigger>
          <TabsTrigger value="recipients" className="flex items-center gap-2">
            <Users className="h-4 w-4" />
            Recipients
          </TabsTrigger>
          <TabsTrigger value="testing" className="flex items-center gap-2">
            <TestTube className="h-4 w-4" />
            A/B Testing
          </TabsTrigger>
          <TabsTrigger value="schedule" className="flex items-center gap-2">
            <Calendar className="h-4 w-4" />
            Schedule
          </TabsTrigger>
        </TabsList>

        <TabsContent value="design" className="flex-1 flex gap-4 p-4">
          <ComponentLibrary onAddComponent={addComponent} />
          <DragDropEditor
            components={components}
            onComponentsChange={setComponents}
            onEditComponent={handleEditComponent}
          />
          {editingComponent && (
            <ComponentEditor
              component={editingComponent}
              onSave={handleSaveComponent}
              onCancel={() => setEditingComponent(null)}
            />
          )}
        </TabsContent>

        <TabsContent value="recipients" className="flex-1 p-4">
          <RecipientManager />
        </TabsContent>

        <TabsContent value="testing" className="flex-1 p-4">
          <ABTestSetup />
        </TabsContent>

        <TabsContent value="schedule" className="flex-1 p-4">
          <CampaignScheduler />
        </TabsContent>
      </Tabs>
    </div>
  );
};