import React, { useState, useMemo } from 'react';
import { Card, CardContent } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Slider } from './ui/slider';
import { MapPin, DollarSign, Clock, Briefcase, Search, Filter, SortAsc } from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  type: string;
  experience: string;
  description: string;
  logo: string;
  posted: string;
  tags: string[];
}

const mockJobs: Job[] = [
  {
    id: '1',
    title: 'Senior Frontend Developer',
    company: 'TechCorp',
    location: 'San Francisco, CA',
    salary: '$120,000 - $160,000',
    type: 'Full-time',
    experience: 'Senior',
    description: 'Build amazing user experiences with React and TypeScript. Work with a talented team on cutting-edge web applications.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555706972_7b039abb.webp',
    posted: '2 days ago',
    tags: ['React', 'TypeScript', 'CSS']
  },
  {
    id: '2',
    title: 'Product Manager',
    company: 'InnovateLab',
    location: 'New York, NY',
    salary: '$100,000 - $140,000',
    type: 'Full-time',
    experience: 'Mid-level',
    description: 'Lead product strategy and work with cross-functional teams to deliver exceptional user experiences.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555708747_e629d1ae.webp',
    posted: '1 day ago',
    tags: ['Strategy', 'Analytics', 'Leadership']
  },
  {
    id: '3',
    title: 'UX Designer',
    company: 'DesignStudio',
    location: 'Remote',
    salary: '$80,000 - $110,000',
    type: 'Contract',
    experience: 'Mid-level',
    description: 'Create intuitive and beautiful user experiences for web and mobile applications.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555710487_6d000933.webp',
    posted: '3 days ago',
    tags: ['Figma', 'Prototyping', 'User Research']
  },
  {
    id: '4',
    title: 'DevOps Engineer',
    company: 'CloudTech',
    location: 'Austin, TX',
    salary: '$110,000 - $150,000',
    type: 'Full-time',
    experience: 'Senior',
    description: 'Manage cloud infrastructure and CI/CD pipelines for scalable applications.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555712193_99af9653.webp',
    posted: '1 week ago',
    tags: ['AWS', 'Docker', 'Kubernetes']
  },
  {
    id: '5',
    title: 'Data Scientist',
    company: 'DataFlow',
    location: 'Seattle, WA',
    salary: '$95,000 - $130,000',
    type: 'Full-time',
    experience: 'Mid-level',
    description: 'Analyze complex datasets and build machine learning models to drive business insights.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555714329_77ab53e9.webp',
    posted: '4 days ago',
    tags: ['Python', 'ML', 'SQL']
  },
  {
    id: '6',
    title: 'Marketing Manager',
    company: 'GrowthCo',
    location: 'Los Angeles, CA',
    salary: '$75,000 - $100,000',
    type: 'Full-time',
    experience: 'Mid-level',
    description: 'Drive marketing campaigns and growth strategies for B2B SaaS products.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555716107_30ba1eea.webp',
    posted: '5 days ago',
    tags: ['Digital Marketing', 'SaaS', 'Analytics']
  },
  {
    id: '7',
    title: 'Backend Developer',
    company: 'ServerSide',
    location: 'Chicago, IL',
    salary: '$90,000 - $125,000',
    type: 'Full-time',
    experience: 'Mid-level',
    description: 'Build robust APIs and microservices using Node.js and cloud technologies.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555717871_fee05b9d.webp',
    posted: '6 days ago',
    tags: ['Node.js', 'API', 'MongoDB']
  },
  {
    id: '8',
    title: 'Sales Director',
    company: 'SalesForce Pro',
    location: 'Miami, FL',
    salary: '$130,000 - $180,000',
    type: 'Full-time',
    experience: 'Senior',
    description: 'Lead sales team and develop strategic partnerships to drive revenue growth.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555719654_43fae738.webp',
    posted: '1 week ago',
    tags: ['Sales', 'Leadership', 'B2B']
  },
  {
    id: '9',
    title: 'Mobile Developer',
    company: 'AppBuilder',
    location: 'Remote',
    salary: '$85,000 - $115,000',
    type: 'Contract',
    experience: 'Mid-level',
    description: 'Develop native mobile applications for iOS and Android platforms.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555774574_f070ced9.webp',
    posted: '3 days ago',
    tags: ['React Native', 'iOS', 'Android']
  },
  {
    id: '10',
    title: 'Cybersecurity Analyst',
    company: 'SecureNet',
    location: 'Washington, DC',
    salary: '$105,000 - $140,000',
    type: 'Full-time',
    experience: 'Senior',
    description: 'Monitor and protect systems from security threats and vulnerabilities.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555776313_a7d9e7f0.webp',
    posted: '2 days ago',
    tags: ['Security', 'Network', 'Risk Assessment']
  },
  {
    id: '11',
    title: 'Content Writer',
    company: 'ContentCraft',
    location: 'Remote',
    salary: '$50,000 - $70,000',
    type: 'Part-time',
    experience: 'Entry-level',
    description: 'Create engaging content for blogs, social media, and marketing campaigns.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555778183_c3b08fe5.webp',
    posted: '1 day ago',
    tags: ['Writing', 'SEO', 'Social Media']
  },
  {
    id: '12',
    title: 'Project Manager',
    company: 'AgileWorks',
    location: 'Denver, CO',
    salary: '$80,000 - $110,000',
    type: 'Full-time',
    experience: 'Mid-level',
    description: 'Coordinate cross-functional teams and manage project timelines and deliverables.',
    logo: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758555779910_8dbb339e.webp',
    posted: '4 days ago',
    tags: ['Agile', 'Scrum', 'Leadership']
  }
];

export const ComprehensiveJobSearch: React.FC = () => {
  const [searchTerm, setSearchTerm] = useState('');
  const [location, setLocation] = useState('');
  const [jobType, setJobType] = useState('');
  const [experience, setExperience] = useState('');
  const [salaryRange, setSalaryRange] = useState([0]);
  const [sortBy, setSortBy] = useState('relevance');

  const filteredJobs = useMemo(() => {
    return mockJobs.filter(job => {
      const matchesSearch = job.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                           job.company.toLowerCase().includes(searchTerm.toLowerCase());
      const matchesLocation = !location || job.location.toLowerCase().includes(location.toLowerCase());
      const matchesType = !jobType || job.type === jobType;
      const matchesExperience = !experience || job.experience === experience;
      
      return matchesSearch && matchesLocation && matchesType && matchesExperience;
    });
  }, [searchTerm, location, jobType, experience]);

  return (
    <div className="space-y-6">
      {/* Search Header */}
      <div className="bg-white rounded-lg shadow-sm border p-6">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Job title or company"
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10"
            />
          </div>
          <div className="relative">
            <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Location"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              className="pl-10"
            />
          </div>
          <Select value={jobType} onValueChange={setJobType}>
            <SelectTrigger>
              <SelectValue placeholder="Job Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="Full-time">Full-time</SelectItem>
              <SelectItem value="Part-time">Part-time</SelectItem>
              <SelectItem value="Contract">Contract</SelectItem>
              <SelectItem value="Remote">Remote</SelectItem>
            </SelectContent>
          </Select>
          <Select value={experience} onValueChange={setExperience}>
            <SelectTrigger>
              <SelectValue placeholder="Experience" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Levels</SelectItem>
              <SelectItem value="Entry-level">Entry-level</SelectItem>
              <SelectItem value="Mid-level">Mid-level</SelectItem>
              <SelectItem value="Senior">Senior</SelectItem>
            </SelectContent>
          </Select>
        </div>
        
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <Filter className="h-4 w-4 text-gray-500" />
            <span className="text-sm text-gray-600">{filteredJobs.length} jobs found</span>
          </div>
          <Select value={sortBy} onValueChange={setSortBy}>
            <SelectTrigger className="w-40">
              <SortAsc className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="relevance">Relevance</SelectItem>
              <SelectItem value="date">Date Posted</SelectItem>
              <SelectItem value="salary">Salary</SelectItem>
              <SelectItem value="company">Company</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Job Results */}
      <div className="grid gap-4">
        {filteredJobs.map((job) => (
          <Card key={job.id} className="hover:shadow-lg transition-shadow cursor-pointer">
            <CardContent className="p-6">
              <div className="flex items-start gap-4">
                <img
                  src={job.logo}
                  alt={`${job.company} logo`}
                  className="w-16 h-16 rounded-lg object-cover"
                />
                <div className="flex-1">
                  <div className="flex items-start justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-1">
                        {job.title}
                      </h3>
                      <p className="text-lg text-gray-700 mb-2">{job.company}</p>
                    </div>
                    <Button className="ml-4">Apply Now</Button>
                  </div>
                  
                  <div className="flex flex-wrap items-center gap-4 mb-3 text-sm text-gray-600">
                    <div className="flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {job.location}
                    </div>
                    <div className="flex items-center gap-1">
                      <DollarSign className="h-4 w-4" />
                      {job.salary}
                    </div>
                    <div className="flex items-center gap-1">
                      <Briefcase className="h-4 w-4" />
                      {job.type}
                    </div>
                    <div className="flex items-center gap-1">
                      <Clock className="h-4 w-4" />
                      {job.posted}
                    </div>
                  </div>
                  
                  <p className="text-gray-700 mb-3">{job.description}</p>
                  
                  <div className="flex flex-wrap gap-2">
                    {job.tags.map((tag) => (
                      <Badge key={tag} variant="secondary">
                        {tag}
                      </Badge>
                    ))}
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};