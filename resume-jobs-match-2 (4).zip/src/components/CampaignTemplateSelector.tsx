import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Search, Eye, Star, Filter } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';

interface Template {
  id: string;
  name: string;
  description: string;
  category: string;
  preview_url: string;
  rating: number;
  usage_count: number;
  is_premium: boolean;
  tags: string[];
}

interface CampaignTemplateSelectorProps {
  selectedTemplate?: string;
  onSelectTemplate: (templateId: string) => void;
}

export const CampaignTemplateSelector: React.FC<CampaignTemplateSelectorProps> = ({
  selectedTemplate,
  onSelectTemplate
}) => {
  const [templates, setTemplates] = useState<Template[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    loadTemplates();
  }, []);

  const loadTemplates = async () => {
    setIsLoading(true);
    try {
      // Mock data for demonstration
      const mockTemplates: Template[] = [
        {
          id: 'welcome-modern',
          name: 'Modern Welcome',
          description: 'Clean, modern welcome email template',
          category: 'welcome',
          preview_url: '/templates/welcome-modern.png',
          rating: 4.8,
          usage_count: 1250,
          is_premium: false,
          tags: ['welcome', 'onboarding', 'modern']
        },
        {
          id: 'newsletter-minimal',
          name: 'Minimal Newsletter',
          description: 'Simple, elegant newsletter design',
          category: 'newsletter',
          preview_url: '/templates/newsletter-minimal.png',
          rating: 4.6,
          usage_count: 890,
          is_premium: true,
          tags: ['newsletter', 'minimal', 'content']
        },
        {
          id: 'promo-bold',
          name: 'Bold Promotion',
          description: 'Eye-catching promotional email template',
          category: 'promotional',
          preview_url: '/templates/promo-bold.png',
          rating: 4.7,
          usage_count: 2100,
          is_premium: false,
          tags: ['promotion', 'sale', 'bold']
        },
        {
          id: 'event-elegant',
          name: 'Elegant Event',
          description: 'Sophisticated event invitation template',
          category: 'event',
          preview_url: '/templates/event-elegant.png',
          rating: 4.9,
          usage_count: 650,
          is_premium: true,
          tags: ['event', 'invitation', 'elegant']
        }
      ];
      setTemplates(mockTemplates);
    } catch (error) {
      console.error('Error loading templates:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const filteredTemplates = templates.filter(template => {
    const matchesSearch = template.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         template.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesCategory = categoryFilter === 'all' || template.category === categoryFilter;
    
    return matchesSearch && matchesCategory;
  });

  const categories = ['all', ...Array.from(new Set(templates.map(t => t.category)))];

  return (
    <div className="space-y-6">
      <div className="flex gap-4 items-center">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
          <Input
            placeholder="Search templates..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
        <Select value={categoryFilter} onValueChange={setCategoryFilter}>
          <SelectTrigger className="w-48">
            <Filter className="w-4 h-4 mr-2" />
            <SelectValue placeholder="Filter by category" />
          </SelectTrigger>
          <SelectContent>
            {categories.map(category => (
              <SelectItem key={category} value={category}>
                {category === 'all' ? 'All Categories' : category.charAt(0).toUpperCase() + category.slice(1)}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <div className="h-48 bg-gray-200 rounded-t-lg"></div>
              <CardContent className="p-4">
                <div className="h-4 bg-gray-200 rounded mb-2"></div>
                <div className="h-3 bg-gray-200 rounded mb-4"></div>
                <div className="flex justify-between">
                  <div className="h-6 w-16 bg-gray-200 rounded"></div>
                  <div className="h-6 w-20 bg-gray-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredTemplates.map(template => (
            <Card 
              key={template.id} 
              className={`cursor-pointer transition-all hover:shadow-lg ${
                selectedTemplate === template.id ? 'ring-2 ring-blue-500' : ''
              }`}
              onClick={() => onSelectTemplate(template.id)}
            >
              <div className="relative">
                <div className="h-48 bg-gradient-to-br from-blue-100 to-purple-100 rounded-t-lg flex items-center justify-center">
                  <div className="text-gray-500 text-sm">Template Preview</div>
                </div>
                {template.is_premium && (
                  <Badge className="absolute top-2 right-2 bg-yellow-500">Premium</Badge>
                )}
              </div>
              <CardContent className="p-4">
                <div className="flex items-start justify-between mb-2">
                  <h3 className="font-semibold text-lg">{template.name}</h3>
                  <div className="flex items-center gap-1">
                    <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    <span className="text-sm text-gray-600">{template.rating}</span>
                  </div>
                </div>
                <p className="text-gray-600 text-sm mb-3">{template.description}</p>
                <div className="flex items-center justify-between">
                  <Badge variant="outline">{template.category}</Badge>
                  <span className="text-xs text-gray-500">{template.usage_count} uses</span>
                </div>
                <div className="flex flex-wrap gap-1 mt-3">
                  {template.tags.slice(0, 3).map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                </div>
                <div className="flex gap-2 mt-4">
                  <Button 
                    size="sm" 
                    variant="outline" 
                    className="flex-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      // Preview functionality
                    }}
                  >
                    <Eye className="w-4 h-4 mr-1" />
                    Preview
                  </Button>
                  <Button 
                    size="sm" 
                    className="flex-1"
                    onClick={(e) => {
                      e.stopPropagation();
                      onSelectTemplate(template.id);
                    }}
                  >
                    Select
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {filteredTemplates.length === 0 && !isLoading && (
        <div className="text-center py-12">
          <p className="text-gray-500">No templates found matching your criteria.</p>
          <Button variant="outline" className="mt-4" onClick={() => {
            setSearchTerm('');
            setCategoryFilter('all');
          }}>
            Clear Filters
          </Button>
        </div>
      )}
    </div>
  );
};