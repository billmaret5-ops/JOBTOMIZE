import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { 
  Users, Upload, Download, Search, Filter, Plus, 
  Mail, UserCheck, UserX, FileText 
} from 'lucide-react';

interface Recipient {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  status: 'active' | 'unsubscribed' | 'bounced';
  tags: string[];
  custom_fields: Record<string, any>;
}

interface RecipientList {
  id: string;
  name: string;
  description: string;
  recipient_count: number;
  created_at: string;
}

interface CampaignRecipientManagerProps {
  recipients: Recipient[];
  onRecipientsChange: (recipients: Recipient[]) => void;
}

export const CampaignRecipientManager: React.FC<CampaignRecipientManagerProps> = ({
  recipients,
  onRecipientsChange
}) => {
  const [recipientLists, setRecipientLists] = useState<RecipientList[]>([]);
  const [selectedList, setSelectedList] = useState<string>('');
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [newRecipient, setNewRecipient] = useState({
    email: '',
    first_name: '',
    last_name: '',
    tags: ''
  });
  const [bulkEmails, setBulkEmails] = useState('');

  useEffect(() => {
    loadRecipientLists();
  }, []);

  const loadRecipientLists = async () => {
    // Mock data for demonstration
    const mockLists: RecipientList[] = [
      {
        id: 'list1',
        name: 'Newsletter Subscribers',
        description: 'General newsletter subscribers',
        recipient_count: 1250,
        created_at: '2024-01-15'
      },
      {
        id: 'list2',
        name: 'Premium Users',
        description: 'Users with premium subscriptions',
        recipient_count: 340,
        created_at: '2024-02-01'
      },
      {
        id: 'list3',
        name: 'Trial Users',
        description: 'Users currently on trial',
        recipient_count: 890,
        created_at: '2024-02-10'
      }
    ];
    setRecipientLists(mockLists);
  };

  const addRecipient = () => {
    if (!newRecipient.email) return;

    const recipient: Recipient = {
      id: `recipient-${Date.now()}`,
      email: newRecipient.email,
      first_name: newRecipient.first_name,
      last_name: newRecipient.last_name,
      status: 'active',
      tags: newRecipient.tags.split(',').map(tag => tag.trim()).filter(Boolean),
      custom_fields: {}
    };

    onRecipientsChange([...recipients, recipient]);
    setNewRecipient({ email: '', first_name: '', last_name: '', tags: '' });
  };

  const addBulkRecipients = () => {
    const emails = bulkEmails
      .split('\n')
      .map(line => line.trim())
      .filter(Boolean);

    const newRecipients: Recipient[] = emails.map(email => ({
      id: `recipient-${Date.now()}-${Math.random()}`,
      email,
      status: 'active' as const,
      tags: [],
      custom_fields: {}
    }));

    onRecipientsChange([...recipients, ...newRecipients]);
    setBulkEmails('');
  };

  const removeRecipient = (id: string) => {
    onRecipientsChange(recipients.filter(r => r.id !== id));
  };

  const importFromList = async (listId: string) => {
    try {
      // Mock importing recipients from a list
      const mockRecipients: Recipient[] = [
        {
          id: `imported-1-${Date.now()}`,
          email: 'john@example.com',
          first_name: 'John',
          last_name: 'Doe',
          status: 'active',
          tags: ['newsletter'],
          custom_fields: {}
        },
        {
          id: `imported-2-${Date.now()}`,
          email: 'jane@example.com',
          first_name: 'Jane',
          last_name: 'Smith',
          status: 'active',
          tags: ['newsletter'],
          custom_fields: {}
        }
      ];

      onRecipientsChange([...recipients, ...mockRecipients]);
    } catch (error) {
      console.error('Error importing recipients:', error);
    }
  };

  const filteredRecipients = recipients.filter(recipient => {
    const matchesSearch = 
      recipient.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipient.first_name?.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipient.last_name?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || recipient.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'unsubscribed': return 'bg-yellow-100 text-yellow-800';
      case 'bounced': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Users className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <div className="text-2xl font-bold">{recipients.length}</div>
            <div className="text-sm text-gray-600">Total Recipients</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <UserCheck className="w-8 h-8 mx-auto mb-2 text-green-600" />
            <div className="text-2xl font-bold">
              {recipients.filter(r => r.status === 'active').length}
            </div>
            <div className="text-sm text-gray-600">Active</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <UserX className="w-8 h-8 mx-auto mb-2 text-red-600" />
            <div className="text-2xl font-bold">
              {recipients.filter(r => r.status !== 'active').length}
            </div>
            <div className="text-sm text-gray-600">Inactive</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="manage">
        <TabsList>
          <TabsTrigger value="manage">Manage Recipients</TabsTrigger>
          <TabsTrigger value="import">Import Recipients</TabsTrigger>
          <TabsTrigger value="lists">Recipient Lists</TabsTrigger>
        </TabsList>

        <TabsContent value="manage" className="space-y-4">
          <div className="flex gap-4 items-center">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                placeholder="Search recipients..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-40">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="unsubscribed">Unsubscribed</SelectItem>
                <SelectItem value="bounced">Bounced</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Add Single Recipient</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <Input
                  placeholder="Email address"
                  value={newRecipient.email}
                  onChange={(e) => setNewRecipient({ ...newRecipient, email: e.target.value })}
                />
                <Input
                  placeholder="First name"
                  value={newRecipient.first_name}
                  onChange={(e) => setNewRecipient({ ...newRecipient, first_name: e.target.value })}
                />
                <Input
                  placeholder="Last name"
                  value={newRecipient.last_name}
                  onChange={(e) => setNewRecipient({ ...newRecipient, last_name: e.target.value })}
                />
                <Button onClick={addRecipient} disabled={!newRecipient.email}>
                  <Plus className="w-4 h-4 mr-2" />
                  Add
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recipients ({filteredRecipients.length})</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {filteredRecipients.map(recipient => (
                  <div key={recipient.id} className="flex items-center justify-between p-3 border rounded">
                    <div className="flex items-center gap-3">
                      <Mail className="w-4 h-4 text-gray-400" />
                      <div>
                        <div className="font-medium">{recipient.email}</div>
                        {(recipient.first_name || recipient.last_name) && (
                          <div className="text-sm text-gray-600">
                            {recipient.first_name} {recipient.last_name}
                          </div>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge className={getStatusColor(recipient.status)}>
                        {recipient.status}
                      </Badge>
                      <Button
                        size="sm"
                        variant="ghost"
                        onClick={() => removeRecipient(recipient.id)}
                      >
                        ×
                      </Button>
                    </div>
                  </div>
                ))}
                {filteredRecipients.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No recipients found
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="import" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Bulk Import</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Email Addresses (one per line)</Label>
                <Textarea
                  placeholder="email1@example.com&#10;email2@example.com&#10;email3@example.com"
                  value={bulkEmails}
                  onChange={(e) => setBulkEmails(e.target.value)}
                  rows={6}
                />
              </div>
              <Button onClick={addBulkRecipients} disabled={!bulkEmails.trim()}>
                <Upload className="w-4 h-4 mr-2" />
                Import Recipients
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-lg">CSV Import</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <p className="text-sm text-gray-600">
                  Upload a CSV file with columns: email, first_name, last_name, tags
                </p>
                <Button variant="outline">
                  <Upload className="w-4 h-4 mr-2" />
                  Choose CSV File
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lists" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recipientLists.map(list => (
              <Card key={list.id} className="cursor-pointer hover:shadow-md">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-2">
                    <h3 className="font-semibold">{list.name}</h3>
                    <Badge variant="outline">{list.recipient_count}</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-4">{list.description}</p>
                  <Button
                    size="sm"
                    onClick={() => importFromList(list.id)}
                    className="w-full"
                  >
                    Import from List
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};