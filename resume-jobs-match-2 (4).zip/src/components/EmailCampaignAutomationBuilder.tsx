import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Mail, Users, Calendar, Zap, Play, Save, Settings, BarChart3 } from 'lucide-react';
import { CampaignTemplateSelector } from './CampaignTemplateSelector';
import { CampaignContentEditor } from './CampaignContentEditor';
import { CampaignRecipientManager } from './CampaignRecipientManager';
import { CampaignSchedulingSystem } from './CampaignSchedulingSystem';
import { AutomatedFollowUpBuilder } from './AutomatedFollowUpBuilder';
import { EmailWorkflowVisualizer } from './EmailWorkflowVisualizer';
import { supabase } from '@/lib/supabase';

interface Campaign {
  id?: string;
  name: string;
  subject: string;
  template_id?: string;
  content: any;
  recipients: any[];
  schedule: any;
  follow_ups: any[];
  workflow: any;
  status: 'draft' | 'scheduled' | 'active' | 'completed';
  created_at?: string;
}

export const EmailCampaignAutomationBuilder: React.FC = () => {
  const [campaign, setCampaign] = useState<Campaign>({
    name: '',
    subject: '',
    content: { components: [] },
    recipients: [],
    schedule: { type: 'immediate' },
    follow_ups: [],
    workflow: { nodes: [], connections: [] },
    status: 'draft'
  });
  const [activeTab, setActiveTab] = useState('template');
  const [isLoading, setIsLoading] = useState(false);
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);

  useEffect(() => {
    loadCampaigns();
  }, []);

  const loadCampaigns = async () => {
    try {
      const { data } = await supabase
        .from('email_campaigns')
        .select('*')
        .order('created_at', { ascending: false });
      
      setCampaigns(data || []);
    } catch (error) {
      console.error('Error loading campaigns:', error);
    }
  };

  const saveCampaign = async () => {
    setIsLoading(true);
    try {
      const { data, error } = await supabase
        .from('email_campaigns')
        .upsert({
          ...campaign,
          user_id: (await supabase.auth.getUser()).data.user?.id
        })
        .select()
        .single();

      if (error) throw error;
      
      setCampaign(data);
      await loadCampaigns();
    } catch (error) {
      console.error('Error saving campaign:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const launchCampaign = async () => {
    if (!campaign.id) return;
    
    setIsLoading(true);
    try {
      const { error } = await supabase.functions.invoke('email-campaign-launcher', {
        body: { 
          campaignId: campaign.id,
          action: 'launch'
        }
      });

      if (error) throw error;
      
      setCampaign({ ...campaign, status: 'active' });
      await loadCampaigns();
    } catch (error) {
      console.error('Error launching campaign:', error);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <div>
          <h1 className="text-3xl font-bold">Email Campaign Automation Builder</h1>
          <p className="text-gray-600 mt-2">Create sophisticated email campaigns with drag-and-drop automation</p>
        </div>
        <div className="flex gap-2">
          <Button onClick={saveCampaign} disabled={isLoading} variant="outline">
            <Save className="w-4 h-4 mr-2" />
            Save Campaign
          </Button>
          <Button onClick={launchCampaign} disabled={isLoading || !campaign.id}>
            <Play className="w-4 h-4 mr-2" />
            Launch Campaign
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-12 gap-6">
        <div className="col-span-3">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="w-5 h-5" />
                Campaign Overview
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Campaign Name</Label>
                <Input
                  value={campaign.name}
                  onChange={(e) => setCampaign({ ...campaign, name: e.target.value })}
                  placeholder="Enter campaign name"
                />
              </div>
              <div>
                <Label>Subject Line</Label>
                <Input
                  value={campaign.subject}
                  onChange={(e) => setCampaign({ ...campaign, subject: e.target.value })}
                  placeholder="Email subject line"
                />
              </div>
              <div>
                <Label>Status</Label>
                <Badge variant={campaign.status === 'draft' ? 'secondary' : 'default'}>
                  {campaign.status}
                </Badge>
              </div>
              <div className="pt-4 space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span>Recipients</span>
                  <Badge variant="outline">{campaign.recipients.length}</Badge>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span>Follow-ups</span>
                  <Badge variant="outline">{campaign.follow_ups.length}</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="col-span-9">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-6">
              <TabsTrigger value="template">Template</TabsTrigger>
              <TabsTrigger value="content">Content</TabsTrigger>
              <TabsTrigger value="recipients">Recipients</TabsTrigger>
              <TabsTrigger value="schedule">Schedule</TabsTrigger>
              <TabsTrigger value="automation">Automation</TabsTrigger>
              <TabsTrigger value="workflow">Workflow</TabsTrigger>
            </TabsList>

            <TabsContent value="template">
              <CampaignTemplateSelector
                selectedTemplate={campaign.template_id}
                onSelectTemplate={(templateId) => setCampaign({ ...campaign, template_id: templateId })}
              />
            </TabsContent>

            <TabsContent value="content">
              <CampaignContentEditor
                content={campaign.content}
                onContentChange={(content) => setCampaign({ ...campaign, content })}
              />
            </TabsContent>

            <TabsContent value="recipients">
              <CampaignRecipientManager
                recipients={campaign.recipients}
                onRecipientsChange={(recipients) => setCampaign({ ...campaign, recipients })}
              />
            </TabsContent>

            <TabsContent value="schedule">
              <CampaignSchedulingSystem
                schedule={campaign.schedule}
                onScheduleChange={(schedule) => setCampaign({ ...campaign, schedule })}
              />
            </TabsContent>

            <TabsContent value="automation">
              <AutomatedFollowUpBuilder
                followUps={campaign.follow_ups}
                onFollowUpsChange={(followUps) => setCampaign({ ...campaign, follow_ups: followUps })}
              />
            </TabsContent>

            <TabsContent value="workflow">
              <EmailWorkflowVisualizer
                workflow={campaign.workflow}
                onWorkflowChange={(workflow) => setCampaign({ ...campaign, workflow })}
              />
            </TabsContent>
          </Tabs>
        </div>
      </div>
    </div>
  );
};