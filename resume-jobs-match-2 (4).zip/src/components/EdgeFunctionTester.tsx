import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { SUPABASE_CONFIG } from '@/config/supabase.config';
import { supabase } from '@/lib/supabase';
import { Loader2, Terminal, CheckCircle, XCircle } from 'lucide-react';

export default function EdgeFunctionTester() {
  const [testing, setTesting] = useState(false);
  const [result, setResult] = useState<any>(null);

  const testEdgeFunction = async () => {
    setTesting(true);
    
    try {
      const { data: { session } } = await supabase.auth.getSession();
      const authToken = session?.access_token || SUPABASE_CONFIG.anonKey;
      
      console.log('🔐 Auth Check:', {
        hasSession: !!session,
        tokenLength: authToken.length,
        tokenStart: authToken.substring(0, 20) + '...',
        anonKeyStart: SUPABASE_CONFIG.anonKey.substring(0, 20) + '...'
      });

      const url = `${SUPABASE_CONFIG.url}/functions/v1/fetch-jobs/health`;
      
      const headers = {
        'Authorization': `Bearer ${SUPABASE_CONFIG.anonKey}`,
        'apikey': SUPABASE_CONFIG.anonKey
      };

      console.log('📡 Request:', { url, headers: { ...headers, Authorization: headers.Authorization.substring(0, 30) + '...' } });

      const response = await fetch(url, {
        method: 'GET',
        headers
      });

      const data = await response.json();

      setResult({
        success: response.ok,
        status: response.status,
        statusText: response.statusText,
        data,
        headers: Object.fromEntries(response.headers.entries())
      });

      console.log('✅ Response:', { status: response.status, data });
    } catch (error: any) {
      console.error('❌ Error:', error);
      setResult({
        success: false,
        error: error.message,
        stack: error.stack
      });
    } finally {
      setTesting(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Terminal className="h-5 w-5" />
          Edge Function Tester
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Alert>
          <AlertDescription>
            Testing: GET {SUPABASE_CONFIG.url}/functions/v1/fetch-jobs/health
          </AlertDescription>
        </Alert>

        <Button onClick={testEdgeFunction} disabled={testing}>
          {testing ? <Loader2 className="mr-2 h-4 w-4 animate-spin" /> : null}
          Test Health Endpoint
        </Button>

        {result && (
          <div className="space-y-3">
            <div className="flex items-center gap-2">
              {result.success ? (
                <CheckCircle className="h-5 w-5 text-green-500" />
              ) : (
                <XCircle className="h-5 w-5 text-red-500" />
              )}
              <Badge variant={result.success ? 'default' : 'destructive'}>
                HTTP {result.status || 'Error'}
              </Badge>
            </div>

            <pre className="p-4 bg-gray-100 rounded text-xs overflow-auto max-h-96">
              {JSON.stringify(result, null, 2)}
            </pre>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
