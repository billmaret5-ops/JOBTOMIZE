import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { UserPresenceIndicator } from './collaboration/UserPresenceIndicator';
import { CommentSystem } from './collaboration/CommentSystem';
import { ChangeTracker } from './collaboration/ChangeTracker';
import { useRealTimeCollaboration } from '../hooks/useRealTimeCollaboration';
import { Briefcase, Calendar, DollarSign, MapPin, MessageSquare, Activity } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';

interface Application {
  id: string;
  company: string;
  position: string;
  status: string;
  appliedDate: string;
  salary?: string;
  location: string;
}

interface CollaborativeApplicationTrackerProps {
  userId: string;
  applications: Application[];
}

export const CollaborativeApplicationTracker: React.FC<CollaborativeApplicationTrackerProps> = ({
  userId,
  applications
}) => {
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  const {
    users,
    comments,
    activities,
    isConnected,
    addComment
  } = useRealTimeCollaboration('applications', userId);

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'applied': return 'bg-blue-500';
      case 'interview': return 'bg-yellow-500';
      case 'offer': return 'bg-green-500';
      case 'rejected': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="flex gap-4 p-4">
      <div className="flex-1 space-y-4">
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Application Tracker</CardTitle>
              <div className="flex items-center gap-4">
                <UserPresenceIndicator users={users} />
                {isConnected ? (
                  <span className="flex items-center gap-2 text-sm text-green-600">
                    <span className="w-2 h-2 bg-green-600 rounded-full animate-pulse" />
                    Live
                  </span>
                ) : (
                  <span className="text-sm text-red-600">Offline</span>
                )}
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid gap-4">
              {applications.map((app) => (
                <Card 
                  key={app.id}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    selectedApp?.id === app.id ? 'ring-2 ring-primary' : ''
                  }`}
                  onClick={() => setSelectedApp(app)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between">
                      <div className="space-y-2 flex-1">
                        <div className="flex items-center gap-2">
                          <Briefcase className="w-5 h-5 text-muted-foreground" />
                          <h3 className="font-semibold text-lg">{app.position}</h3>
                        </div>
                        <p className="text-muted-foreground">{app.company}</p>
                        <div className="flex flex-wrap gap-3 text-sm">
                          <span className="flex items-center gap-1">
                            <MapPin className="w-4 h-4" />
                            {app.location}
                          </span>
                          <span className="flex items-center gap-1">
                            <Calendar className="w-4 h-4" />
                            {app.appliedDate}
                          </span>
                          {app.salary && (
                            <span className="flex items-center gap-1">
                              <DollarSign className="w-4 h-4" />
                              {app.salary}
                            </span>
                          )}
                        </div>
                      </div>
                      <Badge className={getStatusColor(app.status)}>
                        {app.status}
                      </Badge>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="w-96">
        <Tabs defaultValue="comments">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="comments">
              <MessageSquare className="w-4 h-4 mr-2" />
              Comments
            </TabsTrigger>
            <TabsTrigger value="activity">
              <Activity className="w-4 h-4 mr-2" />
              Activity
            </TabsTrigger>
          </TabsList>
          <TabsContent value="comments">
            <CommentSystem
              comments={comments}
              users={users}
              onAddComment={addComment}
            />
          </TabsContent>
          <TabsContent value="activity">
            <ChangeTracker activities={activities} users={users} />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
