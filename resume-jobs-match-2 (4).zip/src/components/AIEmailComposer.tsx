import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Sparkles, Copy, Send, Save, TrendingUp, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

export default function AIEmailComposer() {
  const { toast } = useToast();
  const [generating, setGenerating] = useState(false);
  const [inputs, setInputs] = useState({
    jobTitle: '',
    companyName: '',
    jobDescription: '',
    companyResearch: '',
    interviewNotes: '',
    tone: 'professional',
    length: 'standard',
    emailType: 'follow-up'
  });
  const [generatedEmail, setGeneratedEmail] = useState({ subject: '', body: '' });
  const [successfulEmails] = useState([
    { id: 1, subject: 'Thank you for the opportunity', body: 'I wanted to express my gratitude...', responseRate: 85 },
    { id: 2, subject: 'Following up on our conversation', body: 'I enjoyed learning about...', responseRate: 78 }
  ]);

  const generateEmail = async () => {
    setGenerating(true);
    
    // Simulate AI generation
    setTimeout(() => {
      const templates = {
        'follow-up': {
          professional: {
            subject: `Following Up: ${inputs.jobTitle} Application at ${inputs.companyName}`,
            body: `Dear Hiring Manager,\n\nI hope this email finds you well. I wanted to follow up on my application for the ${inputs.jobTitle} position at ${inputs.companyName}, which I submitted on [date].\n\n${inputs.companyResearch ? `I remain very excited about the opportunity to contribute to ${inputs.companyName}'s mission, particularly your work in ${inputs.companyResearch.substring(0, 50)}...` : 'I remain very interested in this opportunity.'}\n\n${inputs.jobDescription ? `My experience aligns well with the requirements, especially regarding ${inputs.jobDescription.substring(0, 50)}...` : 'I believe my skills would be a great fit for this role.'}\n\nI would welcome the opportunity to discuss how I can contribute to your team. Please let me know if you need any additional information.\n\nBest regards`
          }
        },
        'thank-you': {
          professional: {
            subject: `Thank You - ${inputs.jobTitle} Interview`,
            body: `Dear [Interviewer Name],\n\nThank you for taking the time to meet with me today to discuss the ${inputs.jobTitle} position at ${inputs.companyName}.\n\n${inputs.interviewNotes ? `I particularly enjoyed our conversation about ${inputs.interviewNotes.substring(0, 50)}... It reinforced my enthusiasm for the role.` : 'I enjoyed learning more about the role and your team.'}\n\nOur discussion confirmed my strong interest in joining ${inputs.companyName}. I'm confident that my skills and experience would enable me to make valuable contributions to your team.\n\nThank you again for your consideration. I look forward to hearing from you.\n\nBest regards`
          }
        }
      };

      const template = templates[inputs.emailType as keyof typeof templates]?.[inputs.tone as keyof typeof templates.professional] || templates['follow-up'].professional;
      setGeneratedEmail(template);
      setGenerating(false);
      
      toast({
        title: 'Email Generated!',
        description: 'Your personalized email is ready to review and send.'
      });
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5 text-purple-500" />
            AI Email Composer
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <Label>Job Title</Label>
              <Input value={inputs.jobTitle} onChange={(e) => setInputs({...inputs, jobTitle: e.target.value})} placeholder="Senior Software Engineer" />
            </div>
            <div>
              <Label>Company Name</Label>
              <Input value={inputs.companyName} onChange={(e) => setInputs({...inputs, companyName: e.target.value})} placeholder="Tech Corp" />
            </div>
          </div>

          <div>
            <Label>Job Description (key requirements)</Label>
            <Textarea value={inputs.jobDescription} onChange={(e) => setInputs({...inputs, jobDescription: e.target.value})} placeholder="5+ years React, TypeScript, team leadership..." rows={3} />
          </div>

          <div>
            <Label>Company Research</Label>
            <Textarea value={inputs.companyResearch} onChange={(e) => setInputs({...inputs, companyResearch: e.target.value})} placeholder="Leading fintech company, recently raised Series B..." rows={3} />
          </div>

          <div>
            <Label>Interview Notes (if applicable)</Label>
            <Textarea value={inputs.interviewNotes} onChange={(e) => setInputs({...inputs, interviewNotes: e.target.value})} placeholder="Discussed microservices architecture, team culture..." rows={3} />
          </div>

          <div className="grid md:grid-cols-3 gap-4">
            <div>
              <Label>Email Type</Label>
              <Select value={inputs.emailType} onValueChange={(v) => setInputs({...inputs, emailType: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="follow-up">Follow-up</SelectItem>
                  <SelectItem value="thank-you">Thank You</SelectItem>
                  <SelectItem value="check-in">Check-in</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Tone</Label>
              <Select value={inputs.tone} onValueChange={(v) => setInputs({...inputs, tone: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="professional">Professional</SelectItem>
                  <SelectItem value="friendly">Friendly</SelectItem>
                  <SelectItem value="casual">Casual</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Length</Label>
              <Select value={inputs.length} onValueChange={(v) => setInputs({...inputs, length: v})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="concise">Concise</SelectItem>
                  <SelectItem value="standard">Standard</SelectItem>
                  <SelectItem value="detailed">Detailed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={generateEmail} disabled={generating} className="w-full">
            {generating ? <><Loader2 className="mr-2 h-4 w-4 animate-spin" /> Generating...</> : <><Sparkles className="mr-2 h-4 w-4" /> Generate Email</>}
          </Button>
        </CardContent>
      </Card>

      {generatedEmail.subject && (
        <Card>
          <CardHeader>
            <CardTitle>Generated Email</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Subject</Label>
              <Input value={generatedEmail.subject} onChange={(e) => setGeneratedEmail({...generatedEmail, subject: e.target.value})} />
            </div>
            <div>
              <Label>Body</Label>
              <Textarea value={generatedEmail.body} onChange={(e) => setGeneratedEmail({...generatedEmail, body: e.target.value})} rows={12} />
            </div>
            <div className="flex gap-2">
              <Button onClick={() => { navigator.clipboard.writeText(`${generatedEmail.subject}\n\n${generatedEmail.body}`); toast({ title: 'Copied!' }); }}>
                <Copy className="mr-2 h-4 w-4" /> Copy
              </Button>
              <Button variant="outline"><Save className="mr-2 h-4 w-4" /> Save Template</Button>
              <Button className="ml-auto"><Send className="mr-2 h-4 w-4" /> Send Email</Button>
            </div>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="h-5 w-5 text-green-500" />
            Learning from Success
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-muted-foreground mb-4">Emails that received responses (used to improve AI generation)</p>
          <div className="space-y-2">
            {successfulEmails.map(email => (
              <div key={email.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <p className="font-medium">{email.subject}</p>
                  <p className="text-sm text-muted-foreground">{email.body.substring(0, 60)}...</p>
                </div>
                <Badge variant="secondary">{email.responseRate}% response rate</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}