import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Bot, Send, Clock, CheckCircle, AlertCircle, Play, Pause } from 'lucide-react';

interface AutoApplication {
  id: string;
  jobTitle: string;
  company: string;
  status: 'pending' | 'submitted' | 'failed';
  submittedAt?: string;
  matchScore: number;
}

export function ApplicationAutomator() {
  const [isAutomationActive, setIsAutomationActive] = useState(false);
  const [applications, setApplications] = useState<AutoApplication[]>([
    {
      id: '1',
      jobTitle: 'Senior Frontend Developer',
      company: 'TechCorp Inc',
      status: 'submitted',
      submittedAt: '2024-01-15 09:30',
      matchScore: 95
    },
    {
      id: '2',
      jobTitle: 'Full Stack Engineer',
      company: 'StartupXYZ',
      status: 'pending',
      matchScore: 88
    },
    {
      id: '3',
      jobTitle: 'React Developer',
      company: 'WebSolutions',
      status: 'failed',
      matchScore: 82
    }
  ]);

  const [automationSettings, setAutomationSettings] = useState({
    minMatchScore: 80,
    maxApplicationsPerDay: 10,
    autoCustomizeCoverLetter: true,
    autoOptimizeResume: true,
    skipCompaniesAppliedTo: true
  });

  const toggleAutomation = () => {
    setIsAutomationActive(!isAutomationActive);
    console.log('Automation toggled:', !isAutomationActive);
  };

  const retryFailedApplication = (id: string) => {
    setApplications(prev => prev.map(app => 
      app.id === id ? { ...app, status: 'pending' as const } : app
    ));
    console.log('Retrying application:', id);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'failed': return <AlertCircle className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'submitted': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'failed': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bot className="w-5 h-5" />
            Automated Job Applications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center justify-between mb-6">
            <div>
              <h3 className="text-lg font-medium">Automation Status</h3>
              <p className="text-gray-600">
                {isAutomationActive ? 'Actively applying to matching jobs' : 'Automation paused'}
              </p>
            </div>
            <Button
              onClick={toggleAutomation}
              variant={isAutomationActive ? "destructive" : "default"}
              className="flex items-center gap-2"
            >
              {isAutomationActive ? (
                <>
                  <Pause className="w-4 h-4" />
                  Pause Automation
                </>
              ) : (
                <>
                  <Play className="w-4 h-4" />
                  Start Automation
                </>
              )}
            </Button>
          </div>

          <div className="grid md:grid-cols-3 gap-4 mb-6">
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-blue-600">24</div>
                <div className="text-sm text-gray-600">Applications Sent</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-green-600">8</div>
                <div className="text-sm text-gray-600">Interviews Scheduled</div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-4 text-center">
                <div className="text-2xl font-bold text-purple-600">33%</div>
                <div className="text-sm text-gray-600">Response Rate</div>
              </CardContent>
            </Card>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Automation Settings</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <Label htmlFor="minMatch">Minimum Match Score</Label>
              <Input
                id="minMatch"
                type="number"
                value={automationSettings.minMatchScore}
                onChange={(e) => setAutomationSettings(prev => ({
                  ...prev,
                  minMatchScore: parseInt(e.target.value)
                }))}
                className="mt-1"
              />
              <p className="text-sm text-gray-500 mt-1">
                Only apply to jobs with match score above this threshold
              </p>
            </div>

            <div>
              <Label htmlFor="maxApps">Maximum Applications Per Day</Label>
              <Input
                id="maxApps"
                type="number"
                value={automationSettings.maxApplicationsPerDay}
                onChange={(e) => setAutomationSettings(prev => ({
                  ...prev,
                  maxApplicationsPerDay: parseInt(e.target.value)
                }))}
                className="mt-1"
              />
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-customize Cover Letters</Label>
                  <p className="text-sm text-gray-500">
                    Automatically tailor cover letters for each job
                  </p>
                </div>
                <Switch
                  checked={automationSettings.autoCustomizeCoverLetter}
                  onCheckedChange={(checked) => setAutomationSettings(prev => ({
                    ...prev,
                    autoCustomizeCoverLetter: checked
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Auto-optimize Resume</Label>
                  <p className="text-sm text-gray-500">
                    Optimize resume keywords for each application
                  </p>
                </div>
                <Switch
                  checked={automationSettings.autoOptimizeResume}
                  onCheckedChange={(checked) => setAutomationSettings(prev => ({
                    ...prev,
                    autoOptimizeResume: checked
                  }))}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Skip Previously Applied Companies</Label>
                  <p className="text-sm text-gray-500">
                    Avoid applying to companies you've already applied to
                  </p>
                </div>
                <Switch
                  checked={automationSettings.skipCompaniesAppliedTo}
                  onCheckedChange={(checked) => setAutomationSettings(prev => ({
                    ...prev,
                    skipCompaniesAppliedTo: checked
                  }))}
                />
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {applications.map((app) => (
              <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-4">
                  {getStatusIcon(app.status)}
                  <div>
                    <h4 className="font-medium">{app.jobTitle}</h4>
                    <p className="text-sm text-gray-600">{app.company}</p>
                    {app.submittedAt && (
                      <p className="text-xs text-gray-500">Submitted: {app.submittedAt}</p>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <Badge variant="outline">{app.matchScore}% match</Badge>
                  <Badge className={getStatusColor(app.status)}>
                    {app.status}
                  </Badge>
                  {app.status === 'failed' && (
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => retryFailedApplication(app.id)}
                    >
                      Retry
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default ApplicationAutomator;