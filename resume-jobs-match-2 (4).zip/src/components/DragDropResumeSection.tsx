import React from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { GripVertical, Eye, EyeOff, Trash2, Plus } from 'lucide-react';
import { ResumeSection } from '@/types/resume';

interface DragDropResumeSectionProps {
  section: ResumeSection;
  onUpdate: (section: ResumeSection) => void;
  onDelete: () => void;
  onDragStart: (e: React.DragEvent) => void;
  onDragOver: (e: React.DragEvent) => void;
  onDrop: (e: React.DragEvent) => void;
}

export function DragDropResumeSection({
  section,
  onUpdate,
  onDelete,
  onDragStart,
  onDragOver,
  onDrop
}: DragDropResumeSectionProps) {
  const toggleVisibility = () => {
    onUpdate({ ...section, visible: !section.visible });
  };

  const updateContent = (field: string, value: any) => {
    onUpdate({ ...section, content: { ...section.content, [field]: value } });
  };

  return (
    <Card
      className="p-4 mb-3 cursor-move hover:shadow-md transition-shadow"
      draggable
      onDragStart={onDragStart}
      onDragOver={onDragOver}
      onDrop={onDrop}
    >
      <div className="flex items-center justify-between mb-3">
        <div className="flex items-center gap-2">
          <GripVertical className="h-5 w-5 text-gray-400" />
          <Input
            value={section.title}
            onChange={(e) => onUpdate({ ...section, title: e.target.value })}
            className="font-semibold border-none p-0 h-auto"
          />
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="ghost" onClick={toggleVisibility}>
            {section.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
          </Button>
          <Button size="sm" variant="ghost" onClick={onDelete}>
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {section.visible && (
        <div className="space-y-3">
          {section.type === 'summary' && (
            <Textarea
              placeholder="Write a compelling professional summary..."
              value={section.content || ''}
              onChange={(e) => onUpdate({ ...section, content: e.target.value })}
              rows={4}
            />
          )}
          
          {section.type === 'skills' && (
            <div>
              <Input
                placeholder="Add skills (comma-separated)"
                value={section.content?.join(', ') || ''}
                onChange={(e) => onUpdate({ 
                  ...section, 
                  content: e.target.value.split(',').map(s => s.trim()) 
                })}
              />
            </div>
          )}

          {section.type === 'experience' && (
            <div className="space-y-2">
              <Input placeholder="Company" />
              <Input placeholder="Position" />
              <div className="grid grid-cols-2 gap-2">
                <Input placeholder="Start Date" type="month" />
                <Input placeholder="End Date" type="month" />
              </div>
              <Textarea placeholder="Description (one per line)" rows={3} />
            </div>
          )}
        </div>
      )}
    </Card>
  );
}
