import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Building2, Briefcase, Tag, TrendingUp, Sparkles } from 'lucide-react';

interface ExtractedEntities {
  companies: string[];
  positions: string[];
  keywords: string[];
  dates: string[];
  locations: string[];
}

export default function EmailEntityExtractor() {
  const [emailText, setEmailText] = useState('');
  const [entities, setEntities] = useState<ExtractedEntities>({
    companies: ['TechCorp', 'InnovateLabs'],
    positions: ['Senior Developer', 'Product Manager'],
    keywords: ['interview', 'application', 'review', 'next steps'],
    dates: ['March 15, 2024', 'Next Monday'],
    locations: ['San Francisco', 'Remote']
  });
  const [extracting, setExtracting] = useState(false);

  const extractEntities = async () => {
    setExtracting(true);
    // Simulate extraction
    setTimeout(() => {
      setEntities({
        companies: ['TechCorp', 'InnovateLabs', 'StartupXYZ'],
        positions: ['Senior Developer', 'Product Manager', 'UX Designer'],
        keywords: ['interview', 'application', 'offer', 'salary', 'benefits'],
        dates: ['March 15, 2024', 'Next Monday', '2:00 PM'],
        locations: ['San Francisco', 'Remote', 'New York']
      });
      setExtracting(false);
    }, 1000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Sparkles className="h-5 w-5" />
            Smart Entity Extraction
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Email Content</label>
            <Textarea
              value={emailText}
              onChange={(e) => setEmailText(e.target.value)}
              placeholder="Paste email content here..."
              rows={6}
              className="w-full"
            />
          </div>
          <Button onClick={extractEntities} disabled={extracting}>
            {extracting ? 'Extracting...' : 'Extract Entities'}
          </Button>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Building2 className="h-4 w-4" />
              Companies Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {entities.companies.map((company, idx) => (
                <Badge key={idx} variant="outline" className="bg-blue-50">
                  {company}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Briefcase className="h-4 w-4" />
              Positions Detected
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {entities.positions.map((position, idx) => (
                <Badge key={idx} variant="outline" className="bg-green-50">
                  {position}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <Tag className="h-4 w-4" />
              Keywords Extracted
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex flex-wrap gap-2">
              {entities.keywords.map((keyword, idx) => (
                <Badge key={idx} variant="outline" className="bg-purple-50">
                  {keyword}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-base">
              <TrendingUp className="h-4 w-4" />
              Dates & Locations
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <div>
                <p className="text-xs text-gray-600 mb-1">Dates:</p>
                <div className="flex flex-wrap gap-1">
                  {entities.dates.map((date, idx) => (
                    <Badge key={idx} variant="outline" className="bg-yellow-50 text-xs">
                      {date}
                    </Badge>
                  ))}
                </div>
              </div>
              <div>
                <p className="text-xs text-gray-600 mb-1">Locations:</p>
                <div className="flex flex-wrap gap-1">
                  {entities.locations.map((location, idx) => (
                    <Badge key={idx} variant="outline" className="bg-orange-50 text-xs">
                      {location}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
