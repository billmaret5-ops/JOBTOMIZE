import React from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CSVImportManager } from './CSVImportManager';
import { ContactSegmentBuilder } from './ContactSegmentBuilder';
import { BulkContactExporter } from './BulkContactExporter';
import { Upload, Filter, Download } from 'lucide-react';

export const ContactImportDashboard = () => {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-8">
        <h1 className="text-3xl font-bold mb-2">Contact Management</h1>
        <p className="text-gray-600">
          Import, segment, and export your contact lists with advanced validation and filtering
        </p>
      </div>

      <Tabs defaultValue="import" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="import" className="flex items-center gap-2">
            <Upload className="h-4 w-4" />
            Import Contacts
          </TabsTrigger>
          <TabsTrigger value="segments" className="flex items-center gap-2">
            <Filter className="h-4 w-4" />
            Create Segments
          </TabsTrigger>
          <TabsTrigger value="export" className="flex items-center gap-2">
            <Download className="h-4 w-4" />
            Export Data
          </TabsTrigger>
        </TabsList>

        <TabsContent value="import" className="mt-6">
          <CSVImportManager />
        </TabsContent>

        <TabsContent value="segments" className="mt-6">
          <ContactSegmentBuilder />
        </TabsContent>

        <TabsContent value="export" className="mt-6">
          <BulkContactExporter />
        </TabsContent>
      </Tabs>
    </div>
  );
};