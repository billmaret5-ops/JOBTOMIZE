import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { supabase } from '@/lib/supabase';
import { Building2, TrendingUp, Users, Target, Save, Sparkles } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

interface CompanyResearchAnalyzerProps {
  interviewId: string;
  company: string;
}

export default function CompanyResearchAnalyzer({ interviewId, company }: CompanyResearchAnalyzerProps) {
  const [notes, setNotes] = useState('');
  const [aiInsights, setAiInsights] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadNotes();
  }, [interviewId]);

  const loadNotes = async () => {
    const { data } = await supabase
      .from('company_research_notes')
      .select('*')
      .eq('interview_id', interviewId)
      .single();

    if (data) {
      setNotes(data.notes || '');
      setAiInsights(data.ai_insights);
    }
  };

  const saveNotes = async () => {
    const { error } = await supabase
      .from('company_research_notes')
      .upsert({
        interview_id: interviewId,
        company: company,
        notes: notes,
        updated_at: new Date().toISOString()
      });

    if (!error) {
      toast({
        title: 'Notes Saved',
        description: 'Your research notes have been saved.'
      });
    }
  };

  const generateInsights = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-company-research', {
        body: { company, notes }
      });

      if (!error && data) {
        setAiInsights(data.insights);
        
        await supabase
          .from('company_research_notes')
          .upsert({
            interview_id: interviewId,
            company: company,
            notes: notes,
            ai_insights: data.insights,
            updated_at: new Date().toISOString()
          });

        toast({
          title: 'Insights Generated',
          description: 'AI has analyzed the company information.'
        });
      }
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to generate insights.',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Building2 className="w-5 h-5" />
          Company Research: {company}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <Tabs defaultValue="notes">
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="notes">Research Notes</TabsTrigger>
            <TabsTrigger value="insights">AI Insights</TabsTrigger>
          </TabsList>

          <TabsContent value="notes" className="space-y-4">
            <div>
              <Textarea
                value={notes}
                onChange={(e) => setNotes(e.target.value)}
                placeholder="Add your research notes about the company, their products, culture, recent news, competitors, etc."
                rows={12}
                className="resize-none"
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={saveNotes} className="flex-1">
                <Save className="w-4 h-4 mr-2" />
                Save Notes
              </Button>
              <Button onClick={generateInsights} variant="secondary" disabled={loading}>
                <Sparkles className="w-4 h-4 mr-2" />
                {loading ? 'Analyzing...' : 'Generate Insights'}
              </Button>
            </div>
          </TabsContent>

          <TabsContent value="insights" className="space-y-4">
            {!aiInsights ? (
              <div className="text-center py-8 text-muted-foreground">
                <Sparkles className="w-12 h-12 mx-auto mb-3 opacity-50" />
                <p>No insights generated yet.</p>
                <p className="text-sm">Add research notes and click "Generate Insights"</p>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Target className="w-4 h-4 text-blue-500" />
                    <h4 className="font-semibold">Key Focus Areas</h4>
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {aiInsights.focus_areas?.map((area: string, i: number) => (
                      <Badge key={i} variant="secondary">{area}</Badge>
                    ))}
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-green-500" />
                    <h4 className="font-semibold">Recent Developments</h4>
                  </div>
                  <ul className="space-y-2 text-sm">
                    {aiInsights.recent_news?.map((news: string, i: number) => (
                      <li key={i} className="flex gap-2">
                        <span className="text-muted-foreground">•</span>
                        <span>{news}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center gap-2">
                    <Users className="w-4 h-4 text-purple-500" />
                    <h4 className="font-semibold">Culture Insights</h4>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    {aiInsights.culture_summary}
                  </p>
                </div>

                <div className="p-3 bg-blue-50 dark:bg-blue-950 border border-blue-200 dark:border-blue-800 rounded-lg">
                  <h4 className="font-semibold text-sm mb-2">Questions to Ask</h4>
                  <ul className="space-y-1 text-sm">
                    {aiInsights.suggested_questions?.map((q: string, i: number) => (
                      <li key={i} className="text-muted-foreground">• {q}</li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
}
