import React, { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from './ui/card'
import { Badge } from './ui/badge'
import { Button } from './ui/button'
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs'
import { Alert, AlertDescription } from './ui/alert'
import { Progress } from './ui/progress'
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts'

interface DeliverabilityMetrics {
  id: string
  domain: string
  provider: string
  sent_count: number
  delivered_count: number
  bounced_count: number
  spam_complaints: number
  inbox_placement_rate: number
  bounce_rate: number
  complaint_rate: number
  recorded_at: string
}

interface SenderReputation {
  id: string
  domain: string
  reputation_score: number
  blacklist_status: Record<string, boolean>
  last_checked: string
}

interface DomainAuth {
  domain: string
  spf_status: string
  dkim_status: string
  dmarc_status: string
  bimi_status: string
  last_verified: string
}

interface DeliverabilityAlert {
  id: string
  alert_type: string
  severity: 'low' | 'medium' | 'high'
  message: string
  current_value: number
  created_at: string
}

export default function EmailDeliverabilityDashboard() {
  const [metrics, setMetrics] = useState<DeliverabilityMetrics[]>([])
  const [reputation, setReputation] = useState<SenderReputation[]>([])
  const [authentication, setAuthentication] = useState<DomainAuth[]>([])
  const [alerts, setAlerts] = useState<DeliverabilityAlert[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadDeliverabilityData()
  }, [])

  const loadDeliverabilityData = async () => {
    try {
      // Simulate API calls
      setMetrics([
        {
          id: '1',
          domain: 'example.com',
          provider: 'Gmail',
          sent_count: 10000,
          delivered_count: 9850,
          bounced_count: 150,
          spam_complaints: 5,
          inbox_placement_rate: 95.2,
          bounce_rate: 1.5,
          complaint_rate: 0.05,
          recorded_at: new Date().toISOString()
        }
      ])

      setReputation([
        {
          id: '1',
          domain: 'example.com',
          reputation_score: 85,
          blacklist_status: { spamhaus: false, barracuda: false },
          last_checked: new Date().toISOString()
        }
      ])

      setAuthentication([
        {
          domain: 'example.com',
          spf_status: 'valid',
          dkim_status: 'valid',
          dmarc_status: 'valid',
          bimi_status: 'not_configured',
          last_verified: new Date().toISOString()
        }
      ])

      setAlerts([
        {
          id: '1',
          alert_type: 'bounce_rate',
          severity: 'medium',
          message: 'Bounce rate increased by 15% in last 24 hours',
          current_value: 2.1,
          created_at: new Date().toISOString()
        }
      ])

      setLoading(false)
    } catch (error) {
      console.error('Error loading deliverability data:', error)
      setLoading(false)
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'valid': return 'bg-green-500'
      case 'invalid': return 'bg-red-500'
      case 'warning': return 'bg-yellow-500'
      default: return 'bg-gray-500'
    }
  }

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'high': return 'destructive'
      case 'medium': return 'default'
      case 'low': return 'secondary'
      default: return 'default'
    }
  }

  if (loading) {
    return <div className="p-6">Loading deliverability data...</div>
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Email Deliverability Monitor</h1>
        <Button onClick={loadDeliverabilityData}>Refresh Data</Button>
      </div>

      {/* Alerts */}
      {alerts.length > 0 && (
        <div className="space-y-2">
          {alerts.map((alert) => (
            <Alert key={alert.id} className="border-l-4 border-l-red-500">
              <AlertDescription>
                <div className="flex justify-between items-center">
                  <span>{alert.message}</span>
                  <Badge variant={getSeverityColor(alert.severity)}>
                    {alert.severity}
                  </Badge>
                </div>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="reputation">Sender Reputation</TabsTrigger>
          <TabsTrigger value="authentication">Domain Authentication</TabsTrigger>
          <TabsTrigger value="metrics">Delivery Metrics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Inbox Placement Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">95.2%</div>
                <Progress value={95.2} className="mt-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Bounce Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">1.5%</div>
                <Progress value={1.5} className="mt-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Spam Complaint Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">0.05%</div>
                <Progress value={0.05} className="mt-2" />
              </CardContent>
            </Card>
            <Card>
              <CardHeader className="pb-2">
                <CardTitle className="text-sm font-medium">Sender Reputation</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold">85/100</div>
                <Progress value={85} className="mt-2" />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="reputation" className="space-y-4">
          {reputation.map((rep) => (
            <Card key={rep.id}>
              <CardHeader>
                <CardTitle>Domain: {rep.domain}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <h3 className="font-semibold mb-2">Reputation Score</h3>
                    <div className="text-3xl font-bold">{rep.reputation_score}/100</div>
                    <Progress value={rep.reputation_score} className="mt-2" />
                  </div>
                  <div>
                    <h3 className="font-semibold mb-2">Blacklist Status</h3>
                    <div className="space-y-1">
                      {Object.entries(rep.blacklist_status).map(([list, status]) => (
                        <div key={list} className="flex justify-between items-center">
                          <span className="capitalize">{list}</span>
                          <Badge variant={status ? "destructive" : "default"}>
                            {status ? "Listed" : "Clean"}
                          </Badge>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="authentication" className="space-y-4">
          {authentication.map((auth) => (
            <Card key={auth.domain}>
              <CardHeader>
                <CardTitle>Domain Authentication: {auth.domain}</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center">
                    <div className="font-semibold">SPF</div>
                    <div className={`w-4 h-4 rounded-full mx-auto mt-1 ${getStatusColor(auth.spf_status)}`}></div>
                    <div className="text-sm text-gray-600 capitalize">{auth.spf_status}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">DKIM</div>
                    <div className={`w-4 h-4 rounded-full mx-auto mt-1 ${getStatusColor(auth.dkim_status)}`}></div>
                    <div className="text-sm text-gray-600 capitalize">{auth.dkim_status}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">DMARC</div>
                    <div className={`w-4 h-4 rounded-full mx-auto mt-1 ${getStatusColor(auth.dmarc_status)}`}></div>
                    <div className="text-sm text-gray-600 capitalize">{auth.dmarc_status}</div>
                  </div>
                  <div className="text-center">
                    <div className="font-semibold">BIMI</div>
                    <div className={`w-4 h-4 rounded-full mx-auto mt-1 ${getStatusColor(auth.bimi_status)}`}></div>
                    <div className="text-sm text-gray-600 capitalize">{auth.bimi_status}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="metrics" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Delivery Metrics by Provider</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={metrics}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="provider" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="inbox_placement_rate" fill="#8884d8" />
                  <Bar dataKey="bounce_rate" fill="#82ca9d" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}