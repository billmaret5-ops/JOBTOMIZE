import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Bell, Plus, AlertTriangle } from 'lucide-react';
import { backupCostAnalysisService, BudgetAlert } from '@/services/backupCostAnalysisService';

export const BudgetAlertsManager: React.FC = () => {
  const [alerts, setAlerts] = useState<BudgetAlert[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({ name: '', threshold: '', alertType: 'monthly' });

  useEffect(() => {
    loadAlerts();
  }, []);

  const loadAlerts = async () => {
    const data = await backupCostAnalysisService.getBudgetAlerts();
    setAlerts(data);
  };

  const handleToggle = (id: string) => {
    setAlerts(alerts.map(a => a.id === id ? { ...a, enabled: !a.enabled } : a));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const newAlert: BudgetAlert = {
      id: Date.now().toString(),
      name: formData.name,
      threshold: parseFloat(formData.threshold),
      currentSpend: 0,
      alertType: formData.alertType as any,
      enabled: true
    };
    setAlerts([...alerts, newAlert]);
    setFormData({ name: '', threshold: '', alertType: 'monthly' });
    setShowForm(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h3 className="text-lg font-semibold">Budget Alerts</h3>
        <Button onClick={() => setShowForm(!showForm)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Alert
        </Button>
      </div>

      {showForm && (
        <Card>
          <CardContent className="pt-6">
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <Label>Alert Name</Label>
                <Input value={formData.name} onChange={(e) => setFormData({...formData, name: e.target.value})} required />
              </div>
              <div>
                <Label>Budget Threshold ($)</Label>
                <Input type="number" value={formData.threshold} onChange={(e) => setFormData({...formData, threshold: e.target.value})} required />
              </div>
              <div>
                <Label>Period</Label>
                <Select value={formData.alertType} onValueChange={(v) => setFormData({...formData, alertType: v})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="monthly">Monthly</SelectItem>
                    <SelectItem value="quarterly">Quarterly</SelectItem>
                    <SelectItem value="annual">Annual</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <Button type="submit">Create Alert</Button>
            </form>
          </CardContent>
        </Card>
      )}

      <div className="space-y-4">
        {alerts.map((alert) => {
          const percentage = (alert.currentSpend / alert.threshold) * 100;
          const isWarning = percentage > 80;
          
          return (
            <Card key={alert.id}>
              <CardContent className="pt-6">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-2">
                      <Bell className="w-4 h-4" />
                      <h4 className="font-semibold">{alert.name}</h4>
                      <Badge variant={isWarning ? "destructive" : "secondary"}>
                        {alert.alertType}
                      </Badge>
                    </div>
                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span>Current Spend: ${alert.currentSpend}</span>
                        <span>Threshold: ${alert.threshold}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div className={`h-2 rounded-full ${isWarning ? 'bg-red-500' : 'bg-blue-500'}`} style={{width: `${Math.min(percentage, 100)}%`}} />
                      </div>
                      <p className="text-sm text-gray-600">{percentage.toFixed(1)}% of budget used</p>
                    </div>
                  </div>
                  <Switch checked={alert.enabled} onCheckedChange={() => handleToggle(alert.id)} />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};
