import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Fingerprint, AlertCircle, Shield, ArrowLeft } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface BiometricLoginVerificationProps {
  email: string;
  onSuccess: (credential: any) => void;
  onFallback: () => void;
  onCancel: () => void;
}

export function BiometricLoginVerification({ 
  email, 
  onSuccess, 
  onFallback, 
  onCancel 
}: BiometricLoginVerificationProps) {
  const [isVerifying, setIsVerifying] = useState(false);
  const [error, setError] = useState('');
  const [isSupported, setIsSupported] = useState(false);

  useEffect(() => {
    const supported = window.PublicKeyCredential && 
                     navigator.credentials && 
                     navigator.credentials.get;
    setIsSupported(supported);

    if (supported) {
      // Auto-trigger biometric verification
      handleBiometricVerification();
    }
  }, []);

  const handleBiometricVerification = async () => {
    setIsVerifying(true);
    setError('');

    try {
      // Generate challenge
      const challenge = new Uint8Array(32);
      crypto.getRandomValues(challenge);

      const getCredentialOptions: CredentialRequestOptions = {
        publicKey: {
          challenge,
          timeout: 60000,
          rpId: window.location.hostname,
          userVerification: 'required',
        },
      };

      const credential = await navigator.credentials.get(getCredentialOptions) as PublicKeyCredential;
      
      if (!credential) {
        throw new Error('No credential received');
      }

      const response = credential.response as AuthenticatorAssertionResponse;
      const credentialId = Array.from(new Uint8Array(credential.rawId));

      // Verify with backend
      const { data, error } = await supabase.functions.invoke('biometric-auth-manager', {
        body: {
          action: 'verify_credential',
          credentialId: btoa(String.fromCharCode(...credentialId)),
        }
      });

      if (error) throw error;

      if (data?.success) {
        onSuccess(data.credential);
      } else {
        throw new Error('Verification failed');
      }
    } catch (err: any) {
      console.error('Biometric verification failed:', err);
      setError(err.message || 'Biometric verification failed');
    } finally {
      setIsVerifying(false);
    }
  };

  if (!isSupported) {
    return (
      <Card className="w-full max-w-md mx-auto">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Fingerprint className="h-5 w-5" />
            Biometric Authentication
          </CardTitle>
          <CardDescription>
            Biometric authentication is not supported on this device
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Please use an alternative authentication method.
            </AlertDescription>
          </Alert>
          
          <div className="flex gap-2">
            <Button variant="outline" onClick={onCancel} className="flex-1">
              <ArrowLeft className="h-4 w-4 mr-2" />
              Back
            </Button>
            <Button onClick={onFallback} className="flex-1">
              Use Password
            </Button>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Fingerprint className="h-5 w-5" />
          Biometric Authentication
        </CardTitle>
        <CardDescription>
          Use your fingerprint or face recognition to sign in
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        <div className="text-center py-8">
          <div className="mx-auto w-16 h-16 bg-primary/10 rounded-full flex items-center justify-center mb-4">
            <Fingerprint className={`h-8 w-8 text-primary ${isVerifying ? 'animate-pulse' : ''}`} />
          </div>
          <p className="text-sm text-muted-foreground">
            {isVerifying 
              ? 'Verifying your biometric authentication...'
              : 'Touch the sensor or look at the camera to authenticate'
            }
          </p>
        </div>

        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={onCancel}
            disabled={isVerifying}
            className="flex-1"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Cancel
          </Button>
          <Button 
            onClick={onFallback}
            disabled={isVerifying}
            className="flex-1"
          >
            Use Password/2FA
          </Button>
        </div>

        {!isVerifying && (
          <Button 
            onClick={handleBiometricVerification}
            className="w-full"
            variant="outline"
          >
            <Shield className="h-4 w-4 mr-2" />
            Try Again
          </Button>
        )}
      </CardContent>
    </Card>
  );
}