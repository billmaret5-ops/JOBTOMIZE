import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { UserPresenceIndicator } from './collaboration/UserPresenceIndicator';
import { LiveCursorOverlay } from './collaboration/LiveCursorOverlay';
import { CommentSystem } from './collaboration/CommentSystem';
import { ChangeTracker } from './collaboration/ChangeTracker';
import { useRealTimeCollaboration } from '../hooks/useRealTimeCollaboration';
import { Users, MessageCircle, History, Share2, Lock, Unlock, Wifi, WifiOff } from 'lucide-react';

interface User {
  id: string;
  name: string;
  avatar?: string;
  color: string;
  isActive: boolean;
  lastSeen: Date;
  cursor?: { x: number; y: number };
}

interface Comment {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  content: string;
  timestamp: Date;
  position: { x: number; y: number };
  elementId?: string;
  status: 'open' | 'resolved';
  replies: Comment[];
}

interface Change {
  id: string;
  userId: string;
  userName: string;
  userAvatar?: string;
  timestamp: Date;
  type: 'content' | 'style' | 'structure' | 'settings';
  description: string;
  elementId?: string;
  oldValue?: any;
  newValue?: any;
  conflicted?: boolean;
}

interface Version {
  id: string;
  name: string;
  description: string;
  timestamp: Date;
  userId: string;
  userName: string;
  changeCount: number;
  isCurrent: boolean;
}

export const CollaborativeEmailEditor: React.FC = () => {
  const templateId = 'template-123'; // In real app, this would come from props/router
  const currentUser = { 
    id: 'current-user', 
    name: 'You', 
    avatar: 'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758515212756_a07a094e.webp' 
  };

  // Real-time collaboration hook
  const {
    activeUsers,
    comments,
    isConnected,
    isLoading,
    conflicts,
    sendTextOperation,
    sendFormatOperation,
    updateCursor,
    updateSelection,
    addComment,
    replyToComment,
    resolveComment
  } = useRealTimeCollaboration({
    templateId,
    userId: currentUser.id,
    userName: currentUser.name,
    userAvatar: currentUser.avatar
  });

  const [isLocked, setIsLocked] = useState(false);
  const [activePanel, setActivePanel] = useState<'comments' | 'changes' | null>(null);
  const [selectedText, setSelectedText] = useState<string>('');
  const editorRef = useRef<HTMLDivElement>(null);

  // Handle mouse movement for cursor tracking
  const handleMouseMove = (e: React.MouseEvent) => {
    if (!editorRef.current) return;
    
    const rect = editorRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    updateCursor(x, y);
  };

  // Handle text selection
  const handleTextSelection = () => {
    const selection = window.getSelection();
    if (selection && selection.rangeCount > 0) {
      const range = selection.getRangeAt(0);
      const selectedText = range.toString();
      
      if (selectedText) {
        setSelectedText(selectedText);
        updateSelection(range.startOffset, range.endOffset);
      }
    }
  };

  // Handle content changes
  const handleContentChange = async (
    type: 'insert' | 'delete',
    position: number,
    content?: string,
    length?: number
  ) => {
    await sendTextOperation(type, position, content, length);
  };

  // Handle comment addition
  const handleAddComment = async (e: React.MouseEvent) => {
    if (!editorRef.current) return;
    
    const rect = editorRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    const commentContent = prompt('Add a comment:');
    if (commentContent) {
      await addComment(commentContent, { x, y });
    }
  };

  // Convert activeUsers to cursor format
  const cursors = activeUsers
    .filter(user => user.isActive && user.cursor && user.userId !== currentUser.id)
    .map(user => ({
      userId: user.userId,
      userName: user.userName,
      x: user.cursor!.x,
      y: user.cursor!.y,
      color: user.color,
      isTyping: Math.random() > 0.7 // Simulate typing indicator
    }));

  // Mock data for demonstration
  const mockChanges: Change[] = [
    {
      id: '1',
      userId: 'user-1',
      userName: 'Sarah Johnson',
      timestamp: new Date(Date.now() - 300000),
      type: 'style',
      description: 'Changed button color to blue',
      conflicted: false
    },
    {
      id: '2',
      userId: 'user-2',
      userName: 'Mike Chen',
      timestamp: new Date(Date.now() - 600000),
      type: 'content',
      description: 'Updated headline text',
      conflicted: conflicts.length > 0
    }
  ];

  const mockVersions: Version[] = [
    {
      id: '1',
      name: 'v1.2',
      description: 'Updated CTA and hero section',
      timestamp: new Date(),
      userId: 'user-1',
      userName: 'Sarah Johnson',
      changeCount: 5,
      isCurrent: true
    },
    {
      id: '2',
      name: 'v1.1',
      description: 'Initial design with product showcase',
      timestamp: new Date(Date.now() - 86400000),
      userId: 'user-2',
      userName: 'Mike Chen',
      changeCount: 12,
      isCurrent: false
    }
  ];

  return (
    <div className="h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <div className="bg-white border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-semibold">Real-Time Email Editor</h1>
            <Badge variant="outline" className="flex items-center space-x-1">
              {isConnected ? (
                <>
                  <Wifi className="w-3 h-3 text-green-500" />
                  <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                  <span>Connected</span>
                </>
              ) : (
                <>
                  <WifiOff className="w-3 h-3 text-red-500" />
                  <div className="w-2 h-2 bg-red-500 rounded-full" />
                  <span>Disconnected</span>
                </>
              )}
            </Badge>
            {conflicts.length > 0 && (
              <Badge variant="destructive">
                {conflicts.length} Conflict{conflicts.length !== 1 ? 's' : ''}
              </Badge>
            )}
          </div>
          
          <div className="flex items-center space-x-4">
            <UserPresenceIndicator users={activeUsers} currentUserId={currentUser.id} />
            
            <div className="flex items-center space-x-2">
              <Button
                variant={activePanel === 'comments' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActivePanel(activePanel === 'comments' ? null : 'comments')}
              >
                <MessageCircle className="h-4 w-4 mr-1" />
                Comments ({comments.filter(c => c.status === 'open').length})
              </Button>
              
              <Button
                variant={activePanel === 'changes' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setActivePanel(activePanel === 'changes' ? null : 'changes')}
               >
                 <History className="h-4 w-4 mr-1" />
                 Changes ({mockChanges.length})
               </Button>
              
              <Button
                variant={isLocked ? 'destructive' : 'outline'}
                size="sm"
                onClick={() => setIsLocked(!isLocked)}
              >
                {isLocked ? <Lock className="h-4 w-4 mr-1" /> : <Unlock className="h-4 w-4 mr-1" />}
                {isLocked ? 'Locked' : 'Unlocked'}
              </Button>
              
              <Button size="sm">
                <Share2 className="h-4 w-4 mr-1" />
                Share
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 flex">
        {/* Editor Area */}
        <div className="flex-1 relative">
          <div 
            ref={editorRef}
            className="h-full bg-white m-4 rounded-lg shadow-sm border border-gray-200 relative overflow-hidden"
            onMouseMove={handleMouseMove}
            onMouseUp={handleTextSelection}
            onDoubleClick={handleAddComment}
          >
            <LiveCursorOverlay cursors={cursors} containerRef={editorRef} />
            
            {/* Real-time editing toolbar */}
            <div className="absolute top-4 right-4 bg-white rounded-lg shadow-lg border p-2 flex items-center space-x-2">
              <Badge variant="outline" className="text-xs">
                {activeUsers.length} online
              </Badge>
              {selectedText && (
                <Button 
                  size="sm" 
                  variant="outline"
                  onClick={() => handleContentChange('format', 0, selectedText)}
                >
                  Format
                </Button>
              )}
            </div>
            <div className="p-8">
              <div className="max-w-2xl mx-auto bg-white border border-gray-200 rounded-lg overflow-hidden">
                {/* Email Header */}
                <div className="bg-gradient-to-r from-blue-600 to-purple-600 text-white p-8 text-center">
                  <h1 className="text-3xl font-bold mb-2">Summer Sale</h1>
                  <p className="text-blue-100">Up to 50% off selected items</p>
                </div>
                
                {/* Email Body */}
                <div className="p-8">
                  <div className="mb-6">
                    <img 
                      src="https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758515212756_a07a094e.webp"
                      alt="Collaborative Editor"
                      className="w-full h-48 object-cover rounded-lg mb-4"
                    />
                    <h2 className="text-2xl font-semibold mb-3">Don't Miss Out!</h2>
                    <p className="text-gray-600 mb-4">
                      Our biggest sale of the year is here. Shop now and save big on your favorite products.
                    </p>
                  </div>
                  
                  <div className="text-center">
                    <Button size="lg" className="bg-blue-600 hover:bg-blue-700">
                      Shop Now
                    </Button>
                  </div>
                </div>
                
                {/* Email Footer */}
                <div className="bg-gray-50 p-6 text-center text-sm text-gray-500">
                  <p>© 2024 Your Company. All rights reserved.</p>
                  <p className="mt-1">
                    <a href="#" className="text-blue-600 hover:underline">Unsubscribe</a> | 
                    <a href="#" className="text-blue-600 hover:underline ml-1">Update Preferences</a>
                  </p>
                </div>
              </div>
            </div>
            
            {isLocked && (
              <div className="absolute inset-0 bg-black bg-opacity-20 flex items-center justify-center">
                <Card className="p-6 text-center">
                  <Lock className="h-8 w-8 mx-auto mb-2 text-red-500" />
                  <p className="font-medium">Template Locked</p>
                  <p className="text-sm text-gray-500">Another user is making changes</p>
                </Card>
              </div>
            )}
          </div>
        </div>

        {/* Side Panels */}
        {activePanel === 'comments' && (
          <CommentSystem
            comments={comments}
            onAddComment={() => {}}
            onReplyToComment={() => {}}
            onResolveComment={() => {}}
            onDeleteComment={() => {}}
            currentUser={currentUser}
          />
        )}
        
        {activePanel === 'changes' && (
          <ChangeTracker
            changes={mockChanges}
            versions={mockVersions}
            onRevertChange={() => {}}
            onCreateVersion={() => {}}
            onRestoreVersion={() => {}}
            onPreviewChange={() => {}}
            onResolveConflict={() => {}}
          />
        )}
      </div>
    </div>
  );
};