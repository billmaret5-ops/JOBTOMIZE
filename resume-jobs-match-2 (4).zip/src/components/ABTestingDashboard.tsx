import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Plus, Play, Pause, BarChart3 } from 'lucide-react';
import { ABTestCreator } from './ABTestCreator';
import { ABTestResults } from './ABTestResults';
import { abTestService, ABTest } from '@/services/abTestService';
import { useToast } from '@/hooks/use-toast';

export function ABTestingDashboard() {
  const [tests, setTests] = useState<ABTest[]>([]);
  const [selectedTest, setSelectedTest] = useState<ABTest | null>(null);
  const [activeTab, setActiveTab] = useState('overview');
  const [loading, setLoading] = useState(true);
  const { toast } = useToast();

  useEffect(() => {
    loadTests();
  }, []);

  const loadTests = async () => {
    try {
      const testsData = await abTestService.getTests();
      setTests(testsData);
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to load tests', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const handleTestCreated = (test: ABTest) => {
    setTests(prev => [test, ...prev]);
    setActiveTab('overview');
  };

  const toggleTestStatus = async (test: ABTest) => {
    const newStatus = test.status === 'running' ? 'paused' : 'running';
    try {
      await abTestService.updateTestStatus(test.id, newStatus);
      setTests(prev => prev.map(t => t.id === test.id ? { ...t, status: newStatus } : t));
      toast({ title: 'Success', description: `Test ${newStatus}` });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to update test', variant: 'destructive' });
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      case 'paused': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading A/B tests...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">A/B Testing Dashboard</h1>
        <Button onClick={() => setActiveTab('create')}>
          <Plus className="h-4 w-4 mr-2" />
          Create Test
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="create">Create Test</TabsTrigger>
          {selectedTest && <TabsTrigger value="results">Test Results</TabsTrigger>}
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card>
              <CardHeader>
                <CardTitle>Total Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold">{tests.length}</div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Running Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  {tests.filter(t => t.status === 'running').length}
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Completed Tests</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">
                  {tests.filter(t => t.status === 'completed').length}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Tests</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {tests.map(test => (
                  <div key={test.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex-1">
                      <div className="flex items-center space-x-2">
                        <h3 className="font-medium">{test.name}</h3>
                        <Badge className={getStatusColor(test.status)}>{test.status}</Badge>
                        <Badge variant="outline">{test.test_type.replace('_', ' ')}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mt-1">
                        Created {new Date(test.created_at).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        onClick={() => {
                          setSelectedTest(test);
                          setActiveTab('results');
                        }}
                        variant="outline"
                        size="sm"
                      >
                        <BarChart3 className="h-4 w-4 mr-2" />
                        View Results
                      </Button>
                      {test.status !== 'completed' && (
                        <Button
                          onClick={() => toggleTestStatus(test)}
                          variant="outline"
                          size="sm"
                        >
                          {test.status === 'running' ? (
                            <><Pause className="h-4 w-4 mr-2" />Pause</>
                          ) : (
                            <><Play className="h-4 w-4 mr-2" />Start</>
                          )}
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
                {tests.length === 0 && (
                  <div className="text-center py-8 text-gray-500">
                    No A/B tests found. Create your first test to get started.
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="create">
          <ABTestCreator
            campaignId="default"
            onTestCreated={handleTestCreated}
          />
        </TabsContent>

        {selectedTest && (
          <TabsContent value="results">
            <ABTestResults test={selectedTest} />
          </TabsContent>
        )}
      </Tabs>
    </div>
  );
}