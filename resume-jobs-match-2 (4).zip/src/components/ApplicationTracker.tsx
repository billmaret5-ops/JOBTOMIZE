import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ApplicationPipeline } from './ApplicationPipeline';
import { ApplicationNotes } from './ApplicationNotes';
import { ApplicationAnalytics } from './ApplicationAnalytics';
import { 
  Plus, 
  Search, 
  Filter, 
  Calendar, 
  Bell,
  BarChart3,
  Target,
  Clock,
  CheckCircle
} from 'lucide-react';
import { toast } from 'sonner';

interface Application {
  id: string;
  job_title: string;
  company_name: string;
  location?: string;
  salary_range?: string;
  status: 'saved' | 'applied' | 'interviewing' | 'offer' | 'rejected';
  applied_date?: string;
  follow_up_date?: string;
  interview_date?: string;
  job_url?: string;
  notes?: any[];
  priority?: 'high' | 'medium' | 'low';
  created_at: string;
  updated_at: string;
}

export function ApplicationTracker() {
  const { user } = useAuth();
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user]);

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .select('*')
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      console.error('Error fetching applications:', error);
      toast.error('Failed to fetch applications');
    } finally {
      setLoading(false);
    }
  };


  const updateApplicationNotes = (appId: string, notes: any[]) => {
    setApplications(prev => prev.map(app => 
      app.id === appId ? { ...app, notes } : app
    ));
  };

  const stats = {
    total: applications.length,
    applied: applications.filter(app => app.status === 'applied').length,
    interviewing: applications.filter(app => app.status === 'interviewing').length,
    offers: applications.filter(app => app.status === 'offer').length,
    pending: applications.filter(app => app.follow_up_date && new Date(app.follow_up_date) <= new Date()).length
  };

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Application Tracker</h1>
          <p className="text-gray-600 mt-2">Track your job applications, interviews, and success rate</p>
        </div>
        <Button>
          <Plus className="w-4 h-4 mr-2" />
          Add Application
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-sm text-gray-600">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{stats.applied}</p>
                <p className="text-sm text-gray-600">Applied</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">{stats.interviewing}</p>
                <p className="text-sm text-gray-600">Interviewing</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{stats.offers}</p>
                <p className="text-sm text-gray-600">Offers</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-2xl font-bold">{stats.pending}</p>
                <p className="text-sm text-gray-600">Follow-ups</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="pipeline" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="notes">Notes</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="pipeline" className="mt-6">
          <ApplicationPipeline applications={applications} />
        </TabsContent>

        <TabsContent value="applications" className="mt-6">
          <div className="space-y-4">
            {applications.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Target className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-500 mb-4">No applications tracked yet</p>
                  <Button>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Application
                  </Button>
                </CardContent>
              </Card>
            ) : (
              applications.map((app) => (
                <Card key={app.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{app.job_title}</h3>
                        <p className="text-gray-600">{app.company_name}</p>
                        {app.location && <p className="text-sm text-gray-500">{app.location}</p>}
                        {app.salary_range && <p className="text-sm text-green-600">{app.salary_range}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          app.status === 'offer' ? 'bg-green-100 text-green-800' :
                          app.status === 'interviewing' ? 'bg-yellow-100 text-yellow-800' :
                          app.status === 'applied' ? 'bg-blue-100 text-blue-800' :
                          app.status === 'rejected' ? 'bg-red-100 text-red-800' :
                          'bg-gray-100 text-gray-800'
                        }`}>
                          {app.status.charAt(0).toUpperCase() + app.status.slice(1)}
                        </span>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setSelectedApp(app)}
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                      {app.applied_date && (
                        <span>Applied: {new Date(app.applied_date).toLocaleDateString()}</span>
                      )}
                      {app.interview_date && (
                        <span>Interview: {new Date(app.interview_date).toLocaleDateString()}</span>
                      )}
                      {app.follow_up_date && (
                        <span>Follow-up: {new Date(app.follow_up_date).toLocaleDateString()}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="notes" className="mt-6">
          {selectedApp ? (
            <ApplicationNotes
              applicationId={selectedApp.id}
              notes={selectedApp.notes || []}
              onNotesUpdate={(notes) => updateApplicationNotes(selectedApp.id, notes)}
            />
          ) : (
            <Card>
              <CardContent className="text-center py-12">
                <p className="text-gray-500">Select an application to view and manage notes</p>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <ApplicationAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
}

export default ApplicationTracker;