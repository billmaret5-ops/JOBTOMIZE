import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { CalendarIcon, Download, FileText, Shield, Activity } from 'lucide-react';
import { format } from 'date-fns';
import { supabase } from '@/lib/supabase';

interface ComplianceReport {
  id: string;
  report_type: string;
  status: string;
  created_at: string;
  completed_at: string;
  report_data: any;
}

export function ComplianceReportGenerator() {
  const [reports, setReports] = useState<ComplianceReport[]>([]);
  const [generating, setGenerating] = useState(false);
  const [reportType, setReportType] = useState('activity_summary');
  const [dateRange, setDateRange] = useState<{ from: Date; to: Date }>({
    from: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000),
    to: new Date()
  });

  const generateReport = async () => {
    setGenerating(true);
    try {
      const { data, error } = await supabase.functions.invoke('compliance-report-generator', {
        body: {
          tenantId: 'current-tenant-id', // Replace with actual tenant ID
          reportType,
          dateRangeStart: dateRange.from.toISOString(),
          dateRangeEnd: dateRange.to.toISOString(),
          filters: {},
          userId: 'current-user-id' // Replace with actual user ID
        }
      });

      if (error) throw error;
      
      // Refresh reports list
      fetchReports();
    } catch (error) {
      console.error('Error generating report:', error);
    } finally {
      setGenerating(false);
    }
  };

  const fetchReports = async () => {
    try {
      const { data, error } = await supabase
        .from('compliance_reports')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(10);

      if (error) throw error;
      setReports(data || []);
    } catch (error) {
      console.error('Error fetching reports:', error);
    }
  };

  React.useEffect(() => {
    fetchReports();
  }, []);

  const getReportIcon = (type: string) => {
    switch (type) {
      case 'security_events': return Shield;
      case 'activity_summary': return Activity;
      default: return FileText;
    }
  };

  const getReportTitle = (type: string) => {
    switch (type) {
      case 'activity_summary': return 'Activity Summary';
      case 'security_events': return 'Security Events';
      case 'data_changes': return 'Data Changes';
      default: return 'General Report';
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Generate Compliance Report</CardTitle>
          <CardDescription>
            Create detailed audit and compliance reports for regulatory requirements
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Report Type</label>
              <Select value={reportType} onValueChange={setReportType}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="activity_summary">Activity Summary</SelectItem>
                  <SelectItem value="security_events">Security Events</SelectItem>
                  <SelectItem value="data_changes">Data Changes</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">Start Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(dateRange.from, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.from}
                    onSelect={(date) => date && setDateRange(prev => ({ ...prev, from: date }))}
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div>
              <label className="text-sm font-medium mb-2 block">End Date</label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start text-left">
                    <CalendarIcon className="mr-2 h-4 w-4" />
                    {format(dateRange.to, 'PPP')}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <Calendar
                    mode="single"
                    selected={dateRange.to}
                    onSelect={(date) => date && setDateRange(prev => ({ ...prev, to: date }))}
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          <Button onClick={generateReport} disabled={generating} className="w-full">
            <FileText className="w-4 h-4 mr-2" />
            {generating ? 'Generating Report...' : 'Generate Report'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
          <CardDescription>
            Previously generated compliance and audit reports
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {reports.map((report) => {
              const IconComponent = getReportIcon(report.report_type);
              return (
                <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <IconComponent className="w-5 h-5 text-blue-600" />
                    <div>
                      <div className="font-medium">{getReportTitle(report.report_type)}</div>
                      <div className="text-sm text-muted-foreground">
                        Generated {format(new Date(report.created_at), 'PPp')}
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className={`px-2 py-1 rounded-full text-xs ${
                      report.status === 'completed' 
                        ? 'bg-green-100 text-green-800' 
                        : 'bg-yellow-100 text-yellow-800'
                    }`}>
                      {report.status}
                    </span>
                    {report.status === 'completed' && (
                      <Button size="sm" variant="outline">
                        <Download className="w-4 h-4 mr-1" />
                        Download
                      </Button>
                    )}
                  </div>
                </div>
              );
            })}
            {reports.length === 0 && (
              <div className="text-center py-8 text-muted-foreground">
                No reports generated yet
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}