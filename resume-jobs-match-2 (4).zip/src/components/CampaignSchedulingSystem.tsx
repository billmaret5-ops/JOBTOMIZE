import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Calendar } from './ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from './ui/popover';
import { 
  Calendar as CalendarIcon, Clock, Send, Pause, 
  Globe, Users, BarChart3, Settings 
} from 'lucide-react';
import { format } from 'date-fns';

interface ScheduleConfig {
  type: 'immediate' | 'scheduled' | 'recurring' | 'timezone_optimized';
  send_date?: Date;
  send_time?: string;
  timezone?: string;
  recurring_pattern?: {
    frequency: 'daily' | 'weekly' | 'monthly';
    interval: number;
    end_date?: Date;
  };
  timezone_optimization?: {
    enabled: boolean;
    preferred_hours: string[];
  };
}

interface CampaignSchedulingSystemProps {
  schedule: ScheduleConfig;
  onScheduleChange: (schedule: ScheduleConfig) => void;
}

export const CampaignSchedulingSystem: React.FC<CampaignSchedulingSystemProps> = ({
  schedule,
  onScheduleChange
}) => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(schedule.send_date);
  const [showCalendar, setShowCalendar] = useState(false);

  const timezones = [
    { value: 'UTC', label: 'UTC (Coordinated Universal Time)' },
    { value: 'America/New_York', label: 'Eastern Time (ET)' },
    { value: 'America/Chicago', label: 'Central Time (CT)' },
    { value: 'America/Denver', label: 'Mountain Time (MT)' },
    { value: 'America/Los_Angeles', label: 'Pacific Time (PT)' },
    { value: 'Europe/London', label: 'Greenwich Mean Time (GMT)' },
    { value: 'Europe/Paris', label: 'Central European Time (CET)' },
    { value: 'Asia/Tokyo', label: 'Japan Standard Time (JST)' }
  ];

  const updateSchedule = (updates: Partial<ScheduleConfig>) => {
    onScheduleChange({ ...schedule, ...updates });
  };

  const handleDateSelect = (date: Date | undefined) => {
    setSelectedDate(date);
    updateSchedule({ send_date: date });
    setShowCalendar(false);
  };

  const getScheduleStatus = () => {
    switch (schedule.type) {
      case 'immediate':
        return { label: 'Send Immediately', color: 'bg-green-100 text-green-800' };
      case 'scheduled':
        return { label: 'Scheduled', color: 'bg-blue-100 text-blue-800' };
      case 'recurring':
        return { label: 'Recurring', color: 'bg-purple-100 text-purple-800' };
      case 'timezone_optimized':
        return { label: 'Timezone Optimized', color: 'bg-orange-100 text-orange-800' };
      default:
        return { label: 'Not Configured', color: 'bg-gray-100 text-gray-800' };
    }
  };

  const status = getScheduleStatus();

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <Send className="w-8 h-8 mx-auto mb-2 text-blue-600" />
            <Badge className={status.color}>{status.label}</Badge>
            <div className="text-sm text-gray-600 mt-2">Current Status</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Clock className="w-8 h-8 mx-auto mb-2 text-green-600" />
            <div className="text-lg font-semibold">
              {schedule.send_date ? format(schedule.send_date, 'MMM dd, yyyy') : 'Not Set'}
            </div>
            <div className="text-sm text-gray-600">Send Date</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <Globe className="w-8 h-8 mx-auto mb-2 text-purple-600" />
            <div className="text-lg font-semibold">
              {schedule.timezone || 'UTC'}
            </div>
            <div className="text-sm text-gray-600">Timezone</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Schedule Configuration
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-base font-medium">Send Options</Label>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-3">
              {[
                { value: 'immediate', label: 'Send Immediately', icon: Send },
                { value: 'scheduled', label: 'Schedule for Later', icon: CalendarIcon },
                { value: 'recurring', label: 'Recurring Campaign', icon: Clock },
                { value: 'timezone_optimized', label: 'Timezone Optimized', icon: Globe }
              ].map(({ value, label, icon: Icon }) => (
                <Card
                  key={value}
                  className={`cursor-pointer transition-all hover:shadow-md ${
                    schedule.type === value ? 'ring-2 ring-blue-500' : ''
                  }`}
                  onClick={() => updateSchedule({ type: value as ScheduleConfig['type'] })}
                >
                  <CardContent className="p-4 text-center">
                    <Icon className="w-6 h-6 mx-auto mb-2" />
                    <div className="font-medium">{label}</div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {schedule.type === 'scheduled' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Send Date</Label>
                  <Popover open={showCalendar} onOpenChange={setShowCalendar}>
                    <PopoverTrigger asChild>
                      <Button variant="outline" className="w-full justify-start">
                        <CalendarIcon className="w-4 h-4 mr-2" />
                        {selectedDate ? format(selectedDate, 'PPP') : 'Select date'}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0" align="start">
                      <Calendar
                        mode="single"
                        selected={selectedDate}
                        onSelect={handleDateSelect}
                        disabled={(date) => date < new Date()}
                        initialFocus
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                <div>
                  <Label>Send Time</Label>
                  <Input
                    type="time"
                    value={schedule.send_time || '09:00'}
                    onChange={(e) => updateSchedule({ send_time: e.target.value })}
                  />
                </div>
              </div>
              <div>
                <Label>Timezone</Label>
                <Select
                  value={schedule.timezone || 'UTC'}
                  onValueChange={(value) => updateSchedule({ timezone: value })}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Select timezone" />
                  </SelectTrigger>
                  <SelectContent>
                    {timezones.map(tz => (
                      <SelectItem key={tz.value} value={tz.value}>
                        {tz.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          )}

          {schedule.type === 'recurring' && (
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label>Frequency</Label>
                  <Select
                    value={schedule.recurring_pattern?.frequency || 'weekly'}
                    onValueChange={(value) => updateSchedule({
                      recurring_pattern: {
                        ...schedule.recurring_pattern,
                        frequency: value as 'daily' | 'weekly' | 'monthly'
                      }
                    })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="daily">Daily</SelectItem>
                      <SelectItem value="weekly">Weekly</SelectItem>
                      <SelectItem value="monthly">Monthly</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Interval</Label>
                  <Input
                    type="number"
                    min="1"
                    value={schedule.recurring_pattern?.interval || 1}
                    onChange={(e) => updateSchedule({
                      recurring_pattern: {
                        ...schedule.recurring_pattern,
                        interval: parseInt(e.target.value)
                      }
                    })}
                  />
                </div>
                <div>
                  <Label>Send Time</Label>
                  <Input
                    type="time"
                    value={schedule.send_time || '09:00'}
                    onChange={(e) => updateSchedule({ send_time: e.target.value })}
                  />
                </div>
              </div>
            </div>
          )}

          {schedule.type === 'timezone_optimized' && (
            <div className="space-y-4">
              <div className="p-4 bg-blue-50 rounded-lg">
                <h4 className="font-medium text-blue-900 mb-2">Timezone Optimization</h4>
                <p className="text-sm text-blue-700">
                  Automatically send emails at optimal times based on recipient timezones and engagement patterns.
                </p>
              </div>
              <div>
                <Label>Preferred Sending Hours (24-hour format)</Label>
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {Array.from({ length: 24 }, (_, i) => i).map(hour => (
                    <Button
                      key={hour}
                      size="sm"
                      variant={
                        schedule.timezone_optimization?.preferred_hours?.includes(hour.toString()) 
                          ? 'default' 
                          : 'outline'
                      }
                      onClick={() => {
                        const currentHours = schedule.timezone_optimization?.preferred_hours || [];
                        const hourStr = hour.toString();
                        const newHours = currentHours.includes(hourStr)
                          ? currentHours.filter(h => h !== hourStr)
                          : [...currentHours, hourStr];
                        
                        updateSchedule({
                          timezone_optimization: {
                            enabled: true,
                            preferred_hours: newHours
                          }
                        });
                      }}
                    >
                      {hour.toString().padStart(2, '0')}:00
                    </Button>
                  ))}
                </div>
              </div>
            </div>
          )}
        </CardContent>
      </Card>

      {schedule.type !== 'immediate' && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="w-5 h-5" />
              Delivery Insights
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h4 className="font-medium mb-3">Optimal Send Times</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Tuesday 10:00 AM</span>
                    <Badge variant="outline">Best Open Rate</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Thursday 2:00 PM</span>
                    <Badge variant="outline">Best Click Rate</Badge>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Wednesday 11:00 AM</span>
                    <Badge variant="outline">Lowest Unsubscribe</Badge>
                  </div>
                </div>
              </div>
              <div>
                <h4 className="font-medium mb-3">Recipient Distribution</h4>
                <div className="space-y-2">
                  <div className="flex justify-between text-sm">
                    <span>Americas (UTC-8 to UTC-5)</span>
                    <span>45%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Europe (UTC+0 to UTC+2)</span>
                    <span>35%</span>
                  </div>
                  <div className="flex justify-between text-sm">
                    <span>Asia-Pacific (UTC+8 to UTC+12)</span>
                    <span>20%</span>
                  </div>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
};