import { useState } from 'react';
import { FileText, Download, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import AdvancedFilters from './AdvancedFilters';
import SavedSearches from './SavedSearches';
import SearchAnalytics from './SearchAnalytics';
import { useAdvancedSearch } from '@/hooks/useAdvancedSearch';
import { exportToCSV, exportToJSON } from '@/lib/exportUtils';
import { Pagination, PaginationContent, PaginationItem, PaginationLink, PaginationNext, PaginationPrevious } from '@/components/ui/pagination';

const templateFields = [
  { label: 'Name', value: 'name', type: 'text' },
  { label: 'Subject', value: 'subject', type: 'text' },
  { label: 'Category', value: 'category', type: 'text' },
  { label: 'Status', value: 'status', type: 'text' },
  { label: 'Created', value: 'created_at', type: 'date' }
];

export function ComprehensiveEmailTemplateSystem() {

  const { results, total, loading, config, updateConfig, refresh } = useAdvancedSearch('email_templates');
  const [showAnalytics, setShowAnalytics] = useState(false);

  const handleExport = (format: 'csv' | 'json') => {
    if (format === 'csv') {
      exportToCSV(results, 'email-templates');
    } else {
      exportToJSON(results, 'email-templates');
    }
  };

  const handleLoadSearch = (search: any) => {
    updateConfig({
      query: search.search_query,
      filters: search.filters,
      sortField: search.sort_field,
      sortDirection: search.sort_direction
    });
  };

  const totalPages = Math.ceil(total / config.pageSize);

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Email Templates</h1>
          <p className="text-gray-600">{total} templates found</p>
        </div>
        <Button>
          <Plus className="h-4 w-4 mr-2" />
          New Template
        </Button>
      </div>

      <div className="grid lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1 space-y-4">
          <SavedSearches
            entityType="templates"
            onLoad={handleLoadSearch}
            currentConfig={config}
          />
          <Button variant="outline" onClick={() => setShowAnalytics(!showAnalytics)} className="w-full">
            View Analytics
          </Button>
        </div>

        <div className="lg:col-span-3 space-y-4">
          <AdvancedFilters
            onSearch={(q) => updateConfig({ query: q, page: 1 })}
            onFilter={(f) => updateConfig({ filters: f, page: 1 })}
            onSort={(field, dir) => updateConfig({ sortField: field, sortDirection: dir, page: 1 })}
            onExport={handleExport}
            onSaveSearch={() => {}}
            fields={templateFields}
            data={results}
          />

          {showAnalytics && <SearchAnalytics />}

          {loading ? (
            <div className="text-center py-12">Loading...</div>
          ) : (
            <div className="grid md:grid-cols-2 gap-4">
              {results.map((template) => (
                <Card key={template.id} className="hover:shadow-lg transition-shadow">
                  <CardHeader>
                    <div className="flex justify-between items-start">
                      <div className="flex items-center gap-2">
                        <FileText className="h-5 w-5 text-blue-600" />
                        <CardTitle className="text-lg">{template.name}</CardTitle>
                      </div>
                      <Badge>{template.category || 'General'}</Badge>
                    </div>
                  </CardHeader>
                  <CardContent>
                    <p className="text-sm text-gray-600 mb-2">{template.subject}</p>
                    <div className="flex justify-between items-center text-xs text-gray-500">
                      <span>Created {new Date(template.created_at).toLocaleDateString()}</span>
                      <Button variant="ghost" size="sm">Edit</Button>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          )}

          {totalPages > 1 && (
            <Pagination>
              <PaginationContent>
                <PaginationItem>
                  <PaginationPrevious 
                    onClick={() => config.page > 1 && updateConfig({ page: config.page - 1 })}
                  />
                </PaginationItem>
                {[...Array(Math.min(5, totalPages))].map((_, i) => (
                  <PaginationItem key={i}>
                    <PaginationLink
                      onClick={() => updateConfig({ page: i + 1 })}
                      isActive={config.page === i + 1}
                    >
                      {i + 1}
                    </PaginationLink>
                  </PaginationItem>
                ))}
                <PaginationItem>
                  <PaginationNext
                    onClick={() => config.page < totalPages && updateConfig({ page: config.page + 1 })}
                  />
                </PaginationItem>
              </PaginationContent>
            </Pagination>
          )}
        </div>
      </div>
    </div>
  );
}
