import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { 
  Mail, Users, TestTube, Calendar, BarChart3, 
  Settings, Zap, Send, Eye, Play, Pause
} from 'lucide-react';

interface CampaignBuilderProps {
  campaignId?: string;
}

export const ComprehensiveCampaignBuilder: React.FC<CampaignBuilderProps> = ({ 
  campaignId 
}) => {
  const [activeTab, setActiveTab] = useState('template');
  const [campaignProgress, setCampaignProgress] = useState(25);
  const [campaignStatus, setCampaignStatus] = useState<'draft' | 'scheduled' | 'sending' | 'sent'>('draft');

  const tabs = [
    { id: 'template', label: 'Template', icon: Mail, completed: true },
    { id: 'recipients', label: 'Recipients', icon: Users, completed: false },
    { id: 'testing', label: 'A/B Testing', icon: TestTube, completed: false },
    { id: 'schedule', label: 'Schedule', icon: Calendar, completed: false },
    { id: 'analytics', label: 'Analytics', icon: BarChart3, completed: false }
  ];

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'scheduled': return 'bg-blue-100 text-blue-800';
      case 'sending': return 'bg-orange-100 text-orange-800';
      case 'sent': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Campaign Builder</h1>
          <p className="text-gray-600 mt-1">Create and manage email campaigns</p>
        </div>
        <div className="flex items-center gap-4">
          <Badge className={getStatusColor(campaignStatus)}>
            {campaignStatus.charAt(0).toUpperCase() + campaignStatus.slice(1)}
          </Badge>
          <Button variant="outline" size="sm">
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
          <Button>
            <Send className="w-4 h-4 mr-2" />
            Send Campaign
          </Button>
        </div>
      </div>

      {/* Progress Bar */}
      <Card>
        <CardContent className="pt-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm font-medium">Campaign Progress</span>
            <span className="text-sm text-gray-500">{campaignProgress}% Complete</span>
          </div>
          <Progress value={campaignProgress} className="h-2" />
        </CardContent>
      </Card>

      {/* Main Content */}
      <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
        <TabsList className="grid w-full grid-cols-5">
          {tabs.map((tab) => (
            <TabsTrigger 
              key={tab.id} 
              value={tab.id}
              className="flex items-center gap-2"
            >
              <tab.icon className="w-4 h-4" />
              {tab.label}
              {tab.completed && (
                <div className="w-2 h-2 bg-green-500 rounded-full ml-1" />
              )}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="template">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Email Template Editor</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-96 bg-gray-50 rounded-lg flex items-center justify-center">
                    <div className="text-center">
                      <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                      <p className="text-gray-600">Drag & Drop Email Builder</p>
                      <Button className="mt-4">
                        <Zap className="w-4 h-4 mr-2" />
                        Open Builder
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Template Library</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-3">
                    {['Newsletter', 'Promotion', 'Welcome', 'Follow-up'].map((template) => (
                      <div key={template} className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer">
                        <div className="font-medium">{template}</div>
                        <div className="text-sm text-gray-500">Professional template</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="recipients">
          <Card>
            <CardHeader>
              <CardTitle>Recipient Management</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-4">Contact Lists</h3>
                  <div className="space-y-2">
                    {['All Subscribers', 'VIP Customers', 'New Users', 'Inactive Users'].map((list) => (
                      <div key={list} className="flex items-center justify-between p-3 border rounded-lg">
                        <span>{list}</span>
                        <Badge variant="outline">1,234</Badge>
                      </div>
                    ))}
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-4">Segmentation</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="font-medium">Geographic Filter</div>
                      <div className="text-sm text-gray-500 mt-1">Target specific locations</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="font-medium">Behavioral Filter</div>
                      <div className="text-sm text-gray-500 mt-1">Based on user activity</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing">
          <Card>
            <CardHeader>
              <CardTitle>A/B Testing Setup</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-4">Test Configuration</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="font-medium">Subject Line Test</div>
                      <div className="text-sm text-gray-500 mt-1">Test different subject lines</div>
                      <div className="mt-2">
                        <Badge>50% / 50%</Badge>
                      </div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="font-medium">Content Test</div>
                      <div className="text-sm text-gray-500 mt-1">Test email content variations</div>
                      <div className="mt-2">
                        <Badge variant="outline">Not Set</Badge>
                      </div>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-4">Test Results</h3>
                  <div className="text-center py-8">
                    <TestTube className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600">No test results yet</p>
                    <p className="text-sm text-gray-500">Results will appear after sending</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="schedule">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Scheduling</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-4">Send Options</h3>
                  <div className="space-y-4">
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <Play className="w-4 h-4" />
                        <span className="font-medium">Send Now</span>
                      </div>
                      <div className="text-sm text-gray-500 mt-1">Send immediately</div>
                    </div>
                    <div className="p-4 border rounded-lg">
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" />
                        <span className="font-medium">Schedule Send</span>
                      </div>
                      <div className="text-sm text-gray-500 mt-1">Choose date and time</div>
                    </div>
                  </div>
                </div>
                <div>
                  <h3 className="font-semibold mb-4">Follow-up Sequences</h3>
                  <div className="space-y-3">
                    <div className="p-3 border rounded-lg">
                      <div className="font-medium">Welcome Series</div>
                      <div className="text-sm text-gray-500">3 emails over 7 days</div>
                    </div>
                    <div className="p-3 border rounded-lg">
                      <div className="font-medium">Re-engagement</div>
                      <div className="text-sm text-gray-500">2 emails over 14 days</div>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
                {[
                  { label: 'Sent', value: '0', color: 'text-blue-600' },
                  { label: 'Delivered', value: '0', color: 'text-green-600' },
                  { label: 'Opened', value: '0%', color: 'text-orange-600' },
                  { label: 'Clicked', value: '0%', color: 'text-purple-600' }
                ].map((stat) => (
                  <div key={stat.label} className="text-center p-4 border rounded-lg">
                    <div className={`text-2xl font-bold ${stat.color}`}>{stat.value}</div>
                    <div className="text-sm text-gray-500">{stat.label}</div>
                  </div>
                ))}
              </div>
              <div className="text-center py-8">
                <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No analytics data yet</p>
                <p className="text-sm text-gray-500">Data will appear after sending campaign</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};