import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { realTimeDataService, DataSource } from '@/services/realTimeDataService';
import { StreamingChart } from './StreamingChart';

export function DataStreamManager() {
  const [dataSources, setDataSources] = useState<DataSource[]>([]);
  const [selectedSources, setSelectedSources] = useState<string[]>([]);
  const [autoReconnect, setAutoReconnect] = useState(true);
  const [bufferSize, setBufferSize] = useState(1000);
  const [newSource, setNewSource] = useState({
    name: '',
    url: '',
    type: 'websocket' as const,
    headers: '',
    params: ''
  });

  useEffect(() => {
    const updateSources = () => {
      setDataSources(realTimeDataService.getDataSources());
    };
    
    updateSources();
    const interval = setInterval(updateSources, 1000);
    
    return () => clearInterval(interval);
  }, []);

  const addDataSource = () => {
    if (!newSource.name || !newSource.url) return;
    
    const sourceId = `source_${Date.now()}`;
    realTimeDataService.addDataSource({
      id: sourceId,
      name: newSource.name,
      url: newSource.url,
      type: newSource.type
    });
    
    setNewSource({ name: '', url: '', type: 'websocket', headers: '', params: '' });
  };

  const toggleSourceSelection = (sourceId: string) => {
    setSelectedSources(prev => 
      prev.includes(sourceId) 
        ? prev.filter(id => id !== sourceId)
        : [...prev, sourceId]
    );
  };

  const getConnectionHealth = (source: DataSource) => {
    const timeSinceUpdate = Date.now() - source.lastUpdate.getTime();
    if (timeSinceUpdate < 5000) return 'excellent';
    if (timeSinceUpdate < 30000) return 'good';
    if (timeSinceUpdate < 60000) return 'fair';
    return 'poor';
  };

  const getHealthColor = (health: string) => {
    switch (health) {
      case 'excellent': return 'bg-green-500';
      case 'good': return 'bg-blue-500';
      case 'fair': return 'bg-yellow-500';
      case 'poor': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  const predefinedSources = [
    { name: 'Stock Prices', url: 'wss://ws.finnhub.io?token=demo', type: 'websocket' as const },
    { name: 'Crypto Prices', url: 'wss://stream.binance.com:9443/ws/btcusdt@ticker', type: 'websocket' as const },
    { name: 'System Metrics', url: 'ws://localhost:8080/metrics', type: 'websocket' as const },
    { name: 'IoT Sensors', url: 'ws://localhost:8081/sensors', type: 'websocket' as const }
  ];

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Data Stream Manager</h2>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Label htmlFor="auto-reconnect">Auto Reconnect</Label>
            <Switch
              id="auto-reconnect"
              checked={autoReconnect}
              onCheckedChange={setAutoReconnect}
            />
          </div>
          <Badge variant="outline">
            {dataSources.filter(s => s.status === 'connected').length} / {dataSources.length} Connected
          </Badge>
        </div>
      </div>

      <Tabs defaultValue="sources" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="streams">Live Streams</TabsTrigger>
          <TabsTrigger value="health">Connection Health</TabsTrigger>
          <TabsTrigger value="settings">Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="sources" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Add New Data Source</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="source-name">Source Name</Label>
                  <Input
                    id="source-name"
                    placeholder="Enter source name"
                    value={newSource.name}
                    onChange={(e) => setNewSource(prev => ({ ...prev, name: e.target.value }))}
                  />
                </div>
                <div>
                  <Label htmlFor="source-type">Connection Type</Label>
                  <Select value={newSource.type} onValueChange={(value: any) => setNewSource(prev => ({ ...prev, type: value }))}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="websocket">WebSocket</SelectItem>
                      <SelectItem value="sse">Server-Sent Events</SelectItem>
                      <SelectItem value="polling">HTTP Polling</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div>
                <Label htmlFor="source-url">Connection URL</Label>
                <Input
                  id="source-url"
                  placeholder="ws://localhost:8080/data or https://api.example.com/stream"
                  value={newSource.url}
                  onChange={(e) => setNewSource(prev => ({ ...prev, url: e.target.value }))}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={addDataSource} className="flex-1">
                  Add Data Source
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Quick Add Predefined Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-2">
                {predefinedSources.map((source, index) => (
                  <Button
                    key={index}
                    variant="outline"
                    onClick={() => setNewSource(source)}
                    className="justify-start"
                  >
                    {source.name}
                  </Button>
                ))}
              </div>
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {dataSources.map(source => (
              <Card key={source.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <h3 className="font-semibold">{source.name}</h3>
                        <Badge variant={source.status === 'connected' ? 'default' : 'secondary'}>
                          {source.status}
                        </Badge>
                        <Badge variant="outline">{source.type}</Badge>
                      </div>
                      <p className="text-sm text-gray-600 mb-2">{source.url}</p>
                      <div className="text-xs text-gray-500">
                        Last update: {source.lastUpdate.toLocaleString()}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Button
                        variant={selectedSources.includes(source.id) ? "default" : "outline"}
                        size="sm"
                        onClick={() => toggleSourceSelection(source.id)}
                      >
                        {selectedSources.includes(source.id) ? "Selected" : "Select"}
                      </Button>
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => realTimeDataService.disconnect(source.id)}
                      >
                        Remove
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="streams" className="space-y-4">
          <div className="grid gap-4">
            {selectedSources.map(sourceId => {
              const source = dataSources.find(s => s.id === sourceId);
              if (!source) return null;
              
              return (
                <StreamingChart
                  key={sourceId}
                  sourceId={sourceId}
                  title={source.name}
                  chartType="line"
                  maxDataPoints={100}
                />
              );
            })}
            {selectedSources.length === 0 && (
              <Card>
                <CardContent className="pt-6 text-center">
                  <p className="text-gray-500">Select data sources to view live streams</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        <TabsContent value="health" className="space-y-4">
          <div className="grid gap-4">
            {dataSources.map(source => {
              const health = getConnectionHealth(source);
              return (
                <Card key={source.id}>
                  <CardContent className="pt-6">
                    <div className="flex justify-between items-center">
                      <div>
                        <h3 className="font-semibold">{source.name}</h3>
                        <p className="text-sm text-gray-600">
                          Reconnect attempts: {source.reconnectAttempts}/{source.maxReconnectAttempts}
                        </p>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className={`w-3 h-3 rounded-full ${getHealthColor(health)}`} />
                        <span className="text-sm capitalize">{health}</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </TabsContent>

        <TabsContent value="settings" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Stream Settings</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="buffer-size">Buffer Size (records)</Label>
                <Input
                  id="buffer-size"
                  type="number"
                  value={bufferSize}
                  onChange={(e) => setBufferSize(Number(e.target.value))}
                />
              </div>
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-reconnect-setting">Automatic Reconnection</Label>
                <Switch
                  id="auto-reconnect-setting"
                  checked={autoReconnect}
                  onCheckedChange={setAutoReconnect}
                />
              </div>
              <Button className="w-full">Save Settings</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}