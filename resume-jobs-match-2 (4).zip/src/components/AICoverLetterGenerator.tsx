import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Card } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Loader2, FileText, Copy, Download } from 'lucide-react';
import { generateAIContent } from '@/lib/aiService';
import { useToast } from '@/hooks/use-toast';

export default function AICoverLetterGenerator() {
  const [loading, setLoading] = useState(false);
  const [tone, setTone] = useState<'professional' | 'creative' | 'technical'>('professional');
  const [jobDescription, setJobDescription] = useState('');
  const [resumeSummary, setResumeSummary] = useState('');
  const [generatedLetter, setGeneratedLetter] = useState('');
  const { toast } = useToast();

  const handleGenerate = async () => {
    if (!jobDescription || !resumeSummary) {
      toast({ title: 'Missing info', description: 'Please fill all fields', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const content = await generateAIContent({
        action: 'tailor_to_job',
        data: { resumeContent: resumeSummary, jobDescription, tone }
      });
      setGeneratedLetter(content);
      toast({ title: 'Cover letter generated!', description: 'Review and customize as needed' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to generate cover letter', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(generatedLetter);
    toast({ title: 'Copied!', description: 'Cover letter copied to clipboard' });
  };

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <FileText className="w-6 h-6 text-blue-600" />
          AI Cover Letter Generator
        </h2>

        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Tone</label>
            <Select value={tone} onValueChange={(v: any) => setTone(v)}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="professional">Professional</SelectItem>
                <SelectItem value="creative">Creative</SelectItem>
                <SelectItem value="technical">Technical</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Job Description</label>
            <Textarea
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste the job description here..."
              rows={6}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Your Resume Summary</label>
            <Textarea
              value={resumeSummary}
              onChange={(e) => setResumeSummary(e.target.value)}
              placeholder="Brief summary of your experience and skills..."
              rows={4}
            />
          </div>

          <Button onClick={handleGenerate} disabled={loading} className="w-full">
            {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <FileText className="w-4 h-4 mr-2" />}
            Generate Cover Letter
          </Button>
        </div>
      </Card>

      {generatedLetter && (
        <Card className="p-6">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-xl font-semibold">Generated Cover Letter</h3>
            <div className="flex gap-2">
              <Button onClick={copyToClipboard} variant="outline" size="sm">
                <Copy className="w-4 h-4 mr-2" />
                Copy
              </Button>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Download
              </Button>
            </div>
          </div>
          <Textarea value={generatedLetter} onChange={(e) => setGeneratedLetter(e.target.value)} rows={16} />
        </Card>
      )}
    </div>
  );
}
