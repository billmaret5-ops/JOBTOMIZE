import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Switch } from '@/components/ui/switch';
import { followUpSequenceService, FollowUpSequence } from '@/services/followUpSequenceService';
import { Plus, Play, Pause, Trash2, BarChart3 } from 'lucide-react';

export function AutomatedFollowUpBuilder() {
  const [sequences, setSequences] = useState<FollowUpSequence[]>([]);
  const [selectedSequence, setSelectedSequence] = useState<FollowUpSequence | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [analytics, setAnalytics] = useState<any>({});

  useEffect(() => {
    loadSequences();
  }, []);

  const loadSequences = async () => {
    try {
      const data = await followUpSequenceService.getSequences();
      setSequences(data);
    } catch (error) {
      console.error('Error loading sequences:', error);
    }
  };

  const createNewSequence = async (sequenceData: any) => {
    try {
      await followUpSequenceService.createSequence(sequenceData);
      await loadSequences();
      setIsCreating(false);
    } catch (error) {
      console.error('Error creating sequence:', error);
    }
  };

  const toggleSequence = async (id: string, isActive: boolean) => {
    try {
      await followUpSequenceService.updateSequence(id, { isActive });
      await loadSequences();
    } catch (error) {
      console.error('Error toggling sequence:', error);
    }
  };

  const loadAnalytics = async (sequenceId: string) => {
    try {
      const data = await followUpSequenceService.getSequenceAnalytics(sequenceId);
      setAnalytics(prev => ({ ...prev, [sequenceId]: data }));
    } catch (error) {
      console.error('Error loading analytics:', error);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Follow-Up Sequences</h2>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Create Sequence
        </Button>
      </div>

      <Tabs defaultValue="sequences" className="w-full">
        <TabsList>
          <TabsTrigger value="sequences">Sequences</TabsTrigger>
          <TabsTrigger value="executions">Active Executions</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="sequences" className="space-y-4">
          <div className="grid gap-4">
            {sequences.map((sequence) => (
              <Card key={sequence.id}>
                <CardHeader className="flex flex-row items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{sequence.name}</CardTitle>
                    <div className="flex gap-2 mt-2">
                      <Badge variant="outline">{sequence.trigger}</Badge>
                      <Badge variant={sequence.isActive ? "default" : "secondary"}>
                        {sequence.isActive ? "Active" : "Inactive"}
                      </Badge>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Switch
                      checked={sequence.isActive}
                      onCheckedChange={(checked) => toggleSequence(sequence.id, checked)}
                    />
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => loadAnalytics(sequence.id)}
                    >
                      <BarChart3 className="w-4 h-4" />
                    </Button>
                  </div>
                </CardHeader>
                <CardContent>
                  <p className="text-sm text-muted-foreground mb-2">
                    {sequence.steps.length} steps configured
                  </p>
                  {analytics[sequence.id] && (
                    <div className="grid grid-cols-4 gap-4 text-sm">
                      <div>
                        <div className="font-medium">Total</div>
                        <div>{analytics[sequence.id].total}</div>
                      </div>
                      <div>
                        <div className="font-medium">Completed</div>
                        <div>{analytics[sequence.id].completed}</div>
                      </div>
                      <div>
                        <div className="font-medium">Active</div>
                        <div>{analytics[sequence.id].active}</div>
                      </div>
                      <div>
                        <div className="font-medium">Success Rate</div>
                        <div>{analytics[sequence.id].completionRate.toFixed(1)}%</div>
                      </div>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="executions">
          <Card>
            <CardHeader>
              <CardTitle>Active Sequence Executions</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                View and manage currently running follow-up sequences
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Sequence Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Detailed analytics and performance metrics for all sequences
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {isCreating && (
        <SequenceBuilder
          onSave={createNewSequence}
          onCancel={() => setIsCreating(false)}
        />
      )}
    </div>
  );
}

function SequenceBuilder({ onSave, onCancel }: { onSave: (data: any) => void; onCancel: () => void }) {
  const [name, setName] = useState('');
  const [trigger, setTrigger] = useState('');
  const [steps, setSteps] = useState([{ delay: 24, templateId: '', condition: null }]);

  const handleSave = () => {
    onSave({
      name,
      trigger,
      conditions: [],
      steps: steps.map((step, index) => ({
        id: `step-${index}`,
        delay: step.delay,
        emailTemplateId: step.templateId,
        condition: step.condition,
        nextStepId: index < steps.length - 1 ? `step-${index + 1}` : undefined
      })),
      isActive: true
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Create New Follow-Up Sequence</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <label className="text-sm font-medium">Sequence Name</label>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Enter sequence name"
          />
        </div>
        
        <div>
          <label className="text-sm font-medium">Trigger Event</label>
          <Select value={trigger} onValueChange={setTrigger}>
            <SelectTrigger>
              <SelectValue placeholder="Select trigger" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="application_submitted">Application Submitted</SelectItem>
              <SelectItem value="no_response">No Response</SelectItem>
              <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
              <SelectItem value="interview_completed">Interview Completed</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="flex gap-2">
          <Button onClick={handleSave} disabled={!name || !trigger}>
            Save Sequence
          </Button>
          <Button variant="outline" onClick={onCancel}>
            Cancel
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}