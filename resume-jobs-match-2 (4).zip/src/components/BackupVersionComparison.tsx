import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { ArrowRight, FileText, Database, Clock, TrendingUp, TrendingDown } from 'lucide-react';
import { backupVersioningService, BackupVersion } from '@/services/backupVersioningService';

interface VersionComparisonProps {
  versions: BackupVersion[];
}

export function BackupVersionComparison({ versions }: VersionComparisonProps) {
  const [version1, setVersion1] = useState<string>('');
  const [version2, setVersion2] = useState<string>('');
  const [comparison, setComparison] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleCompare = async () => {
    if (!version1 || !version2) return;
    
    setLoading(true);
    const result = await backupVersioningService.compareVersions(version1, version2);
    setComparison(result);
    setLoading(false);
  };

  const formatSize = (bytes: number) => {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    if (bytes < 1024 * 1024 * 1024) return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
    return `${(bytes / (1024 * 1024 * 1024)).toFixed(2)} GB`;
  };

  const formatDuration = (ms: number) => {
    const hours = Math.floor(ms / (1000 * 60 * 60));
    const minutes = Math.floor((ms % (1000 * 60 * 60)) / (1000 * 60));
    return `${hours}h ${minutes}m`;
  };

  return (
    <Card className="p-6">
      <h3 className="text-lg font-semibold mb-4">Version Comparison</h3>

      <div className="grid grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium mb-2">Version 1</label>
          <Select value={version1} onValueChange={setVersion1}>
            <SelectTrigger>
              <SelectValue placeholder="Select version" />
            </SelectTrigger>
            <SelectContent>
              {versions.map((v) => (
                <SelectItem key={v.id} value={v.id}>
                  Version {v.version_number} - {new Date(v.created_at).toLocaleDateString()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>

        <div className="flex items-end justify-center">
          <Button onClick={handleCompare} disabled={!version1 || !version2 || loading}>
            <ArrowRight className="w-4 h-4 mr-2" />
            Compare
          </Button>
        </div>

        <div>
          <label className="block text-sm font-medium mb-2">Version 2</label>
          <Select value={version2} onValueChange={setVersion2}>
            <SelectTrigger>
              <SelectValue placeholder="Select version" />
            </SelectTrigger>
            <SelectContent>
              {versions.map((v) => (
                <SelectItem key={v.id} value={v.id}>
                  Version {v.version_number} - {new Date(v.created_at).toLocaleDateString()}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>

      {comparison && (
        <div className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Card className="p-4 bg-blue-50">
              <h4 className="font-semibold mb-2">Version {comparison.version1.version_number}</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  <span>{formatSize(comparison.version1.size_bytes)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  <span>{comparison.version1.file_count} files</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{new Date(comparison.version1.created_at).toLocaleString()}</span>
                </div>
                <Badge variant="outline">{comparison.version1.backup_type}</Badge>
              </div>
            </Card>

            <Card className="p-4 bg-green-50">
              <h4 className="font-semibold mb-2">Version {comparison.version2.version_number}</h4>
              <div className="space-y-2 text-sm">
                <div className="flex items-center gap-2">
                  <Database className="w-4 h-4" />
                  <span>{formatSize(comparison.version2.size_bytes)}</span>
                </div>
                <div className="flex items-center gap-2">
                  <FileText className="w-4 h-4" />
                  <span>{comparison.version2.file_count} files</span>
                </div>
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  <span>{new Date(comparison.version2.created_at).toLocaleString()}</span>
                </div>
                <Badge variant="outline">{comparison.version2.backup_type}</Badge>
              </div>
            </Card>
          </div>

          <Card className="p-4 bg-gray-50">
            <h4 className="font-semibold mb-3">Differences</h4>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <div className="text-sm text-gray-600 mb-1">Size Change</div>
                <div className="flex items-center gap-2">
                  {comparison.sizeDiff > 0 ? (
                    <>
                      <TrendingUp className="w-4 h-4 text-red-500" />
                      <span className="font-semibold text-red-500">+{formatSize(comparison.sizeDiff)}</span>
                    </>
                  ) : comparison.sizeDiff < 0 ? (
                    <>
                      <TrendingDown className="w-4 h-4 text-green-500" />
                      <span className="font-semibold text-green-500">{formatSize(comparison.sizeDiff)}</span>
                    </>
                  ) : (
                    <span className="font-semibold text-gray-500">No change</span>
                  )}
                </div>
              </div>

              <div>
                <div className="text-sm text-gray-600 mb-1">File Count Change</div>
                <div className="font-semibold">{comparison.fileDiff > 0 ? '+' : ''}{comparison.fileDiff} files</div>
              </div>

              <div>
                <div className="text-sm text-gray-600 mb-1">Time Between</div>
                <div className="font-semibold">{formatDuration(comparison.timeDiff)}</div>
              </div>
            </div>
          </Card>
        </div>
      )}
    </Card>
  );
}
