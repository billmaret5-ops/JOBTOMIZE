import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Plus, Trash2, Play, Save } from 'lucide-react';
import { abTestService, ABTest, ABTestVariant } from '@/services/abTestService';
import { useToast } from '@/hooks/use-toast';

interface ABTestCreatorProps {
  campaignId: string;
  onTestCreated?: (test: ABTest) => void;
}

interface VariantForm {
  name: string;
  subject_line?: string;
  content?: string;
  send_time?: string;
  sender_name?: string;
  traffic_percentage: number;
  is_control: boolean;
}

export function ABTestCreator({ campaignId, onTestCreated }: ABTestCreatorProps) {
  const { toast } = useToast();
  const [testName, setTestName] = useState('');
  const [testType, setTestType] = useState<'subject_line' | 'content' | 'send_time' | 'sender_name'>('subject_line');
  const [confidenceLevel, setConfidenceLevel] = useState(95);
  const [trafficSplit, setTrafficSplit] = useState(50);
  const [variants, setVariants] = useState<VariantForm[]>([
    { name: 'Control', traffic_percentage: 50, is_control: true },
    { name: 'Variant A', traffic_percentage: 50, is_control: false }
  ]);
  const [isCreating, setIsCreating] = useState(false);

  const addVariant = () => {
    const newVariant: VariantForm = {
      name: `Variant ${String.fromCharCode(65 + variants.length - 1)}`,
      traffic_percentage: Math.floor(100 / (variants.length + 1)),
      is_control: false
    };
    
    const updatedVariants = [...variants, newVariant];
    redistributeTraffic(updatedVariants);
  };

  const removeVariant = (index: number) => {
    if (variants.length <= 2) return;
    const updatedVariants = variants.filter((_, i) => i !== index);
    redistributeTraffic(updatedVariants);
  };

  const redistributeTraffic = (variantList: VariantForm[]) => {
    const equalSplit = Math.floor(100 / variantList.length);
    const remainder = 100 - (equalSplit * variantList.length);
    
    const redistributed = variantList.map((variant, index) => ({
      ...variant,
      traffic_percentage: equalSplit + (index < remainder ? 1 : 0)
    }));
    
    setVariants(redistributed);
  };

  const updateVariant = (index: number, field: keyof VariantForm, value: any) => {
    const updated = variants.map((variant, i) => 
      i === index ? { ...variant, [field]: value } : variant
    );
    setVariants(updated);
  };

  const createTest = async (startImmediately = false) => {
    if (!testName.trim()) {
      toast({ title: 'Error', description: 'Test name is required', variant: 'destructive' });
      return;
    }

    if (variants.some(v => !v.name.trim())) {
      toast({ title: 'Error', description: 'All variants must have names', variant: 'destructive' });
      return;
    }

    const totalTraffic = variants.reduce((sum, v) => sum + v.traffic_percentage, 0);
    if (Math.abs(totalTraffic - 100) > 1) {
      toast({ title: 'Error', description: 'Traffic split must equal 100%', variant: 'destructive' });
      return;
    }

    setIsCreating(true);
    try {
      const test = await abTestService.createTest({
        name: testName,
        campaign_id: campaignId,
        status: startImmediately ? 'running' : 'draft',
        test_type: testType,
        traffic_split: trafficSplit,
        confidence_level: confidenceLevel / 100,
        minimum_sample_size: 100,
        start_date: startImmediately ? new Date().toISOString() : undefined
      });

      for (const variant of variants) {
        await abTestService.createVariant({
          test_id: test.id,
          ...variant
        });
      }

      toast({ 
        title: 'Success', 
        description: `A/B test ${startImmediately ? 'created and started' : 'saved as draft'}` 
      });
      
      onTestCreated?.(test);
      
      // Reset form
      setTestName('');
      setVariants([
        { name: 'Control', traffic_percentage: 50, is_control: true },
        { name: 'Variant A', traffic_percentage: 50, is_control: false }
      ]);
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to create test', variant: 'destructive' });
    } finally {
      setIsCreating(false);
    }
  };

  const renderVariantFields = (variant: VariantForm, index: number) => {
    switch (testType) {
      case 'subject_line':
        return (
          <div className="space-y-2">
            <Label>Subject Line</Label>
            <Input
              value={variant.subject_line || ''}
              onChange={(e) => updateVariant(index, 'subject_line', e.target.value)}
              placeholder="Enter subject line..."
            />
          </div>
        );
      case 'content':
        return (
          <div className="space-y-2">
            <Label>Email Content</Label>
            <Textarea
              value={variant.content || ''}
              onChange={(e) => updateVariant(index, 'content', e.target.value)}
              placeholder="Enter email content..."
              rows={4}
            />
          </div>
        );
      case 'send_time':
        return (
          <div className="space-y-2">
            <Label>Send Time</Label>
            <Input
              type="time"
              value={variant.send_time || ''}
              onChange={(e) => updateVariant(index, 'send_time', e.target.value)}
            />
          </div>
        );
      case 'sender_name':
        return (
          <div className="space-y-2">
            <Label>Sender Name</Label>
            <Input
              value={variant.sender_name || ''}
              onChange={(e) => updateVariant(index, 'sender_name', e.target.value)}
              placeholder="Enter sender name..."
            />
          </div>
        );
      default:
        return null;
    }
  };

  return (
    <Card className="w-full max-w-4xl mx-auto">
      <CardHeader>
        <CardTitle>Create A/B Test</CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label htmlFor="testName">Test Name</Label>
            <Input
              id="testName"
              value={testName}
              onChange={(e) => setTestName(e.target.value)}
              placeholder="Enter test name..."
            />
          </div>
          <div className="space-y-2">
            <Label>Test Type</Label>
            <Select value={testType} onValueChange={setTestType as any}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="subject_line">Subject Line</SelectItem>
                <SelectItem value="content">Email Content</SelectItem>
                <SelectItem value="send_time">Send Time</SelectItem>
                <SelectItem value="sender_name">Sender Name</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        <div className="space-y-2">
          <Label>Confidence Level: {confidenceLevel}%</Label>
          <Slider
            value={[confidenceLevel]}
            onValueChange={([value]) => setConfidenceLevel(value)}
            min={90}
            max={99}
            step={1}
            className="w-full"
          />
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Test Variants</h3>
            <Button onClick={addVariant} size="sm">
              <Plus className="h-4 w-4 mr-2" />
              Add Variant
            </Button>
          </div>

          {variants.map((variant, index) => (
            <Card key={index} className="p-4">
              <div className="flex items-center justify-between mb-4">
                <div className="flex items-center space-x-2">
                  <Input
                    value={variant.name}
                    onChange={(e) => updateVariant(index, 'name', e.target.value)}
                    className="w-32"
                  />
                  {variant.is_control && <Badge variant="secondary">Control</Badge>}
                </div>
                <div className="flex items-center space-x-2">
                  <span className="text-sm text-gray-600">
                    {variant.traffic_percentage}% traffic
                  </span>
                  {variants.length > 2 && !variant.is_control && (
                    <Button
                      onClick={() => removeVariant(index)}
                      size="sm"
                      variant="outline"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              </div>
              {renderVariantFields(variant, index)}
            </Card>
          ))}
        </div>

        <div className="flex space-x-4">
          <Button
            onClick={() => createTest(false)}
            disabled={isCreating}
            variant="outline"
          >
            <Save className="h-4 w-4 mr-2" />
            Save as Draft
          </Button>
          <Button
            onClick={() => createTest(true)}
            disabled={isCreating}
          >
            <Play className="h-4 w-4 mr-2" />
            Create & Start Test
          </Button>
        </div>
      </CardContent>
    </Card>
  );
}