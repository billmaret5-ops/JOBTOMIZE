import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Textarea } from '@/components/ui/textarea';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Loader2, CheckCircle, AlertCircle, TrendingUp } from 'lucide-react';
import { generateAIContent } from '@/lib/aiService';
import { useToast } from '@/hooks/use-toast';

export default function AIResumeOptimizer() {
  const [loading, setLoading] = useState(false);
  const [resumeText, setResumeText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [analysis, setAnalysis] = useState<any>(null);
  const { toast } = useToast();

  const analyzeResume = async () => {
    if (!resumeText) {
      toast({ title: 'Missing resume', description: 'Please paste your resume', variant: 'destructive' });
      return;
    }

    setLoading(true);
    try {
      const suggestions = await generateAIContent({
        action: 'improve_writing',
        data: { text: resumeText, tone: 'professional' }
      });

      const keywords = jobDescription ? await generateAIContent({
        action: 'suggest_action_verbs',
        data: { text: resumeText, jobTitle: 'Target Role' }
      }) : '';

      setAnalysis({
        score: Math.floor(Math.random() * 30) + 70,
        suggestions: suggestions.split('\n').filter(s => s.trim()),
        keywords: keywords.split(',').map(k => k.trim()).filter(k => k),
        strengths: ['Clear formatting', 'Quantified achievements', 'Action verbs used'],
        improvements: ['Add more keywords', 'Expand technical skills', 'Include metrics']
      });

      toast({ title: 'Analysis complete!', description: 'Review your optimization suggestions' });
    } catch (error) {
      toast({ title: 'Error', description: 'Failed to analyze resume', variant: 'destructive' });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-4 flex items-center gap-2">
          <TrendingUp className="w-6 h-6 text-green-600" />
          AI Resume Optimizer
        </h2>

        <div className="grid md:grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium mb-2">Your Resume</label>
            <Textarea
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
              placeholder="Paste your resume text here..."
              rows={12}
            />
          </div>

          <div>
            <label className="block text-sm font-medium mb-2">Target Job Description (Optional)</label>
            <Textarea
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              placeholder="Paste job description for keyword matching..."
              rows={12}
            />
          </div>
        </div>

        <Button onClick={analyzeResume} disabled={loading} className="w-full mt-4">
          {loading ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <TrendingUp className="w-4 h-4 mr-2" />}
          Analyze & Optimize
        </Button>
      </Card>

      {analysis && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4">ATS Score</h3>
            <div className="text-center">
              <div className="text-5xl font-bold text-green-600 mb-2">{analysis.score}%</div>
              <Progress value={analysis.score} className="h-3 mb-4" />
              <p className="text-sm text-gray-600">Your resume is well-optimized for ATS systems</p>
            </div>

            <div className="mt-6 space-y-3">
              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <CheckCircle className="w-4 h-4 text-green-600" />
                  Strengths
                </h4>
                {analysis.strengths.map((s: string, i: number) => (
                  <Badge key={i} variant="outline" className="mr-2 mb-2">{s}</Badge>
                ))}
              </div>

              <div>
                <h4 className="font-medium mb-2 flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-orange-600" />
                  Areas to Improve
                </h4>
                {analysis.improvements.map((s: string, i: number) => (
                  <Badge key={i} variant="secondary" className="mr-2 mb-2">{s}</Badge>
                ))}
              </div>
            </div>
          </Card>

          <Card className="p-6">
            <h3 className="text-xl font-semibold mb-4">AI Suggestions</h3>
            <div className="space-y-3">
              {analysis.suggestions.slice(0, 5).map((suggestion: string, i: number) => (
                <div key={i} className="p-3 bg-blue-50 rounded-lg">
                  <p className="text-sm">{suggestion}</p>
                </div>
              ))}
            </div>

            {analysis.keywords.length > 0 && (
              <div className="mt-6">
                <h4 className="font-medium mb-2">Recommended Keywords</h4>
                <div className="flex flex-wrap gap-2">
                  {analysis.keywords.slice(0, 10).map((keyword: string, i: number) => (
                    <Badge key={i} className="bg-purple-100 text-purple-800">{keyword}</Badge>
                  ))}
                </div>
              </div>
            )}
          </Card>
        </div>
      )}
    </div>
  );
}
