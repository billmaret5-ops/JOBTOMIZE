import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar, PieChart, Pie, Cell } from 'recharts';
import { TrendingUp, Mail, MousePointer, Users, Globe, Download, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AnalyticsData {
  campaigns: any[];
  abTests: any[];
  engagement: any[];
  heatmapData: any[];
  performanceData: any[];
  geographicData: any[];
}

export const ComprehensiveEmailAnalytics: React.FC = () => {
  const [data, setData] = useState<AnalyticsData>({
    campaigns: [],
    abTests: [],
    engagement: [],
    heatmapData: [],
    performanceData: [],
    geographicData: []
  });
  const [loading, setLoading] = useState(true);
  const [selectedCampaign, setSelectedCampaign] = useState<string>('all');

  useEffect(() => {
    fetchAnalyticsData();
  }, []);

  const fetchAnalyticsData = async () => {
    try {
      const [campaigns, analytics, abTests, engagement] = await Promise.all([
        supabase.from('email_campaigns').select('*'),
        supabase.from('email_campaigns_analytics').select('*'),
        supabase.from('email_ab_tests').select('*'),
        supabase.from('email_recipient_engagement').select('*')
      ]);

      setData({
        campaigns: campaigns.data || [],
        abTests: abTests.data || [],
        engagement: engagement.data || [],
        heatmapData: [],
        performanceData: generatePerformanceData(analytics.data || []),
        geographicData: generateGeographicData(engagement.data || [])
      });
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const generatePerformanceData = (analytics: any[]) => {
    return analytics.map(item => ({
      date: new Date(item.created_at).toLocaleDateString(),
      openRate: item.open_rate,
      clickRate: item.click_rate,
      bounceRate: item.bounce_rate,
      conversionRate: item.conversion_rate
    }));
  };

  const generateGeographicData = (engagement: any[]) => {
    const countryData: { [key: string]: number } = {};
    engagement.forEach(item => {
      if (item.location_country) {
        countryData[item.location_country] = (countryData[item.location_country] || 0) + 1;
      }
    });
    return Object.entries(countryData).map(([country, count]) => ({ country, count }));
  };

  const exportReport = async () => {
    const reportData = {
      summary: {
        totalCampaigns: data.campaigns.length,
        totalEngagement: data.engagement.length,
        avgOpenRate: data.performanceData.reduce((acc, item) => acc + item.openRate, 0) / data.performanceData.length || 0
      },
      campaigns: data.campaigns,
      performance: data.performanceData,
      geographic: data.geographicData
    };
    
    const blob = new Blob([JSON.stringify(reportData, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `email-analytics-${new Date().toISOString().split('T')[0]}.json`;
    a.click();
  };

  if (loading) return <div className="animate-pulse">Loading analytics...</div>;

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Email Analytics Dashboard</h2>
        <Button onClick={exportReport} className="flex items-center gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="abtests">A/B Tests</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="geographic">Geographic</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2">
                  <Mail className="h-5 w-5 text-blue-500" />
                  <div>
                    <p className="text-2xl font-bold">{data.campaigns.length}</p>
                    <p className="text-sm text-gray-600">Total Campaigns</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2">
                  <TrendingUp className="h-5 w-5 text-green-500" />
                  <div>
                    <p className="text-2xl font-bold">
                      {data.performanceData.length > 0 ? 
                        Math.round(data.performanceData.reduce((acc, item) => acc + item.openRate, 0) / data.performanceData.length) : 0}%
                    </p>
                    <p className="text-sm text-gray-600">Avg Open Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2">
                  <MousePointer className="h-5 w-5 text-purple-500" />
                  <div>
                    <p className="text-2xl font-bold">
                      {data.performanceData.length > 0 ? 
                        Math.round(data.performanceData.reduce((acc, item) => acc + item.clickRate, 0) / data.performanceData.length) : 0}%
                    </p>
                    <p className="text-sm text-gray-600">Avg Click Rate</p>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center gap-2">
                  <Users className="h-5 w-5 text-orange-500" />
                  <div>
                    <p className="text-2xl font-bold">{data.engagement.length}</p>
                    <p className="text-sm text-gray-600">Total Engagements</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Performance Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={data.performanceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="openRate" stroke="#3b82f6" name="Open Rate" />
                  <Line type="monotone" dataKey="clickRate" stroke="#10b981" name="Click Rate" />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance Comparison</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <BarChart data={data.performanceData}>
                    <CartesianGrid strokeDasharray="3 3" />
                    <XAxis dataKey="date" />
                    <YAxis />
                    <Tooltip />
                    <Bar dataKey="openRate" fill="#3b82f6" name="Open Rate" />
                    <Bar dataKey="clickRate" fill="#10b981" name="Click Rate" />
                  </BarChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Engagement Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div>
                    <div className="flex justify-between mb-2">
                      <span>Open Rate</span>
                      <span>65%</span>
                    </div>
                    <Progress value={65} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span>Click Rate</span>
                      <span>23%</span>
                    </div>
                    <Progress value={23} className="h-2" />
                  </div>
                  <div>
                    <div className="flex justify-between mb-2">
                      <span>Conversion Rate</span>
                      <span>8%</span>
                    </div>
                    <Progress value={8} className="h-2" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="abtests">
          <Card>
            <CardHeader>
              <CardTitle>A/B Test Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.abTests.map((test) => (
                  <div key={test.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold">{test.test_name}</h3>
                        <Badge variant={test.status === 'completed' ? 'default' : 'secondary'}>
                          {test.status}
                        </Badge>
                      </div>
                      {test.winning_variant && (
                        <Badge variant="outline">
                          Winner: Variant {test.winning_variant}
                        </Badge>
                      )}
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Variant A</p>
                        <p className="text-xs text-gray-600">{test.variant_a_subject}</p>
                        <div className="flex gap-4 text-sm">
                          <span>Sent: {test.variant_a_sent}</span>
                          <span>Opened: {test.variant_a_opened}</span>
                        </div>
                      </div>
                      <div className="space-y-2">
                        <p className="text-sm font-medium">Variant B</p>
                        <p className="text-xs text-gray-600">{test.variant_b_subject}</p>
                        <div className="flex gap-4 text-sm">
                          <span>Sent: {test.variant_b_sent}</span>
                          <span>Opened: {test.variant_b_opened}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
                {data.abTests.length === 0 && (
                  <p className="text-center text-gray-500 py-8">No A/B tests found</p>
                )}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engagement">
          <Card>
            <CardHeader>
              <CardTitle>Recipient Engagement Details</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {data.engagement.slice(0, 10).map((item) => (
                  <div key={item.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{item.recipient_email}</p>
                      <p className="text-xs text-gray-500">
                        {item.location_city}, {item.location_country}
                      </p>
                    </div>
                    <div className="flex gap-2">
                      {item.opened_at && <Badge variant="outline">Opened</Badge>}
                      {item.clicked_at && <Badge variant="outline">Clicked</Badge>}
                      {item.converted_at && <Badge variant="default">Converted</Badge>}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="geographic">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Globe className="h-5 w-5" />
                Geographic Distribution
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={data.geographicData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="country" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#3b82f6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};