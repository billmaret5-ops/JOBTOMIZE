import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { 
  AlertTriangle, 
  Mail, 
  Clock, 
  CreditCard, 
  Settings,
  Save,
  Plus,
  Trash2
} from 'lucide-react';
import { toast } from '@/hooks/use-toast';

interface DunningRule {
  id: string;
  name: string;
  triggerDays: number;
  emailTemplate: string;
  action: 'email' | 'suspend' | 'cancel';
  isActive: boolean;
}

interface FailedPayment {
  id: string;
  customerId: string;
  customerEmail: string;
  amount: number;
  failedDate: string;
  retryCount: number;
  status: 'pending' | 'recovered' | 'failed';
  nextRetryDate?: string;
}

export function DunningManager() {
  const [dunningRules, setDunningRules] = useState<DunningRule[]>([
    {
      id: '1',
      name: 'First Reminder',
      triggerDays: 1,
      emailTemplate: 'payment_failed_reminder_1',
      action: 'email',
      isActive: true
    },
    {
      id: '2',
      name: 'Second Reminder',
      triggerDays: 7,
      emailTemplate: 'payment_failed_reminder_2',
      action: 'email',
      isActive: true
    },
    {
      id: '3',
      name: 'Final Notice',
      triggerDays: 14,
      emailTemplate: 'payment_failed_final',
      action: 'suspend',
      isActive: true
    }
  ]);

  const [failedPayments, setFailedPayments] = useState<FailedPayment[]>([
    {
      id: 'fp_1',
      customerId: 'cus_123',
      customerEmail: 'user@example.com',
      amount: 2900,
      failedDate: '2024-01-15',
      retryCount: 2,
      status: 'pending',
      nextRetryDate: '2024-01-17'
    },
    {
      id: 'fp_2',
      customerId: 'cus_456',
      customerEmail: 'customer@example.com',
      amount: 9900,
      failedDate: '2024-01-10',
      retryCount: 1,
      status: 'recovered'
    }
  ]);

  const [newRule, setNewRule] = useState<Partial<DunningRule>>({
    name: '',
    triggerDays: 1,
    emailTemplate: '',
    action: 'email',
    isActive: true
  });

  const [showNewRuleForm, setShowNewRuleForm] = useState(false);

  const handleSaveRule = () => {
    if (!newRule.name || !newRule.emailTemplate) {
      toast({
        title: "Error",
        description: "Please fill in all required fields.",
        variant: "destructive"
      });
      return;
    }

    const rule: DunningRule = {
      id: Date.now().toString(),
      name: newRule.name!,
      triggerDays: newRule.triggerDays!,
      emailTemplate: newRule.emailTemplate!,
      action: newRule.action!,
      isActive: newRule.isActive!
    };

    setDunningRules(prev => [...prev, rule]);
    setNewRule({
      name: '',
      triggerDays: 1,
      emailTemplate: '',
      action: 'email',
      isActive: true
    });
    setShowNewRuleForm(false);

    toast({
      title: "Success",
      description: "Dunning rule created successfully."
    });
  };

  const handleToggleRule = (ruleId: string) => {
    setDunningRules(prev => 
      prev.map(rule => 
        rule.id === ruleId 
          ? { ...rule, isActive: !rule.isActive }
          : rule
      )
    );
  };

  const handleDeleteRule = (ruleId: string) => {
    setDunningRules(prev => prev.filter(rule => rule.id !== ruleId));
    toast({
      title: "Success",
      description: "Dunning rule deleted successfully."
    });
  };

  const handleRetryPayment = async (paymentId: string) => {
    try {
      // Simulate API call to retry payment
      await new Promise(resolve => setTimeout(resolve, 1000));
      
      setFailedPayments(prev =>
        prev.map(payment =>
          payment.id === paymentId
            ? { 
                ...payment, 
                retryCount: payment.retryCount + 1,
                nextRetryDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString().split('T')[0]
              }
            : payment
        )
      );

      toast({
        title: "Success",
        description: "Payment retry initiated."
      });
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to retry payment.",
        variant: "destructive"
      });
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Dunning Management</h1>
          <p className="text-muted-foreground">
            Manage failed payment recovery and automated dunning processes
          </p>
        </div>
        <Button onClick={() => setShowNewRuleForm(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Rule
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Dunning Rules */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <Settings className="w-5 h-5 mr-2" />
              Dunning Rules
            </CardTitle>
            <CardDescription>
              Configure automated actions for failed payments
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {dunningRules.map((rule) => (
              <div key={rule.id} className="p-4 border rounded-lg space-y-3">
                <div className="flex justify-between items-start">
                  <div>
                    <h3 className="font-medium">{rule.name}</h3>
                    <p className="text-sm text-muted-foreground">
                      Trigger after {rule.triggerDays} day{rule.triggerDays !== 1 ? 's' : ''}
                    </p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Switch
                      checked={rule.isActive}
                      onCheckedChange={() => handleToggleRule(rule.id)}
                    />
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => handleDeleteRule(rule.id)}
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
                
                <div className="flex items-center space-x-4 text-sm">
                  <Badge variant="outline">
                    {rule.action === 'email' ? (
                      <Mail className="w-3 h-3 mr-1" />
                    ) : rule.action === 'suspend' ? (
                      <AlertTriangle className="w-3 h-3 mr-1" />
                    ) : (
                      <CreditCard className="w-3 h-3 mr-1" />
                    )}
                    {rule.action}
                  </Badge>
                  <span className="text-muted-foreground">
                    Template: {rule.emailTemplate}
                  </span>
                </div>
              </div>
            ))}

            {showNewRuleForm && (
              <div className="p-4 border-2 border-dashed rounded-lg space-y-4">
                <h3 className="font-medium">New Dunning Rule</h3>
                
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="ruleName">Rule Name</Label>
                    <Input
                      id="ruleName"
                      value={newRule.name}
                      onChange={(e) => setNewRule(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="e.g., First Reminder"
                    />
                  </div>
                  <div>
                    <Label htmlFor="triggerDays">Trigger Days</Label>
                    <Input
                      id="triggerDays"
                      type="number"
                      min="1"
                      value={newRule.triggerDays}
                      onChange={(e) => setNewRule(prev => ({ ...prev, triggerDays: parseInt(e.target.value) }))}
                    />
                  </div>
                </div>

                <div>
                  <Label htmlFor="emailTemplate">Email Template</Label>
                  <Input
                    id="emailTemplate"
                    value={newRule.emailTemplate}
                    onChange={(e) => setNewRule(prev => ({ ...prev, emailTemplate: e.target.value }))}
                    placeholder="Template ID"
                  />
                </div>

                <div>
                  <Label htmlFor="action">Action</Label>
                  <Select 
                    value={newRule.action} 
                    onValueChange={(value) => setNewRule(prev => ({ ...prev, action: value as any }))}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="email">Send Email</SelectItem>
                      <SelectItem value="suspend">Suspend Account</SelectItem>
                      <SelectItem value="cancel">Cancel Subscription</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="flex justify-end space-x-2">
                  <Button variant="outline" onClick={() => setShowNewRuleForm(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSaveRule}>
                    <Save className="w-4 h-4 mr-2" />
                    Save Rule
                  </Button>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Failed Payments */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center">
              <AlertTriangle className="w-5 h-5 mr-2" />
              Failed Payments
            </CardTitle>
            <CardDescription>
              Monitor and manage payment failures
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {failedPayments.map((payment) => (
              <div key={payment.id} className="p-4 border rounded-lg">
                <div className="flex justify-between items-start mb-3">
                  <div>
                    <p className="font-medium">{payment.customerEmail}</p>
                    <p className="text-sm text-muted-foreground">
                      ${(payment.amount / 100).toFixed(2)} • Failed {new Date(payment.failedDate).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant={
                    payment.status === 'recovered' ? 'default' : 
                    payment.status === 'failed' ? 'destructive' : 'secondary'
                  }>
                    {payment.status}
                  </Badge>
                </div>

                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-4">
                    <span className="text-muted-foreground">
                      Retries: {payment.retryCount}
                    </span>
                    {payment.nextRetryDate && (
                      <span className="text-muted-foreground flex items-center">
                        <Clock className="w-3 h-3 mr-1" />
                        Next: {new Date(payment.nextRetryDate).toLocaleDateString()}
                      </span>
                    )}
                  </div>
                  
                  {payment.status === 'pending' && (
                    <Button 
                      size="sm" 
                      variant="outline"
                      onClick={() => handleRetryPayment(payment.id)}
                    >
                      Retry Now
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}