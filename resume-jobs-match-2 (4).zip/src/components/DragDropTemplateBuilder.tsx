import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Plus, Save, Eye, Send } from 'lucide-react';
import ContentBlock from './template-library/ContentBlock';
import MergeTagSelector from './template-library/MergeTagSelector';

const DragDropTemplateBuilder: React.FC = () => {
  const [blocks, setBlocks] = useState([
    { id: '1', type: 'header' as const, content: 'Subject: Following up on {{jobTitle}} position' },
    { id: '2', type: 'paragraph' as const, content: 'Dear {{hiringManager}}, I hope this email finds you well.' },
    { id: '3', type: 'paragraph' as const, content: 'I wanted to follow up on my application for the {{jobTitle}} position at {{companyName}}.' },
    { id: '4', type: 'cta' as const, content: 'Schedule Interview' },
    { id: '5', type: 'signature' as const, content: 'Best regards, {{fullName}}' }
  ]);

  const addBlock = (type: string) => {
    const newBlock = {
      id: Date.now().toString(),
      type: type as any,
      content: `New ${type} content`
    };
    setBlocks([...blocks, newBlock]);
  };

  const editBlock = (id: string) => {
    console.log('Editing block:', id);
  };

  const duplicateBlock = (id: string) => {
    const block = blocks.find(b => b.id === id);
    if (block) {
      const newBlock = { ...block, id: Date.now().toString() };
      setBlocks([...blocks, newBlock]);
    }
  };

  const deleteBlock = (id: string) => {
    setBlocks(blocks.filter(b => b.id !== id));
  };

  const handleTagSelect = (tag: string) => {
    console.log('Selected tag:', tag);
  };

  const blockTypes = [
    { type: 'header', label: 'Header', icon: '📋' },
    { type: 'paragraph', label: 'Paragraph', icon: '📄' },
    { type: 'cta', label: 'Call to Action', icon: '🔗' },
    { type: 'signature', label: 'Signature', icon: '✍️' },
    { type: 'image', label: 'Image', icon: '🖼️' }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6">
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Email Template Builder</h1>
        <div className="flex gap-2">
          <Button variant="outline"><Eye size={16} className="mr-2" />Preview</Button>
          <Button variant="outline"><Send size={16} className="mr-2" />Test Send</Button>
          <Button><Save size={16} className="mr-2" />Save Template</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        <div className="lg:col-span-1">
          <Tabs defaultValue="blocks" className="w-full">
            <TabsList className="grid w-full grid-cols-2">
              <TabsTrigger value="blocks">Blocks</TabsTrigger>
              <TabsTrigger value="tags">Tags</TabsTrigger>
            </TabsList>
            <TabsContent value="blocks">
              <Card>
                <CardHeader>
                  <CardTitle>Content Blocks</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  {blockTypes.map(block => (
                    <Button
                      key={block.type}
                      variant="outline"
                      className="w-full justify-start"
                      onClick={() => addBlock(block.type)}
                    >
                      <span className="mr-2">{block.icon}</span>
                      <Plus size={14} className="mr-2" />
                      {block.label}
                    </Button>
                  ))}
                </CardContent>
              </Card>
            </TabsContent>
            <TabsContent value="tags">
              <MergeTagSelector onTagSelect={handleTagSelect} />
            </TabsContent>
          </Tabs>
        </div>

        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Template Builder</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {blocks.map(block => (
                  <ContentBlock
                    key={block.id}
                    id={block.id}
                    type={block.type}
                    content={block.content}
                    onEdit={editBlock}
                    onDuplicate={duplicateBlock}
                    onDelete={deleteBlock}
                  />
                ))}
                {blocks.length === 0 && (
                  <div className="text-center py-12 text-gray-500">
                    <p>No content blocks yet. Add some from the sidebar!</p>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle>Live Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-white border rounded-lg p-4 space-y-3 text-sm">
                {blocks.map(block => (
                  <div key={block.id}>
                    {block.type === 'header' && (
                      <div className="font-bold border-b pb-2">{block.content}</div>
                    )}
                    {block.type === 'paragraph' && (
                      <p className="text-gray-700">{block.content}</p>
                    )}
                    {block.type === 'cta' && (
                      <div className="text-center">
                        <span className="bg-blue-600 text-white px-4 py-2 rounded inline-block">
                          {block.content}
                        </span>
                      </div>
                    )}
                    {block.type === 'signature' && (
                      <div className="italic text-gray-600 border-t pt-2">{block.content}</div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default DragDropTemplateBuilder;