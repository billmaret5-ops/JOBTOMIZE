import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { toast } from 'sonner';
import { Upload, FileText, User, Mail } from 'lucide-react';

interface Job {
  id: string;
  title: string;
  company: string;
  location?: string;
  salary?: string;
  type?: string;
}

interface ApplyJobModalProps {
  open: boolean;
  onClose: () => void;
  job: Job | null;
}

export default function ApplyJobModal({ open, onClose, job }: ApplyJobModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    fullName: user?.user_metadata?.full_name || '',
    email: user?.email || '',
    phone: '',
    coverLetter: '',
    resumeFile: null as File | null,
    expectedSalary: '',
    availableStartDate: '',
    workAuthorization: 'yes'
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !job) return;

    setLoading(true);
    try {
      // Create application record
      const applicationData = {
        user_id: user.id,
        job_id: job.id,
        job_title: job.title,
        company_name: job.company,
        location: job.location,
        salary_range: job.salary,
        status: 'submitted',
        applied_date: new Date().toISOString(),
        applied_via: 'platform',
        notes: formData.coverLetter,
        salary_expectation: formData.expectedSalary ? parseInt(formData.expectedSalary) : null,
        email_notifications: true,
        follow_up_reminder: true,
        follow_up_date: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString() // 7 days from now
      };

      const { error: appError } = await supabase
        .from('job_applications')
        .insert([applicationData]);

      if (appError) throw appError;

      // Upload resume if provided
      if (formData.resumeFile) {
        const fileName = `${user.id}/${Date.now()}_${formData.resumeFile.name}`;
        const { error: uploadError } = await supabase.storage
          .from('resumes')
          .upload(fileName, formData.resumeFile);

        if (uploadError) {
          console.error('Resume upload failed:', uploadError);
          // Don't fail the entire application if resume upload fails
        }
      }

      toast.success('Application submitted successfully!');
      onClose();
      
      // Reset form
      setFormData({
        fullName: user?.user_metadata?.full_name || '',
        email: user?.email || '',
        phone: '',
        coverLetter: '',
        resumeFile: null,
        expectedSalary: '',
        availableStartDate: '',
        workAuthorization: 'yes'
      });
    } catch (error) {
      console.error('Error submitting application:', error);
      toast.error('Failed to submit application. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      if (file.size > 5 * 1024 * 1024) { // 5MB limit
        toast.error('File size must be less than 5MB');
        return;
      }
      if (!['application/pdf', 'application/msword', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document'].includes(file.type)) {
        toast.error('Please upload a PDF or Word document');
        return;
      }
      setFormData(prev => ({ ...prev, resumeFile: file }));
    }
  };

  if (!job) return null;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <FileText className="w-5 h-5" />
            Apply for {job.title}
          </DialogTitle>
          <p className="text-sm text-gray-600">{job.company} • {job.location}</p>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="fullName">Full Name *</Label>
              <Input
                id="fullName"
                value={formData.fullName}
                onChange={(e) => setFormData(prev => ({ ...prev, fullName: e.target.value }))}
                required
              />
            </div>
            <div>
              <Label htmlFor="email">Email *</Label>
              <Input
                id="email"
                type="email"
                value={formData.email}
                onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="expectedSalary">Expected Salary</Label>
              <Input
                id="expectedSalary"
                type="number"
                placeholder="e.g., 75000"
                value={formData.expectedSalary}
                onChange={(e) => setFormData(prev => ({ ...prev, expectedSalary: e.target.value }))}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="startDate">Available Start Date</Label>
              <Input
                id="startDate"
                type="date"
                value={formData.availableStartDate}
                onChange={(e) => setFormData(prev => ({ ...prev, availableStartDate: e.target.value }))}
              />
            </div>
            <div>
              <Label htmlFor="workAuth">Work Authorization</Label>
              <Select value={formData.workAuthorization} onValueChange={(value) => setFormData(prev => ({ ...prev, workAuthorization: value }))}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="yes">Authorized to work</SelectItem>
                  <SelectItem value="no">Need sponsorship</SelectItem>
                  <SelectItem value="student">Student visa</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div>
            <Label htmlFor="resume">Resume/CV</Label>
            <div className="mt-1">
              <input
                id="resume"
                type="file"
                accept=".pdf,.doc,.docx"
                onChange={handleFileChange}
                className="hidden"
              />
              <Button
                type="button"
                variant="outline"
                onClick={() => document.getElementById('resume')?.click()}
                className="w-full"
              >
                <Upload className="w-4 h-4 mr-2" />
                {formData.resumeFile ? formData.resumeFile.name : 'Upload Resume (PDF, DOC, DOCX)'}
              </Button>
            </div>
          </div>

          <div>
            <Label htmlFor="coverLetter">Cover Letter</Label>
            <Textarea
              id="coverLetter"
              rows={6}
              placeholder="Tell us why you're interested in this position and what makes you a great fit..."
              value={formData.coverLetter}
              onChange={(e) => setFormData(prev => ({ ...prev, coverLetter: e.target.value }))}
            />
          </div>

          <div className="flex justify-end gap-2 pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Submitting...' : 'Submit Application'}
            </Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}