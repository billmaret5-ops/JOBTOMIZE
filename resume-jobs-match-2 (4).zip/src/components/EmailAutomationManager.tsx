import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Zap, Clock, Mail, Plus, Trash2 } from 'lucide-react';

interface EmailSequence {
  id: string;
  name: string;
  trigger_event: string;
  is_active: boolean;
  steps: EmailSequenceStep[];
}

interface EmailSequenceStep {
  id: string;
  template_name: string;
  delay_days: number;
  delay_hours: number;
  step_order: number;
  is_active: boolean;
}

export const EmailAutomationManager: React.FC = () => {
  const [sequences, setSequences] = useState<EmailSequence[]>([
    {
      id: '1',
      name: 'Post-Application Follow-up',
      trigger_event: 'application_submitted',
      is_active: true,
      steps: [
        { id: '1', template_name: 'Follow-up After Application', delay_days: 7, delay_hours: 0, step_order: 1, is_active: true },
        { id: '2', template_name: 'Second Follow-up', delay_days: 14, delay_hours: 0, step_order: 2, is_active: true }
      ]
    }
  ]);

  const [newSequence, setNewSequence] = useState({
    name: '',
    trigger_event: 'application_submitted',
    steps: [{ template_name: '', delay_days: 7, delay_hours: 0 }]
  });

  const triggerEvents = [
    { value: 'application_submitted', label: 'Application Submitted' },
    { value: 'interview_completed', label: 'Interview Completed' },
    { value: 'no_response', label: 'No Response Received' },
    { value: 'job_offer_received', label: 'Job Offer Received' },
    { value: 'application_rejected', label: 'Application Rejected' }
  ];

  const addSequenceStep = () => {
    setNewSequence(prev => ({
      ...prev,
      steps: [...prev.steps, { template_name: '', delay_days: 7, delay_hours: 0 }]
    }));
  };

  const removeSequenceStep = (index: number) => {
    setNewSequence(prev => ({
      ...prev,
      steps: prev.steps.filter((_, i) => i !== index)
    }));
  };

  const toggleSequence = (sequenceId: string) => {
    setSequences(prev => prev.map(seq => 
      seq.id === sequenceId ? { ...seq, is_active: !seq.is_active } : seq
    ));
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-2 mb-6">
        <Zap className="h-6 w-6 text-yellow-500" />
        <h2 className="text-2xl font-bold">Email Automation</h2>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              Create Email Sequence
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label>Sequence Name</Label>
              <Input
                value={newSequence.name}
                onChange={(e) => setNewSequence(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Post-Interview Thank You Series"
              />
            </div>

            <div className="space-y-2">
              <Label>Trigger Event</Label>
              <Select
                value={newSequence.trigger_event}
                onValueChange={(value) => setNewSequence(prev => ({ ...prev, trigger_event: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {triggerEvents.map(event => (
                    <SelectItem key={event.value} value={event.value}>
                      {event.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-3">
              <Label>Email Steps</Label>
              {newSequence.steps.map((step, index) => (
                <div key={index} className="border rounded-lg p-3 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-sm font-medium">Step {index + 1}</span>
                    {newSequence.steps.length > 1 && (
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => removeSequenceStep(index)}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>
                  
                  <Select
                    value={step.template_name}
                    onValueChange={(value) => {
                      const updatedSteps = [...newSequence.steps];
                      updatedSteps[index].template_name = value;
                      setNewSequence(prev => ({ ...prev, steps: updatedSteps }));
                    }}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select template" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Follow-up After Application">Follow-up After Application</SelectItem>
                      <SelectItem value="Thank You After Interview">Thank You After Interview</SelectItem>
                      <SelectItem value="Networking Outreach">Networking Outreach</SelectItem>
                    </SelectContent>
                  </Select>

                  <div className="grid grid-cols-2 gap-2">
                    <div>
                      <Label className="text-xs">Days</Label>
                      <Input
                        type="number"
                        value={step.delay_days}
                        onChange={(e) => {
                          const updatedSteps = [...newSequence.steps];
                          updatedSteps[index].delay_days = parseInt(e.target.value) || 0;
                          setNewSequence(prev => ({ ...prev, steps: updatedSteps }));
                        }}
                        min="0"
                      />
                    </div>
                    <div>
                      <Label className="text-xs">Hours</Label>
                      <Input
                        type="number"
                        value={step.delay_hours}
                        onChange={(e) => {
                          const updatedSteps = [...newSequence.steps];
                          updatedSteps[index].delay_hours = parseInt(e.target.value) || 0;
                          setNewSequence(prev => ({ ...prev, steps: updatedSteps }));
                        }}
                        min="0"
                        max="23"
                      />
                    </div>
                  </div>
                </div>
              ))}
              
              <Button variant="outline" onClick={addSequenceStep} className="w-full">
                <Plus className="h-4 w-4 mr-2" />
                Add Step
              </Button>
            </div>

            <Button className="w-full">Create Sequence</Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Sequences</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {sequences.map(sequence => (
                <div key={sequence.id} className="border rounded-lg p-4">
                  <div className="flex items-center justify-between mb-3">
                    <h4 className="font-medium">{sequence.name}</h4>
                    <div className="flex items-center gap-2">
                      <Badge variant={sequence.is_active ? 'default' : 'secondary'}>
                        {sequence.is_active ? 'Active' : 'Inactive'}
                      </Badge>
                      <Switch
                        checked={sequence.is_active}
                        onCheckedChange={() => toggleSequence(sequence.id)}
                      />
                    </div>
                  </div>
                  
                  <p className="text-sm text-gray-600 mb-3">
                    Trigger: {triggerEvents.find(e => e.value === sequence.trigger_event)?.label}
                  </p>
                  
                  <div className="space-y-2">
                    {sequence.steps.map((step, index) => (
                      <div key={step.id} className="flex items-center gap-3 text-sm">
                        <Clock className="h-4 w-4 text-gray-400" />
                        <span>Step {index + 1}:</span>
                        <span className="font-medium">{step.template_name}</span>
                        <span className="text-gray-500">
                          ({step.delay_days}d {step.delay_hours}h)
                        </span>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EmailAutomationManager;