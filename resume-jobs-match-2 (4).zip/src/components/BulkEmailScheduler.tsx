import React, { useState } from 'react';
import { Send, Calendar, Users, CheckCircle, Clock } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';

interface Application {
  id: string;
  company: string;
  position: string;
  contact_email: string;
  contact_name: string;
  timezone: string;
}

export default function BulkEmailScheduler() {
  const [selectedApps, setSelectedApps] = useState<string[]>([]);
  const [emailTemplate, setEmailTemplate] = useState('follow_up');
  const [schedulingStrategy, setSchedulingStrategy] = useState('optimal');

  const applications: Application[] = [
    {
      id: '1',
      company: 'TechCorp',
      position: 'Software Engineer',
      contact_email: 'hr@techcorp.com',
      contact_name: 'Sarah Johnson',
      timezone: 'America/New_York'
    },
    {
      id: '2',
      company: 'StartupIO',
      position: 'Product Manager',
      contact_email: 'recruiter@startup.io',
      contact_name: 'Mike Chen',
      timezone: 'America/Los_Angeles'
    },
    {
      id: '3',
      company: 'DataSystems',
      position: 'Data Analyst',
      contact_email: 'hiring@datasystems.com',
      contact_name: 'Emily Davis',
      timezone: 'America/Chicago'
    }
  ];

  const toggleApp = (id: string) => {
    setSelectedApps(prev =>
      prev.includes(id) ? prev.filter(a => a !== id) : [...prev, id]
    );
  };

  const scheduleAll = () => {
    console.log('Scheduling emails for:', selectedApps);
    alert(`Scheduled ${selectedApps.length} emails with optimal timing!`);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Bulk Email Scheduler</h2>
        <Button onClick={scheduleAll} disabled={selectedApps.length === 0}>
          <Send className="w-4 h-4 mr-2" />
          Schedule {selectedApps.length} Emails
        </Button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Select Applications</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {applications.map(app => (
                  <div
                    key={app.id}
                    className="flex items-center justify-between p-4 border rounded-lg hover:bg-gray-50"
                  >
                    <div className="flex items-center gap-3">
                      <Checkbox
                        checked={selectedApps.includes(app.id)}
                        onCheckedChange={() => toggleApp(app.id)}
                      />
                      <div>
                        <h3 className="font-semibold">{app.company}</h3>
                        <p className="text-sm text-gray-600">{app.position}</p>
                        <p className="text-xs text-gray-500">{app.contact_name} • {app.timezone}</p>
                      </div>
                    </div>
                    <div className="text-right text-sm">
                      <div className="flex items-center gap-1 text-green-600">
                        <Clock className="w-4 h-4" />
                        <span>9:30 AM</span>
                      </div>
                      <span className="text-xs text-gray-500">Optimal time</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Scheduling Options</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label>Email Template</Label>
                <select
                  className="w-full mt-1 p-2 border rounded"
                  value={emailTemplate}
                  onChange={(e) => setEmailTemplate(e.target.value)}
                >
                  <option value="follow_up">Follow-up</option>
                  <option value="thank_you">Thank You</option>
                  <option value="check_in">Check-in</option>
                </select>
              </div>

              <div>
                <Label>Scheduling Strategy</Label>
                <select
                  className="w-full mt-1 p-2 border rounded"
                  value={schedulingStrategy}
                  onChange={(e) => setSchedulingStrategy(e.target.value)}
                >
                  <option value="optimal">AI-Optimized Time</option>
                  <option value="immediate">Send Immediately</option>
                  <option value="custom">Custom Time</option>
                </select>
              </div>

              <div className="pt-4 border-t">
                <h4 className="font-semibold mb-2">Summary</h4>
                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Selected:</span>
                    <span className="font-semibold">{selectedApps.length} emails</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Time zones:</span>
                    <span className="font-semibold">3 zones</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Avg. open rate:</span>
                    <span className="font-semibold text-green-600">68%</span>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}