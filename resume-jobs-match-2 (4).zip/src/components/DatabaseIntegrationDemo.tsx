import React, { useState } from 'react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { useTemplates, useCampaigns } from '../hooks/useDatabaseSync';
import { emailTemplatesDB, campaignsDB, contactsDB, analyticsDB } from '../lib/database';
import { Loader2, Plus, Trash2, Edit, RefreshCw } from 'lucide-react';
import { useToast } from '../hooks/use-toast';

export default function DatabaseIntegrationDemo() {
  const userId = 'demo-user-id'; // Replace with actual user ID from auth
  const { templates, loading: templatesLoading, refresh: refreshTemplates } = useTemplates(userId);
  const { campaigns, loading: campaignsLoading, refresh: refreshCampaigns } = useCampaigns(userId);
  const { toast } = useToast();
  const [newTemplateName, setNewTemplateName] = useState('');
  const [newCampaignName, setNewCampaignName] = useState('');

  const createTemplate = async () => {
    try {
      await emailTemplatesDB.create({
        user_id: userId,
        name: newTemplateName,
        subject: 'New Template',
        html_content: '<p>Template content</p>',
        json_structure: {},
        category: 'newsletter',
        tags: [],
        is_public: false,
        usage_count: 0
      });
      setNewTemplateName('');
      toast({ title: 'Template created successfully!' });
    } catch (error) {
      toast({ title: 'Error creating template', variant: 'destructive' });
    }
  };

  const createCampaign = async () => {
    try {
      await campaignsDB.create({
        user_id: userId,
        name: newCampaignName,
        subject: 'New Campaign',
        html_content: '<p>Campaign content</p>',
        status: 'draft',
        total_recipients: 0,
        total_sent: 0,
        total_delivered: 0,
        total_opened: 0,
        total_clicked: 0,
        total_bounced: 0,
        total_unsubscribed: 0,
        settings: {}
      });
      setNewCampaignName('');
      toast({ title: 'Campaign created successfully!' });
    } catch (error) {
      toast({ title: 'Error creating campaign', variant: 'destructive' });
    }
  };

  const deleteTemplate = async (id: string) => {
    try {
      await emailTemplatesDB.delete(id);
      toast({ title: 'Template deleted' });
    } catch (error) {
      toast({ title: 'Error deleting template', variant: 'destructive' });
    }
  };

  return (
    <div className="container mx-auto p-6 space-y-6">
      <h1 className="text-3xl font-bold">Database Integration Demo</h1>
      
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            Email Templates
            <Button size="sm" onClick={refreshTemplates}>
              <RefreshCw className="h-4 w-4 mr-2" />
              Refresh
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input
              placeholder="Template name"
              value={newTemplateName}
              onChange={(e) => setNewTemplateName(e.target.value)}
            />
            <Button onClick={createTemplate}>
              <Plus className="h-4 w-4 mr-2" />
              Create
            </Button>
          </div>
          
          {templatesLoading ? (
            <div className="flex justify-center p-4">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <div className="space-y-2">
              {templates.map((template) => (
                <div key={template.id} className="flex items-center justify-between p-3 border rounded">
                  <span>{template.name}</span>
                  <Button variant="destructive" size="sm" onClick={() => deleteTemplate(template.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Email Campaigns (Real-time)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-2 mb-4">
            <Input
              placeholder="Campaign name"
              value={newCampaignName}
              onChange={(e) => setNewCampaignName(e.target.value)}
            />
            <Button onClick={createCampaign}>
              <Plus className="h-4 w-4 mr-2" />
              Create
            </Button>
          </div>
          
          {campaignsLoading ? (
            <div className="flex justify-center p-4">
              <Loader2 className="h-6 w-6 animate-spin" />
            </div>
          ) : (
            <div className="space-y-2">
              {campaigns.map((campaign) => (
                <div key={campaign.id} className="p-3 border rounded">
                  <div className="font-medium">{campaign.name}</div>
                  <div className="text-sm text-gray-600">Status: {campaign.status}</div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
