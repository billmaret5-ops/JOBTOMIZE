import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Bell, Plus, Trash2, Calendar } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Reminder {
  id: string;
  application_id: string;
  title: string;
  description: string;
  reminder_date: string;
  reminder_type: string;
  completed: boolean;
}

interface ApplicationReminderManagerProps {
  applicationId: string;
}

export function ApplicationReminderManager({ applicationId }: ApplicationReminderManagerProps) {
  const { user } = useAuth();
  const [reminders, setReminders] = useState<Reminder[]>([]);
  const [showForm, setShowForm] = useState(false);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    reminder_date: '',
    reminder_type: 'follow_up'
  });

  useEffect(() => {
    fetchReminders();
  }, [applicationId]);

  const fetchReminders = async () => {
    const { data, error } = await supabase
      .from('application_reminders')
      .select('*')
      .eq('application_id', applicationId)
      .order('reminder_date', { ascending: true });

    if (!error && data) {
      setReminders(data);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const { error } = await supabase
      .from('application_reminders')
      .insert([{ ...formData, application_id: applicationId, user_id: user?.id }]);

    if (error) {
      toast.error('Failed to create reminder');
    } else {
      toast.success('Reminder created');
      setFormData({ title: '', description: '', reminder_date: '', reminder_type: 'follow_up' });
      setShowForm(false);
      fetchReminders();
    }
  };

  const deleteReminder = async (id: string) => {
    const { error } = await supabase
      .from('application_reminders')
      .delete()
      .eq('id', id);

    if (!error) {
      toast.success('Reminder deleted');
      fetchReminders();
    }
  };

  const toggleComplete = async (reminder: Reminder) => {
    const { error } = await supabase
      .from('application_reminders')
      .update({ completed: !reminder.completed })
      .eq('id', reminder.id);

    if (!error) {
      fetchReminders();
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Bell className="w-5 h-5" />
            Reminders
          </div>
          <Button size="sm" onClick={() => setShowForm(!showForm)}>
            <Plus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {showForm && (
          <form onSubmit={handleSubmit} className="space-y-3 p-4 bg-gray-50 rounded-lg">
            <div>
              <Label>Title</Label>
              <Input required value={formData.title} onChange={(e) => setFormData({...formData, title: e.target.value})} />
            </div>
            <div>
              <Label>Description</Label>
              <Input value={formData.description} onChange={(e) => setFormData({...formData, description: e.target.value})} />
            </div>
            <div className="grid grid-cols-2 gap-2">
              <div>
                <Label>Date</Label>
                <Input type="datetime-local" required value={formData.reminder_date} onChange={(e) => setFormData({...formData, reminder_date: e.target.value})} />
              </div>
              <div>
                <Label>Type</Label>
                <Select value={formData.reminder_type} onValueChange={(value) => setFormData({...formData, reminder_type: value})}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="follow_up">Follow-up</SelectItem>
                    <SelectItem value="interview">Interview</SelectItem>
                    <SelectItem value="deadline">Deadline</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <div className="flex gap-2">
              <Button type="submit" size="sm">Save</Button>
              <Button type="button" size="sm" variant="outline" onClick={() => setShowForm(false)}>Cancel</Button>
            </div>
          </form>
        )}

        <div className="space-y-2">
          {reminders.map((reminder) => (
            <div key={reminder.id} className={`p-3 rounded-lg border ${reminder.completed ? 'bg-gray-50' : 'bg-white'}`}>
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <input
                      type="checkbox"
                      checked={reminder.completed}
                      onChange={() => toggleComplete(reminder)}
                      className="rounded"
                    />
                    <h4 className={`font-medium ${reminder.completed ? 'line-through text-gray-500' : ''}`}>
                      {reminder.title}
                    </h4>
                    <Badge variant="outline" className="text-xs">
                      {reminder.reminder_type}
                    </Badge>
                  </div>
                  {reminder.description && (
                    <p className="text-sm text-gray-600 mt-1 ml-6">{reminder.description}</p>
                  )}
                  <div className="flex items-center gap-1 text-xs text-gray-500 mt-1 ml-6">
                    <Calendar className="w-3 h-3" />
                    {new Date(reminder.reminder_date).toLocaleString()}
                  </div>
                </div>
                <Button size="sm" variant="ghost" onClick={() => deleteReminder(reminder.id)}>
                  <Trash2 className="w-4 h-4 text-red-500" />
                </Button>
              </div>
            </div>
          ))}
          {reminders.length === 0 && !showForm && (
            <p className="text-center text-gray-500 py-4">No reminders set</p>
          )}
        </div>
      </CardContent>
    </Card>
  );
}