import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Plus, Edit, Trash2, Save } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface QualityRule {
  id: string;
  rule_name: string;
  rule_type: string;
  column_name: string;
  rule_config: any;
  severity: string;
  is_active: boolean;
}

export default function DataQualityRulesManager() {
  const [rules, setRules] = useState<QualityRule[]>([]);
  const [editingRule, setEditingRule] = useState<QualityRule | null>(null);
  const [newRule, setNewRule] = useState({
    rule_name: '',
    rule_type: 'completeness',
    column_name: '',
    severity: 'medium',
    threshold: 95
  });

  useEffect(() => {
    loadRules();
  }, []);

  const loadRules = async () => {
    const { data } = await supabase
      .from('data_quality_rules')
      .select('*')
      .order('created_at', { ascending: false });
    setRules(data || []);
  };

  const saveRule = async () => {
    const ruleData = {
      ...newRule,
      rule_config: { threshold: newRule.threshold },
      data_source_id: '00000000-0000-0000-0000-000000000000' // Default
    };

    if (editingRule) {
      await supabase
        .from('data_quality_rules')
        .update(ruleData)
        .eq('id', editingRule.id);
    } else {
      await supabase
        .from('data_quality_rules')
        .insert([ruleData]);
    }

    setNewRule({ rule_name: '', rule_type: 'completeness', column_name: '', severity: 'medium', threshold: 95 });
    setEditingRule(null);
    loadRules();
  };

  const toggleRule = async (id: string, is_active: boolean) => {
    await supabase
      .from('data_quality_rules')
      .update({ is_active })
      .eq('id', id);
    loadRules();
  };

  const deleteRule = async (id: string) => {
    await supabase
      .from('data_quality_rules')
      .delete()
      .eq('id', id);
    loadRules();
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Add Quality Rule</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <Input
              placeholder="Rule Name"
              value={newRule.rule_name}
              onChange={(e) => setNewRule({...newRule, rule_name: e.target.value})}
            />
            <Select value={newRule.rule_type} onValueChange={(value) => setNewRule({...newRule, rule_type: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="completeness">Completeness</SelectItem>
                <SelectItem value="validity">Validity</SelectItem>
                <SelectItem value="uniqueness">Uniqueness</SelectItem>
                <SelectItem value="freshness">Freshness</SelectItem>
                <SelectItem value="outlier">Outlier Detection</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-3 gap-4">
            <Input
              placeholder="Column Name"
              value={newRule.column_name}
              onChange={(e) => setNewRule({...newRule, column_name: e.target.value})}
            />
            <Select value={newRule.severity} onValueChange={(value) => setNewRule({...newRule, severity: value})}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="low">Low</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="high">High</SelectItem>
                <SelectItem value="critical">Critical</SelectItem>
              </SelectContent>
            </Select>
            <Input
              type="number"
              placeholder="Threshold %"
              value={newRule.threshold}
              onChange={(e) => setNewRule({...newRule, threshold: parseInt(e.target.value)})}
            />
          </div>
          <Button onClick={saveRule} className="w-full">
            <Save className="h-4 w-4 mr-2" />
            {editingRule ? 'Update Rule' : 'Add Rule'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Quality Rules ({rules.length})</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-medium">{rule.rule_name}</h3>
                    <Badge variant={rule.severity === 'critical' ? 'destructive' : 'default'}>
                      {rule.severity}
                    </Badge>
                    <Badge variant="outline">{rule.rule_type}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    Column: {rule.column_name} | Threshold: {rule.rule_config?.threshold || 'N/A'}%
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Switch
                    checked={rule.is_active}
                    onCheckedChange={(checked) => toggleRule(rule.id, checked)}
                  />
                  <Button variant="ghost" size="sm" onClick={() => {
                    setEditingRule(rule);
                    setNewRule({
                      rule_name: rule.rule_name,
                      rule_type: rule.rule_type,
                      column_name: rule.column_name,
                      severity: rule.severity,
                      threshold: rule.rule_config?.threshold || 95
                    });
                  }}>
                    <Edit className="h-4 w-4" />
                  </Button>
                  <Button variant="ghost" size="sm" onClick={() => deleteRule(rule.id)}>
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}