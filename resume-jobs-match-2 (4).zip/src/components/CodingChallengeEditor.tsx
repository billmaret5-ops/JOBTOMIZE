import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Play, CheckCircle2, XCircle, Loader2, Lightbulb } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Challenge {
  id: string;
  title: string;
  description: string;
  difficulty: string;
  category: string;
  starter_code: any;
  test_cases: any[];
  hints: string[];
  time_complexity: string;
  space_complexity: string;
}

interface Props {
  challenge: Challenge;
}

export default function CodingChallengeEditor({ challenge }: Props) {
  const [code, setCode] = useState('');
  const [language, setLanguage] = useState('javascript');
  const [running, setRunning] = useState(false);
  const [results, setResults] = useState<any>(null);
  const [showHints, setShowHints] = useState(false);

  useEffect(() => {
    if (challenge.starter_code?.[language]) {
      setCode(challenge.starter_code[language]);
    }
  }, [challenge, language]);

  const runCode = async () => {
    setRunning(true);
    try {
      const { data, error } = await supabase.functions.invoke('code-executor', {
        body: {
          code,
          language,
          testCases: challenge.test_cases,
        }
      });

      if (error) throw error;
      setResults(data);
    } catch (error) {
      console.error('Error running code:', error);
    } finally {
      setRunning(false);
    }
  };

  return (
    <div className="grid lg:grid-cols-2 gap-6">
      <div className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-start">
              <div>
                <CardTitle>{challenge.title}</CardTitle>
                <div className="flex gap-2 mt-2">
                  <Badge variant={challenge.difficulty === 'hard' ? 'destructive' : 'default'}>
                    {challenge.difficulty}
                  </Badge>
                  <Badge variant="outline">{challenge.category}</Badge>
                </div>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-sm">{challenge.description}</p>
            
            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Test Cases:</h4>
              {challenge.test_cases.map((tc: any, i: number) => (
                <div key={i} className="bg-muted p-3 rounded text-sm">
                  <div><strong>Input:</strong> {JSON.stringify(tc.input)}</div>
                  <div><strong>Output:</strong> {JSON.stringify(tc.output)}</div>
                </div>
              ))}
            </div>

            <div className="space-y-2">
              <h4 className="font-semibold text-sm">Complexity:</h4>
              <div className="text-sm">
                <div>Time: {challenge.time_complexity}</div>
                <div>Space: {challenge.space_complexity}</div>
              </div>
            </div>

            <Button
              variant="outline"
              onClick={() => setShowHints(!showHints)}
              className="w-full"
            >
              <Lightbulb className="mr-2 h-4 w-4" />
              {showHints ? 'Hide' : 'Show'} Hints
            </Button>

            {showHints && (
              <div className="space-y-2">
                {challenge.hints.map((hint: string, i: number) => (
                  <div key={i} className="bg-yellow-50 border border-yellow-200 p-3 rounded text-sm">
                    <strong>Hint {i + 1}:</strong> {hint}
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <div className="space-y-4">
        <Card>
          <CardHeader>
            <div className="flex justify-between items-center">
              <CardTitle>Code Editor</CardTitle>
              <Select value={language} onValueChange={setLanguage}>
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="javascript">JavaScript</SelectItem>
                  <SelectItem value="python">Python</SelectItem>
                  <SelectItem value="java">Java</SelectItem>
                  <SelectItem value="cpp">C++</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </CardHeader>
          <CardContent className="space-y-4">
            <Textarea
              value={code}
              onChange={(e) => setCode(e.target.value)}
              className="font-mono text-sm min-h-[300px]"
              placeholder="Write your code here..."
            />

            <Button onClick={runCode} disabled={running} className="w-full">
              {running ? (
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
              ) : (
                <Play className="mr-2 h-4 w-4" />
              )}
              Run Code
            </Button>

            {results && (
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Results</CardTitle>
                  <Badge variant={results.success ? 'default' : 'destructive'}>
                    {results.summary.passed}/{results.summary.total} Passed
                  </Badge>
                </CardHeader>
                <CardContent className="space-y-2">
                  {results.results.map((result: any, i: number) => (
                    <div key={i} className="flex items-start gap-2 p-2 border rounded">
                      {result.passed ? (
                        <CheckCircle2 className="h-5 w-5 text-green-500 flex-shrink-0" />
                      ) : (
                        <XCircle className="h-5 w-5 text-red-500 flex-shrink-0" />
                      )}
                      <div className="text-sm flex-1">
                        <div className="font-semibold">Test Case {i + 1}</div>
                        {result.output && <div className="text-muted-foreground">Output: {result.output}</div>}
                        {result.error && <div className="text-red-500">Error: {result.error}</div>}
                      </div>
                    </div>
                  ))}
                </CardContent>
              </Card>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}