import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Switch } from '@/components/ui/switch';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Database, Webhook, Zap, Settings, CheckCircle, XCircle, RefreshCw } from 'lucide-react';

interface DataSource {
  id: string;
  name: string;
  type: 'email' | 'crm' | 'social' | 'webhook';
  status: 'connected' | 'disconnected' | 'error';
  lastSync: string;
  recordsCount: number;
}

export default function DataSourceManager() {
  const [sources, setSources] = useState<DataSource[]>([
    {
      id: '1',
      name: 'Gmail API',
      type: 'email',
      status: 'connected',
      lastSync: '2 minutes ago',
      recordsCount: 15420
    },
    {
      id: '2',
      name: 'Salesforce CRM',
      type: 'crm',
      status: 'connected',
      lastSync: '5 minutes ago',
      recordsCount: 8932
    },
    {
      id: '3',
      name: 'Twitter API',
      type: 'social',
      status: 'error',
      lastSync: '1 hour ago',
      recordsCount: 0
    }
  ]);

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'connected': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'error': return <XCircle className="h-4 w-4 text-red-500" />;
      default: return <RefreshCw className="h-4 w-4 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'connected': return 'bg-green-100 text-green-800';
      case 'error': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Data Source Manager</h1>
          <p className="text-muted-foreground">Manage real-time data integrations</p>
        </div>
        <Button>
          <Database className="w-4 h-4 mr-2" />
          Add Source
        </Button>
      </div>

      <Tabs defaultValue="sources" className="w-full">
        <TabsList>
          <TabsTrigger value="sources">Data Sources</TabsTrigger>
          <TabsTrigger value="webhooks">Webhooks</TabsTrigger>
          <TabsTrigger value="sync">Sync Settings</TabsTrigger>
        </TabsList>

        <TabsContent value="sources">
          <div className="grid gap-4">
            {sources.map((source) => (
              <Card key={source.id}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Database className="h-5 w-5 text-blue-600" />
                      </div>
                      <div>
                        <CardTitle className="text-lg">{source.name}</CardTitle>
                        <CardDescription>Last sync: {source.lastSync}</CardDescription>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      {getStatusIcon(source.status)}
                      <Badge className={getStatusColor(source.status)}>
                        {source.status}
                      </Badge>
                    </div>
                  </div>
                </CardHeader>
                <CardContent>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-4">
                      <div className="text-sm text-muted-foreground">
                        Records: {source.recordsCount.toLocaleString()}
                      </div>
                      <div className="text-sm text-muted-foreground">
                        Type: {source.type}
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Switch defaultChecked={source.status === 'connected'} />
                      <Button variant="outline" size="sm">
                        <Settings className="w-4 h-4" />
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="webhooks">
          <Card>
            <CardHeader>
              <CardTitle>Webhook Configuration</CardTitle>
              <CardDescription>Configure real-time data webhooks</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid w-full items-center gap-1.5">
                <Label htmlFor="webhook-url">Webhook URL</Label>
                <Input
                  type="url"
                  id="webhook-url"
                  placeholder="https://your-app.com/webhook"
                />
              </div>
              <div className="flex items-center space-x-2">
                <Switch id="webhook-enabled" />
                <Label htmlFor="webhook-enabled">Enable real-time webhooks</Label>
              </div>
              <Button>
                <Webhook className="w-4 h-4 mr-2" />
                Test Webhook
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sync">
          <Card>
            <CardHeader>
              <CardTitle>Synchronization Settings</CardTitle>
              <CardDescription>Configure automated data sync intervals</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <Label htmlFor="auto-sync">Automatic Sync</Label>
                <Switch id="auto-sync" defaultChecked />
              </div>
              <div className="grid w-full items-center gap-1.5">
                <Label htmlFor="sync-interval">Sync Interval (minutes)</Label>
                <Input
                  type="number"
                  id="sync-interval"
                  defaultValue="5"
                  min="1"
                  max="60"
                />
              </div>
              <Button>
                <Zap className="w-4 h-4 mr-2" />
                Force Sync All
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}