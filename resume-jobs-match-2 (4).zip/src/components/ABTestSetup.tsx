import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { TestTube, Plus, Trash2 } from 'lucide-react';

interface ABTestVariant {
  id: string;
  name: string;
  subject: string;
  trafficPercentage: number;
  isControl: boolean;
}

export const ABTestSetup: React.FC = () => {
  const [testEnabled, setTestEnabled] = useState(false);
  const [testType, setTestType] = useState('subject');
  const [testDuration, setTestDuration] = useState('24');
  const [winnerCriteria, setWinnerCriteria] = useState('open_rate');
  const [variants, setVariants] = useState<ABTestVariant[]>([
    {
      id: '1',
      name: 'Control',
      subject: 'Your original subject line',
      trafficPercentage: 50,
      isControl: true
    },
    {
      id: '2',
      name: 'Variant A',
      subject: 'Alternative subject line',
      trafficPercentage: 50,
      isControl: false
    }
  ]);

  const addVariant = () => {
    const newVariant: ABTestVariant = {
      id: Date.now().toString(),
      name: `Variant ${String.fromCharCode(65 + variants.length - 1)}`,
      subject: '',
      trafficPercentage: 0,
      isControl: false
    };
    setVariants([...variants, newVariant]);
    redistributeTraffic([...variants, newVariant]);
  };

  const removeVariant = (id: string) => {
    const updatedVariants = variants.filter(v => v.id !== id);
    setVariants(updatedVariants);
    redistributeTraffic(updatedVariants);
  };

  const redistributeTraffic = (variantList: ABTestVariant[]) => {
    const equalPercentage = Math.floor(100 / variantList.length);
    const remainder = 100 % variantList.length;
    
    const updatedVariants = variantList.map((variant, index) => ({
      ...variant,
      trafficPercentage: equalPercentage + (index < remainder ? 1 : 0)
    }));
    
    setVariants(updatedVariants);
  };

  const updateVariant = (id: string, field: keyof ABTestVariant, value: any) => {
    setVariants(variants.map(v => 
      v.id === id ? { ...v, [field]: value } : v
    ));
  };

  const totalPercentage = variants.reduce((sum, v) => sum + v.trafficPercentage, 0);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <TestTube className="h-5 w-5" />
              A/B Test Configuration
            </CardTitle>
            <div className="flex items-center gap-2">
              <Label htmlFor="test-enabled">Enable A/B Testing</Label>
              <Switch
                id="test-enabled"
                checked={testEnabled}
                onCheckedChange={setTestEnabled}
              />
            </div>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          {testEnabled && (
            <>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Test Type</Label>
                  <Select value={testType} onValueChange={setTestType}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="subject">Subject Line</SelectItem>
                      <SelectItem value="content">Email Content</SelectItem>
                      <SelectItem value="sender">Sender Name</SelectItem>
                      <SelectItem value="send_time">Send Time</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <Label>Test Duration (hours)</Label>
                  <Input
                    type="number"
                    value={testDuration}
                    onChange={(e) => setTestDuration(e.target.value)}
                    min="1"
                    max="168"
                  />
                </div>
              </div>

              <div>
                <Label>Winner Selection Criteria</Label>
                <Select value={winnerCriteria} onValueChange={setWinnerCriteria}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="open_rate">Open Rate</SelectItem>
                    <SelectItem value="click_rate">Click Rate</SelectItem>
                    <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
                    <SelectItem value="revenue">Revenue</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <div className="flex items-center justify-between mb-4">
                  <Label className="text-lg">Test Variants</Label>
                  <Button onClick={addVariant} size="sm">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Variant
                  </Button>
                </div>

                <div className="space-y-4">
                  {variants.map((variant) => (
                    <Card key={variant.id} className="p-4">
                      <div className="flex items-center justify-between mb-4">
                        <div className="flex items-center gap-2">
                          <Input
                            value={variant.name}
                            onChange={(e) => updateVariant(variant.id, 'name', e.target.value)}
                            className="w-32"
                          />
                          {variant.isControl && (
                            <Badge variant="secondary">Control</Badge>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <Input
                            type="number"
                            value={variant.trafficPercentage}
                            onChange={(e) => updateVariant(variant.id, 'trafficPercentage', parseInt(e.target.value))}
                            className="w-20"
                            min="0"
                            max="100"
                          />
                          <span className="text-sm text-muted-foreground">%</span>
                          {!variant.isControl && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => removeVariant(variant.id)}
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          )}
                        </div>
                      </div>

                      {testType === 'subject' && (
                        <div>
                          <Label>Subject Line</Label>
                          <Input
                            value={variant.subject}
                            onChange={(e) => updateVariant(variant.id, 'subject', e.target.value)}
                            placeholder="Enter subject line for this variant"
                          />
                        </div>
                      )}
                    </Card>
                  ))}
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <span className="text-sm font-medium">Total Traffic Allocation:</span>
                  <Badge variant={totalPercentage === 100 ? 'default' : 'destructive'}>
                    {totalPercentage}%
                  </Badge>
                </div>
              </div>
            </>
          )}
        </CardContent>
      </Card>
    </div>
  );
};