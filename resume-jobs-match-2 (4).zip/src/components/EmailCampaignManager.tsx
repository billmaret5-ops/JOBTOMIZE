import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { useEmailNotifications } from '../hooks/useEmailNotifications';
import { Calendar, Send, Users, TrendingUp, Plus, Clock, Mail } from 'lucide-react';

interface EmailCampaign {
  id: string;
  name: string;
  type: 'follow_up' | 'thank_you' | 'networking' | 'status_inquiry';
  subject: string;
  content: string;
  scheduled_for: string;
  status: 'draft' | 'scheduled' | 'sent' | 'sending';
  recipient_count: number;
  created_at: string;
  sent_at?: string;
  open_rate?: number;
  click_rate?: number;
}

interface EmailRecipient {
  email: string;
  name: string;
  company?: string;
  jobTitle?: string;
  personalizationData: Record<string, string>;
}

export const EmailCampaignManager: React.FC = () => {
  const { scheduleNotification } = useEmailNotifications();
  const [campaigns, setCampaigns] = useState<EmailCampaign[]>([
    {
      id: '1',
      name: 'Weekly Follow-ups',
      type: 'follow_up',
      subject: 'Following up on my application',
      content: 'Dear {{recipientName}}, I wanted to follow up...',
      scheduled_for: '',
      status: 'draft',
      recipient_count: 0,
      created_at: new Date().toISOString(),
      open_rate: 0,
      click_rate: 0
    }
  ]);
  
  const [newCampaign, setNewCampaign] = useState({
    name: '',
    type: 'follow_up' as const,
    subject: '',
    content: '',
    scheduled_for: ''
  });

  const [recipients, setRecipients] = useState<EmailRecipient[]>([]);
  const [newRecipient, setNewRecipient] = useState({
    email: '',
    name: '',
    company: '',
    jobTitle: ''
  });

  const addRecipient = () => {
    if (newRecipient.email && newRecipient.name) {
      setRecipients(prev => [...prev, {
        ...newRecipient,
        personalizationData: {
          recipientName: newRecipient.name,
          companyName: newRecipient.company || '',
          jobTitle: newRecipient.jobTitle || ''
        }
      }]);
      setNewRecipient({ email: '', name: '', company: '', jobTitle: '' });
    }
  };
  const handleCreateCampaign = async () => {
    if (!newCampaign.name || !newCampaign.subject || !newCampaign.content) {
      return;
    }

    const success = await scheduleNotification(
      newCampaign.type,
      newCampaign.subject,
      newCampaign.content,
      newCampaign.scheduled_for ? new Date(newCampaign.scheduled_for) : undefined
    );

    if (success) {
      setNewCampaign({
        name: '',
        type: 'follow_up',
        subject: '',
        content: '',
        scheduled_for: ''
      });
    }
  };
  const campaignStats = {
    total: campaigns.length,
    scheduled: campaigns.filter(c => c.status === 'scheduled').length,
    sent: campaigns.filter(c => c.status === 'sent').length,
    totalRecipients: campaigns.reduce((sum, c) => sum + c.recipient_count, 0)
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Send className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{campaignStats.total}</p>
                <p className="text-sm text-gray-600">Total Campaigns</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">{campaignStats.scheduled}</p>
                <p className="text-sm text-gray-600">Scheduled</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{campaignStats.sent}</p>
                <p className="text-sm text-gray-600">Sent</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center gap-2">
              <Users className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{campaignStats.totalRecipients}</p>
                <p className="text-sm text-gray-600">Total Reach</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Create New Campaign</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="campaign-name">Campaign Name</Label>
              <Input
                id="campaign-name"
                value={newCampaign.name}
                onChange={(e) => setNewCampaign(prev => ({ ...prev, name: e.target.value }))}
                placeholder="Weekly Job Matches"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="campaign-type">Campaign Type</Label>
              <Select
                value={newCampaign.type}
                onValueChange={(value: any) => setNewCampaign(prev => ({ ...prev, type: value }))}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="job_match">Job Match Alerts</SelectItem>
                  <SelectItem value="deadline_reminder">Deadline Reminders</SelectItem>
                  <SelectItem value="export_complete">Export Notifications</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="campaign-subject">Subject Line</Label>
              <Input
                id="campaign-subject"
                value={newCampaign.subject}
                onChange={(e) => setNewCampaign(prev => ({ ...prev, subject: e.target.value }))}
                placeholder="Your weekly job matches are here!"
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="campaign-content">Email Content</Label>
              <Textarea
                id="campaign-content"
                value={newCampaign.content}
                onChange={(e) => setNewCampaign(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Write your email content here..."
                rows={4}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="scheduled-for">Schedule For (Optional)</Label>
              <Input
                id="scheduled-for"
                type="datetime-local"
                value={newCampaign.scheduled_for}
                onChange={(e) => setNewCampaign(prev => ({ ...prev, scheduled_for: e.target.value }))}
              />
            </div>

            <Button onClick={handleCreateCampaign} className="w-full">
              Create Campaign
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Recent Campaigns</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {campaigns.length === 0 ? (
                <p className="text-center text-gray-500 py-8">No campaigns created yet</p>
              ) : (
                campaigns.slice(0, 5).map((campaign) => (
                  <div key={campaign.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <p className="font-medium text-sm">{campaign.name}</p>
                      <p className="text-xs text-gray-500">{campaign.subject}</p>
                      <p className="text-xs text-gray-400">{new Date(campaign.created_at).toLocaleDateString()}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant={campaign.status === 'sent' ? 'default' : campaign.status === 'scheduled' ? 'secondary' : 'outline'}>
                        {campaign.status}
                      </Badge>
                      <p className="text-xs text-gray-500 mt-1">{campaign.recipient_count} recipients</p>
                    </div>
                  </div>
                ))
              )}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};