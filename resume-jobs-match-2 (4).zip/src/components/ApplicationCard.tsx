import React from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { 
  MapPin, 
  DollarSign, 
  Calendar, 
  ExternalLink, 
  Edit, 
  Trash2, 
  Bell,
  FileText,
  Clock
} from 'lucide-react';

interface Application {
  id: string;
  job_title: string;
  company_name: string;
  location?: string;
  salary_range?: string;
  status: string;
  applied_date?: string;
  follow_up_date?: string;
  interview_date?: string;
  job_url?: string;
  notes?: string;
  cover_letter_url?: string;
  created_at: string;
}

interface ApplicationCardProps {
  application: Application;
  onStatusUpdate: (id: string, status: string) => void;
  onEdit: (application: Application) => void;
  onDelete: (id: string) => void;
}

const statusColors = {
  saved: 'bg-gray-100 text-gray-800',
  applied: 'bg-blue-100 text-blue-800',
  interviewing: 'bg-yellow-100 text-yellow-800',
  rejected: 'bg-red-100 text-red-800',
  offer: 'bg-green-100 text-green-800',
  accepted: 'bg-purple-100 text-purple-800'
};

export default function ApplicationCard({ 
  application, 
  onStatusUpdate, 
  onEdit, 
  onDelete 
}: ApplicationCardProps) {
  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    return new Date(dateString).toLocaleDateString();
  };

  const isFollowUpOverdue = application.follow_up_date && 
    new Date(application.follow_up_date) < new Date();

  return (
    <Card className="hover:shadow-md transition-shadow">
      <CardContent className="pt-6">
        <div className="flex justify-between items-start mb-4">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h3 className="font-semibold text-lg">{application.job_title}</h3>
              <Badge className={statusColors[application.status as keyof typeof statusColors]}>
                {application.status.charAt(0).toUpperCase() + application.status.slice(1)}
              </Badge>
            </div>
            <p className="text-gray-600 font-medium">{application.company_name}</p>
            
            <div className="flex flex-wrap gap-4 mt-3 text-sm text-gray-500">
              {application.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="w-4 h-4" />
                  {application.location}
                </div>
              )}
              {application.salary_range && (
                <div className="flex items-center gap-1">
                  <DollarSign className="w-4 h-4" />
                  {application.salary_range}
                </div>
              )}
              {application.applied_date && (
                <div className="flex items-center gap-1">
                  <Calendar className="w-4 h-4" />
                  Applied: {formatDate(application.applied_date)}
                </div>
              )}
            </div>

            {application.interview_date && (
              <div className="flex items-center gap-1 mt-2 text-sm text-blue-600">
                <Calendar className="w-4 h-4" />
                Interview: {formatDate(application.interview_date)}
              </div>
            )}

            {application.follow_up_date && (
              <div className={`flex items-center gap-1 mt-2 text-sm ${
                isFollowUpOverdue ? 'text-red-600' : 'text-orange-600'
              }`}>
                <Clock className="w-4 h-4" />
                Follow-up: {formatDate(application.follow_up_date)}
                {isFollowUpOverdue && <Bell className="w-4 h-4 ml-1" />}
              </div>
            )}

            {application.cover_letter_url && (
              <div className="flex items-center gap-1 mt-2 text-sm text-green-600">
                <FileText className="w-4 h-4" />
                Cover letter attached
              </div>
            )}
          </div>

          <div className="flex gap-2 ml-4">
            <select
              value={application.status}
              onChange={(e) => onStatusUpdate(application.id, e.target.value)}
              className="text-sm border rounded px-2 py-1 bg-white"
            >
              <option value="saved">Saved</option>
              <option value="applied">Applied</option>
              <option value="interviewing">Interviewing</option>
              <option value="rejected">Rejected</option>
              <option value="offer">Offer</option>
              <option value="accepted">Accepted</option>
            </select>
          </div>
        </div>

        {application.notes && (
          <div className="mb-4 p-3 bg-gray-50 rounded-lg">
            <p className="text-sm text-gray-700">{application.notes}</p>
          </div>
        )}

        <div className="flex justify-between items-center">
          <div className="flex gap-2">
            {application.job_url && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => window.open(application.job_url, '_blank')}
              >
                <ExternalLink className="w-4 h-4 mr-1" />
                View Job
              </Button>
            )}
          </div>
          
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onEdit(application)}
            >
              <Edit className="w-4 h-4" />
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => onDelete(application.id)}
              className="text-red-600 hover:text-red-700"
            >
              <Trash2 className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}