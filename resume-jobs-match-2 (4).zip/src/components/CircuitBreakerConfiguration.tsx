import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Settings, Save, Plus } from 'lucide-react';
import { circuitBreakerService, EndpointType } from '@/services/circuitBreakerService';
import { useToast } from '@/hooks/use-toast';

export const CircuitBreakerConfiguration: React.FC = () => {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    endpoint_url: '',
    endpoint_type: 'webhook' as EndpointType,
    failure_threshold: 5,
    success_threshold: 2,
    timeout_duration: '60 seconds',
    half_open_max_calls: 3,
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await circuitBreakerService.getOrCreateCircuitBreaker(
        formData.endpoint_url,
        formData.endpoint_type,
        {
          failure_threshold: formData.failure_threshold,
          success_threshold: formData.success_threshold,
          timeout_duration: formData.timeout_duration,
          half_open_max_calls: formData.half_open_max_calls,
        }
      );
      toast({
        title: 'Circuit Breaker Created',
        description: 'Circuit breaker configuration saved successfully',
      });
      setFormData({
        endpoint_url: '',
        endpoint_type: 'webhook',
        failure_threshold: 5,
        success_threshold: 2,
        timeout_duration: '60 seconds',
        half_open_max_calls: 3,
      });
    } catch (error) {
      toast({
        title: 'Error',
        description: 'Failed to create circuit breaker',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Settings className="h-5 w-5" />
          Circuit Breaker Configuration
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="endpoint_url">Endpoint URL</Label>
            <Input
              id="endpoint_url"
              value={formData.endpoint_url}
              onChange={(e) => setFormData({ ...formData, endpoint_url: e.target.value })}
              placeholder="https://hooks.slack.com/services/..."
              required
            />
          </div>

          <div>
            <Label htmlFor="endpoint_type">Endpoint Type</Label>
            <Select
              value={formData.endpoint_type}
              onValueChange={(value) => setFormData({ ...formData, endpoint_type: value as EndpointType })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="slack">Slack</SelectItem>
                <SelectItem value="pagerduty">PagerDuty</SelectItem>
                <SelectItem value="webhook">Generic Webhook</SelectItem>
                <SelectItem value="email">Email</SelectItem>
                <SelectItem value="sms">SMS</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="failure_threshold">Failure Threshold</Label>
              <Input
                id="failure_threshold"
                type="number"
                value={formData.failure_threshold}
                onChange={(e) => setFormData({ ...formData, failure_threshold: parseInt(e.target.value) })}
                min={1}
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Consecutive failures before opening circuit
              </p>
            </div>

            <div>
              <Label htmlFor="success_threshold">Success Threshold</Label>
              <Input
                id="success_threshold"
                type="number"
                value={formData.success_threshold}
                onChange={(e) => setFormData({ ...formData, success_threshold: parseInt(e.target.value) })}
                min={1}
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Successes needed to close circuit
              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="timeout_duration">Timeout Duration</Label>
              <Select
                value={formData.timeout_duration}
                onValueChange={(value) => setFormData({ ...formData, timeout_duration: value })}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="30 seconds">30 seconds</SelectItem>
                  <SelectItem value="60 seconds">1 minute</SelectItem>
                  <SelectItem value="120 seconds">2 minutes</SelectItem>
                  <SelectItem value="300 seconds">5 minutes</SelectItem>
                  <SelectItem value="600 seconds">10 minutes</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground mt-1">
                Wait time before recovery attempt
              </p>
            </div>

            <div>
              <Label htmlFor="half_open_max_calls">Half-Open Max Calls</Label>
              <Input
                id="half_open_max_calls"
                type="number"
                value={formData.half_open_max_calls}
                onChange={(e) => setFormData({ ...formData, half_open_max_calls: parseInt(e.target.value) })}
                min={1}
                required
              />
              <p className="text-xs text-muted-foreground mt-1">
                Test requests in half-open state
              </p>
            </div>
          </div>

          <Button type="submit" className="w-full">
            <Plus className="h-4 w-4 mr-2" />
            Create Circuit Breaker
          </Button>
        </form>

        <div className="mt-6 p-4 bg-blue-50 rounded-lg">
          <h4 className="font-semibold mb-2">Circuit Breaker States</h4>
          <ul className="space-y-2 text-sm">
            <li>
              <strong>Closed:</strong> Normal operation, all requests pass through
            </li>
            <li>
              <strong>Open:</strong> Circuit tripped, requests blocked to prevent cascading failures
            </li>
            <li>
              <strong>Half-Open:</strong> Testing recovery, limited requests allowed
            </li>
          </ul>
        </div>
      </CardContent>
    </Card>
  );
};
