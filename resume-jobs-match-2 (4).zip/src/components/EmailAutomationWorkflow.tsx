import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Play, Pause, Settings, Mail, Clock, Users, TrendingUp } from 'lucide-react';

interface WorkflowStep {
  id: string;
  type: 'trigger' | 'condition' | 'action' | 'delay';
  name: string;
  config: any;
  position: { x: number; y: number };
}

interface EmailWorkflow {
  id: string;
  name: string;
  status: 'active' | 'paused' | 'draft';
  steps: WorkflowStep[];
  stats: {
    triggered: number;
    completed: number;
    responseRate: number;
  };
}

export default function EmailAutomationWorkflow() {
  const [workflows, setWorkflows] = useState<EmailWorkflow[]>([
    {
      id: '1',
      name: 'Job Application Follow-up',
      status: 'active',
      steps: [
        { id: 't1', type: 'trigger', name: 'Email Sent', config: {}, position: { x: 0, y: 0 } },
        { id: 'c1', type: 'condition', name: 'No Response 3 Days', config: { delay: 3 }, position: { x: 1, y: 0 } },
        { id: 'a1', type: 'action', name: 'Send Follow-up', config: { template: 'polite-followup' }, position: { x: 2, y: 0 } }
      ],
      stats: { triggered: 45, completed: 38, responseRate: 24.5 }
    },
    {
      id: '2',
      name: 'Interview Request Sequence',
      status: 'active',
      steps: [
        { id: 't2', type: 'trigger', name: 'Application Viewed', config: {}, position: { x: 0, y: 0 } },
        { id: 'd1', type: 'delay', name: 'Wait 1 Day', config: { hours: 24 }, position: { x: 1, y: 0 } },
        { id: 'a2', type: 'action', name: 'Send Interview Request', config: { template: 'interview-request' }, position: { x: 2, y: 0 } }
      ],
      stats: { triggered: 23, completed: 19, responseRate: 31.2 }
    }
  ]);

  const [selectedWorkflow, setSelectedWorkflow] = useState<string | null>(null);
  const [newWorkflowName, setNewWorkflowName] = useState('');

  const triggerTypes = [
    { value: 'email_sent', label: 'Email Sent', icon: Mail },
    { value: 'email_opened', label: 'Email Opened', icon: Mail },
    { value: 'link_clicked', label: 'Link Clicked', icon: TrendingUp },
    { value: 'no_response', label: 'No Response', icon: Clock },
    { value: 'application_viewed', label: 'Application Viewed', icon: Users }
  ];

  const actionTypes = [
    { value: 'send_email', label: 'Send Email', icon: Mail },
    { value: 'create_task', label: 'Create Task', icon: Settings },
    { value: 'update_status', label: 'Update Status', icon: TrendingUp },
    { value: 'send_notification', label: 'Send Notification', icon: Users }
  ];

  const toggleWorkflowStatus = (workflowId: string) => {
    setWorkflows(prev => prev.map(workflow => 
      workflow.id === workflowId 
        ? { ...workflow, status: workflow.status === 'active' ? 'paused' : 'active' }
        : workflow
    ));
  };

  const createNewWorkflow = () => {
    if (!newWorkflowName.trim()) return;
    
    const newWorkflow: EmailWorkflow = {
      id: Date.now().toString(),
      name: newWorkflowName,
      status: 'draft',
      steps: [],
      stats: { triggered: 0, completed: 0, responseRate: 0 }
    };
    
    setWorkflows(prev => [...prev, newWorkflow]);
    setNewWorkflowName('');
    setSelectedWorkflow(newWorkflow.id);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Email Automation Workflows</h2>
        <div className="flex gap-2">
          <Input
            placeholder="New workflow name..."
            value={newWorkflowName}
            onChange={(e) => setNewWorkflowName(e.target.value)}
            className="w-64"
          />
          <Button onClick={createNewWorkflow}>Create Workflow</Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {workflows.map((workflow) => (
          <Card key={workflow.id} className="cursor-pointer hover:shadow-md transition-shadow"
                onClick={() => setSelectedWorkflow(workflow.id)}>
            <CardHeader className="pb-3">
              <div className="flex justify-between items-start">
                <CardTitle className="text-lg">{workflow.name}</CardTitle>
                <Badge variant={workflow.status === 'active' ? 'default' : 'secondary'}>
                  {workflow.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                <div className="flex justify-between text-sm">
                  <span>Triggered:</span>
                  <span className="font-medium">{workflow.stats.triggered}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Completed:</span>
                  <span className="font-medium">{workflow.stats.completed}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Response Rate:</span>
                  <span className="font-medium text-green-600">{workflow.stats.responseRate}%</span>
                </div>
                <div className="flex gap-2 pt-2">
                  <Button
                    size="sm"
                    variant={workflow.status === 'active' ? 'destructive' : 'default'}
                    onClick={(e) => {
                      e.stopPropagation();
                      toggleWorkflowStatus(workflow.id);
                    }}
                  >
                    {workflow.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button size="sm" variant="outline">
                    <Settings className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {selectedWorkflow && (
        <Card>
          <CardHeader>
            <CardTitle>Workflow Builder</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <h4 className="font-medium mb-3">Triggers</h4>
                <div className="space-y-2">
                  {triggerTypes.map((trigger) => (
                    <div key={trigger.value} className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="flex items-center gap-2">
                        <trigger.icon className="w-4 h-4" />
                        <span className="text-sm">{trigger.label}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Conditions</h4>
                <div className="space-y-2">
                  <div className="p-3 border rounded-lg">
                    <div className="text-sm font-medium">Time Delay</div>
                    <div className="text-xs text-gray-600">Wait specific time</div>
                  </div>
                  <div className="p-3 border rounded-lg">
                    <div className="text-sm font-medium">Engagement Check</div>
                    <div className="text-xs text-gray-600">Check interaction</div>
                  </div>
                </div>
              </div>
              
              <div>
                <h4 className="font-medium mb-3">Actions</h4>
                <div className="space-y-2">
                  {actionTypes.map((action) => (
                    <div key={action.value} className="p-3 border rounded-lg cursor-pointer hover:bg-gray-50">
                      <div className="flex items-center gap-2">
                        <action.icon className="w-4 h-4" />
                        <span className="text-sm">{action.label}</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}