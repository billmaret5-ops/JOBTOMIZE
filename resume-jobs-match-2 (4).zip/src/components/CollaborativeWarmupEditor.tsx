import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Slider } from './ui/slider';
import { Users, MessageSquare, History, Save, Video, VideoOff, FileText, Mic, Brain, TrendingUp, Zap } from 'lucide-react';
import { warmupCollaborationService, CollaborationUser } from '../services/warmupCollaborationService';
import { LiveCursorOverlay } from './LiveCursorOverlay';
import { UserPresenceIndicator } from './UserPresenceIndicator';
import { CollaborativeComments } from './CollaborativeComments';
import { CollaborativeChangeTracker } from './CollaborativeChangeTracker';
import { CollaborativeChatSidebar } from './CollaborativeChatSidebar';
import { WarmupVideoConferencePanel } from './WarmupVideoConferencePanel';
import { LiveTranscriptPanel } from './LiveTranscriptPanel';
import { MeetingSummaryViewer } from './MeetingSummaryViewer';
import AIWarmupOptimizer from './AIWarmupOptimizer';
import WarmupPerformanceAnalyzer from './WarmupPerformanceAnalyzer';
import WarmupABTestSuggestions from './WarmupABTestSuggestions';
import SmartVolumeRampingVisualizer from './SmartVolumeRampingVisualizer';
import { AIRecommendationNotificationCenter } from './AIRecommendationNotificationCenter';


interface WarmupSchedule {
  day: number;
  volume: number;
}

export const CollaborativeWarmupEditor: React.FC = () => {
  const [templateId] = useState('template-1');
  const [templateName, setTemplateName] = useState('E-commerce Warmup Schedule');
  const [schedule, setSchedule] = useState<WarmupSchedule[]>(
    Array.from({ length: 14 }, (_, i) => ({ day: i + 1, volume: Math.min(10 + i * 5, 100) }))
  );
  const [participants, setParticipants] = useState<CollaborationUser[]>([]);
  const [showComments, setShowComments] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [showChat, setShowChat] = useState(true);
  const [showVideo, setShowVideo] = useState(false);
  const [showTranscript, setShowTranscript] = useState(false);
  const [showSummary, setShowSummary] = useState(false);
  const [showAIOptimizer, setShowAIOptimizer] = useState(false);
  const [currentUser] = useState({ id: 'user-1', name: 'John Doe', avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=John' });
  const [recommendedSchedule, setRecommendedSchedule] = useState<WarmupSchedule[]>(
    Array.from({ length: 14 }, (_, i) => ({ day: i + 1, volume: Math.min(15 + i * 6, 120) }))
  );




  useEffect(() => {
    initializeSession();
  }, []);

  const initializeSession = async () => {
    try {
      await warmupCollaborationService.startSession(templateId, currentUser.id);
      setParticipants(warmupCollaborationService.getParticipants());
    } catch (error) {
      console.error('Failed to start collaboration session:', error);
    }
  };

  const handleVolumeChange = async (day: number, newVolume: number) => {
    const oldValue = schedule.find(s => s.day === day)?.volume;
    setSchedule(prev => prev.map(s => s.day === day ? { ...s, volume: newVolume } : s));
    
    await warmupCollaborationService.trackChange({
      userId: currentUser.id,
      userName: currentUser.name,
      changeType: 'volume',
      section: `Day ${day}`,
      oldValue,
      newValue: newVolume
    });
  };

  const handleApplyRecommendation = (recommendation: any) => {
    if (recommendation.suggestedChanges?.dailyVolume) {
      const newSchedule = schedule.map(s => ({
        ...s,
        volume: Math.min(s.volume * (recommendation.suggestedChanges.dailyVolume / 100), 150)
      }));
      setSchedule(newSchedule);
    }
  };

  const handleStartABTest = (suggestion: any) => {
    console.log('Starting A/B test:', suggestion);
  };

  const handleSave = () => {
    console.log('Saving template:', { templateName, schedule });
  };


  return (
    <div className="flex h-screen bg-gray-50">
      {showTranscript && (
        <div className="w-96 border-r border-gray-200">
          <LiveTranscriptPanel
            sessionId={templateId}
            userId={currentUser.id}
            userName={currentUser.name}
            isExpanded={showTranscript}
          />
        </div>
      )}
      

      <div className="flex-1 p-6 overflow-auto">
        <Card className="p-6">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4 flex-1">
              <Input
                value={templateName}
                onChange={(e) => setTemplateName(e.target.value)}
                className="text-2xl font-bold border-none shadow-none p-0 h-auto"
              />
              <UserPresenceIndicator participants={participants} />
            </div>
            <div className="flex items-center gap-2">
              <AIRecommendationNotificationCenter 
                onNotificationClick={(notification) => {
                  if (notification.type === 'new_recommendation' || notification.type === 'vote_update') {
                    setShowAIOptimizer(true);
                  }
                }}
              />
              <Button 
                variant={showAIOptimizer ? 'default' : 'outline'} 
                onClick={() => setShowAIOptimizer(!showAIOptimizer)}
                className="bg-purple-600 hover:bg-purple-700"
              >
                <Brain className="w-4 h-4 mr-2" />
                AI Optimizer
              </Button>
              <Button 
                variant={showVideo ? 'default' : 'outline'} 
                onClick={() => setShowVideo(!showVideo)}
              >
                {showVideo ? <VideoOff className="w-4 h-4 mr-2" /> : <Video className="w-4 h-4 mr-2" />}
                Video
              </Button>
              <Button 
                variant={showTranscript ? 'default' : 'outline'} 
                onClick={() => setShowTranscript(!showTranscript)}
              >
                <Mic className="w-4 h-4 mr-2" />
                Transcript
              </Button>
              <Button 
                variant="outline" 
                onClick={() => setShowSummary(!showSummary)}
              >
                <FileText className="w-4 h-4 mr-2" />
                Summary
              </Button>
              <Button variant="outline" onClick={() => setShowComments(!showComments)}>
                <MessageSquare className="w-4 h-4 mr-2" />
                Comments
              </Button>
              <Button variant="outline" onClick={() => setShowHistory(!showHistory)}>
                <History className="w-4 h-4 mr-2" />
                History
              </Button>
              <Button onClick={handleSave}>
                <Save className="w-4 h-4 mr-2" />
                Save
              </Button>
            </div>




          </div>

          <LiveCursorOverlay participants={participants} />

          {showVideo && (
            <div className="mb-6">
              <WarmupVideoConferencePanel
                sessionId={templateId}
                userId={currentUser.id}
                userName={currentUser.name}
                userAvatar={currentUser.avatar}
                onClose={() => setShowVideo(false)}
              />
            </div>
          )}


          <div className="space-y-4">
            <h3 className="text-lg font-semibold">Volume Schedule</h3>
            {schedule.map((item) => (
              <div key={item.day} className="flex items-center gap-4">
                <span className="w-20 text-sm font-medium">Day {item.day}</span>
                <Slider
                  value={[item.volume]}
                  onValueChange={([value]) => handleVolumeChange(item.day, value)}
                  max={100}
                  step={5}
                  className="flex-1"
                />
                <span className="w-16 text-sm text-right">{item.volume} emails</span>
              </div>
            ))}
          </div>
        </Card>

        {showAIOptimizer && (
          <div className="mt-6 grid grid-cols-2 gap-6">
            <div className="space-y-6">
              <AIWarmupOptimizer 
                templateId={templateId}
                currentUserId={currentUser.id}
                onApplyRecommendation={handleApplyRecommendation}
              />

              <WarmupABTestSuggestions 
                templateId={templateId}
                onStartTest={handleStartABTest}
              />
            </div>
            <div className="space-y-6">
              <SmartVolumeRampingVisualizer
                currentSchedule={schedule}
                recommendedSchedule={recommendedSchedule}
                confidence={0.87}
              />
              <WarmupPerformanceAnalyzer templateId={templateId} />
            </div>
          </div>
        )}

        {showComments && <CollaborativeComments templateId={templateId} currentUser={currentUser} />}
        {showHistory && <CollaborativeChangeTracker templateId={templateId} />}
        
        {showSummary && (
          <div className="mt-6">
            <MeetingSummaryViewer
              sessionId={templateId}
              onClose={() => setShowSummary(false)}
            />
          </div>
        )}
      </div>

      {showChat && (
        <CollaborativeChatSidebar
          currentUser={currentUser}
          onClose={() => setShowChat(false)}
          videoCallActive={showVideo}
          onVideoToggle={() => setShowVideo(!showVideo)}
        />
      )}
    </div>
  );
};
