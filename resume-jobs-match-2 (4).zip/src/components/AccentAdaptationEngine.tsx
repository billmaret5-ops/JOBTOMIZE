import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Settings, Mic, Brain, TrendingUp, Save } from 'lucide-react';

const AccentAdaptationEngine = () => {
  const [selectedAccent, setSelectedAccent] = useState('american');
  const [adaptationSettings, setAdaptationSettings] = useState({
    phonemeWeighting: [80],
    stressPatternSensitivity: [70],
    intonationAdaptation: [60],
    vowelShiftTolerance: [75],
    consonantVariationTolerance: [65]
  });
  const [realTimeAdaptation, setRealTimeAdaptation] = useState(true);
  const [adaptationProgress, setAdaptationProgress] = useState(85);

  const accentProfiles = [
    { name: 'American', accuracy: 94, samples: 1250, confidence: 0.92 },
    { name: 'British', accuracy: 89, samples: 890, confidence: 0.87 },
    { name: 'Australian', accuracy: 86, samples: 650, confidence: 0.84 },
    { name: 'Canadian', accuracy: 91, samples: 720, confidence: 0.89 },
    { name: 'Indian', accuracy: 82, samples: 540, confidence: 0.79 },
    { name: 'South African', accuracy: 78, samples: 320, confidence: 0.76 }
  ];

  const phonemeAdaptations = [
    { phoneme: '/æ/', variations: ['[æ]', '[ɛ]', '[a]'], weight: 85 },
    { phoneme: '/ɑ/', variations: ['[ɑ]', '[ɒ]', '[a]'], weight: 78 },
    { phoneme: '/r/', variations: ['[ɹ]', '[r]', '[ɾ]'], weight: 92 },
    { phoneme: '/t/', variations: ['[t]', '[ɾ]', '[ʔ]'], weight: 88 }
  ];

  const handleSaveAdaptation = () => {
    console.log('Saving adaptation settings:', {
      accent: selectedAccent,
      settings: adaptationSettings,
      realTime: realTimeAdaptation
    });
    // Implement save functionality
  };

  const handleTrainModel = () => {
    console.log('Training model for accent:', selectedAccent);
    // Implement model training
  };

  const handleTestAdaptation = () => {
    console.log('Testing adaptation for:', selectedAccent);
    // Implement adaptation testing
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Accent Adaptation Engine</h1>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleTestAdaptation}>
            <Mic className="w-4 h-4 mr-2" />
            Test Adaptation
          </Button>
          <Button onClick={handleSaveAdaptation}>
            <Save className="w-4 h-4 mr-2" />
            Save Settings
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Accent Selection & Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label className="block text-sm font-medium mb-2">Target Accent</label>
                <Select value={selectedAccent} onValueChange={setSelectedAccent}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {accentProfiles.map((profile) => (
                      <SelectItem key={profile.name.toLowerCase()} value={profile.name.toLowerCase()}>
                        {profile.name} ({profile.accuracy}% accuracy)
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <label className="text-sm font-medium">Real-time Adaptation</label>
                <Switch 
                  checked={realTimeAdaptation} 
                  onCheckedChange={setRealTimeAdaptation}
                />
              </div>

              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium mb-2">
                    Phoneme Weighting: {adaptationSettings.phonemeWeighting[0]}%
                  </label>
                  <Slider
                    value={adaptationSettings.phonemeWeighting}
                    onValueChange={(value) => setAdaptationSettings(prev => ({
                      ...prev,
                      phonemeWeighting: value
                    }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Stress Pattern Sensitivity: {adaptationSettings.stressPatternSensitivity[0]}%
                  </label>
                  <Slider
                    value={adaptationSettings.stressPatternSensitivity}
                    onValueChange={(value) => setAdaptationSettings(prev => ({
                      ...prev,
                      stressPatternSensitivity: value
                    }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Intonation Adaptation: {adaptationSettings.intonationAdaptation[0]}%
                  </label>
                  <Slider
                    value={adaptationSettings.intonationAdaptation}
                    onValueChange={(value) => setAdaptationSettings(prev => ({
                      ...prev,
                      intonationAdaptation: value
                    }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Vowel Shift Tolerance: {adaptationSettings.vowelShiftTolerance[0]}%
                  </label>
                  <Slider
                    value={adaptationSettings.vowelShiftTolerance}
                    onValueChange={(value) => setAdaptationSettings(prev => ({
                      ...prev,
                      vowelShiftTolerance: value
                    }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium mb-2">
                    Consonant Variation Tolerance: {adaptationSettings.consonantVariationTolerance[0]}%
                  </label>
                  <Slider
                    value={adaptationSettings.consonantVariationTolerance}
                    onValueChange={(value) => setAdaptationSettings(prev => ({
                      ...prev,
                      consonantVariationTolerance: value
                    }))}
                    max={100}
                    step={1}
                    className="w-full"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Phoneme Adaptation Matrix</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {phonemeAdaptations.map((phoneme, index) => (
                  <div key={index} className="p-4 border rounded-lg">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="font-semibold text-lg">{phoneme.phoneme}</h3>
                      <Badge variant="secondary">{phoneme.weight}% weight</Badge>
                    </div>
                    <div>
                      <p className="text-sm text-gray-600 mb-2">Recognized variations:</p>
                      <div className="flex gap-2">
                        {phoneme.variations.map((variation, idx) => (
                          <Badge key={idx} variant="outline">{variation}</Badge>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Adaptation Progress</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center mb-4">
                <div className="text-3xl font-bold text-green-600">{adaptationProgress}%</div>
                <p className="text-sm text-gray-600">Model Adaptation Complete</p>
              </div>
              <Progress value={adaptationProgress} className="mb-4" />
              <Button 
                className="w-full" 
                onClick={handleTrainModel}
                disabled={adaptationProgress === 100}
              >
                <Brain className="w-4 h-4 mr-2" />
                {adaptationProgress === 100 ? 'Model Ready' : 'Train Model'}
              </Button>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Accent Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={accentProfiles}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="name" angle={-45} textAnchor="end" height={80} />
                  <YAxis domain={[70, 100]} />
                  <Tooltip />
                  <Bar dataKey="accuracy" fill="#8884d8" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Current Profile</CardTitle>
            </CardHeader>
            <CardContent>
              {accentProfiles
                .filter(profile => profile.name.toLowerCase() === selectedAccent)
                .map((profile, index) => (
                  <div key={index} className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Accuracy</span>
                      <span className="font-semibold">{profile.accuracy}%</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Samples</span>
                      <span className="font-semibold">{profile.samples}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-sm text-gray-600">Confidence</span>
                      <span className="font-semibold">{(profile.confidence * 100).toFixed(0)}%</span>
                    </div>
                  </div>
                ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
};

export default AccentAdaptationEngine;