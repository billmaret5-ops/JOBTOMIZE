import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from './ui/dialog';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { AlertTriangle } from 'lucide-react';
import { Conflict, ResolutionStrategy } from '../lib/conflictResolution';

interface ConflictResolutionModalProps {
  conflict: Conflict | null;
  isOpen: boolean;
  onClose: () => void;
  onResolve: (strategy: ResolutionStrategy) => void;
}

export const ConflictResolutionModal: React.FC<ConflictResolutionModalProps> = ({
  conflict,
  isOpen,
  onClose,
  onResolve
}) => {
  if (!conflict) return null;

  const getConflictTypeLabel = (type: Conflict['type']) => {
    switch (type) {
      case 'concurrent_edit': return 'Concurrent Edit';
      case 'deletion': return 'Deletion Conflict';
      case 'formatting': return 'Formatting Conflict';
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-yellow-500" />
            Resolve Conflict
          </DialogTitle>
          <DialogDescription>
            Multiple users edited the same content. Choose how to resolve this conflict.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Badge variant="secondary">{getConflictTypeLabel(conflict.type)}</Badge>

          <div className="grid grid-cols-2 gap-4">
            <div className="border rounded-lg p-4 space-y-2">
              <h3 className="font-semibold">Your Changes</h3>
              <div className="bg-muted p-3 rounded text-sm font-mono">
                {JSON.stringify(conflict.localChange, null, 2)}
              </div>
            </div>

            <div className="border rounded-lg p-4 space-y-2">
              <h3 className="font-semibold">Their Changes</h3>
              <div className="bg-muted p-3 rounded text-sm font-mono">
                {JSON.stringify(conflict.remoteChange, null, 2)}
              </div>
            </div>
          </div>
        </div>

        <DialogFooter className="flex gap-2">
          <Button variant="outline" onClick={() => onResolve('local')}>
            Keep Mine
          </Button>
          <Button variant="outline" onClick={() => onResolve('remote')}>
            Keep Theirs
          </Button>
          <Button onClick={() => onResolve('merge')}>
            Merge Both
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
