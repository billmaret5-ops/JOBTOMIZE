import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Checkbox } from '@/components/ui/checkbox';
import { Calendar } from '@/components/ui/calendar';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Download, CalendarIcon, Filter, Mail, FileText, Database, Brain, BarChart3 } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ExportJob {
  id: string;
  name: string;
  format: 'csv' | 'json' | 'pdf';
  dataType: 'streaming' | 'ml' | 'dashboard';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  progress: number;
  createdAt: Date;
  completedAt?: Date;
  downloadUrl?: string;
}

interface ExportFilter {
  dateRange: { start: Date; end: Date };
  dataTypes: string[];
  sources: string[];
  customFilters: Record<string, any>;
}

export default function DataExportManager() {
  const [exportJobs, setExportJobs] = useState<ExportJob[]>([]);
  const [selectedFormat, setSelectedFormat] = useState<'csv' | 'json' | 'pdf'>('csv');
  const [selectedDataType, setSelectedDataType] = useState<'streaming' | 'ml' | 'dashboard'>('streaming');
  const [exportName, setExportName] = useState('');
  const [filters, setFilters] = useState<ExportFilter>({
    dateRange: { start: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000), end: new Date() },
    dataTypes: [],
    sources: [],
    customFilters: {}
  });
  const [emailDelivery, setEmailDelivery] = useState(false);
  const [recipientEmail, setRecipientEmail] = useState('');
  const [isExporting, setIsExporting] = useState(false);

  useEffect(() => {
    loadExportJobs();
    const interval = setInterval(loadExportJobs, 5000);
    return () => clearInterval(interval);
  }, []);

  const loadExportJobs = async () => {
    try {
      const { data, error } = await supabase
        .from('export_jobs')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(20);

      if (error) throw error;
      
      setExportJobs(data?.map(job => ({
        id: job.id,
        name: job.name,
        format: job.format,
        dataType: job.data_type,
        status: job.status,
        progress: job.progress || 0,
        createdAt: new Date(job.created_at),
        completedAt: job.completed_at ? new Date(job.completed_at) : undefined,
        downloadUrl: job.download_url
      })) || []);
    } catch (error) {
      console.error('Error loading export jobs:', error);
    }
  };

  const handleExport = async () => {
    if (!exportName.trim()) return;
    
    setIsExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke('data-export-processor', {
        body: {
          name: exportName,
          format: selectedFormat,
          dataType: selectedDataType,
          filters,
          emailDelivery,
          recipientEmail: emailDelivery ? recipientEmail : null
        }
      });

      if (error) throw error;
      
      setExportName('');
      loadExportJobs();
    } catch (error) {
      console.error('Export failed:', error);
    } finally {
      setIsExporting(false);
    }
  };

  const downloadExport = (job: ExportJob) => {
    if (job.downloadUrl) {
      window.open(job.downloadUrl, '_blank');
    }
  };

  const getDataTypeIcon = (type: string) => {
    switch (type) {
      case 'streaming': return <Database className="h-4 w-4" />;
      case 'ml': return <Brain className="h-4 w-4" />;
      case 'dashboard': return <BarChart3 className="h-4 w-4" />;
      default: return <FileText className="h-4 w-4" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'processing': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      default: return 'bg-gray-500';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Data Export Manager</h2>
        <Badge variant="outline" className="text-sm">
          {exportJobs.filter(j => j.status === 'processing').length} Active Exports
        </Badge>
      </div>

      <Tabs defaultValue="create" className="space-y-4">
        <TabsList>
          <TabsTrigger value="create">Create Export</TabsTrigger>
          <TabsTrigger value="jobs">Export Jobs</TabsTrigger>
          <TabsTrigger value="scheduled">Scheduled Exports</TabsTrigger>
        </TabsList>

        <TabsContent value="create">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Download className="h-5 w-5" />
                Create New Export
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="export-name">Export Name</Label>
                  <Input
                    id="export-name"
                    placeholder="My Data Export"
                    value={exportName}
                    onChange={(e) => setExportName(e.target.value)}
                  />
                </div>
                
                <div className="space-y-2">
                  <Label>Export Format</Label>
                  <Select value={selectedFormat} onValueChange={(value: any) => setSelectedFormat(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="json">JSON</SelectItem>
                      <SelectItem value="pdf">PDF Report</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Data Type</Label>
                <Select value={selectedDataType} onValueChange={(value: any) => setSelectedDataType(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="streaming">Real-time Streaming Data</SelectItem>
                    <SelectItem value="ml">ML Predictions & Models</SelectItem>
                    <SelectItem value="dashboard">Dashboard Visualizations</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-4">
                <Label className="flex items-center gap-2">
                  <Filter className="h-4 w-4" />
                  Filters & Options
                </Label>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>Start Date</Label>
                    <Input
                      type="date"
                      value={filters.dateRange.start.toISOString().split('T')[0]}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        dateRange: { ...prev.dateRange, start: new Date(e.target.value) }
                      }))}
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <Label>End Date</Label>
                    <Input
                      type="date"
                      value={filters.dateRange.end.toISOString().split('T')[0]}
                      onChange={(e) => setFilters(prev => ({
                        ...prev,
                        dateRange: { ...prev.dateRange, end: new Date(e.target.value) }
                      }))}
                     />
                  </div>
                </div>
              </div>

              <div className="space-y-4">
                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="email-delivery"
                    checked={emailDelivery}
                    onCheckedChange={(checked) => setEmailDelivery(checked as boolean)}
                  />
                  <Label htmlFor="email-delivery" className="flex items-center gap-2">
                    <Mail className="h-4 w-4" />
                    Email delivery when complete
                  </Label>
                </div>
                
                {emailDelivery && (
                  <Input
                    placeholder="recipient@example.com"
                    value={recipientEmail}
                    onChange={(e) => setRecipientEmail(e.target.value)}
                  />
                )}
              </div>

              <Button 
                onClick={handleExport} 
                disabled={!exportName.trim() || isExporting}
                className="w-full"
              >
                {isExporting ? 'Creating Export...' : 'Create Export'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="jobs">
          <Card>
            <CardHeader>
              <CardTitle>Recent Export Jobs</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {exportJobs.map((job) => (
                  <div key={job.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {getDataTypeIcon(job.dataType)}
                      <div>
                        <h3 className="font-medium">{job.name}</h3>
                        <p className="text-sm text-muted-foreground">
                          {job.format.toUpperCase()} • {job.createdAt.toLocaleDateString()}
                        </p>
                      </div>
                    </div>
                    
                    <div className="flex items-center gap-3">
                      {job.status === 'processing' && (
                        <div className="w-24">
                          <Progress value={job.progress} />
                        </div>
                      )}
                      
                      <Badge className={getStatusColor(job.status)}>
                        {job.status}
                      </Badge>
                      
                      {job.status === 'completed' && job.downloadUrl && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => downloadExport(job)}
                        >
                          <Download className="h-4 w-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="scheduled">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Calendar className="h-5 w-5" />
                Scheduled Exports
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-muted-foreground">
                Schedule automatic exports to run daily, weekly, or monthly.
              </p>
              <Button className="mt-4" variant="outline">
                Create Scheduled Export
              </Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}