import { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { Switch } from '@/components/ui/switch';
import { backupService } from '@/services/backupService';

interface BackupJobFormProps {
  onClose: () => void;
}

export function BackupJobForm({ onClose }: BackupJobFormProps) {
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    schedule: '0 2 * * *',
    backup_type: 'full',
    retention_days: 30,
    encryption_enabled: true,
    storage_provider: 's3',
    storage_config: {
      bucket: '',
      region: 'us-east-1'
    }
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await backupService.createBackupJob(formData);
      onClose();
    } catch (error) {
      console.error('Error creating backup job:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Create Backup Job</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <Label htmlFor="name">Job Name</Label>
            <Input
              id="name"
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Daily Production Backup"
              required
            />
          </div>

          <div>
            <Label htmlFor="description">Description</Label>
            <Textarea
              id="description"
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Full database backup with encryption"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="backup_type">Backup Type</Label>
              <Select value={formData.backup_type} onValueChange={(value) => setFormData({ ...formData, backup_type: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="full">Full Backup</SelectItem>
                  <SelectItem value="incremental">Incremental</SelectItem>
                  <SelectItem value="differential">Differential</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <Label htmlFor="schedule">Schedule (Cron)</Label>
              <Input
                id="schedule"
                value={formData.schedule}
                onChange={(e) => setFormData({ ...formData, schedule: e.target.value })}
                placeholder="0 2 * * *"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="retention">Retention (Days)</Label>
              <Input
                id="retention"
                type="number"
                value={formData.retention_days}
                onChange={(e) => setFormData({ ...formData, retention_days: parseInt(e.target.value) })}
                min="1"
              />
            </div>

            <div>
              <Label htmlFor="storage">Storage Provider</Label>
              <Select value={formData.storage_provider} onValueChange={(value) => setFormData({ ...formData, storage_provider: value })}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="s3">Amazon S3</SelectItem>
                  <SelectItem value="gcs">Google Cloud Storage</SelectItem>
                  <SelectItem value="azure">Azure Blob Storage</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label htmlFor="bucket">Bucket Name</Label>
              <Input
                id="bucket"
                value={formData.storage_config.bucket}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  storage_config: { ...formData.storage_config, bucket: e.target.value }
                })}
                placeholder="my-backup-bucket"
                required
              />
            </div>

            <div>
              <Label htmlFor="region">Region</Label>
              <Input
                id="region"
                value={formData.storage_config.region}
                onChange={(e) => setFormData({ 
                  ...formData, 
                  storage_config: { ...formData.storage_config, region: e.target.value }
                })}
                placeholder="us-east-1"
              />
            </div>
          </div>

          <div className="flex items-center space-x-2">
            <Switch
              id="encryption"
              checked={formData.encryption_enabled}
              onCheckedChange={(checked) => setFormData({ ...formData, encryption_enabled: checked })}
            />
            <Label htmlFor="encryption">Enable AES-256 Encryption</Label>
          </div>

          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={loading}>
              {loading ? 'Creating...' : 'Create Backup Job'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
