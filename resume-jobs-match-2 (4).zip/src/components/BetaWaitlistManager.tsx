import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mail, CheckCircle, XCircle, Clock, Search, RefreshCw } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface WaitlistEntry {
  id: string;
  email: string;
  name: string;
  company: string | null;
  role: string | null;
  reason: string | null;
  status: string;
  priority: number;
  created_at: string;
  invite_code: string | null;
}

export default function BetaWaitlistManager() {
  const [entries, setEntries] = useState<WaitlistEntry[]>([]);
  const [filteredEntries, setFilteredEntries] = useState<WaitlistEntry[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [loading, setLoading] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    loadWaitlist();
  }, []);

  useEffect(() => {
    filterEntries();
  }, [entries, searchTerm, statusFilter]);

  const loadWaitlist = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('beta_waitlist')
        .select('*')
        .order('priority', { ascending: false })
        .order('created_at', { ascending: true });

      if (error) throw error;
      setEntries(data || []);
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const filterEntries = () => {
    let filtered = entries;

    if (statusFilter !== 'all') {
      filtered = filtered.filter(e => e.status === statusFilter);
    }

    if (searchTerm) {
      filtered = filtered.filter(e => 
        e.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
        e.name.toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    setFilteredEntries(filtered);
  };

  const updateStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('beta_waitlist')
        .update({ status })
        .eq('id', id);

      if (error) throw error;

      toast({
        title: 'Status Updated',
        description: `Waitlist entry marked as ${status}`
      });

      loadWaitlist();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const sendInvite = async (entry: WaitlistEntry) => {
    try {
      // Generate invite code
      const code = `BETA-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      
      const { error: inviteError } = await supabase.from('beta_invites').insert({
        code,
        email: entry.email,
        max_uses: 1,
        current_uses: 0,
        status: 'active'
      });

      if (inviteError) throw inviteError;

      // Update waitlist entry
      const { error: updateError } = await supabase
        .from('beta_waitlist')
        .update({ 
          status: 'invited',
          invite_code: code,
          invited_at: new Date().toISOString()
        })
        .eq('id', entry.id);

      if (updateError) throw updateError;

      toast({
        title: 'Invite Sent',
        description: `Invite code ${code} generated for ${entry.email}`
      });

      loadWaitlist();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pending': return <Clock className="w-4 h-4" />;
      case 'approved': return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'invited': return <Mail className="w-4 h-4 text-blue-500" />;
      case 'rejected': return <XCircle className="w-4 h-4 text-red-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Waitlist Management</h2>
        <Button variant="outline" onClick={loadWaitlist} disabled={loading}>
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <Card className="p-4">
        <div className="flex gap-4">
          <div className="flex-1">
            <Input
              placeholder="Search by email or name..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              icon={<Search className="w-4 h-4" />}
            />
          </div>
          <Select value={statusFilter} onValueChange={setStatusFilter}>
            <SelectTrigger className="w-40">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="pending">Pending</SelectItem>
              <SelectItem value="approved">Approved</SelectItem>
              <SelectItem value="invited">Invited</SelectItem>
              <SelectItem value="rejected">Rejected</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </Card>

      <div className="grid gap-4">
        {filteredEntries.map((entry) => (
          <Card key={entry.id} className="p-4">
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <h3 className="font-semibold">{entry.name}</h3>
                  <Badge variant="outline" className="flex items-center gap-1">
                    {getStatusIcon(entry.status)}
                    {entry.status}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground mb-2">{entry.email}</p>
                {(entry.company || entry.role) && (
                  <p className="text-sm mb-2">
                    {entry.role} {entry.company && `at ${entry.company}`}
                  </p>
                )}
                {entry.reason && (
                  <p className="text-sm text-muted-foreground italic mb-2">
                    "{entry.reason}"
                  </p>
                )}
                <p className="text-xs text-muted-foreground">
                  Applied {new Date(entry.created_at).toLocaleDateString()}
                </p>
                {entry.invite_code && (
                  <p className="text-sm font-mono mt-2">
                    Invite: <code className="bg-muted px-2 py-1 rounded">{entry.invite_code}</code>
                  </p>
                )}
              </div>
              <div className="flex flex-col gap-2">
                {entry.status === 'pending' && (
                  <>
                    <Button size="sm" onClick={() => updateStatus(entry.id, 'approved')}>
                      Approve
                    </Button>
                    <Button size="sm" variant="outline" onClick={() => sendInvite(entry)}>
                      <Mail className="w-4 h-4 mr-2" />
                      Send Invite
                    </Button>
                    <Button 
                      size="sm" 
                      variant="destructive" 
                      onClick={() => updateStatus(entry.id, 'rejected')}
                    >
                      Reject
                    </Button>
                  </>
                )}
                {entry.status === 'approved' && (
                  <Button size="sm" onClick={() => sendInvite(entry)}>
                    <Mail className="w-4 h-4 mr-2" />
                    Send Invite
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>

      {filteredEntries.length === 0 && (
        <Card className="p-8 text-center">
          <p className="text-muted-foreground">No waitlist entries found</p>
        </Card>
      )}
    </div>
  );
}