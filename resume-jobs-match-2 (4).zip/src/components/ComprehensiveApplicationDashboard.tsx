import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Button } from '@/components/ui/button';
import { ApplicationFormModal } from './ApplicationFormModal';
import { ApplicationReminders } from './ApplicationReminders';
import { ApplicationPipeline } from './ApplicationPipeline';
import { ApplicationAnalytics } from './ApplicationAnalytics';
import ApplicationDeadlineTracker from './ApplicationDeadlineTracker';
import ApplicationStatusAutomation from './ApplicationStatusAutomation';
import { JobApplicationFollowUpTemplates } from './JobApplicationFollowUpTemplates';
import CompanyResearch from './CompanyResearch';
import InterviewScheduler from './InterviewScheduler';
import ApplicationCalendar from './ApplicationCalendar';
import CalendarEventModal from './CalendarEventModal';
import CalendarSyncManager from './CalendarSyncManager';
import CalendarMilestoneView from './CalendarMilestoneView';
import { ApplicationNotificationCenter } from './ApplicationNotificationCenter';
import { ComprehensiveEmailTemplateSystem } from './ComprehensiveEmailTemplateSystem';
import { 
  Bell, 
  Calendar, 
  Target, 
  CheckCircle,
  Clock,
  TrendingUp,
  Filter,
  Search,
  Building,
  Zap,
  Plus
} from 'lucide-react';
import { toast } from 'sonner';
import { Input } from '@/components/ui/input';

interface Application {
  id: string;
  job_title: string;
  company_name: string;
  location?: string;
  salary_range?: string;
  status: 'draft' | 'submitted' | 'reviewing' | 'interview' | 'offer' | 'rejected' | 'accepted';
  applied_date?: string;
  follow_up_date?: string;
  interview_date?: string;
  job_url?: string;
  notes?: string;
  priority?: 'high' | 'medium' | 'low';
  created_at: string;
  updated_at: string;
}

export default function ComprehensiveApplicationDashboard() {
  const { user } = useAuth();
  const [applications, setApplications] = useState<Application[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedApp, setSelectedApp] = useState<Application | null>(null);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    if (user) {
      fetchApplications();
    }
  }, [user]);

  const fetchApplications = async () => {
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .select('*')
        .eq('user_id', user?.id)
        .order('updated_at', { ascending: false });

      if (error) throw error;
      setApplications(data || []);
    } catch (error) {
      toast.error('Failed to fetch applications');
    } finally {
      setLoading(false);
    }
  };

  const handleAddApplication = async (appData: any) => {
    try {
      const { error } = await supabase
        .from('job_applications')
        .insert([appData]);

      if (error) throw error;
      
      toast.success('Application added successfully');
      fetchApplications();
    } catch (error) {
      toast.error('Failed to add application');
      throw error;
    }
  };

  const updateApplicationStatus = async (id: string, status: string) => {
    try {
      const { error } = await supabase
        .from('job_applications')
        .update({ 
          status,
          updated_at: new Date().toISOString()
        })
        .eq('id', id);

      if (error) throw error;
      
      toast.success('Application status updated');
      fetchApplications();
    } catch (error) {
      toast.error('Failed to update status');
    }
  };

  const filteredApplications = applications.filter(app => {
    const matchesSearch = app.job_title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         app.company_name.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === 'all' || app.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const stats = {
    total: applications.length,
    submitted: applications.filter(app => app.status === 'submitted').length,
    reviewing: applications.filter(app => app.status === 'reviewing').length,
    interview: applications.filter(app => app.status === 'interview').length,
    offers: applications.filter(app => app.status === 'offer').length,
    pending: applications.filter(app => app.follow_up_date && new Date(app.follow_up_date) <= new Date()).length
  };

  if (loading) {
    return <div className="flex justify-center items-center h-64">Loading...</div>;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold">Job Application Tracker</h1>
          <p className="text-gray-600 mt-2">Manage your job applications, track progress, and stay organized</p>
        </div>
        <Button onClick={() => setShowAddModal(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Application
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 md:grid-cols-6 gap-4 mb-8">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-2xl font-bold">{stats.total}</p>
                <p className="text-sm text-gray-600">Total</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <CheckCircle className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-2xl font-bold">{stats.submitted}</p>
                <p className="text-sm text-gray-600">Submitted</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-yellow-500" />
              <div>
                <p className="text-2xl font-bold">{stats.reviewing}</p>
                <p className="text-sm text-gray-600">Reviewing</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Calendar className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-2xl font-bold">{stats.interview}</p>
                <p className="text-sm text-gray-600">Interview</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-green-600" />
              <div>
                <p className="text-2xl font-bold">{stats.offers}</p>
                <p className="text-sm text-gray-600">Offers</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Bell className="h-5 w-5 text-red-500" />
              <div>
                <p className="text-2xl font-bold">{stats.pending}</p>
                <p className="text-sm text-gray-600">Follow-ups</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="applications" className="w-full">
        <TabsList className="grid w-full grid-cols-11">
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="notifications">Notifications</TabsTrigger>
          <TabsTrigger value="calendar">Calendar</TabsTrigger>
          <TabsTrigger value="deadlines">Deadlines</TabsTrigger>
          <TabsTrigger value="pipeline">Pipeline</TabsTrigger>
          <TabsTrigger value="reminders">Reminders</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="emails">Email System</TabsTrigger>
          <TabsTrigger value="research">Research</TabsTrigger>
        </TabsList>
        <TabsContent value="notifications" className="mt-6">
          <ApplicationNotificationCenter />
        </TabsContent>

        <TabsContent value="applications" className="mt-6">
          <div className="flex gap-4 mb-6">
            <div className="flex-1">
              <Input
                placeholder="Search applications..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="max-w-sm"
              />
            </div>
            <select 
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="px-3 py-2 border rounded-md"
            >
              <option value="all">All Status</option>
              <option value="draft">Draft</option>
              <option value="submitted">Submitted</option>
              <option value="reviewing">Under Review</option>
              <option value="interview">Interview</option>
              <option value="offer">Offer</option>
              <option value="rejected">Rejected</option>
              <option value="accepted">Accepted</option>
            </select>
          </div>

          <div className="space-y-4">
            {filteredApplications.length === 0 ? (
              <Card>
                <CardContent className="text-center py-12">
                  <Target className="h-12 w-12 mx-auto mb-4 text-gray-400" />
                  <p className="text-gray-500 mb-4">No applications found</p>
                  <Button onClick={() => setShowAddModal(true)}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Your First Application
                  </Button>
                </CardContent>
              </Card>
            ) : (
              filteredApplications.map((app) => (
                <Card key={app.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-6">
                    <div className="flex justify-between items-start">
                      <div className="flex-1">
                        <h3 className="font-semibold text-lg">{app.job_title}</h3>
                        <p className="text-gray-600">{app.company_name}</p>
                        {app.location && <p className="text-sm text-gray-500">{app.location}</p>}
                        {app.salary_range && <p className="text-sm text-green-600">{app.salary_range}</p>}
                      </div>
                      <div className="flex items-center gap-2">
                        <select
                          value={app.status}
                          onChange={(e) => updateApplicationStatus(app.id, e.target.value)}
                          className={`px-3 py-1 rounded-full text-sm font-medium border-0 ${
                            app.status === 'offer' ? 'bg-green-100 text-green-800' :
                            app.status === 'interview' ? 'bg-yellow-100 text-yellow-800' :
                            app.status === 'submitted' ? 'bg-blue-100 text-blue-800' :
                            app.status === 'reviewing' ? 'bg-purple-100 text-purple-800' :
                            app.status === 'rejected' ? 'bg-red-100 text-red-800' :
                            app.status === 'accepted' ? 'bg-green-100 text-green-800' :
                            'bg-gray-100 text-gray-800'
                          }`}
                        >
                          <option value="draft">Draft</option>
                          <option value="submitted">Submitted</option>
                          <option value="reviewing">Under Review</option>
                          <option value="interview">Interview</option>
                          <option value="offer">Offer</option>
                          <option value="rejected">Rejected</option>
                          <option value="accepted">Accepted</option>
                        </select>
                        <Button 
                          size="sm" 
                          variant="outline"
                          onClick={() => setSelectedApp(app)}
                        >
                          View Details
                        </Button>
                      </div>
                    </div>
                    <div className="flex items-center gap-4 mt-4 text-sm text-gray-500">
                      {app.applied_date && (
                        <span>Applied: {new Date(app.applied_date).toLocaleDateString()}</span>
                      )}
                      {app.interview_date && (
                        <span>Interview: {new Date(app.interview_date).toLocaleDateString()}</span>
                      )}
                      {app.follow_up_date && (
                        <span>Follow-up: {new Date(app.follow_up_date).toLocaleDateString()}</span>
                      )}
                    </div>
                  </CardContent>
                </Card>
              ))
            )}
          </div>
        </TabsContent>

        <TabsContent value="calendar" className="mt-6">
          <div className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2">
                <ApplicationCalendar />
              </div>
              <div className="space-y-6">
                <CalendarSyncManager />
                <CalendarMilestoneView />
              </div>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="deadlines" className="mt-6">
          <ApplicationDeadlineTracker />
        </TabsContent>

        <TabsContent value="pipeline" className="mt-6">
          <ApplicationPipeline applications={applications} />
        </TabsContent>

        <TabsContent value="reminders" className="mt-6">
          <ApplicationReminders />
        </TabsContent>

        <TabsContent value="analytics" className="mt-6">
          <ApplicationAnalytics />
        </TabsContent>

        <TabsContent value="automation" className="mt-6">
          <ApplicationStatusAutomation />
        </TabsContent>

        <TabsContent value="templates" className="mt-6">
          <JobApplicationFollowUpTemplates />
        </TabsContent>

        <TabsContent value="emails" className="mt-6">
          <ComprehensiveEmailTemplateSystem />
        </TabsContent>

        <TabsContent value="research" className="mt-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <CompanyResearch />
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Calendar className="h-5 w-5" />
                  Interview Scheduler
                </CardTitle>
              </CardHeader>
              <CardContent>
                <InterviewScheduler onInterviewScheduled={() => fetchApplications()} />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>

      <ApplicationFormModal
        open={showAddModal}
        onClose={() => setShowAddModal(false)}
        onSubmit={handleAddApplication}
      />
    </div>
  );
}