import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { 
  Mail, 
  Users, 
  Calendar, 
  BarChart3, 
  Settings,
  Send,
  Eye,
  Save,
  ArrowLeft
} from 'lucide-react';
import { VisualEmailEditor } from './campaign-builder/VisualEmailEditor';
import { RecipientManager } from './campaign-builder/RecipientManager';
import { CampaignScheduler } from './campaign-builder/CampaignScheduler';
import { ABTestSetup } from './campaign-builder/ABTestSetup';
import { CampaignAnalytics } from './campaign-builder/CampaignAnalytics';
import { useEmailCampaignDatabase } from '../hooks/useEmailCampaignDatabase';

interface EmailCampaignBuilderProps {
  onBack?: () => void;
}

export const EmailCampaignBuilder: React.FC<EmailCampaignBuilderProps> = ({ onBack }) => {
  const [activeTab, setActiveTab] = useState('setup');
  const [campaignData, setCampaignData] = useState({
    name: '',
    subject: '',
    from_name: '',
    from_email: '',
    preview_text: '',
    content: {},
    status: 'draft' as const,
    campaign_type: 'standard' as const,
    send_type: 'immediate' as const,
    total_recipients: 0
  });

  const { createCampaign, loading } = useEmailCampaignDatabase();

  const handleSaveDraft = async () => {
    try {
      await createCampaign(campaignData);
      if (onBack) onBack();
    } catch (error) {
      console.error('Failed to save campaign:', error);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center">
              {onBack && (
                <Button variant="ghost" onClick={onBack} className="mr-4">
                  <ArrowLeft className="w-4 h-4 mr-2" />
                  Back
                </Button>
              )}
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Email Campaign Builder</h1>
                <p className="text-gray-600">Create, test, and launch email campaigns with database persistence</p>
              </div>
            </div>
            <div className="flex space-x-3">
              <Button variant="outline">
                <Eye className="w-4 h-4 mr-2" />
                Preview
              </Button>
              <Button variant="outline" onClick={handleSaveDraft} disabled={loading}>
                <Save className="w-4 h-4 mr-2" />
                Save Draft
              </Button>
              <Button className="bg-blue-600 hover:bg-blue-700" disabled={!campaignData.name || !campaignData.subject}>
                <Send className="w-4 h-4 mr-2" />
                Launch Campaign
              </Button>
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-6">
          <TabsList className="grid w-full grid-cols-6">
            <TabsTrigger value="setup" className="flex items-center">
              <Settings className="w-4 h-4 mr-2" />
              Setup
            </TabsTrigger>
            <TabsTrigger value="design" className="flex items-center">
              <Mail className="w-4 h-4 mr-2" />
              Design
            </TabsTrigger>
            <TabsTrigger value="recipients" className="flex items-center">
              <Users className="w-4 h-4 mr-2" />
              Recipients
            </TabsTrigger>
            <TabsTrigger value="schedule" className="flex items-center">
              <Calendar className="w-4 h-4 mr-2" />
              Schedule
            </TabsTrigger>
            <TabsTrigger value="testing" className="flex items-center">
              <BarChart3 className="w-4 h-4 mr-2" />
              A/B Testing
            </TabsTrigger>
            <TabsTrigger value="analytics" className="flex items-center">
              <BarChart3 className="w-4 h-4 mr-2" />
              Analytics
            </TabsTrigger>
          </TabsList>

          <TabsContent value="setup" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Setup</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="name">Campaign Name</Label>
                    <Input
                      id="name"
                      value={campaignData.name}
                      onChange={(e) => setCampaignData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter campaign name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="subject">Subject Line</Label>
                    <Input
                      id="subject"
                      value={campaignData.subject}
                      onChange={(e) => setCampaignData(prev => ({ ...prev, subject: e.target.value }))}
                      placeholder="Enter email subject"
                    />
                  </div>
                  <div>
                    <Label htmlFor="from_name">From Name</Label>
                    <Input
                      id="from_name"
                      value={campaignData.from_name}
                      onChange={(e) => setCampaignData(prev => ({ ...prev, from_name: e.target.value }))}
                      placeholder="Your Name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="from_email">From Email</Label>
                    <Input
                      id="from_email"
                      type="email"
                      value={campaignData.from_email}
                      onChange={(e) => setCampaignData(prev => ({ ...prev, from_email: e.target.value }))}
                      placeholder="your@email.com"
                    />
                  </div>
                  <div className="md:col-span-2">
                    <Label htmlFor="preview_text">Preview Text</Label>
                    <Input
                      id="preview_text"
                      value={campaignData.preview_text}
                      onChange={(e) => setCampaignData(prev => ({ ...prev, preview_text: e.target.value }))}
                      placeholder="This text appears in the email preview"
                    />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="design" className="space-y-6">
            <VisualEmailEditor />
          </TabsContent>

          <TabsContent value="recipients" className="space-y-6">
            <RecipientManager />
          </TabsContent>

          <TabsContent value="schedule" className="space-y-6">
            <CampaignScheduler />
          </TabsContent>

          <TabsContent value="testing" className="space-y-6">
            <ABTestSetup />
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <CampaignAnalytics />
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};
