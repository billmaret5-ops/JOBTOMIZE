import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Switch } from './ui/switch';
import { Bell, Mail, Calendar, Settings, Clock, CheckCircle } from 'lucide-react';

interface NotificationRule {
  id: string;
  name: string;
  trigger: string;
  delay: string;
  template: string;
  enabled: boolean;
  lastSent?: string;
}

export function EmailNotificationSystem() {
  const [rules, setRules] = useState<NotificationRule[]>([
    {
      id: '1',
      name: 'Follow-up Reminder',
      trigger: 'Application Submitted',
      delay: '3 days',
      template: 'Follow-up Template',
      enabled: true,
      lastSent: '2024-01-15'
    },
    {
      id: '2',
      name: 'Interview Confirmation',
      trigger: 'Interview Scheduled',
      delay: '1 day before',
      template: 'Interview Reminder',
      enabled: true,
      lastSent: '2024-01-14'
    },
    {
      id: '3',
      name: 'Status Update Alert',
      trigger: 'Status Changed',
      delay: 'Immediate',
      template: 'Status Update',
      enabled: false
    },
    {
      id: '4',
      name: 'Weekly Summary',
      trigger: 'Weekly',
      delay: 'Every Monday',
      template: 'Weekly Report',
      enabled: true,
      lastSent: '2024-01-13'
    }
  ]);

  const [stats] = useState({
    totalSent: 47,
    deliveryRate: 98.5,
    openRate: 76.2,
    clickRate: 34.8
  });

  const toggleRule = (id: string) => {
    setRules(rules.map(rule => 
      rule.id === id ? { ...rule, enabled: !rule.enabled } : rule
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">Email Notifications</h2>
          <p className="text-gray-600">Automated reminders and updates for your job applications</p>
        </div>
        <Button>
          <Settings className="w-4 h-4 mr-2" />
          Settings
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <Mail className="w-8 h-8 text-blue-600" />
              <div className="ml-3">
                <p className="text-sm text-gray-600">Total Sent</p>
                <p className="text-2xl font-bold">{stats.totalSent}</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <CheckCircle className="w-8 h-8 text-green-600" />
              <div className="ml-3">
                <p className="text-sm text-gray-600">Delivery Rate</p>
                <p className="text-2xl font-bold">{stats.deliveryRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <Bell className="w-8 h-8 text-orange-600" />
              <div className="ml-3">
                <p className="text-sm text-gray-600">Open Rate</p>
                <p className="text-2xl font-bold">{stats.openRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center">
              <Clock className="w-8 h-8 text-purple-600" />
              <div className="ml-3">
                <p className="text-sm text-gray-600">Click Rate</p>
                <p className="text-2xl font-bold">{stats.clickRate}%</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notification Rules */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Notification Rules
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {rules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center space-x-3">
                    <h4 className="font-medium">{rule.name}</h4>
                    <Badge variant={rule.enabled ? "default" : "secondary"}>
                      {rule.enabled ? "Active" : "Inactive"}
                    </Badge>
                  </div>
                  <div className="mt-2 text-sm text-gray-600">
                    <span className="font-medium">Trigger:</span> {rule.trigger} • 
                    <span className="font-medium ml-2">Delay:</span> {rule.delay} • 
                    <span className="font-medium ml-2">Template:</span> {rule.template}
                  </div>
                  {rule.lastSent && (
                    <p className="text-xs text-gray-500 mt-1">
                      Last sent: {rule.lastSent}
                    </p>
                  )}
                </div>
                <div className="flex items-center space-x-3">
                  <Button variant="outline" size="sm">
                    Edit
                  </Button>
                  <Switch
                    checked={rule.enabled}
                    onCheckedChange={() => toggleRule(rule.id)}
                  />
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}