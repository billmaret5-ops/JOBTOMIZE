import { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Zap, BarChart3, Settings, TestTube } from 'lucide-react';
import AutomatedSequenceBuilder from './AutomatedSequenceBuilder';
import SequenceStepEditor from './SequenceStepEditor';
import BehaviorBasedScheduler from './BehaviorBasedScheduler';
import SequenceABTestManager from './SequenceABTestManager';
import SequencePerformanceAnalytics from './SequencePerformanceAnalytics';

export default function AutomatedFollowUpSystem() {
  const [selectedSequence, setSelectedSequence] = useState<string | null>(null);

  return (
    <div className="container mx-auto py-8">
      <div className="mb-8">
        <h1 className="text-4xl font-bold mb-2">Automated Email Sequences</h1>
        <p className="text-muted-foreground">
          Create trigger-based follow-ups with behavior optimization and A/B testing
        </p>
      </div>

      <Tabs defaultValue="sequences" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="sequences" className="flex items-center gap-2">
            <Zap className="w-4 h-4" />
            Sequences
          </TabsTrigger>
          <TabsTrigger value="behavior" className="flex items-center gap-2">
            <Settings className="w-4 h-4" />
            Behavior
          </TabsTrigger>
          <TabsTrigger value="testing" className="flex items-center gap-2">
            <TestTube className="w-4 h-4" />
            A/B Testing
          </TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2">
            <BarChart3 className="w-4 h-4" />
            Analytics
          </TabsTrigger>
        </TabsList>

        <TabsContent value="sequences" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <AutomatedSequenceBuilder />
            {selectedSequence && (
              <SequenceStepEditor
                sequenceId={selectedSequence}
                onStepAdded={() => console.log('Step added')}
              />
            )}
          </div>
        </TabsContent>

        <TabsContent value="behavior">
          <Card>
            <CardHeader>
              <CardTitle>Behavior-Based Scheduling</CardTitle>
              <CardDescription>
                Optimize send times based on recipient engagement patterns
              </CardDescription>
            </CardHeader>
            <CardContent>
              <BehaviorBasedScheduler contactId="sample-contact-id" />
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="testing">
          <SequenceABTestManager stepId="sample-step-id" />
        </TabsContent>

        <TabsContent value="analytics">
          <SequencePerformanceAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
}
