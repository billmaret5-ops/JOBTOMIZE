import React, { useState } from 'react';
import { Download, FileText, Filter, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Input } from './ui/input';
import { supabase } from '@/lib/supabase';

interface ExportOptions {
  format: 'csv' | 'json' | 'xlsx';
  includeFields: string[];
  filterBy: 'all' | 'list' | 'segment' | 'status' | 'date_range';
  listId?: string;
  segmentId?: string;
  status?: string;
  dateFrom?: Date;
  dateTo?: Date;
}

export const BulkContactExporter = () => {
  const [exporting, setExporting] = useState(false);
  const [options, setOptions] = useState<ExportOptions>({
    format: 'csv',
    includeFields: ['email', 'first_name', 'last_name', 'company'],
    filterBy: 'all'
  });

  const availableFields = [
    { id: 'email', label: 'Email', required: true },
    { id: 'first_name', label: 'First Name' },
    { id: 'last_name', label: 'Last Name' },
    { id: 'company', label: 'Company' },
    { id: 'phone', label: 'Phone' },
    { id: 'tags', label: 'Tags' },
    { id: 'status', label: 'Status' },
    { id: 'created_at', label: 'Created Date' },
    { id: 'updated_at', label: 'Updated Date' }
  ];

  const handleFieldToggle = (fieldId: string, checked: boolean) => {
    if (fieldId === 'email') return; // Email is required

    setOptions(prev => ({
      ...prev,
      includeFields: checked
        ? [...prev.includeFields, fieldId]
        : prev.includeFields.filter(id => id !== fieldId)
    }));
  };

  const exportContacts = async () => {
    setExporting(true);
    try {
      const { data, error } = await supabase.functions.invoke('contact-export-manager', {
        body: options
      });

      if (error) throw error;

      // Create and download file
      const blob = new Blob([data.content], { 
        type: options.format === 'csv' ? 'text/csv' : 'application/json' 
      });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `contacts_export_${new Date().toISOString().split('T')[0]}.${options.format}`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Export failed:', error);
      alert('Export failed. Please try again.');
    } finally {
      setExporting(false);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Download className="h-5 w-5" />
          Export Contacts
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label className="text-sm font-medium mb-2 block">Export Format</label>
            <Select value={options.format} onValueChange={(value: 'csv' | 'json' | 'xlsx') => 
              setOptions(prev => ({ ...prev, format: value }))
            }>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
                <SelectItem value="xlsx">Excel (XLSX)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="text-sm font-medium mb-2 block">Filter By</label>
            <Select value={options.filterBy} onValueChange={(value: any) => 
              setOptions(prev => ({ ...prev, filterBy: value }))
            }>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Contacts</SelectItem>
                <SelectItem value="list">Specific List</SelectItem>
                <SelectItem value="segment">Specific Segment</SelectItem>
                <SelectItem value="status">By Status</SelectItem>
                <SelectItem value="date_range">Date Range</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {options.filterBy === 'status' && (
          <div>
            <label className="text-sm font-medium mb-2 block">Status</label>
            <Select value={options.status} onValueChange={(value) => 
              setOptions(prev => ({ ...prev, status: value }))
            }>
              <SelectTrigger>
                <SelectValue placeholder="Select status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="active">Active</SelectItem>
                <SelectItem value="unsubscribed">Unsubscribed</SelectItem>
                <SelectItem value="bounced">Bounced</SelectItem>
              </SelectContent>
            </Select>
          </div>
        )}

        {options.filterBy === 'date_range' && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">From Date</label>
              <Input
                type="date"
                onChange={(e) => setOptions(prev => ({ ...prev, dateFrom: new Date(e.target.value) }))}
              />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">To Date</label>
              <Input
                type="date"
                onChange={(e) => setOptions(prev => ({ ...prev, dateTo: new Date(e.target.value) }))}
              />
            </div>
          </div>
        )}

        <div>
          <label className="text-sm font-medium mb-3 block">Include Fields</label>
          <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
            {availableFields.map(field => (
              <div key={field.id} className="flex items-center space-x-2">
                <Checkbox
                  id={field.id}
                  checked={options.includeFields.includes(field.id)}
                  onCheckedChange={(checked) => handleFieldToggle(field.id, !!checked)}
                  disabled={field.required}
                />
                <label htmlFor={field.id} className="text-sm">
                  {field.label}
                  {field.required && <span className="text-red-500 ml-1">*</span>}
                </label>
              </div>
            ))}
          </div>
        </div>

        <div className="flex justify-between items-center pt-4 border-t">
          <div className="text-sm text-gray-600">
            Selected fields: {options.includeFields.length}
          </div>
          <Button onClick={exportContacts} disabled={exporting}>
            {exporting ? (
              <>
                <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                Exporting...
              </>
            ) : (
              <>
                <FileText className="h-4 w-4 mr-2" />
                Export Contacts
              </>
            )}
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};