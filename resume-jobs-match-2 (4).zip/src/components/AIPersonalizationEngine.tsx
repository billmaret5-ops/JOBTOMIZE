import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Brain, Target, Zap, TrendingUp, Users, Building } from 'lucide-react';

interface JobAnalysis {
  company: string;
  role: string;
  industry: string;
  keySkills: string[];
  tone: 'professional' | 'casual' | 'enthusiastic';
  urgency: 'low' | 'medium' | 'high';
}

interface PersonalizationSuggestion {
  variable: string;
  value: string;
  confidence: number;
  source: string;
}

export const AIPersonalizationEngine: React.FC = () => {
  const [jobUrl, setJobUrl] = useState('');
  const [analysis, setAnalysis] = useState<JobAnalysis | null>(null);
  const [suggestions, setSuggestions] = useState<PersonalizationSuggestion[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeJob = async () => {
    setIsAnalyzing(true);
    // Simulate AI analysis
    setTimeout(() => {
      setAnalysis({
        company: 'TechCorp Inc.',
        role: 'Senior Software Engineer',
        industry: 'Technology',
        keySkills: ['React', 'TypeScript', 'Node.js', 'AWS'],
        tone: 'professional',
        urgency: 'medium'
      });
      
      setSuggestions([
        { variable: '{company_name}', value: 'TechCorp Inc.', confidence: 95, source: 'Job Posting' },
        { variable: '{role_title}', value: 'Senior Software Engineer', confidence: 98, source: 'Job Posting' },
        { variable: '{key_skill}', value: 'React and TypeScript', confidence: 88, source: 'Requirements Analysis' },
        { variable: '{company_mission}', value: 'innovative technology solutions', confidence: 75, source: 'Company Research' },
        { variable: '{hiring_manager}', value: 'Sarah Johnson', confidence: 65, source: 'LinkedIn Research' }
      ]);
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5 text-blue-600" />
            AI Template Personalization Engine
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex gap-4 mb-6">
            <Input
              placeholder="Paste job posting URL or description..."
              value={jobUrl}
              onChange={(e) => setJobUrl(e.target.value)}
              className="flex-1"
            />
            <Button onClick={analyzeJob} disabled={isAnalyzing}>
              {isAnalyzing ? 'Analyzing...' : 'Analyze Job'}
            </Button>
          </div>

          {analysis && (
            <Tabs defaultValue="analysis" className="w-full">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="analysis">Job Analysis</TabsTrigger>
                <TabsTrigger value="suggestions">Smart Variables</TabsTrigger>
                <TabsTrigger value="tone">Tone Adaptation</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
              </TabsList>

              <TabsContent value="analysis" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Building className="h-4 w-4" />
                        Company Analysis
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-2">
                        <div><strong>Company:</strong> {analysis.company}</div>
                        <div><strong>Industry:</strong> {analysis.industry}</div>
                        <div><strong>Role:</strong> {analysis.role}</div>
                      </div>
                    </CardContent>
                  </Card>

                  <Card>
                    <CardHeader className="pb-3">
                      <CardTitle className="text-sm flex items-center gap-2">
                        <Target className="h-4 w-4" />
                        Key Requirements
                      </CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="flex flex-wrap gap-2">
                        {analysis.keySkills.map((skill, index) => (
                          <Badge key={index} variant="secondary">{skill}</Badge>
                        ))}
                      </div>
                      <div className="mt-3">
                        <Badge variant={analysis.urgency === 'high' ? 'destructive' : 'default'}>
                          {analysis.urgency} urgency
                        </Badge>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>

              <TabsContent value="suggestions" className="space-y-4">
                <div className="space-y-3">
                  {suggestions.map((suggestion, index) => (
                    <Card key={index}>
                      <CardContent className="pt-4">
                        <div className="flex justify-between items-start">
                          <div className="flex-1">
                            <div className="font-mono text-sm bg-gray-100 px-2 py-1 rounded mb-2">
                              {suggestion.variable}
                            </div>
                            <div className="text-sm text-gray-600 mb-1">
                              Suggested value: <strong>{suggestion.value}</strong>
                            </div>
                            <div className="text-xs text-gray-500">
                              Source: {suggestion.source}
                            </div>
                          </div>
                          <div className="text-right">
                            <div className="text-sm font-medium text-green-600">
                              {suggestion.confidence}% confidence
                            </div>
                            <Button size="sm" variant="outline" className="mt-2">
                              Apply
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </TabsContent>

              <TabsContent value="tone" className="space-y-4">
                <Card>
                  <CardHeader>
                    <CardTitle className="text-sm">Recommended Tone Adaptation</CardTitle>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="p-4 bg-blue-50 rounded-lg">
                        <div className="font-medium text-blue-900 mb-2">Professional Tone Detected</div>
                        <div className="text-sm text-blue-700">
                          Based on company culture and industry standards, we recommend a professional yet approachable tone.
                        </div>
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="font-medium mb-2">Before (Generic):</div>
                          <div className="p-3 bg-gray-100 rounded text-sm">
                            "I am interested in this position and believe I would be a good fit."
                          </div>
                        </div>
                        <div>
                          <div className="font-medium mb-2">After (Personalized):</div>
                          <div className="p-3 bg-green-100 rounded text-sm">
                            "I'm excited about the Senior Software Engineer role at TechCorp Inc. and how my React and TypeScript expertise aligns with your innovative technology solutions."
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="performance" className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-green-600">+47%</div>
                          <div className="text-sm text-gray-600">Response Rate</div>
                        </div>
                        <TrendingUp className="h-8 w-8 text-green-600" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-blue-600">+32%</div>
                          <div className="text-sm text-gray-600">Open Rate</div>
                        </div>
                        <Zap className="h-8 w-8 text-blue-600" />
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardContent className="pt-6">
                      <div className="flex items-center justify-between">
                        <div>
                          <div className="text-2xl font-bold text-purple-600">+28%</div>
                          <div className="text-sm text-gray-600">Interview Rate</div>
                        </div>
                        <Users className="h-8 w-8 text-purple-600" />
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
            </Tabs>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default AIPersonalizationEngine;