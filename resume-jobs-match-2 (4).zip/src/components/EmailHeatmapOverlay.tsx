import React, { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';

interface HeatmapData {
  x: number;
  y: number;
  intensity: number;
  clicks: number;
}

interface EmailHeatmapOverlayProps {
  emailContent: string;
  heatmapData: HeatmapData[];
  showClickDensity?: boolean;
  showScrollDepth?: boolean;
  onDataUpdate?: (data: HeatmapData[]) => void;
}

export function EmailHeatmapOverlay({ 
  emailContent, 
  heatmapData, 
  showClickDensity = true,
  showScrollDepth = true,
  onDataUpdate 
}: EmailHeatmapOverlayProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [scrollDepth, setScrollDepth] = useState(0);
  const [isTracking, setIsTracking] = useState(false);

  useEffect(() => {
    if (canvasRef.current && containerRef.current) {
      drawHeatmap();
    }
  }, [heatmapData, showClickDensity]);

  const drawHeatmap = () => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = container.offsetWidth;
    canvas.height = container.offsetHeight;

    ctx.clearRect(0, 0, canvas.width, canvas.height);

    if (showClickDensity) {
      heatmapData.forEach(point => {
        const gradient = ctx.createRadialGradient(
          point.x, point.y, 0,
          point.x, point.y, 30
        );
        
        const alpha = Math.min(point.intensity / 100, 0.8);
        gradient.addColorStop(0, `rgba(255, 0, 0, ${alpha})`);
        gradient.addColorStop(0.5, `rgba(255, 165, 0, ${alpha * 0.5})`);
        gradient.addColorStop(1, `rgba(255, 255, 0, 0)`);

        ctx.fillStyle = gradient;
        ctx.fillRect(point.x - 30, point.y - 30, 60, 60);
      });
    }

    if (showScrollDepth && scrollDepth > 0) {
      const scrollLine = (scrollDepth / 100) * canvas.height;
      ctx.strokeStyle = '#3b82f6';
      ctx.lineWidth = 2;
      ctx.setLineDash([5, 5]);
      ctx.beginPath();
      ctx.moveTo(0, scrollLine);
      ctx.lineTo(canvas.width, scrollLine);
      ctx.stroke();
    }
  };

  const handleClick = (event: React.MouseEvent) => {
    if (!isTracking) return;

    const rect = containerRef.current?.getBoundingClientRect();
    if (!rect) return;

    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    const existingPoint = heatmapData.find(
      point => Math.abs(point.x - x) < 20 && Math.abs(point.y - y) < 20
    );

    let updatedData;
    if (existingPoint) {
      updatedData = heatmapData.map(point =>
        point === existingPoint
          ? { ...point, clicks: point.clicks + 1, intensity: point.intensity + 10 }
          : point
      );
    } else {
      updatedData = [...heatmapData, { x, y, intensity: 20, clicks: 1 }];
    }

    onDataUpdate?.(updatedData);
  };

  const handleScroll = (event: React.UIEvent) => {
    const target = event.target as HTMLDivElement;
    const scrollPercentage = (target.scrollTop / (target.scrollHeight - target.clientHeight)) * 100;
    setScrollDepth(Math.min(scrollPercentage, 100));
  };

  return (
    <Card className="relative overflow-hidden">
      <div className="p-4 border-b bg-gray-50">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold">Email Heatmap Analysis</h3>
          <div className="flex items-center space-x-4">
            <button
              onClick={() => setIsTracking(!isTracking)}
              className={`px-3 py-1 rounded text-sm ${
                isTracking 
                  ? 'bg-red-500 text-white' 
                  : 'bg-green-500 text-white'
              }`}
            >
              {isTracking ? 'Stop Tracking' : 'Start Tracking'}
            </button>
            <div className="text-sm text-gray-600">
              Scroll Depth: {scrollDepth.toFixed(1)}%
            </div>
          </div>
        </div>
      </div>
      
      <div 
        ref={containerRef}
        className="relative h-96 overflow-auto"
        onClick={handleClick}
        onScroll={handleScroll}
      >
        <canvas
          ref={canvasRef}
          className="absolute top-0 left-0 pointer-events-none z-10"
          style={{ mixBlendMode: 'multiply' }}
        />
        <div 
          className="p-4 relative z-0"
          dangerouslySetInnerHTML={{ __html: emailContent }}
        />
      </div>

      <div className="p-4 border-t bg-gray-50">
        <div className="flex items-center justify-between text-sm">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-red-500 rounded opacity-60"></div>
              <span>High Engagement</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-orange-500 rounded opacity-60"></div>
              <span>Medium Engagement</span>
            </div>
            <div className="flex items-center space-x-2">
              <div className="w-4 h-4 bg-blue-500 rounded"></div>
              <span>Scroll Depth</span>
            </div>
          </div>
          <div className="text-gray-600">
            Total Clicks: {heatmapData.reduce((sum, point) => sum + point.clicks, 0)}
          </div>
        </div>
      </div>
    </Card>
  );
}