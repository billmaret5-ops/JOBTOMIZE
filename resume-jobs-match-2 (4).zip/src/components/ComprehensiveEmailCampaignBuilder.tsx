import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { 
  Mail, Users, TestTube, Calendar, BarChart3, 
  Settings, Send, Eye, Play, Pause, Plus, Trash2
} from 'lucide-react';
import { CampaignBuilderService, Campaign, Template } from '../services/campaignBuilderService';
import { templateAnalyticsService } from '../services/templateAnalyticsService';

interface CampaignBuilderProps {
  campaignId?: string;
  onCampaignCreated?: (campaign: Campaign) => void;
}

export const ComprehensiveEmailCampaignBuilder: React.FC<CampaignBuilderProps> = ({ 
  campaignId,
  onCampaignCreated 
}) => {
  const [activeTab, setActiveTab] = useState('setup');
  const [campaign, setCampaign] = useState<Partial<Campaign>>({
    name: '',
    subject: '',
    template_content: {},
    recipients: [],
    status: 'draft',
    ab_test: {
      enabled: false,
      variant_a: {},
      variant_b: {},
      split_percentage: 50,
      test_metric: 'open_rate'
    }
  });
  const [templates, setTemplates] = useState<Template[]>([]);
  const [contactLists, setContactLists] = useState<any[]>([]);
  const [analytics, setAnalytics] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(25);

  const campaignService = new CampaignBuilderService();

  useEffect(() => {
    loadData();
  }, [campaignId]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [templatesData, contactsData] = await Promise.all([
        campaignService.getTemplates(),
        campaignService.getContactLists()
      ]);
      
      setTemplates(templatesData);
      setContactLists(contactsData);

      if (campaignId) {
        const campaignData = await campaignService.getCampaign(campaignId);
        if (campaignData) {
          setCampaign(campaignData);
          const analyticsData = await campaignService.getCampaignAnalytics(campaignId);
          setAnalytics(analyticsData);
        }
      }
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSaveCampaign = async () => {
    try {
      setLoading(true);
      let savedCampaign;
      
      if (campaignId) {
        savedCampaign = await campaignService.updateCampaign(campaignId, campaign);
      } else {
        savedCampaign = await campaignService.createCampaign(campaign as Omit<Campaign, 'id' | 'created_at' | 'updated_at'>);
        onCampaignCreated?.(savedCampaign);
      }
      
      setCampaign(savedCampaign);
    } catch (error) {
      console.error('Error saving campaign:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSendCampaign = async () => {
    if (!campaignId) return;
    
    try {
      setLoading(true);
      await campaignService.sendCampaign(campaignId);
      setCampaign(prev => ({ ...prev, status: 'sending' }));
    } catch (error) {
      console.error('Error sending campaign:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleScheduleCampaign = async (scheduledAt: string) => {
    if (!campaignId) return;
    
    try {
      await campaignService.scheduleCampaign(campaignId, scheduledAt);
      setCampaign(prev => ({ ...prev, status: 'scheduled', scheduled_at: scheduledAt }));
    } catch (error) {
      console.error('Error scheduling campaign:', error);
    }
  };

  const tabs = [
    { id: 'setup', label: 'Setup', icon: Settings },
    { id: 'template', label: 'Template', icon: Mail },
    { id: 'recipients', label: 'Recipients', icon: Users },
    { id: 'testing', label: 'A/B Testing', icon: TestTube },
    { id: 'schedule', label: 'Schedule', icon: Calendar },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 }
  ];

  return (
    <div className="max-w-7xl mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Email Campaign Builder</h1>
          <p className="text-gray-600">Create and manage email campaigns with A/B testing</p>
        </div>
        <div className="flex gap-2">
          <Badge variant={campaign.status === 'draft' ? 'secondary' : 'default'}>
            {campaign.status}
          </Badge>
          <Button variant="outline" onClick={() => console.log('Preview')}>
            <Eye className="w-4 h-4 mr-2" />
            Preview
          </Button>
          <Button onClick={handleSaveCampaign} disabled={loading}>
            Save
          </Button>
          <Button onClick={handleSendCampaign} disabled={loading || !campaignId}>
            <Send className="w-4 h-4 mr-2" />
            Send
          </Button>
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          <Progress value={progress} className="h-2" />
        </CardContent>
      </Card>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid grid-cols-6 w-full">
          {tabs.map((tab) => (
            <TabsTrigger key={tab.id} value={tab.id} className="flex items-center gap-2">
              <tab.icon className="w-4 h-4" />
              {tab.label}
            </TabsTrigger>
          ))}
        </TabsList>

        <TabsContent value="setup" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="name">Campaign Name</Label>
                <Input
                  id="name"
                  value={campaign.name}
                  onChange={(e) => setCampaign(prev => ({ ...prev, name: e.target.value }))}
                  placeholder="Enter campaign name"
                />
              </div>
              <div>
                <Label htmlFor="subject">Email Subject</Label>
                <Input
                  id="subject"
                  value={campaign.subject}
                  onChange={(e) => setCampaign(prev => ({ ...prev, subject: e.target.value }))}
                  placeholder="Enter email subject"
                />
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="template" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <Card>
                <CardHeader>
                  <CardTitle>Template Editor</CardTitle>
                </CardHeader>
                <CardContent>
                  <Textarea
                    value={JSON.stringify(campaign.template_content, null, 2)}
                    onChange={(e) => {
                      try {
                        const content = JSON.parse(e.target.value);
                        setCampaign(prev => ({ ...prev, template_content: content }));
                      } catch {}
                    }}
                    className="h-64 font-mono text-sm"
                    placeholder="Template content (JSON)"
                  />
                </CardContent>
              </Card>
            </div>
            <div>
              <Card>
                <CardHeader>
                  <CardTitle>Template Library</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-2">
                    {templates.map((template) => (
                      <div 
                        key={template.id} 
                        className="p-3 border rounded cursor-pointer hover:bg-gray-50"
                        onClick={() => setCampaign(prev => ({ 
                          ...prev, 
                          template_id: template.id,
                          template_content: template.content 
                        }))}
                      >
                        <div className="font-medium">{template.name}</div>
                        <div className="text-sm text-gray-500">{template.category}</div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        <TabsContent value="testing" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>A/B Testing Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <Switch
                  checked={campaign.ab_test?.enabled}
                  onCheckedChange={(enabled) => 
                    setCampaign(prev => ({ 
                      ...prev, 
                      ab_test: { ...prev.ab_test!, enabled } 
                    }))
                  }
                />
                <Label>Enable A/B Testing</Label>
              </div>
              
              {campaign.ab_test?.enabled && (
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Test Metric</Label>
                    <Select 
                      value={campaign.ab_test.test_metric}
                      onValueChange={(value: any) => 
                        setCampaign(prev => ({ 
                          ...prev, 
                          ab_test: { ...prev.ab_test!, test_metric: value } 
                        }))
                      }
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="open_rate">Open Rate</SelectItem>
                        <SelectItem value="click_rate">Click Rate</SelectItem>
                        <SelectItem value="conversion_rate">Conversion Rate</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Split Percentage</Label>
                    <Input
                      type="number"
                      value={campaign.ab_test.split_percentage}
                      onChange={(e) => 
                        setCampaign(prev => ({ 
                          ...prev, 
                          ab_test: { ...prev.ab_test!, split_percentage: parseInt(e.target.value) } 
                        }))
                      }
                      min="10"
                      max="90"
                    />
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
            </CardHeader>
            <CardContent>
              {analytics ? (
                <div className="grid grid-cols-4 gap-4">
                  <div className="text-center p-4 border rounded">
                    <div className="text-2xl font-bold text-blue-600">
                      {analytics.analytics?.total_sent || 0}
                    </div>
                    <div className="text-sm text-gray-500">Sent</div>
                  </div>
                  <div className="text-center p-4 border rounded">
                    <div className="text-2xl font-bold text-green-600">
                      {analytics.analytics?.delivered || 0}
                    </div>
                    <div className="text-sm text-gray-500">Delivered</div>
                  </div>
                  <div className="text-center p-4 border rounded">
                    <div className="text-2xl font-bold text-orange-600">
                      {(analytics.analytics?.open_rate || 0).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-500">Open Rate</div>
                  </div>
                  <div className="text-center p-4 border rounded">
                    <div className="text-2xl font-bold text-purple-600">
                      {(analytics.analytics?.click_rate || 0).toFixed(1)}%
                    </div>
                    <div className="text-sm text-gray-500">Click Rate</div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <BarChart3 className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">No analytics data available</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};