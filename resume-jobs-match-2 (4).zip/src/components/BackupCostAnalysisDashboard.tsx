import React, { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { DollarSign, TrendingDown, TrendingUp, Download, Lightbulb } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { backupCostAnalysisService, RegionCost, CostProjection, CostRecommendation } from '@/services/backupCostAnalysisService';

export const BackupCostAnalysisDashboard: React.FC = () => {
  const [regionCosts, setRegionCosts] = useState<RegionCost[]>([]);
  const [projections, setProjections] = useState<CostProjection[]>([]);
  const [recommendations, setRecommendations] = useState<CostRecommendation[]>([]);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    const [regions, proj, recs] = await Promise.all([
      backupCostAnalysisService.getRegionCosts(),
      backupCostAnalysisService.getCostProjections(),
      backupCostAnalysisService.getRecommendations()
    ]);
    setRegionCosts(regions);
    setProjections(proj);
    setRecommendations(recs);
  };

  const totalCost = regionCosts.reduce((sum, r) => sum + r.totalCost, 0);
  const totalStorage = regionCosts.reduce((sum, r) => sum + r.storageGB, 0);
  const avgCostPerGB = totalCost / totalStorage;
  const potentialSavings = recommendations.reduce((sum, r) => sum + r.potentialSavings, 0);

  const exportReport = () => {
    const report = { regionCosts, projections, recommendations, totalCost, generatedAt: new Date().toISOString() };
    const blob = new Blob([JSON.stringify(report, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `backup-cost-report-${Date.now()}.json`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Cost Analytics & Optimization</h2>
        <Button onClick={exportReport}>
          <Download className="w-4 h-4 mr-2" />
          Export Report
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Total Monthly Cost</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${totalCost.toFixed(2)}</div>
            <p className="text-sm text-gray-600 mt-1">Across all regions</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Avg Cost per GB</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">${avgCostPerGB.toFixed(4)}</div>
            <p className="text-sm text-gray-600 mt-1">Blended rate</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Total Storage</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{totalStorage.toFixed(0)} GB</div>
            <p className="text-sm text-gray-600 mt-1">{regionCosts.reduce((s, r) => s + r.backupCount, 0)} backups</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm">Potential Savings</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">${potentialSavings.toFixed(2)}</div>
            <p className="text-sm text-gray-600 mt-1">{recommendations.length} opportunities</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Cost Projections</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={projections}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" />
              <YAxis />
              <Tooltip formatter={(value: number) => `$${value.toFixed(2)}`} />
              <Legend />
              <Line type="monotone" dataKey="projectedCost" stroke="#3b82f6" name="Projected" />
              <Line type="monotone" dataKey="actualCost" stroke="#10b981" name="Actual" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Cost Optimization Recommendations</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recommendations.map((rec) => (
              <div key={rec.id} className="flex items-start gap-4 p-4 bg-gray-50 rounded-lg">
                <Lightbulb className={`w-5 h-5 mt-1 ${rec.priority === 'high' ? 'text-orange-500' : 'text-blue-500'}`} />
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-semibold">{rec.title}</h4>
                    <Badge variant={rec.priority === 'high' ? 'destructive' : 'secondary'}>
                      {rec.priority}
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-2">{rec.description}</p>
                  <p className="text-sm font-semibold text-green-600">
                    Potential savings: ${rec.potentialSavings}/month
                  </p>
                </div>
                <Button size="sm">Apply</Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
