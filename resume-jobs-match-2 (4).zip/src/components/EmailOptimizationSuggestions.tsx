import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Alert, AlertDescription } from './ui/alert';
import { 
  Lightbulb, 
  TrendingUp, 
  AlertTriangle, 
  CheckCircle,
  Target,
  Clock,
  Users,
  Mail,
  Zap,
  BarChart3
} from 'lucide-react';

interface OptimizationSuggestion {
  id: string;
  type: 'subject' | 'timing' | 'content' | 'audience' | 'frequency';
  priority: 'high' | 'medium' | 'low';
  title: string;
  description: string;
  impact: string;
  confidence: number;
  implementationEffort: 'easy' | 'medium' | 'complex';
  expectedImprovement: string;
  basedOn: string;
  action: string;
}

interface PerformanceInsight {
  metric: string;
  current: number;
  benchmark: number;
  trend: 'up' | 'down' | 'stable';
  recommendation: string;
}

export const EmailOptimizationSuggestions: React.FC = () => {
  const [suggestions, setSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [insights, setInsights] = useState<PerformanceInsight[]>([]);
  const [selectedPriority, setSelectedPriority] = useState<string>('all');

  useEffect(() => {
    // Simulate AI-generated optimization suggestions
    setSuggestions([
      {
        id: '1',
        type: 'subject',
        priority: 'high',
        title: 'Optimize Subject Line Length',
        description: 'Your subject lines average 65 characters. Shorter subjects (30-50 chars) show 23% higher open rates.',
        impact: '+23% open rate',
        confidence: 94,
        implementationEffort: 'easy',
        expectedImprovement: '15-25% increase in opens',
        basedOn: 'Analysis of 10,000+ emails',
        action: 'Reduce subject line length to 30-50 characters'
      },
      {
        id: '2',
        type: 'timing',
        priority: 'high',
        title: 'Adjust Send Time',
        description: 'Your audience shows peak engagement at 10 AM and 2 PM on Tuesdays and Thursdays.',
        impact: '+18% engagement',
        confidence: 87,
        implementationEffort: 'easy',
        expectedImprovement: '10-20% increase in clicks',
        basedOn: 'User behavior analysis',
        action: 'Schedule emails for Tuesday/Thursday 10 AM or 2 PM'
      },
      {
        id: '3',
        type: 'content',
        priority: 'medium',
        title: 'Add Personalization',
        description: 'Emails with personalized content beyond first name show 41% higher click rates.',
        impact: '+41% click rate',
        confidence: 92,
        implementationEffort: 'medium',
        expectedImprovement: '30-45% increase in clicks',
        basedOn: 'Personalization effectiveness study',
        action: 'Include purchase history, location, or behavior-based content'
      },
      {
        id: '4',
        type: 'audience',
        priority: 'medium',
        title: 'Segment by Engagement Level',
        description: 'Create separate campaigns for highly engaged vs. less engaged subscribers.',
        impact: '+28% overall performance',
        confidence: 85,
        implementationEffort: 'medium',
        expectedImprovement: '20-35% improvement across metrics',
        basedOn: 'Segmentation analysis',
        action: 'Create engagement-based segments and tailored content'
      },
      {
        id: '5',
        type: 'frequency',
        priority: 'low',
        title: 'Optimize Send Frequency',
        description: 'Your current 3x/week frequency may be causing fatigue. Test 2x/week for better engagement.',
        impact: '+12% retention',
        confidence: 78,
        implementationEffort: 'easy',
        expectedImprovement: '8-15% reduction in unsubscribes',
        basedOn: 'Frequency analysis',
        action: 'Reduce send frequency to 2 emails per week'
      }
    ]);

    setInsights([
      {
        metric: 'Open Rate',
        current: 22.5,
        benchmark: 25.2,
        trend: 'down',
        recommendation: 'Focus on subject line optimization and sender reputation'
      },
      {
        metric: 'Click Rate',
        current: 3.8,
        benchmark: 4.2,
        trend: 'stable',
        recommendation: 'Improve call-to-action placement and content relevance'
      },
      {
        metric: 'Unsubscribe Rate',
        current: 0.8,
        benchmark: 0.5,
        trend: 'up',
        recommendation: 'Review send frequency and content quality'
      },
      {
        metric: 'Bounce Rate',
        current: 2.1,
        benchmark: 2.0,
        trend: 'stable',
        recommendation: 'Maintain current list hygiene practices'
      }
    ]);
  }, []);

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getEffortColor = (effort: string) => {
    switch (effort) {
      case 'easy': return 'text-green-600';
      case 'medium': return 'text-yellow-600';
      case 'complex': return 'text-red-600';
      default: return 'text-gray-600';
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'subject': return <Mail className="w-4 h-4" />;
      case 'timing': return <Clock className="w-4 h-4" />;
      case 'content': return <Target className="w-4 h-4" />;
      case 'audience': return <Users className="w-4 h-4" />;
      case 'frequency': return <BarChart3 className="w-4 h-4" />;
      default: return <Lightbulb className="w-4 h-4" />;
    }
  };

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case 'up': return <TrendingUp className="w-4 h-4 text-green-600" />;
      case 'down': return <AlertTriangle className="w-4 h-4 text-red-600" />;
      default: return <CheckCircle className="w-4 h-4 text-blue-600" />;
    }
  };

  const filteredSuggestions = selectedPriority === 'all' 
    ? suggestions 
    : suggestions.filter(s => s.priority === selectedPriority);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">AI-Powered Optimization Suggestions</h2>
        <div className="flex gap-2">
          <Button 
            variant={selectedPriority === 'all' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSelectedPriority('all')}
          >
            All
          </Button>
          <Button 
            variant={selectedPriority === 'high' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSelectedPriority('high')}
          >
            High Priority
          </Button>
          <Button 
            variant={selectedPriority === 'medium' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSelectedPriority('medium')}
          >
            Medium
          </Button>
          <Button 
            variant={selectedPriority === 'low' ? 'default' : 'outline'} 
            size="sm"
            onClick={() => setSelectedPriority('low')}
          >
            Low
          </Button>
        </div>
      </div>

      {/* Performance Insights */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <BarChart3 className="w-5 h-5" />
            Performance vs. Benchmarks
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {insights.map((insight, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium">{insight.metric}</span>
                  {getTrendIcon(insight.trend)}
                </div>
                <div className="text-2xl font-bold mb-1">{insight.current}%</div>
                <div className="text-sm text-gray-600 mb-2">
                  Benchmark: {insight.benchmark}%
                </div>
                <div className="text-xs text-gray-500">{insight.recommendation}</div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Optimization Suggestions */}
      <div className="space-y-4">
        {filteredSuggestions.map((suggestion) => (
          <Card key={suggestion.id} className="hover:shadow-md transition-shadow">
            <CardContent className="pt-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center gap-3">
                  {getTypeIcon(suggestion.type)}
                  <div>
                    <h3 className="font-semibold text-lg">{suggestion.title}</h3>
                    <p className="text-gray-600 mt-1">{suggestion.description}</p>
                  </div>
                </div>
                <div className="flex gap-2">
                  <Badge className={getPriorityColor(suggestion.priority)}>
                    {suggestion.priority} priority
                  </Badge>
                  <Badge variant="outline">
                    {suggestion.confidence}% confidence
                  </Badge>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
                <div className="bg-blue-50 p-3 rounded-lg">
                  <div className="text-sm text-gray-600">Expected Impact</div>
                  <div className="font-semibold text-blue-600">{suggestion.impact}</div>
                </div>
                <div className="bg-green-50 p-3 rounded-lg">
                  <div className="text-sm text-gray-600">Implementation</div>
                  <div className={`font-semibold ${getEffortColor(suggestion.implementationEffort)}`}>
                    {suggestion.implementationEffort}
                  </div>
                </div>
                <div className="bg-purple-50 p-3 rounded-lg">
                  <div className="text-sm text-gray-600">Improvement</div>
                  <div className="font-semibold text-purple-600">{suggestion.expectedImprovement}</div>
                </div>
              </div>

              <Alert className="mb-4">
                <Lightbulb className="h-4 w-4" />
                <AlertDescription>
                  <strong>Action:</strong> {suggestion.action}
                  <br />
                  <span className="text-sm text-gray-600">Based on: {suggestion.basedOn}</span>
                </AlertDescription>
              </Alert>

              <div className="flex gap-2">
                <Button size="sm">
                  <Zap className="w-4 h-4 mr-2" />
                  Implement
                </Button>
                <Button variant="outline" size="sm">
                  Learn More
                </Button>
                <Button variant="ghost" size="sm">
                  Dismiss
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};