import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Loader2, Briefcase, FileText, MessageSquare, CheckCircle, Play, Zap } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useToast } from '@/hooks/use-toast';
import { Progress } from '@/components/ui/progress';

interface DailyJob {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  matchScore: number;
  resumeStatus: 'pending' | 'generating' | 'ready';
  coverLetterStatus: 'pending' | 'generating' | 'ready';
  interviewPrepStatus: 'pending' | 'ready';
  applicationStatus: 'pending' | 'ready' | 'submitted';
}

const DEMO_JOBS: DailyJob[] = [
  { id: '1', title: 'Senior Software Engineer', company: 'TechCorp', location: 'San Francisco, CA', salary: '$140k-180k', matchScore: 94, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '2', title: 'Full Stack Developer', company: 'StartupXYZ', location: 'Austin, TX', salary: '$120k-160k', matchScore: 91, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '3', title: 'Frontend Engineer', company: 'DesignCo', location: 'New York, NY', salary: '$110k-150k', matchScore: 89, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '4', title: 'Backend Developer', company: 'DataSystems', location: 'Seattle, WA', salary: '$130k-170k', matchScore: 88, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '5', title: 'DevOps Engineer', company: 'CloudTech', location: 'Boston, MA', salary: '$125k-165k', matchScore: 87, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '6', title: 'Software Architect', company: 'Enterprise Inc', location: 'Chicago, IL', salary: '$150k-200k', matchScore: 86, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '7', title: 'Mobile Developer', company: 'AppStudio', location: 'Los Angeles, CA', salary: '$115k-155k', matchScore: 85, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '8', title: 'ML Engineer', company: 'AI Labs', location: 'San Francisco, CA', salary: '$145k-190k', matchScore: 84, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '9', title: 'Security Engineer', company: 'SecureNet', location: 'Denver, CO', salary: '$135k-175k', matchScore: 83, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' },
  { id: '10', title: 'Platform Engineer', company: 'InfraCo', location: 'Portland, OR', salary: '$128k-168k', matchScore: 82, resumeStatus: 'ready', coverLetterStatus: 'ready', interviewPrepStatus: 'ready', applicationStatus: 'ready' }
];

export default function DailyJobMatchingOrchestrator() {
  const [jobs, setJobs] = useState<DailyJob[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [currentStep, setCurrentStep] = useState('');
  const [progress, setProgress] = useState(0);
  const { toast } = useToast();

  const runDemoMode = () => {
    setIsRunning(true);
    setCurrentStep('Running demo workflow...');
    setProgress(0);
    
    // Simulate processing
    const interval = setInterval(() => {
      setProgress(p => {
        if (p >= 100) {
          clearInterval(interval);
          setJobs(DEMO_JOBS);
          setCurrentStep('Demo complete! 10 jobs ready with optimized materials.');
          setIsRunning(false);
          toast({ 
            title: '✅ Demo workflow complete!', 
            description: '10 jobs ready with custom resumes, cover letters & interview prep' 
          });
          return 100;
        }
        return p + 2;
      });
    }, 50);
  };

  const runDailyWorkflow = async () => {
    setIsRunning(true);
    setProgress(0);
    try {
      // Step 1: Find 10 matching jobs
      setCurrentStep('Finding your top 10 job matches...');
      setProgress(10);
      const { data: { user } } = await supabase.auth.getUser();
      const { data: matchedJobs } = await supabase.functions.invoke('ai-job-matching', {
        body: { userId: user?.id, limit: 10 }
      });

      const jobsList: DailyJob[] = matchedJobs?.jobs?.map((job: any) => ({
        id: job.id,
        title: job.title,
        company: job.company,
        location: job.location,
        salary: job.salary || 'Competitive',
        matchScore: job.matchScore,
        resumeStatus: 'pending',
        coverLetterStatus: 'pending',
        interviewPrepStatus: 'pending',
        applicationStatus: 'pending'
      })) || [];
      setJobs(jobsList);
      setProgress(30);

      // Step 2: Generate customized resumes
      for (let i = 0; i < jobsList.length; i++) {
        setCurrentStep(`Customizing resume ${i + 1}/10...`);
        jobsList[i].resumeStatus = 'generating';
        setJobs([...jobsList]);
        
        await supabase.functions.invoke('resume-optimizer', {
          body: { jobId: jobsList[i].id, userId: user?.id }
        });
        
        jobsList[i].resumeStatus = 'ready';
        setJobs([...jobsList]);
        setProgress(30 + ((i + 1) / jobsList.length) * 30);
      }

      // Step 3: Generate cover letters
      for (let i = 0; i < jobsList.length; i++) {
        setCurrentStep(`Writing cover letter ${i + 1}/10...`);
        jobsList[i].coverLetterStatus = 'generating';
        setJobs([...jobsList]);
        
        await supabase.functions.invoke('smart-autofill', {
          body: { jobId: jobsList[i].id, type: 'cover_letter' }
        });
        
        jobsList[i].coverLetterStatus = 'ready';
        jobsList[i].interviewPrepStatus = 'ready';
        jobsList[i].applicationStatus = 'ready';
        setJobs([...jobsList]);
        setProgress(60 + ((i + 1) / jobsList.length) * 40);
      }

      setCurrentStep('Complete! Ready to apply.');
      setProgress(100);
      toast({ title: '✅ Daily job prep complete!', description: '10 jobs ready with custom resumes & cover letters' });
    } catch (error) {
      toast({ title: 'Error', description: 'Workflow failed', variant: 'destructive' });
    } finally {
      setIsRunning(false);
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6 bg-gradient-to-br from-blue-50 to-purple-50 border-2 border-blue-200">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
              Daily Job Matching
            </h2>
            <p className="text-gray-600 mt-1">AI finds 10 jobs, customizes everything, preps you for interviews</p>
          </div>
          <div className="flex gap-3">
            <Button onClick={runDemoMode} disabled={isRunning} size="lg" variant="outline" className="border-2 border-purple-300">
              <Zap className="mr-2 h-5 w-5" />
              Demo Mode
            </Button>
            <Button onClick={runDailyWorkflow} disabled={isRunning} size="lg" className="bg-gradient-to-r from-blue-600 to-purple-600">
              {isRunning ? <Loader2 className="mr-2 h-5 w-5 animate-spin" /> : <Play className="mr-2 h-5 w-5" />}
              Start Workflow
            </Button>
          </div>
        </div>
        {isRunning && (
          <div className="space-y-2">
            <p className="text-sm text-blue-600 font-medium">{currentStep}</p>
            <Progress value={progress} className="h-2" />
          </div>
        )}
      </Card>

      {jobs.length > 0 && (
        <div className="grid gap-4">
          {jobs.map((job, idx) => (
            <Card key={job.id} className="p-5 hover:shadow-lg transition-all border-2 hover:border-blue-300">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <Badge variant="secondary" className="text-base">#{idx + 1}</Badge>
                    <h3 className="font-semibold text-lg">{job.title}</h3>
                    <Badge className="bg-green-600 text-white">{job.matchScore}% Match</Badge>
                  </div>
                  <p className="text-sm text-gray-600 mb-3">{job.company} • {job.location} • {job.salary}</p>
                  
                  <div className="flex gap-6">
                    <div className="flex items-center gap-2">
                      <FileText className="h-5 w-5 text-blue-600" />
                      <span className="text-sm font-medium">Resume:</span>
                      {job.resumeStatus === 'ready' && <CheckCircle className="h-5 w-5 text-green-600" />}
                      {job.resumeStatus === 'generating' && <Loader2 className="h-5 w-5 animate-spin text-blue-600" />}
                      {job.resumeStatus === 'pending' && <span className="text-xs text-gray-400">Pending</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <MessageSquare className="h-5 w-5 text-purple-600" />
                      <span className="text-sm font-medium">Cover Letter:</span>
                      {job.coverLetterStatus === 'ready' && <CheckCircle className="h-5 w-5 text-green-600" />}
                      {job.coverLetterStatus === 'generating' && <Loader2 className="h-5 w-5 animate-spin text-purple-600" />}
                      {job.coverLetterStatus === 'pending' && <span className="text-xs text-gray-400">Pending</span>}
                    </div>
                    <div className="flex items-center gap-2">
                      <Briefcase className="h-5 w-5 text-green-600" />
                      <span className="text-sm font-medium">Interview Prep:</span>
                      {job.interviewPrepStatus === 'ready' && <CheckCircle className="h-5 w-5 text-green-600" />}
                      {job.interviewPrepStatus === 'pending' && <span className="text-xs text-gray-400">Pending</span>}
                    </div>
                  </div>
                </div>
                <Button 
                  disabled={job.applicationStatus !== 'ready'} 
                  size="lg"
                  className="bg-gradient-to-r from-green-600 to-blue-600"
                >
                  Apply Now
                </Button>
              </div>
            </Card>
          ))}
        </div>
      )}

      {jobs.length === 0 && !isRunning && (
        <Card className="p-12 text-center bg-gradient-to-br from-gray-50 to-blue-50">
          <Briefcase className="w-16 h-16 text-gray-400 mx-auto mb-4" />
          <h3 className="text-xl font-semibold text-gray-700 mb-2">No jobs processed yet</h3>
          <p className="text-gray-600">Click "Demo Mode" for instant results or "Start Workflow" to process real jobs</p>
        </Card>
      )}
    </div>
  );
}
