import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Progress } from '@/components/ui/progress';
import { Switch } from '@/components/ui/switch';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { jobBoardApiService, JobBoardJob, JobSearchParams } from '@/services/jobBoardApiService';
import { 
  Play, 
  Pause, 
  Settings, 
  Target, 
  Clock, 
  CheckCircle, 
  XCircle, 
  AlertCircle,
  Search,
  Filter,
  BarChart3,
  Zap
} from 'lucide-react';

interface ApplicationStatus {
  id: string;
  jobId: string;
  jobTitle: string;
  company: string;
  source: string;
  status: 'pending' | 'submitted' | 'customizing' | 'failed' | 'rate_limited';
  submittedAt?: string;
  customized: boolean;
  matchScore: number;
  error?: string;
}
export function BulkApplicationEngine() {
  const [matchedJobs, setMatchedJobs] = useState<JobBoardJob[]>([]);
  const [applications, setApplications] = useState<ApplicationStatus[]>([]);
  const [isRunning, setIsRunning] = useState(false);
  const [searchParams, setSearchParams] = useState<JobSearchParams>({
    keywords: 'Software Engineer',
    location: 'Remote',
    limit: 25
  });
  const [isSearching, setIsSearching] = useState(false);

  const searchJobs = async () => {
    setIsSearching(true);
    try {
      const results = await jobBoardApiService.bulkSearchJobs(searchParams);
      const allJobs = results.flatMap(result => result.jobs);
      setMatchedJobs(allJobs);
    } catch (error) {
      console.error('Job search failed:', error);
    } finally {
      setIsSearching(false);
    }
  };

  const startBulkApplication = async () => {
    setIsRunning(true);
    setApplications([]);
    
    for (let i = 0; i < matchedJobs.length; i++) {
      const job = matchedJobs[i];
      const status: ApplicationStatus = {
        id: `app_${Date.now()}_${i}`,
        jobId: job.id,
        jobTitle: job.title,
        company: job.company,
        source: job.source,
        status: 'customizing',
        customized: true,
        matchScore: Math.floor(Math.random() * 30) + 70
      };
      
      setApplications(prev => [...prev, status]);
      
      // Simulate application process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      setApplications(prev => prev.map(app => 
        app.id === status.id 
          ? { ...app, status: Math.random() > 0.1 ? 'submitted' : 'failed', submittedAt: new Date().toISOString() }
          : app
      ));
    }
    
    setIsRunning(false);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Bulk Application Engine</h2>
        <div className="flex gap-2">
          <Button onClick={searchJobs} disabled={isSearching}>
            <Search className="h-4 w-4 mr-2" />
            {isSearching ? 'Searching...' : 'Search Jobs'}
          </Button>
          <Button onClick={startBulkApplication} disabled={isRunning || matchedJobs.length === 0}>
            {isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
            {isRunning ? 'Running...' : 'Start Applications'}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Matched Jobs</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{matchedJobs.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{applications.length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Submitted</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{applications.filter(a => a.status === 'submitted').length}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm">Success Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {applications.length > 0 ? Math.round((applications.filter(a => a.status === 'submitted').length / applications.length) * 100) : 0}%
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="search">
        <TabsList>
          <TabsTrigger value="search">Job Search</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
        </TabsList>

        <TabsContent value="search" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Search Parameters</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label>Keywords</Label>
                  <Input
                    value={searchParams.keywords || ''}
                    onChange={(e) => setSearchParams(prev => ({ ...prev, keywords: e.target.value }))}
                    placeholder="e.g. Software Engineer"
                  />
                </div>
                <div>
                  <Label>Location</Label>
                  <Input
                    value={searchParams.location || ''}
                    onChange={(e) => setSearchParams(prev => ({ ...prev, location: e.target.value }))}
                    placeholder="e.g. Remote, New York"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <div className="space-y-4">
            {matchedJobs.map((job) => (
              <Card key={job.id}>
                <CardContent className="pt-6">
                  <div className="flex justify-between">
                    <div>
                      <h3 className="font-semibold">{job.title}</h3>
                      <p className="text-sm text-gray-600">{job.company} • {job.location}</p>
                      <div className="flex gap-2 mt-2">
                        <Badge variant="secondary">{job.source}</Badge>
                        {job.salary && <Badge variant="outline">{job.salary}</Badge>}
                      </div>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="applications" className="space-y-4">
          {applications.map((app) => (
            <Card key={app.id}>
              <CardContent className="pt-6">
                <div className="flex justify-between">
                  <div>
                    <h3 className="font-semibold">{app.jobTitle}</h3>
                    <p className="text-sm text-gray-600">{app.company}</p>
                    <div className="flex gap-2 mt-2">
                      <Badge variant={app.status === 'submitted' ? 'default' : app.status === 'failed' ? 'destructive' : 'secondary'}>
                        {app.status}
                      </Badge>
                      <Badge variant="outline">Match: {app.matchScore}%</Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    {app.submittedAt && (
                      <p className="text-sm text-gray-600">
                        {new Date(app.submittedAt).toLocaleString()}
                      </p>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>
      </Tabs>
    </div>
  );
}