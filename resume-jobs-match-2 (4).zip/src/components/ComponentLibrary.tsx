import React from 'react';
import { Card } from '@/components/ui/card';
import { 
  Type, 
  MousePointer, 
  Image, 
  Minus, 
  Space,
  Heading1,
  Layout,
  Grid3X3
} from 'lucide-react';

interface ComponentItem {
  id: string;
  name: string;
  icon: React.ReactNode;
  description: string;
  category: string;
}

const components: ComponentItem[] = [
  {
    id: 'header',
    name: 'Header',
    icon: <Heading1 className="w-5 h-5" />,
    description: 'Title and subtitle section',
    category: 'Content'
  },
  {
    id: 'text',
    name: 'Text Block',
    icon: <Type className="w-5 h-5" />,
    description: 'Rich text content',
    category: 'Content'
  },
  {
    id: 'button',
    name: 'Button',
    icon: <MousePointer className="w-5 h-5" />,
    description: 'Call-to-action button',
    category: 'Interactive'
  },
  {
    id: 'image',
    name: 'Image',
    icon: <Image className="w-5 h-5" />,
    description: 'Image with optional link',
    category: 'Media'
  },
  {
    id: 'spacer',
    name: 'Spacer',
    icon: <Space className="w-5 h-5" />,
    description: 'Add vertical spacing',
    category: 'Layout'
  },
  {
    id: 'divider',
    name: 'Divider',
    icon: <Minus className="w-5 h-5" />,
    description: 'Horizontal line separator',
    category: 'Layout'
  }
];

const categories = ['Content', 'Interactive', 'Media', 'Layout'];

export const ComponentLibrary: React.FC = () => {
  const handleDragStart = (e: React.DragEvent, componentType: string) => {
    e.dataTransfer.setData('text/plain', componentType);
  };

  return (
    <div className="h-full p-4 overflow-y-auto">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Components</h3>
        <p className="text-sm text-gray-600">Drag components to the canvas to build your email</p>
      </div>

      {categories.map(category => (
        <div key={category} className="mb-6">
          <h4 className="text-sm font-medium text-gray-700 mb-3 uppercase tracking-wide">
            {category}
          </h4>
          
          <div className="space-y-2">
            {components
              .filter(comp => comp.category === category)
              .map(component => (
                <Card
                  key={component.id}
                  className="p-3 cursor-grab hover:bg-gray-50 transition-colors border-gray-200"
                  draggable
                  onDragStart={(e) => handleDragStart(e, component.id)}
                >
                  <div className="flex items-start space-x-3">
                    <div className="flex-shrink-0 text-gray-600">
                      {component.icon}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h5 className="text-sm font-medium text-gray-900">
                        {component.name}
                      </h5>
                      <p className="text-xs text-gray-500 mt-1">
                        {component.description}
                      </p>
                    </div>
                  </div>
                </Card>
              ))}
          </div>
        </div>
      ))}

      <div className="mt-8 p-4 bg-blue-50 rounded-lg">
        <h4 className="text-sm font-medium text-blue-900 mb-2">
          <Layout className="w-4 h-4 inline mr-2" />
          Quick Tips
        </h4>
        <ul className="text-xs text-blue-800 space-y-1">
          <li>• Drag components to the canvas</li>
          <li>• Click to select and edit</li>
          <li>• Use spacers for layout</li>
          <li>• Preview on different devices</li>
        </ul>
      </div>
    </div>
  );
};