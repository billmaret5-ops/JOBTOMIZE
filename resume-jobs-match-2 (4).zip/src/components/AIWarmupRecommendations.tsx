import { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Sparkles, TrendingUp, AlertCircle, CheckCircle, Clock } from 'lucide-react';
import { warmupTemplateService } from '@/services/warmupTemplateService';
import { Progress } from '@/components/ui/progress';

export default function AIWarmupRecommendations() {
  const [domainAge, setDomainAge] = useState(30);
  const [reputation, setReputation] = useState(50);
  const [targetVolume, setTargetVolume] = useState(5000);
  const [recommendations, setRecommendations] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleGetRecommendations = async () => {
    try {
      setLoading(true);
      const data = await warmupTemplateService.getAIRecommendation({
        domain_age_days: domainAge,
        sender_reputation: reputation,
        target_volume: targetVolume
      });
      setRecommendations(data);
    } catch (error) {
      console.error('Error getting recommendations:', error);
      // Mock data for demo
      setRecommendations({
        recommended_template: 'moderate',
        confidence: 87,
        estimated_duration: 28,
        success_probability: 92,
        risk_level: 'low',
        tips: [
          'Start with 50 emails per day for the first week',
          'Maintain engagement rate above 70%',
          'Monitor bounce rates closely in first 14 days',
          'Gradually increase volume by 50% weekly',
          'Use authenticated sending domains'
        ],
        schedule_preview: [
          { day: 1, volume: 50, engagement: 80 },
          { day: 7, volume: 150, engagement: 75 },
          { day: 14, volume: 400, engagement: 72 },
          { day: 21, volume: 1000, engagement: 68 },
          { day: 28, volume: 2500, engagement: 65 }
        ]
      });
    } finally {
      setLoading(false);
    }
  };

  const getRiskColor = (risk: string) => {
    switch (risk) {
      case 'low': return 'text-green-600 bg-green-100';
      case 'medium': return 'text-yellow-600 bg-yellow-100';
      case 'high': return 'text-red-600 bg-red-100';
      default: return 'text-gray-600 bg-gray-100';
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-3xl font-bold flex items-center gap-2">
          <Sparkles className="h-8 w-8 text-purple-500" />
          AI Warmup Recommendations
        </h2>
        <p className="text-muted-foreground">Get personalized warmup strategies powered by AI</p>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Your Email Profile</CardTitle>
          <CardDescription>Tell us about your sending profile to get tailored recommendations</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="space-y-2">
              <Label>Domain Age (days)</Label>
              <Input type="number" value={domainAge} onChange={(e) => setDomainAge(parseInt(e.target.value))} />
              <p className="text-xs text-muted-foreground">How old is your sending domain?</p>
            </div>
            <div className="space-y-2">
              <Label>Current Reputation Score</Label>
              <Input type="number" value={reputation} onChange={(e) => setReputation(parseInt(e.target.value))} max={100} />
              <p className="text-xs text-muted-foreground">0-100 scale</p>
            </div>
            <div className="space-y-2">
              <Label>Target Daily Volume</Label>
              <Input type="number" value={targetVolume} onChange={(e) => setTargetVolume(parseInt(e.target.value))} />
              <p className="text-xs text-muted-foreground">Emails per day goal</p>
            </div>
          </div>
          <Button onClick={handleGetRecommendations} disabled={loading} className="w-full">
            <Sparkles className="h-4 w-4 mr-2" />
            {loading ? 'Analyzing...' : 'Get AI Recommendations'}
          </Button>
        </CardContent>
      </Card>

      {recommendations && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Recommended Template</p>
                  <p className="text-2xl font-bold capitalize">{recommendations.recommended_template}</p>
                  <Badge className="mt-2">Best Match</Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">AI Confidence</p>
                  <p className="text-2xl font-bold">{recommendations.confidence}%</p>
                  <Progress value={recommendations.confidence} className="mt-2" />
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Est. Duration</p>
                  <p className="text-2xl font-bold flex items-center justify-center gap-1">
                    <Clock className="h-5 w-5" />
                    {recommendations.estimated_duration}d
                  </p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-center">
                  <p className="text-sm text-muted-foreground">Risk Level</p>
                  <Badge className={`mt-2 ${getRiskColor(recommendations.risk_level)}`}>
                    {recommendations.risk_level.toUpperCase()}
                  </Badge>
                  <p className="text-sm mt-2">{recommendations.success_probability}% success</p>
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Tips & Best Practices</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recommendations.tips.map((tip: string, index: number) => (
                  <div key={index} className="flex items-start gap-3 p-3 bg-muted rounded-lg">
                    <CheckCircle className="h-5 w-5 text-green-500 mt-0.5 flex-shrink-0" />
                    <p className="text-sm">{tip}</p>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Recommended Schedule Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {recommendations.schedule_preview.map((day: any, index: number) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-4">
                      <Badge variant="outline">Day {day.day}</Badge>
                      <span className="text-sm">Volume: <strong>{day.volume}</strong> emails</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <span className="text-sm text-muted-foreground">Target: {day.engagement}%</span>
                      <TrendingUp className="h-4 w-4 text-green-500" />
                    </div>
                  </div>
                ))}
              </div>
              <Button className="w-full mt-4">Apply This Schedule</Button>
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  );
}
