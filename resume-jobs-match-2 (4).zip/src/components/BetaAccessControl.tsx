import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Loader2, CheckCircle, XCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface BetaAccessControlProps {
  onAccessGranted: () => void;
}

export default function BetaAccessControl({ onAccessGranted }: BetaAccessControlProps) {
  const [inviteCode, setInviteCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [checking, setChecking] = useState(true);
  const [hasAccess, setHasAccess] = useState(false);
  const { toast } = useToast();

  useEffect(() => {
    checkExistingAccess();
  }, []);

  const checkExistingAccess = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        setChecking(false);
        return;
      }

      const { data, error } = await supabase
        .from('beta_access')
        .select('*')
        .eq('user_id', user.id)
        .single();

      if (data && !error) {
        setHasAccess(true);
        onAccessGranted();
      }
    } catch (error) {
      console.error('Error checking access:', error);
    } finally {
      setChecking(false);
    }
  };

  const validateAndRedeem = async () => {
    if (!inviteCode.trim()) {
      toast({
        title: 'Error',
        description: 'Please enter an invite code',
        variant: 'destructive'
      });
      return;
    }

    setLoading(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      
      if (!user) {
        throw new Error('You must be logged in to redeem an invite code');
      }

      // Check if code exists and is valid
      const { data: invites, error: fetchError } = await supabase
        .from('beta_invites')
        .select('*')
        .eq('code', inviteCode.toUpperCase())
        .single();

      if (fetchError || !invites) {
        throw new Error('Invalid invite code');
      }

      if (invites.status !== 'active') {
        throw new Error('This invite code is no longer active');
      }

      if (invites.current_uses >= invites.max_uses) {
        throw new Error('This invite code has been fully used');
      }

      // Update invite usage
      const { error: updateError } = await supabase
        .from('beta_invites')
        .update({
          current_uses: invites.current_uses + 1,
          status: invites.current_uses + 1 >= invites.max_uses ? 'used' : 'active'
        })
        .eq('code', inviteCode.toUpperCase());

      if (updateError) throw updateError;

      // Grant access
      const { error: accessError } = await supabase
        .from('beta_access')
        .insert({
          user_id: user.id,
          invite_code: inviteCode.toUpperCase(),
          access_level: 'standard'
        });

      if (accessError) throw accessError;

      toast({
        title: 'Success!',
        description: 'Beta access granted. Welcome!'
      });

      setHasAccess(true);
      onAccessGranted();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  if (checking) {
    return (
      <div className="flex items-center justify-center min-h-screen">
        <Loader2 className="w-8 h-8 animate-spin" />
      </div>
    );
  }

  if (hasAccess) {
    return null;
  }

  return (
    <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-4">
      <Card className="p-8 max-w-md w-full">
        <div className="text-center mb-6">
          <h1 className="text-3xl font-bold mb-2">Beta Access Required</h1>
          <p className="text-muted-foreground">
            This platform is currently in beta. Enter your invite code to continue.
          </p>
        </div>

        <div className="space-y-4">
          <Input
            placeholder="Enter invite code (e.g., BETA-ABC123)"
            value={inviteCode}
            onChange={(e) => setInviteCode(e.target.value.toUpperCase())}
            onKeyPress={(e) => e.key === 'Enter' && validateAndRedeem()}
          />
          
          <Button 
            onClick={validateAndRedeem} 
            className="w-full" 
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                Validating...
              </>
            ) : (
              'Redeem Code'
            )}
          </Button>

          <div className="text-center">
            <p className="text-sm text-muted-foreground mb-2">
              Don't have an invite code?
            </p>
            <Button variant="link" onClick={() => window.location.href = '/waitlist'}>
              Join the Waitlist
            </Button>
          </div>
        </div>
      </Card>
    </div>
  );
}