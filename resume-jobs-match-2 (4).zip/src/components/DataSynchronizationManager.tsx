import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  RefreshCw, 
  Database, 
  Clock, 
  AlertTriangle, 
  CheckCircle, 
  TrendingUp,
  Calendar,
  Activity
} from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, BarChart, Bar } from 'recharts';

interface SyncJob {
  id: string;
  provider: string;
  type: 'templates' | 'campaigns' | 'analytics' | 'contacts';
  status: 'pending' | 'running' | 'completed' | 'failed';
  progress: number;
  startTime: string;
  endTime?: string;
  recordsProcessed: number;
  totalRecords: number;
  errorMessage?: string;
}

interface SyncMetrics {
  totalSyncs: number;
  successfulSyncs: number;
  failedSyncs: number;
  averageDuration: number;
  dataPointsSynced: number;
  lastSyncTime: string;
}

export const DataSynchronizationManager: React.FC = () => {
  const [syncJobs, setSyncJobs] = useState<SyncJob[]>([]);
  const [metrics, setMetrics] = useState<SyncMetrics>({
    totalSyncs: 156,
    successfulSyncs: 148,
    failedSyncs: 8,
    averageDuration: 45,
    dataPointsSynced: 12450,
    lastSyncTime: new Date().toISOString()
  });
  const [isRunningFullSync, setIsRunningFullSync] = useState(false);

  const syncHistory = [
    { time: '00:00', success: 12, failed: 1 },
    { time: '04:00', success: 15, failed: 0 },
    { time: '08:00', success: 18, failed: 2 },
    { time: '12:00', success: 22, failed: 1 },
    { time: '16:00', success: 19, failed: 0 },
    { time: '20:00', success: 16, failed: 1 }
  ];

  const providerData = [
    { provider: 'SendGrid', synced: 4500, failed: 45, rate: 99.0 },
    { provider: 'Mailchimp', synced: 3200, failed: 12, rate: 99.6 },
    { provider: 'Mailgun', synced: 2800, failed: 28, rate: 99.0 },
    { provider: 'AWS SES', synced: 1950, failed: 8, rate: 99.6 }
  ];

  useEffect(() => {
    // Initialize with mock sync jobs
    setSyncJobs([
      {
        id: '1',
        provider: 'SendGrid',
        type: 'templates',
        status: 'completed',
        progress: 100,
        startTime: new Date(Date.now() - 300000).toISOString(),
        endTime: new Date(Date.now() - 240000).toISOString(),
        recordsProcessed: 45,
        totalRecords: 45
      },
      {
        id: '2',
        provider: 'Mailchimp',
        type: 'campaigns',
        status: 'running',
        progress: 65,
        startTime: new Date(Date.now() - 120000).toISOString(),
        recordsProcessed: 32,
        totalRecords: 50
      },
      {
        id: '3',
        provider: 'Mailgun',
        type: 'analytics',
        status: 'failed',
        progress: 30,
        startTime: new Date(Date.now() - 600000).toISOString(),
        endTime: new Date(Date.now() - 580000).toISOString(),
        recordsProcessed: 15,
        totalRecords: 50,
        errorMessage: 'Rate limit exceeded'
      }
    ]);

    // Simulate progress updates for running jobs
    const interval = setInterval(() => {
      setSyncJobs(prev => prev.map(job => {
        if (job.status === 'running' && job.progress < 100) {
          const newProgress = Math.min(job.progress + Math.random() * 10, 100);
          const newRecordsProcessed = Math.floor((newProgress / 100) * job.totalRecords);
          
          return {
            ...job,
            progress: newProgress,
            recordsProcessed: newRecordsProcessed,
            ...(newProgress >= 100 && {
              status: 'completed' as const,
              endTime: new Date().toISOString()
            })
          };
        }
        return job;
      }));
    }, 2000);

    return () => clearInterval(interval);
  }, []);

  const handleFullSync = async () => {
    setIsRunningFullSync(true);
    
    // Create sync jobs for all providers
    const newJobs: SyncJob[] = [
      {
        id: Date.now().toString(),
        provider: 'SendGrid',
        type: 'templates',
        status: 'running',
        progress: 0,
        startTime: new Date().toISOString(),
        recordsProcessed: 0,
        totalRecords: 45
      },
      {
        id: (Date.now() + 1).toString(),
        provider: 'Mailchimp',
        type: 'campaigns',
        status: 'pending',
        progress: 0,
        startTime: new Date().toISOString(),
        recordsProcessed: 0,
        totalRecords: 38
      }
    ];

    setSyncJobs(prev => [...newJobs, ...prev]);
    
    setTimeout(() => {
      setIsRunningFullSync(false);
    }, 5000);
  };

  const handleRetryJob = (jobId: string) => {
    setSyncJobs(prev => prev.map(job => 
      job.id === jobId 
        ? { 
            ...job, 
            status: 'running', 
            progress: 0, 
            recordsProcessed: 0,
            startTime: new Date().toISOString(),
            endTime: undefined,
            errorMessage: undefined
          }
        : job
    ));
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'completed': return 'bg-green-500';
      case 'running': return 'bg-blue-500';
      case 'failed': return 'bg-red-500';
      case 'pending': return 'bg-yellow-500';
      default: return 'bg-gray-500';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'completed': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'running': return <Activity className="h-4 w-4 text-blue-500 animate-spin" />;
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      case 'pending': return <Clock className="h-4 w-4 text-yellow-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Data Synchronization</h2>
          <p className="text-muted-foreground">
            Monitor and manage data sync from email service providers
          </p>
        </div>
        <Button 
          onClick={handleFullSync}
          disabled={isRunningFullSync}
          className="flex items-center gap-2"
        >
          <RefreshCw className={`h-4 w-4 ${isRunningFullSync ? 'animate-spin' : ''}`} />
          Full Sync
        </Button>
      </div>

      {/* Metrics Overview */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Syncs</p>
                <p className="text-2xl font-bold">{metrics.totalSyncs}</p>
              </div>
              <Database className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
                <p className="text-2xl font-bold">
                  {((metrics.successfulSyncs / metrics.totalSyncs) * 100).toFixed(1)}%
                </p>
              </div>
              <TrendingUp className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Duration</p>
                <p className="text-2xl font-bold">{metrics.averageDuration}s</p>
              </div>
              <Clock className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Data Points</p>
                <p className="text-2xl font-bold">{metrics.dataPointsSynced.toLocaleString()}</p>
              </div>
              <Activity className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="jobs" className="w-full">
        <TabsList>
          <TabsTrigger value="jobs">Active Jobs</TabsTrigger>
          <TabsTrigger value="history">Sync History</TabsTrigger>
          <TabsTrigger value="providers">Provider Status</TabsTrigger>
        </TabsList>

        <TabsContent value="jobs" className="space-y-4">
          {syncJobs.slice(0, 10).map((job) => (
            <Card key={job.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    {getStatusIcon(job.status)}
                    <span className="font-medium">{job.provider}</span>
                    <Badge variant="outline">{job.type}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-sm text-muted-foreground">
                      {job.recordsProcessed}/{job.totalRecords}
                    </span>
                    {job.status === 'failed' && (
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleRetryJob(job.id)}
                      >
                        Retry
                      </Button>
                    )}
                  </div>
                </div>
                
                {job.status === 'running' && (
                  <Progress value={job.progress} className="mb-2" />
                )}
                
                <div className="flex justify-between text-sm text-muted-foreground">
                  <span>Started: {new Date(job.startTime).toLocaleTimeString()}</span>
                  {job.endTime && (
                    <span>Completed: {new Date(job.endTime).toLocaleTimeString()}</span>
                  )}
                  {job.errorMessage && (
                    <span className="text-red-500">Error: {job.errorMessage}</span>
                  )}
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="history" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sync Activity (Last 24 Hours)</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={syncHistory}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="time" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="success" stroke="#10b981" strokeWidth={2} />
                  <Line type="monotone" dataKey="failed" stroke="#ef4444" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="providers" className="space-y-4">
          <div className="grid gap-4">
            {providerData.map((provider) => (
              <Card key={provider.provider}>
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-medium">{provider.provider}</h3>
                      <p className="text-sm text-muted-foreground">
                        {provider.synced.toLocaleString()} records synced
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge 
                        variant={provider.rate > 99 ? 'default' : 'destructive'}
                        className="mb-1"
                      >
                        {provider.rate}% success
                      </Badge>
                      <p className="text-sm text-muted-foreground">
                        {provider.failed} failed
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};