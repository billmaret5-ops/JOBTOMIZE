import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Save, X, Eye } from 'lucide-react';

interface Template {
  id?: string;
  name: string;
  category: string;
  subject: string;
  content: string;
  isActive: boolean;
}

interface Props {
  template?: Template | null;
  onSave: (template: Template) => void;
  onCancel: () => void;
}

export function DragDropTemplateEditor({ template, onSave, onCancel }: Props) {
  const [formData, setFormData] = useState<Template>({
    name: template?.name || '',
    category: template?.category || 'marketing',
    subject: template?.subject || '',
    content: template?.content || '',
    isActive: template?.isActive || true
  });

  const [preview, setPreview] = useState(false);

  const handleSave = () => {
    onSave(formData);
  };

  const insertToken = (token: string) => {
    setFormData(prev => ({
      ...prev,
      content: prev.content + `{{${token}}}`
    }));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">
          {template ? 'Edit Template' : 'Create Template'}
        </h2>
        <div className="flex gap-2">
          <Button variant="outline" onClick={() => setPreview(!preview)}>
            <Eye className="w-4 h-4 mr-2" />
            {preview ? 'Edit' : 'Preview'}
          </Button>
          <Button onClick={handleSave}>
            <Save className="w-4 h-4 mr-2" />
            Save
          </Button>
          <Button variant="outline" onClick={onCancel}>
            <X className="w-4 h-4" />
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          {!preview ? (
            <Card>
              <CardHeader>
                <CardTitle>Template Content</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Input
                  placeholder="Template Name"
                  value={formData.name}
                  onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                />
                <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="verification">Verification</SelectItem>
                    <SelectItem value="welcome">Welcome</SelectItem>
                    <SelectItem value="billing">Billing</SelectItem>
                    <SelectItem value="marketing">Marketing</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  placeholder="Email Subject"
                  value={formData.subject}
                  onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                />
                <Textarea
                  placeholder="Email Content (HTML supported)"
                  value={formData.content}
                  onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                  rows={15}
                />
              </CardContent>
            </Card>
          ) : (
            <Card>
              <CardHeader>
                <CardTitle>Preview</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="border rounded p-4 bg-white">
                  <div className="mb-4 pb-2 border-b">
                    <strong>Subject:</strong> {formData.subject}
                  </div>
                  <div dangerouslySetInnerHTML={{ __html: formData.content }} />
                </div>
              </CardContent>
            </Card>
          )}
        </div>

        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Personalization Tokens</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {['first_name', 'last_name', 'email', 'company', 'subscription_plan'].map(token => (
                <Button
                  key={token}
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => insertToken(token)}
                >
                  {`{{${token}}}`}
                </Button>
              ))}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Template Blocks</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              {[
                { name: 'Header', content: '<header style="background: #f8f9fa; padding: 20px; text-align: center;"><h1>{{company_name}}</h1></header>' },
                { name: 'Button', content: '<a href="{{button_url}}" style="background: #007bff; color: white; padding: 10px 20px; text-decoration: none; border-radius: 4px;">{{button_text}}</a>' },
                { name: 'Footer', content: '<footer style="background: #f8f9fa; padding: 20px; text-align: center; font-size: 12px;">© {{year}} {{company_name}}</footer>' }
              ].map(block => (
                <Button
                  key={block.name}
                  variant="outline"
                  size="sm"
                  className="w-full justify-start"
                  onClick={() => setFormData(prev => ({ ...prev, content: prev.content + block.content }))}
                >
                  {block.name}
                </Button>
              ))}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}