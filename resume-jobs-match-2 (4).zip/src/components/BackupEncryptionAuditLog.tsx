import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { FileText, Search, CheckCircle, XCircle } from 'lucide-react';
import { backupEncryptionService, EncryptionAuditLog } from '@/services/backupEncryptionService';

export const BackupEncryptionAuditLog: React.FC = () => {
  const [logs, setLogs] = useState<EncryptionAuditLog[]>([]);
  const [searchTerm, setSearchTerm] = useState('');

  useEffect(() => {
    loadLogs();
  }, []);

  const loadLogs = async () => {
    const data = await backupEncryptionService.getAuditLogs();
    setLogs(data);
  };

  const filteredLogs = logs.filter(log =>
    log.operation.toLowerCase().includes(searchTerm.toLowerCase()) ||
    log.key_id.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getOperationColor = (operation: string) => {
    const colors: Record<string, string> = {
      encrypt: 'bg-blue-100 text-blue-800',
      decrypt: 'bg-green-100 text-green-800',
      key_rotation: 'bg-purple-100 text-purple-800',
      key_creation: 'bg-yellow-100 text-yellow-800',
      key_revocation: 'bg-red-100 text-red-800',
    };
    return colors[operation] || 'bg-gray-100 text-gray-800';
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <FileText className="h-5 w-5" />
          Encryption Audit Log
        </CardTitle>
        <div className="relative mt-4">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search audit logs..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10"
          />
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-2 max-h-96 overflow-y-auto">
          {filteredLogs.map((log) => (
            <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg hover:bg-gray-50">
              <div className="flex items-center gap-3 flex-1">
                {log.status === 'success' ? (
                  <CheckCircle className="h-4 w-4 text-green-600" />
                ) : (
                  <XCircle className="h-4 w-4 text-red-600" />
                )}
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <Badge className={getOperationColor(log.operation)}>
                      {log.operation.replace('_', ' ')}
                    </Badge>
                    <span className="text-sm text-gray-600">Key: {log.key_id}</span>
                    {log.backup_id && (
                      <span className="text-sm text-gray-600">Backup: {log.backup_id}</span>
                    )}
                  </div>
                  <div className="text-xs text-gray-500 mt-1">
                    {new Date(log.timestamp).toLocaleString()}
                  </div>
                </div>
              </div>
              <Badge variant={log.status === 'success' ? 'default' : 'destructive'}>
                {log.status}
              </Badge>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
};
