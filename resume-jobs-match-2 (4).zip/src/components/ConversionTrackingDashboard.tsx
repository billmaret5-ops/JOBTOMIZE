import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { TrendingUp, Users, Briefcase, Calendar } from 'lucide-react';

export default function ConversionTrackingDashboard() {
  const [conversions] = useState([
    {
      stage: 'Email Sent',
      count: 1000,
      percentage: 100,
      color: 'bg-blue-500'
    },
    {
      stage: 'Email Opened',
      count: 680,
      percentage: 68,
      color: 'bg-green-500'
    },
    {
      stage: 'Link Clicked',
      count: 156,
      percentage: 15.6,
      color: 'bg-orange-500'
    },
    {
      stage: 'Response Received',
      count: 89,
      percentage: 8.9,
      color: 'bg-purple-500'
    },
    {
      stage: 'Interview Scheduled',
      count: 34,
      percentage: 3.4,
      color: 'bg-red-500'
    }
  ]);

  const [jobApplications] = useState([
    {
      company: 'TechCorp Inc',
      position: 'Senior Developer',
      emailsSent: 5,
      responses: 2,
      interviews: 1,
      status: 'Interview Scheduled',
      roi: 85
    },
    {
      company: 'StartupXYZ',
      position: 'Full Stack Engineer',
      emailsSent: 3,
      responses: 1,
      interviews: 0,
      status: 'Awaiting Response',
      roi: 45
    }
  ]);

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Conversion Tracking</h2>
        <p className="text-muted-foreground">Monitor job application success rates and ROI</p>
      </div>

      {/* Conversion Funnel */}
      <Card>
        <CardHeader>
          <CardTitle>Job Application Conversion Funnel</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {conversions.map((stage, index) => (
              <div key={index} className="flex items-center space-x-4">
                <div className="w-32 text-sm font-medium">{stage.stage}</div>
                <div className="flex-1">
                  <Progress value={stage.percentage} className="h-6" />
                </div>
                <div className="w-20 text-right">
                  <span className="font-bold">{stage.count}</span>
                  <span className="text-sm text-muted-foreground ml-1">
                    ({stage.percentage}%)
                  </span>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* ROI Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Total Applications</p>
                <p className="text-2xl font-bold">24</p>
              </div>
              <Briefcase className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Response Rate</p>
                <p className="text-2xl font-bold">8.9%</p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Interviews</p>
                <p className="text-2xl font-bold">34</p>
              </div>
              <Calendar className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Avg ROI</p>
                <p className="text-2xl font-bold">65%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Application Tracking */}
      <Card>
        <CardHeader>
          <CardTitle>Active Job Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {jobApplications.map((app, index) => (
              <div key={index} className="border rounded-lg p-4">
                <div className="flex justify-between items-start mb-2">
                  <div>
                    <h3 className="font-semibold">{app.position}</h3>
                    <p className="text-sm text-muted-foreground">{app.company}</p>
                  </div>
                  <Badge variant={app.status === 'Interview Scheduled' ? 'default' : 'secondary'}>
                    {app.status}
                  </Badge>
                </div>
                <div className="grid grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-muted-foreground">Emails:</span>
                    <span className="ml-1 font-medium">{app.emailsSent}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Responses:</span>
                    <span className="ml-1 font-medium">{app.responses}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">Interviews:</span>
                    <span className="ml-1 font-medium">{app.interviews}</span>
                  </div>
                  <div>
                    <span className="text-muted-foreground">ROI:</span>
                    <span className="ml-1 font-medium text-green-600">{app.roi}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}