import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  TestTube, 
  Play, 
  Pause, 
  BarChart3, 
  Trophy,
  Users,
  Mail,
  Target,
  TrendingUp
} from 'lucide-react';

interface ABTest {
  id: string;
  name: string;
  status: 'draft' | 'running' | 'completed';
  type: 'subject' | 'content' | 'sender';
  variantA: {
    name: string;
    content: string;
    opens: number;
    clicks: number;
    conversions: number;
  };
  variantB: {
    name: string;
    content: string;
    opens: number;
    clicks: number;
    conversions: number;
  };
  trafficSplit: number;
  confidence: number;
  winner?: 'A' | 'B';
  startDate: string;
  endDate?: string;
}

export const EmailABTestManager: React.FC = () => {
  const [tests, setTests] = useState<ABTest[]>([
    {
      id: '1',
      name: 'Subject Line Test - Newsletter',
      status: 'running',
      type: 'subject',
      variantA: {
        name: 'Variant A',
        content: 'Your Weekly Job Updates Are Here!',
        opens: 1250,
        clicks: 89,
        conversions: 12
      },
      variantB: {
        name: 'Variant B', 
        content: '🚀 New Opportunities Just for You',
        opens: 1380,
        clicks: 102,
        conversions: 18
      },
      trafficSplit: 50,
      confidence: 87.5,
      winner: 'B',
      startDate: '2024-01-15'
    }
  ]);

  const [newTest, setNewTest] = useState({
    name: '',
    type: 'subject',
    variantA: '',
    variantB: '',
    trafficSplit: 50
  });

  const createTest = () => {
    const test: ABTest = {
      id: Date.now().toString(),
      name: newTest.name,
      status: 'draft',
      type: newTest.type as 'subject' | 'content' | 'sender',
      variantA: {
        name: 'Variant A',
        content: newTest.variantA,
        opens: 0,
        clicks: 0,
        conversions: 0
      },
      variantB: {
        name: 'Variant B',
        content: newTest.variantB,
        opens: 0,
        clicks: 0,
        conversions: 0
      },
      trafficSplit: newTest.trafficSplit,
      confidence: 0,
      startDate: new Date().toISOString().split('T')[0]
    };

    setTests([...tests, test]);
    setNewTest({ name: '', type: 'subject', variantA: '', variantB: '', trafficSplit: 50 });
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'running': return 'bg-green-500';
      case 'completed': return 'bg-blue-500';
      default: return 'bg-gray-500';
    }
  };

  const calculateWinRate = (variant: any, total: number) => {
    return total > 0 ? ((variant.conversions / total) * 100).toFixed(1) : '0.0';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold flex items-center gap-2">
            <TestTube className="h-6 w-6" />
            A/B Test Manager
          </h2>
          <p className="text-muted-foreground">Create and manage email A/B tests</p>
        </div>
      </div>

      <Tabs defaultValue="tests" className="w-full">
        <TabsList>
          <TabsTrigger value="tests">Active Tests</TabsTrigger>
          <TabsTrigger value="create">Create Test</TabsTrigger>
          <TabsTrigger value="results">Results</TabsTrigger>
        </TabsList>

        <TabsContent value="tests" className="space-y-4">
          {tests.map((test) => (
            <Card key={test.id}>
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <CardTitle className="text-lg">{test.name}</CardTitle>
                    <Badge className={getStatusColor(test.status)}>
                      {test.status}
                    </Badge>
                    <Badge variant="outline">{test.type}</Badge>
                  </div>
                  <div className="flex gap-2">
                    {test.status === 'running' && (
                      <Button size="sm" variant="outline">
                        <Pause className="h-4 w-4 mr-1" />
                        Pause
                      </Button>
                    )}
                    {test.status === 'draft' && (
                      <Button size="sm">
                        <Play className="h-4 w-4 mr-1" />
                        Start
                      </Button>
                    )}
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {/* Variant A */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-blue-600">Variant A</h4>
                      {test.winner === 'A' && (
                        <Trophy className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                    <div className="bg-gray-50 p-3 rounded text-sm">
                      {test.variantA.content}
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Opens</div>
                        <div className="font-semibold">{test.variantA.opens}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Clicks</div>
                        <div className="font-semibold">{test.variantA.clicks}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversions</div>
                        <div className="font-semibold">{test.variantA.conversions}</div>
                      </div>
                    </div>
                    <div className="text-sm">
                      <div className="text-muted-foreground">Conversion Rate</div>
                      <div className="font-semibold text-lg">
                        {calculateWinRate(test.variantA, test.variantA.opens)}%
                      </div>
                    </div>
                  </div>

                  {/* Variant B */}
                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <h4 className="font-semibold text-green-600">Variant B</h4>
                      {test.winner === 'B' && (
                        <Trophy className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                    <div className="bg-gray-50 p-3 rounded text-sm">
                      {test.variantB.content}
                    </div>
                    <div className="grid grid-cols-3 gap-4 text-sm">
                      <div>
                        <div className="text-muted-foreground">Opens</div>
                        <div className="font-semibold">{test.variantB.opens}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Clicks</div>
                        <div className="font-semibold">{test.variantB.clicks}</div>
                      </div>
                      <div>
                        <div className="text-muted-foreground">Conversions</div>
                        <div className="font-semibold">{test.variantB.conversions}</div>
                      </div>
                    </div>
                    <div className="text-sm">
                      <div className="text-muted-foreground">Conversion Rate</div>
                      <div className="font-semibold text-lg">
                        {calculateWinRate(test.variantB, test.variantB.opens)}%
                      </div>
                    </div>
                  </div>
                </div>

                {test.confidence > 0 && (
                  <div className="mt-4 pt-4 border-t">
                    <div className="flex items-center justify-between">
                      <span className="text-sm text-muted-foreground">Statistical Confidence</span>
                      <span className="font-semibold">{test.confidence}%</span>
                    </div>
                    <Progress value={test.confidence} className="mt-2" />
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="create" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Create New A/B Test</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="testName">Test Name</Label>
                <Input
                  id="testName"
                  value={newTest.name}
                  onChange={(e) => setNewTest({ ...newTest, name: e.target.value })}
                  placeholder="Enter test name"
                />
              </div>

              <div>
                <Label htmlFor="testType">Test Type</Label>
                <Select value={newTest.type} onValueChange={(value) => setNewTest({ ...newTest, type: value })}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="subject">Subject Line</SelectItem>
                    <SelectItem value="content">Email Content</SelectItem>
                    <SelectItem value="sender">Sender Name</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="variantA">Variant A</Label>
                  <Textarea
                    id="variantA"
                    value={newTest.variantA}
                    onChange={(e) => setNewTest({ ...newTest, variantA: e.target.value })}
                    placeholder="Enter variant A content"
                  />
                </div>
                <div>
                  <Label htmlFor="variantB">Variant B</Label>
                  <Textarea
                    id="variantB"
                    value={newTest.variantB}
                    onChange={(e) => setNewTest({ ...newTest, variantB: e.target.value })}
                    placeholder="Enter variant B content"
                  />
                </div>
              </div>

              <div>
                <Label>Traffic Split</Label>
                <div className="flex items-center gap-4 mt-2">
                  <span className="text-sm">A: {newTest.trafficSplit}%</span>
                  <input
                    type="range"
                    min="10"
                    max="90"
                    value={newTest.trafficSplit}
                    onChange={(e) => setNewTest({ ...newTest, trafficSplit: parseInt(e.target.value) })}
                    className="flex-1"
                  />
                  <span className="text-sm">B: {100 - newTest.trafficSplit}%</span>
                </div>
              </div>

              <Button onClick={createTest} className="w-full">
                Create A/B Test
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="results" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Test Results Summary</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">3</div>
                  <div className="text-sm text-muted-foreground">Tests Completed</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">1</div>
                  <div className="text-sm text-muted-foreground">Currently Running</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">15.2%</div>
                  <div className="text-sm text-muted-foreground">Avg. Improvement</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};