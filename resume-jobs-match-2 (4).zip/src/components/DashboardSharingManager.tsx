import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { dashboardBuilderService } from '@/services/dashboardBuilderService';
import { Share2, Trash2, Plus, Copy, Check } from 'lucide-react';
import { toast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';

interface Props {
  dashboardId: string;
}

export const DashboardSharingManager: React.FC<Props> = ({ dashboardId }) => {
  const [shares, setShares] = useState<any[]>([]);
  const [showDialog, setShowDialog] = useState(false);
  const [email, setEmail] = useState('');
  const [permission, setPermission] = useState<'view' | 'edit'>('view');
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    loadShares();
  }, [dashboardId]);

  const loadShares = async () => {
    try {
      const data = await dashboardBuilderService.getShares(dashboardId);
      setShares(data);
    } catch (error) {
      console.error('Failed to load shares:', error);
    }
  };

  const handleShare = async () => {
    if (!email.trim()) {
      toast({ title: 'Please enter an email', variant: 'destructive' });
      return;
    }

    try {
      await dashboardBuilderService.shareDashboard(dashboardId, email, permission);
      toast({ title: 'Dashboard shared successfully' });
      setShowDialog(false);
      setEmail('');
      loadShares();
    } catch (error) {
      toast({ title: 'Failed to share dashboard', variant: 'destructive' });
    }
  };

  const handleRemoveShare = async (shareId: string) => {
    try {
      await dashboardBuilderService.removeShare(shareId);
      toast({ title: 'Share removed' });
      loadShares();
    } catch (error) {
      toast({ title: 'Failed to remove share', variant: 'destructive' });
    }
  };

  const handleCopyLink = () => {
    const link = `${window.location.origin}/dashboard/${dashboardId}`;
    navigator.clipboard.writeText(link);
    setCopied(true);
    toast({ title: 'Link copied to clipboard' });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Dashboard Sharing</CardTitle>
          <div className="flex gap-2">
            <Button variant="outline" size="sm" onClick={handleCopyLink}>
              {copied ? <Check className="h-4 w-4 mr-2" /> : <Copy className="h-4 w-4 mr-2" />}
              Copy Link
            </Button>
            <Dialog open={showDialog} onOpenChange={setShowDialog}>
              <DialogTrigger asChild>
                <Button size="sm">
                  <Plus className="h-4 w-4 mr-2" />
                  Share
                </Button>
              </DialogTrigger>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Share Dashboard</DialogTitle>
                </DialogHeader>
                <div className="space-y-4">
                  <div>
                    <label className="text-sm font-medium">Email Address</label>
                    <Input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="colleague@example.com"
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Permission</label>
                    <Select value={permission} onValueChange={(v: any) => setPermission(v)}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="view">View Only</SelectItem>
                        <SelectItem value="edit">Can Edit</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button onClick={handleShare} className="w-full">
                    <Share2 className="h-4 w-4 mr-2" />
                    Share Dashboard
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>
        </div>
      </CardHeader>
      <CardContent>
        <div className="space-y-4">
          {shares.map((share) => (
            <div key={share.id} className="flex items-center justify-between p-4 border rounded">
              <div className="flex-1">
                <p className="font-medium">{share.shared_with_user?.email || 'Unknown User'}</p>
                <div className="flex items-center gap-2 mt-1">
                  <Badge variant={share.permission === 'edit' ? 'default' : 'secondary'}>
                    {share.permission === 'edit' ? 'Can Edit' : 'View Only'}
                  </Badge>
                  <span className="text-xs text-muted-foreground">
                    Shared {new Date(share.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => handleRemoveShare(share.id)}
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>
          ))}
          {shares.length === 0 && (
            <p className="text-center text-muted-foreground py-8">
              Dashboard not shared with anyone yet
            </p>
          )}
        </div>
      </CardContent>
    </Card>
  );
};
