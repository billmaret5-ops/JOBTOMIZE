import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { ContactList } from './ContactList';
import { ContactSegments } from './ContactSegments';
import { ContactImportExport } from './ContactImportExport';
import { ContactAnalytics } from './ContactAnalytics';
import { Users, UserPlus, Filter, Download, Upload } from 'lucide-react';

interface Contact {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  company?: string;
  lifecycle_stage: string;
  lead_score: number;
  engagement_score: number;
  tags: string[];
  last_activity_at?: string;
}

export function ContactManager() {
  const [contacts, setContacts] = useState<Contact[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedContacts, setSelectedContacts] = useState<string[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadContacts();
  }, []);

  const loadContacts = async () => {
    setLoading(true);
    // Mock data
    const mockContacts: Contact[] = [
      {
        id: '1',
        email: 'john.doe@example.com',
        first_name: 'John',
        last_name: 'Doe',
        company: 'Tech Corp',
        lifecycle_stage: 'lead',
        lead_score: 85,
        engagement_score: 72,
        tags: ['high-value', 'tech'],
        last_activity_at: '2024-01-15T10:30:00Z'
      },
      {
        id: '2',
        email: 'jane.smith@example.com',
        first_name: 'Jane',
        last_name: 'Smith',
        company: 'Marketing Inc',
        lifecycle_stage: 'customer',
        lead_score: 95,
        engagement_score: 88,
        tags: ['vip', 'marketing'],
        last_activity_at: '2024-01-14T15:45:00Z'
      }
    ];
    setContacts(mockContacts);
    setLoading(false);
  };

  const filteredContacts = contacts.filter(contact =>
    contact.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
    `${contact.first_name} ${contact.last_name}`.toLowerCase().includes(searchTerm.toLowerCase()) ||
    contact.company?.toLowerCase().includes(searchTerm.toLowerCase())
  );

  const stats = {
    total: contacts.length,
    leads: contacts.filter(c => c.lifecycle_stage === 'lead').length,
    customers: contacts.filter(c => c.lifecycle_stage === 'customer').length,
    avgLeadScore: Math.round(contacts.reduce((sum, c) => sum + c.lead_score, 0) / contacts.length) || 0
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Contact Management</h1>
          <p className="text-muted-foreground">Manage your contacts, segments, and engagement</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Upload className="h-4 w-4 mr-2" />
            Import
          </Button>
          <Button variant="outline" size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
          <Button size="sm">
            <UserPlus className="h-4 w-4 mr-2" />
            Add Contact
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Contacts</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Leads</p>
                <p className="text-2xl font-bold">{stats.leads}</p>
              </div>
              <Badge variant="secondary">{Math.round((stats.leads / stats.total) * 100)}%</Badge>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Customers</p>
                <p className="text-2xl font-bold">{stats.customers}</p>
              </div>
              <Badge variant="default">{Math.round((stats.customers / stats.total) * 100)}%</Badge>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Lead Score</p>
                <p className="text-2xl font-bold">{stats.avgLeadScore}</p>
              </div>
              <div className="text-sm text-green-600">+5.2%</div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search and Filters */}
      <div className="flex gap-4">
        <Input
          placeholder="Search contacts..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
        <Button variant="outline" size="sm">
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
      </div>

      {/* Main Content */}
      <Tabs defaultValue="contacts" className="space-y-4">
        <TabsList>
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="segments">Segments</TabsTrigger>
          <TabsTrigger value="import-export">Import/Export</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="contacts">
          <ContactList 
            contacts={filteredContacts}
            selectedContacts={selectedContacts}
            onSelectionChange={setSelectedContacts}
            loading={loading}
          />
        </TabsContent>

        <TabsContent value="segments">
          <ContactSegments />
        </TabsContent>

        <TabsContent value="import-export">
          <ContactImportExport />
        </TabsContent>

        <TabsContent value="analytics">
          <ContactAnalytics />
        </TabsContent>
      </Tabs>
    </div>
  );
}