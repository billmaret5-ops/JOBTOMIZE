import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { BarChart, LineChart, PieChart, TrendingUp, Mail, MousePointer, Users, DollarSign } from 'lucide-react';

interface Campaign {
  id: string;
  name: string;
  subject: string;
  status: string;
  sent_at: string;
  total_recipients: number;
}

interface Analytics {
  total_sent: number;
  total_delivered: number;
  total_opened: number;
  total_clicked: number;
  open_rate: number;
  click_rate: number;
  bounce_rate: number;
  conversion_rate: number;
  revenue_generated: number;
}

export default function CampaignAnalyticsDashboard() {
  const [campaigns, setCampaigns] = useState<Campaign[]>([]);
  const [selectedCampaign, setSelectedCampaign] = useState<string>('');
  const [analytics, setAnalytics] = useState<Analytics | null>(null);

  const mockCampaigns: Campaign[] = [
    { id: '1', name: 'Summer Sale 2024', subject: '50% Off Everything!', status: 'sent', sent_at: '2024-01-15', total_recipients: 15000 },
    { id: '2', name: 'Product Launch', subject: 'Introducing Our Latest Innovation', status: 'sent', sent_at: '2024-01-10', total_recipients: 8500 },
    { id: '3', name: 'Newsletter #42', subject: 'Weekly Updates & Tips', status: 'sent', sent_at: '2024-01-08', total_recipients: 12000 }
  ];

  const mockAnalytics: Analytics = {
    total_sent: 15000,
    total_delivered: 14250,
    total_opened: 7125,
    total_clicked: 1425,
    open_rate: 50.0,
    click_rate: 10.0,
    bounce_rate: 5.0,
    conversion_rate: 3.2,
    revenue_generated: 45000
  };

  useEffect(() => {
    setCampaigns(mockCampaigns);
    setSelectedCampaign('1');
    setAnalytics(mockAnalytics);
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Email Campaign Analytics</h1>
        <Button>
          <Mail className="w-4 h-4 mr-2" />
          New Campaign
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Sent</p>
                <p className="text-2xl font-bold">{analytics?.total_sent.toLocaleString()}</p>
              </div>
              <Mail className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Open Rate</p>
                <p className="text-2xl font-bold">{analytics?.open_rate}%</p>
              </div>
              <TrendingUp className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Click Rate</p>
                <p className="text-2xl font-bold">{analytics?.click_rate}%</p>
              </div>
              <MousePointer className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Revenue</p>
                <p className="text-2xl font-bold">${analytics?.revenue_generated.toLocaleString()}</p>
              </div>
              <DollarSign className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="overview" className="space-y-4">
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="ab-testing">A/B Testing</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Campaign Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <img 
                  src="https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758495369360_fe610eab.webp"
                  alt="Campaign Performance Chart"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Engagement Metrics</CardTitle>
              </CardHeader>
              <CardContent>
                <img 
                  src="https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758495371063_bb16f33c.webp"
                  alt="Engagement Metrics"
                  className="w-full h-64 object-cover rounded-lg"
                />
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campaigns" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Recent Campaigns</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {campaigns.map((campaign) => (
                  <div key={campaign.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-semibold">{campaign.name}</h3>
                      <p className="text-sm text-muted-foreground">{campaign.subject}</p>
                      <p className="text-xs text-muted-foreground">Sent: {campaign.sent_at}</p>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary">{campaign.status}</Badge>
                      <p className="text-sm mt-1">{campaign.total_recipients.toLocaleString()} recipients</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}