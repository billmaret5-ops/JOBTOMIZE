import { useState } from 'react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import { Progress } from '@/components/ui/progress';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, Loader2 } from 'lucide-react';

interface BulkApplyModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  optimizedData: any;
  originalData: any;
  onApply: (selectedSections: string[]) => Promise<void>;
}

export default function BulkApplyModal({
  open,
  onOpenChange,
  optimizedData,
  originalData,
  onApply
}: BulkApplyModalProps) {
  const [selectedSections, setSelectedSections] = useState<string[]>(['summary', 'experience', 'skills']);
  const [isApplying, setIsApplying] = useState(false);
  const [progress, setProgress] = useState(0);

  const sections = [
    { id: 'summary', label: 'Professional Summary', hasChanges: optimizedData?.summary !== originalData?.summary },
    { id: 'experience', label: 'Work Experience', hasChanges: optimizedData?.experience?.length > 0 },
    { id: 'skills', label: 'Skills', hasChanges: optimizedData?.skills?.length > 0 }
  ];

  const handleToggleSection = (sectionId: string) => {
    setSelectedSections(prev =>
      prev.includes(sectionId) ? prev.filter(s => s !== sectionId) : [...prev, sectionId]
    );
  };

  const handleApply = async () => {
    setIsApplying(true);
    setProgress(0);

    try {
      const increment = 100 / selectedSections.length;
      for (let i = 0; i < selectedSections.length; i++) {
        setProgress((i + 1) * increment);
        await new Promise(resolve => setTimeout(resolve, 300));
      }
      await onApply(selectedSections);
      onOpenChange(false);
    } finally {
      setIsApplying(false);
      setProgress(0);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-3xl max-h-[80vh]">
        <DialogHeader>
          <DialogTitle>Apply All Optimizations</DialogTitle>
          <DialogDescription>
            Review and select which sections to update with AI-optimized content
          </DialogDescription>
        </DialogHeader>

        <ScrollArea className="max-h-[50vh] pr-4">
          <div className="space-y-4">
            {sections.map(section => (
              <div key={section.id} className="border rounded-lg p-4">
                <div className="flex items-start gap-3">
                  <Checkbox
                    id={section.id}
                    checked={selectedSections.includes(section.id)}
                    onCheckedChange={() => handleToggleSection(section.id)}
                    disabled={!section.hasChanges || isApplying}
                  />
                  <div className="flex-1">
                    <Label htmlFor={section.id} className="text-base font-semibold cursor-pointer">
                      {section.label}
                      {section.hasChanges && <Badge className="ml-2" variant="secondary">Changes Available</Badge>}
                      {!section.hasChanges && <Badge className="ml-2" variant="outline">No Changes</Badge>}
                    </Label>
                    {section.id === 'summary' && optimizedData?.summary && (
                      <p className="text-sm text-muted-foreground mt-2 line-clamp-3">{optimizedData.summary}</p>
                    )}
                    {section.id === 'experience' && optimizedData?.experience?.length > 0 && (
                      <p className="text-sm text-muted-foreground mt-2">{optimizedData.experience.length} position(s) will be updated</p>
                    )}
                    {section.id === 'skills' && optimizedData?.skills?.length > 0 && (
                      <p className="text-sm text-muted-foreground mt-2">{optimizedData.skills.length} skill(s) will be added/updated</p>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>

        {isApplying && (
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              <Loader2 className="h-4 w-4 animate-spin" />
              <span>Applying changes...</span>
            </div>
            <Progress value={progress} />
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={isApplying}>
            Cancel
          </Button>
          <Button onClick={handleApply} disabled={selectedSections.length === 0 || isApplying}>
            {isApplying ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                Applying...
              </>
            ) : (
              <>
                <CheckCircle2 className="h-4 w-4 mr-2" />
                Apply {selectedSections.length} Section{selectedSections.length !== 1 ? 's' : ''}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
