import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Skeleton } from '@/components/ui/skeleton';
import { Alert, AlertDescription } from '@/components/ui/alert';
import DataExportManager from './DataExportManager';
import { AnalyticsCharts } from './AnalyticsCharts';
import { UserEngagementAnalytics } from './UserEngagementAnalytics';
import { VideoSharingAnalytics } from './VideoSharingAnalytics';
import { JobSearchRecommendations } from './JobSearchRecommendations';
import { useAnalyticsData } from '@/hooks/useAnalyticsData';
import { 
  TrendingUp, 
  TrendingDown, 
  Users, 
  Calendar, 
  DollarSign, 
  Target,
  BarChart3,
  PieChart,
  Activity,
  RefreshCw,
  AlertCircle
} from 'lucide-react';
export const ComprehensiveAnalytics: React.FC = () => {
  const { 
    applicationMetrics, 
    salaryTrends, 
    skillDemand, 
    interviewMetrics, 
    loading, 
    error,
    refetch 
  } = useAnalyticsData();

  if (loading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <Skeleton className="h-8 w-48" />
          <Skeleton className="h-10 w-24" />
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardHeader className="pb-2">
                <Skeleton className="h-4 w-24" />
              </CardHeader>
              <CardContent>
                <Skeleton className="h-8 w-16 mb-2" />
                <Skeleton className="h-3 w-20" />
              </CardContent>
            </Card>
          ))}
        </div>
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (error) {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertDescription>
          Failed to load analytics data: {error}
          <Button 
            variant="outline" 
            size="sm" 
            onClick={refetch}
            className="ml-2"
          >
            <RefreshCw className="h-4 w-4 mr-1" />
            Retry
          </Button>
        </AlertDescription>
      </Alert>
    );
  }
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
        <Button onClick={refetch} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          Refresh
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Applications</p>
                <p className="text-2xl font-bold">{applicationMetrics?.totalApplications || 0}</p>
                <p className="text-xs text-blue-600">
                  {applicationMetrics?.applicationsByMonth.length || 0} this month
                </p>
              </div>
              <Target className="h-8 w-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Interview Rate</p>
                <p className="text-2xl font-bold">
                  {applicationMetrics?.interviewRate.toFixed(1) || 0}%
                </p>
                <p className="text-xs text-green-600">
                  {interviewMetrics?.totalInterviews || 0} interviews
                </p>
              </div>
              <Users className="h-8 w-8 text-green-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Avg Salary</p>
                <p className="text-2xl font-bold">
                  ${Math.round(salaryTrends?.avgSalary || 0).toLocaleString()}
                </p>
                <p className="text-xs text-purple-600">Market average</p>
              </div>
              <DollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Offer Rate</p>
                <p className="text-2xl font-bold">
                  {applicationMetrics?.offerRate.toFixed(1) || 0}%
                </p>
                <p className="text-xs text-green-600">Success rate</p>
              </div>
              <Activity className="h-8 w-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>
      {/* Data Export Section */}
      <DataExportManager />

      <Tabs defaultValue="overview" className="space-y-6">
        <TabsList className="grid w-full grid-cols-6">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="interviews">Interviews</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
          <TabsTrigger value="videos">Video Sharing</TabsTrigger>
          <TabsTrigger value="recommendations">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Salary Trends by Location</CardTitle>
              </CardHeader>
              <CardContent>
                {salaryTrends?.salaryByLocation.length ? (
                  <AnalyticsCharts 
                    data={salaryTrends.salaryByLocation} 
                    type="bar" 
                    dataKey="avgSalary" 
                    xAxisKey="location" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No salary data available
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Top Skills in Demand</CardTitle>
              </CardHeader>
              <CardContent>
                {skillDemand?.topSkills.length ? (
                  <AnalyticsCharts 
                    data={skillDemand.topSkills.slice(0, 5)} 
                    type="bar" 
                    dataKey="demand" 
                    xAxisKey="skill" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No skill data available
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="applications" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Application Status
                </CardTitle>
              </CardHeader>
              <CardContent>
                {applicationMetrics?.applicationsByStatus.length ? (
                  <AnalyticsCharts 
                    data={applicationMetrics.applicationsByStatus} 
                    type="pie" 
                    dataKey="count" 
                    xAxisKey="status" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No application data available
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Activity className="h-5 w-5 mr-2" />
                  Applications Over Time
                </CardTitle>
              </CardHeader>
              <CardContent>
                {applicationMetrics?.applicationsByMonth.length ? (
                  <AnalyticsCharts 
                    data={applicationMetrics.applicationsByMonth} 
                    type="line" 
                    dataKey="count" 
                    xAxisKey="month" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No timeline data available
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="salary" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Salary by Location</CardTitle>
              </CardHeader>
              <CardContent>
                {salaryTrends?.salaryByLocation.length ? (
                  <AnalyticsCharts 
                    data={salaryTrends.salaryByLocation} 
                    type="bar" 
                    dataKey="avgSalary" 
                    xAxisKey="location" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No salary data available
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Salary by Industry</CardTitle>
              </CardHeader>
              <CardContent>
                {salaryTrends?.salaryByIndustry.length ? (
                  <AnalyticsCharts 
                    data={salaryTrends.salaryByIndustry} 
                    type="bar" 
                    dataKey="avgSalary" 
                    xAxisKey="industry" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No industry data available
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="skills" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Top Skills in Demand</CardTitle>
            </CardHeader>
            <CardContent>
              {skillDemand?.topSkills.length ? (
                <div className="space-y-4">
                  <AnalyticsCharts 
                    data={skillDemand.topSkills} 
                    type="bar" 
                    dataKey="demand" 
                    xAxisKey="skill" 
                  />
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
                    {skillDemand.topSkills.slice(0, 6).map((skill, index) => (
                      <div key={skill.skill} className="p-4 border rounded-lg">
                        <div className="flex items-center justify-between mb-2">
                          <Badge variant="secondary">#{index + 1}</Badge>
                          <span className="text-sm font-medium">{skill.skill}</span>
                        </div>
                        <div className="space-y-1">
                          <div className="flex justify-between text-sm">
                            <span>Demand:</span>
                            <span className="font-medium">{skill.demand} jobs</span>
                          </div>
                          <div className="flex justify-between text-sm">
                            <span>Avg Salary:</span>
                            <span className="font-medium">
                              ${Math.round(skill.avgSalary).toLocaleString()}
                            </span>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <div className="text-center text-gray-500 py-8">
                  No skill demand data available
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="interviews" className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Interview Types</CardTitle>
              </CardHeader>
              <CardContent>
                {interviewMetrics?.interviewsByType.length ? (
                  <AnalyticsCharts 
                    data={interviewMetrics.interviewsByType} 
                    type="pie" 
                    dataKey="count" 
                    xAxisKey="type" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No interview data available
                  </div>
                )}
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle>Interview Outcomes</CardTitle>
              </CardHeader>
              <CardContent>
                {interviewMetrics?.interviewsByOutcome.length ? (
                  <AnalyticsCharts 
                    data={interviewMetrics.interviewsByOutcome} 
                    type="pie" 
                    dataKey="count" 
                    xAxisKey="outcome" 
                  />
                ) : (
                  <div className="text-center text-gray-500 py-8">
                    No outcome data available
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
          
          <Card>
            <CardHeader>
              <CardTitle>Interview Performance Metrics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                <div className="text-center">
                  <div className="text-2xl font-bold text-blue-600">
                    {interviewMetrics?.totalInterviews || 0}
                  </div>
                  <div className="text-sm text-gray-600">Total Interviews</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-green-600">
                    {interviewMetrics?.successRate.toFixed(1) || 0}%
                  </div>
                  <div className="text-sm text-gray-600">Success Rate</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-purple-600">
                    {interviewMetrics?.avgTimeToInterview || 0} days
                  </div>
                  <div className="text-sm text-gray-600">Avg Time to Interview</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engagement" className="space-y-6">
          <UserEngagementAnalytics />
        </TabsContent>

        <TabsContent value="videos" className="space-y-6">
          <VideoSharingAnalytics />
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-6">
          <JobSearchRecommendations />
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComprehensiveAnalytics;