import React, { useState } from 'react';
import { useAIRecommendationAnalytics } from '@/hooks/useAIRecommendationAnalytics';
import { AIRecommendationMetricsCards } from '@/components/analytics/AIRecommendationMetricsCards';
import { AIRecommendationVotingChart } from '@/components/AIRecommendationVotingChart';
import { TemplateImpactChart } from '@/components/TemplateImpactChart';
import { TeamCollaborationMetrics } from '@/components/TeamCollaborationMetrics';
import { ABTestResultsVisualization } from '@/components/ABTestResultsVisualization';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Button } from '@/components/ui/button';
import { RefreshCw, Download } from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';

export const AIRecommendationAnalyticsDashboard: React.FC = () => {
  const [timeRange, setTimeRange] = useState('30d');
  const { metrics, votingPatterns, impactMetrics, teamMetrics, loading, refetch } = useAIRecommendationAnalytics(timeRange);
  const [abTestResults, setAbTestResults] = useState<any[]>([]);

  const handleExport = () => {
    const data = { metrics, votingPatterns, impactMetrics, teamMetrics };
    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ai-recommendation-analytics-${new Date().toISOString()}.json`;
    a.click();
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-96">
        <RefreshCw className="h-8 w-8 animate-spin text-blue-600" />
      </div>
    );
  }

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">AI Recommendation Analytics</h1>
          <p className="text-gray-600">Real-time insights into AI-powered warmup optimization</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={refetch} variant="outline" size="icon">
            <RefreshCw className="h-4 w-4" />
          </Button>
          <Button onClick={handleExport} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      <AIRecommendationMetricsCards metrics={metrics} />

      <Tabs defaultValue="voting" className="space-y-4">
        <TabsList>
          <TabsTrigger value="voting">Voting Patterns</TabsTrigger>
          <TabsTrigger value="impact">Template Impact</TabsTrigger>
          <TabsTrigger value="team">Team Collaboration</TabsTrigger>
          <TabsTrigger value="abtests">A/B Tests</TabsTrigger>
        </TabsList>

        <TabsContent value="voting">
          <AIRecommendationVotingChart data={votingPatterns} />
        </TabsContent>

        <TabsContent value="impact">
          <TemplateImpactChart data={impactMetrics} />
        </TabsContent>

        <TabsContent value="team">
          <TeamCollaborationMetrics data={teamMetrics} />
        </TabsContent>

        <TabsContent value="abtests">
          <ABTestResultsVisualization results={abTestResults} />
        </TabsContent>
      </Tabs>
    </div>
  );
};
