import React, { useState, useRef, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { 
  Eye, 
  User, 
  Smile, 
  Hand, 
  AlertTriangle,
  CheckCircle,
  Camera,
  CameraOff
} from 'lucide-react';

interface BodyLanguageMetrics {
  eyeContact: number;
  posture: number;
  facialExpression: number;
  handGestures: number;
  headMovement: number;
  overallConfidence: number;
}

interface BodyLanguageFeedback {
  category: string;
  score: number;
  feedback: string;
  suggestions: string[];
  status: 'excellent' | 'good' | 'needs_improvement';
}

export function BodyLanguageAnalyzer() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [metrics, setMetrics] = useState<BodyLanguageMetrics>({
    eyeContact: 0,
    posture: 0,
    facialExpression: 0,
    handGestures: 0,
    headMovement: 0,
    overallConfidence: 0
  });
  
  const [feedback, setFeedback] = useState<BodyLanguageFeedback[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const startAnalysis = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { width: 640, height: 480 } 
      });
      
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        videoRef.current.play();
      }
      
      setIsAnalyzing(true);
      simulateBodyLanguageAnalysis();
      
    } catch (error) {
      console.error('Error accessing camera:', error);
    }
  };

  const stopAnalysis = () => {
    if (videoRef.current?.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsAnalyzing(false);
  };

  const simulateBodyLanguageAnalysis = () => {
    const interval = setInterval(() => {
      if (!isAnalyzing) {
        clearInterval(interval);
        return;
      }

      // Simulate real-time body language analysis
      const newMetrics: BodyLanguageMetrics = {
        eyeContact: Math.floor(Math.random() * 30) + 70,
        posture: Math.floor(Math.random() * 25) + 75,
        facialExpression: Math.floor(Math.random() * 35) + 65,
        handGestures: Math.floor(Math.random() * 40) + 60,
        headMovement: Math.floor(Math.random() * 30) + 70,
        overallConfidence: 0
      };
      
      // Calculate overall confidence
      newMetrics.overallConfidence = Math.floor(
        (newMetrics.eyeContact + newMetrics.posture + newMetrics.facialExpression + 
         newMetrics.handGestures + newMetrics.headMovement) / 5
      );
      
      setMetrics(newMetrics);
      
      // Generate feedback
      generateFeedback(newMetrics);
      
    }, 2000);

    // Clean up interval after 30 seconds
    setTimeout(() => {
      clearInterval(interval);
    }, 30000);
  };

  const generateFeedback = (currentMetrics: BodyLanguageMetrics) => {
    const feedbackItems: BodyLanguageFeedback[] = [
      {
        category: 'Eye Contact',
        score: currentMetrics.eyeContact,
        feedback: currentMetrics.eyeContact >= 80 ? 
          'Excellent eye contact! You\'re maintaining good connection with the interviewer.' :
          currentMetrics.eyeContact >= 60 ?
          'Good eye contact, but try to look at the camera more consistently.' :
          'Need to improve eye contact. Look directly at the camera lens.',
        suggestions: currentMetrics.eyeContact < 70 ? [
          'Practice looking at the camera lens, not the screen',
          'Use the "triangle technique" - look at camera, then briefly away',
          'Place a small arrow near your camera as a reminder'
        ] : ['Keep up the great eye contact!'],
        status: currentMetrics.eyeContact >= 80 ? 'excellent' : 
                currentMetrics.eyeContact >= 60 ? 'good' : 'needs_improvement'
      },
      {
        category: 'Posture',
        score: currentMetrics.posture,
        feedback: currentMetrics.posture >= 80 ?
          'Perfect posture! You appear confident and professional.' :
          currentMetrics.posture >= 60 ?
          'Good posture overall, minor adjustments could help.' :
          'Posture needs improvement. Sit up straighter and lean slightly forward.',
        suggestions: currentMetrics.posture < 70 ? [
          'Sit up straight with shoulders back',
          'Lean slightly forward to show engagement',
          'Keep both feet flat on the floor'
        ] : ['Maintain your excellent posture!'],
        status: currentMetrics.posture >= 80 ? 'excellent' : 
                currentMetrics.posture >= 60 ? 'good' : 'needs_improvement'
      },
      {
        category: 'Facial Expression',
        score: currentMetrics.facialExpression,
        feedback: currentMetrics.facialExpression >= 80 ?
          'Great facial expressions! You appear engaged and enthusiastic.' :
          currentMetrics.facialExpression >= 60 ?
          'Good expressions, try to smile more naturally.' :
          'Work on more positive facial expressions and natural smiling.',
        suggestions: currentMetrics.facialExpression < 70 ? [
          'Practice natural, genuine smiles',
          'Show enthusiasm through facial expressions',
          'Avoid looking too serious or stern'
        ] : ['Your expressions are very engaging!'],
        status: currentMetrics.facialExpression >= 80 ? 'excellent' : 
                currentMetrics.facialExpression >= 60 ? 'good' : 'needs_improvement'
      }
    ];
    
    setFeedback(feedbackItems);
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'excellent': return 'text-green-600';
      case 'good': return 'text-blue-600';
      case 'needs_improvement': return 'text-orange-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'excellent': return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'good': return <CheckCircle className="h-4 w-4 text-blue-600" />;
      case 'needs_improvement': return <AlertTriangle className="h-4 w-4 text-orange-600" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      {/* Video Analysis */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Camera className="h-5 w-5" />
            Body Language Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div>
              <div className="relative bg-gray-900 rounded-lg aspect-video mb-4">
                <video
                  ref={videoRef}
                  className="w-full h-full rounded-lg object-cover"
                  muted
                  playsInline
                />
                <canvas
                  ref={canvasRef}
                  className="absolute inset-0 w-full h-full"
                  style={{ display: 'none' }}
                />
                {isAnalyzing && (
                  <div className="absolute top-4 left-4">
                    <Badge variant="default" className="animate-pulse">
                      Analyzing...
                    </Badge>
                  </div>
                )}
                {metrics.overallConfidence > 0 && (
                  <div className="absolute top-4 right-4">
                    <div className="bg-black bg-opacity-50 text-white px-3 py-1 rounded-lg">
                      <div className="text-sm font-medium">Confidence Score</div>
                      <div className="text-xl font-bold">{metrics.overallConfidence}%</div>
                    </div>
                  </div>
                )}
              </div>
              
              <div className="flex gap-2">
                <Button
                  onClick={isAnalyzing ? stopAnalysis : startAnalysis}
                  variant={isAnalyzing ? "destructive" : "default"}
                  className="flex-1"
                >
                  {isAnalyzing ? (
                    <>
                      <CameraOff className="h-4 w-4 mr-2" />
                      Stop Analysis
                    </>
                  ) : (
                    <>
                      <Camera className="h-4 w-4 mr-2" />
                      Start Analysis
                    </>
                  )}
                </Button>
              </div>
            </div>
            
            {/* Real-time Metrics */}
            <div className="space-y-4">
              <h3 className="font-semibold">Real-time Metrics</h3>
              
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Eye className="h-4 w-4 text-blue-600" />
                    <span className="text-sm">Eye Contact</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={metrics.eyeContact} className="w-20 h-2" />
                    <span className="text-sm font-medium w-10">{metrics.eyeContact}%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <User className="h-4 w-4 text-green-600" />
                    <span className="text-sm">Posture</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={metrics.posture} className="w-20 h-2" />
                    <span className="text-sm font-medium w-10">{metrics.posture}%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Smile className="h-4 w-4 text-yellow-600" />
                    <span className="text-sm">Expression</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={metrics.facialExpression} className="w-20 h-2" />
                    <span className="text-sm font-medium w-10">{metrics.facialExpression}%</span>
                  </div>
                </div>
                
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Hand className="h-4 w-4 text-purple-600" />
                    <span className="text-sm">Gestures</span>
                  </div>
                  <div className="flex items-center gap-2">
                    <Progress value={metrics.handGestures} className="w-20 h-2" />
                    <span className="text-sm font-medium w-10">{metrics.handGestures}%</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Detailed Feedback */}
      {feedback.length > 0 && (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {feedback.map((item, index) => (
            <Card key={index}>
              <CardHeader className="pb-3">
                <CardTitle className="flex items-center justify-between text-base">
                  <span>{item.category}</span>
                  <div className="flex items-center gap-2">
                    {getStatusIcon(item.status)}
                    <span className={`text-sm ${getStatusColor(item.status)}`}>
                      {item.score}%
                    </span>
                  </div>
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <p className="text-sm text-gray-600">{item.feedback}</p>
                <div className="space-y-1">
                  {item.suggestions.map((suggestion, suggestionIndex) => (
                    <div key={suggestionIndex} className="text-xs bg-gray-50 p-2 rounded">
                      {suggestion}
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}