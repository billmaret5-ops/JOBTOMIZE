import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Plus, Play, Pause, Trash2 } from 'lucide-react';
import { automatedSequenceService, EmailSequence } from '@/services/automatedSequenceService';
import { useToast } from '@/hooks/use-toast';

export default function AutomatedSequenceBuilder() {
  const [sequences, setSequences] = useState<EmailSequence[]>([]);
  const [newSequence, setNewSequence] = useState({ name: '', trigger_event: 'application_submitted' });
  const { toast } = useToast();

  useEffect(() => {
    loadSequences();
  }, []);

  const loadSequences = async () => {
    try {
      const data = await automatedSequenceService.getSequences('user-id');
      setSequences(data);
    } catch (error) {
      toast({ title: 'Error loading sequences', variant: 'destructive' });
    }
  };

  const createSequence = async () => {
    try {
      await automatedSequenceService.createSequence({
        ...newSequence,
        status: 'draft',
        user_id: 'user-id'
      });
      toast({ title: 'Sequence created successfully' });
      loadSequences();
      setNewSequence({ name: '', trigger_event: 'application_submitted' });
    } catch (error) {
      toast({ title: 'Error creating sequence', variant: 'destructive' });
    }
  };

  const toggleSequence = async (id: string, currentStatus: string) => {
    const newStatus = currentStatus === 'active' ? 'paused' : 'active';
    try {
      await automatedSequenceService.updateStep(id, { status: newStatus } as any);
      toast({ title: `Sequence ${newStatus}` });
      loadSequences();
    } catch (error) {
      toast({ title: 'Error updating sequence', variant: 'destructive' });
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Create New Sequence</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <Input
            placeholder="Sequence name"
            value={newSequence.name}
            onChange={(e) => setNewSequence({ ...newSequence, name: e.target.value })}
          />
          <Select value={newSequence.trigger_event} onValueChange={(v) => setNewSequence({ ...newSequence, trigger_event: v })}>
            <SelectTrigger>
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="application_submitted">Application Submitted</SelectItem>
              <SelectItem value="interview_scheduled">Interview Scheduled</SelectItem>
              <SelectItem value="offer_received">Offer Received</SelectItem>
              <SelectItem value="no_response">No Response (7 days)</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={createSequence} className="w-full">
            <Plus className="w-4 h-4 mr-2" />
            Create Sequence
          </Button>
        </CardContent>
      </Card>

      <div className="grid gap-4">
        {sequences.map((seq) => (
          <Card key={seq.id}>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-semibold">{seq.name}</h3>
                  <p className="text-sm text-muted-foreground">Trigger: {seq.trigger_event}</p>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" size="sm" onClick={() => toggleSequence(seq.id, seq.status)}>
                    {seq.status === 'active' ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                  </Button>
                  <Button variant="destructive" size="sm">
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
