import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';
import { ThumbsUp, ThumbsDown, Users, CheckCircle, XCircle, Clock, TrendingUp } from 'lucide-react';
import { AIRecommendation, RecommendationVote, realtimeAIRecommendationService } from '@/services/realtimeAIRecommendationService';

interface AIRecommendationVotingPanelProps {
  recommendation: AIRecommendation;
  currentUserId: string;
  onApplied?: () => void;
}

export const AIRecommendationVotingPanel: React.FC<AIRecommendationVotingPanelProps> = ({
  recommendation: initialRecommendation,
  currentUserId,
  onApplied
}) => {
  const [recommendation, setRecommendation] = useState(initialRecommendation);
  const [votes, setVotes] = useState<RecommendationVote[]>([]);
  const [userVote, setUserVote] = useState<'approve' | 'reject' | null>(null);
  const [comment, setComment] = useState('');
  const [isVoting, setIsVoting] = useState(false);
  const [isApplying, setIsApplying] = useState(false);

  useEffect(() => {
    setRecommendation(initialRecommendation);
  }, [initialRecommendation]);

  useEffect(() => {
    const handleUpdate = (updated: AIRecommendation) => {
      if (updated.id === recommendation.id) {
        setRecommendation(updated);
      }
    };

    const handleVote = (vote: RecommendationVote) => {
      if (vote.recommendation_id === recommendation.id) {
        setVotes(prev => [...prev, vote]);
        if (vote.user_id === currentUserId) {
          setUserVote(vote.vote);
        }
      }
    };

    realtimeAIRecommendationService.on('recommendation:updated', handleUpdate);
    realtimeAIRecommendationService.on('vote:new', handleVote);

    return () => {
      realtimeAIRecommendationService.off('recommendation:updated', handleUpdate);
      realtimeAIRecommendationService.off('vote:new', handleVote);
    };
  }, [recommendation.id, currentUserId]);

  const handleVote = async (vote: 'approve' | 'reject') => {
    if (userVote) return;
    
    setIsVoting(true);
    try {
      await realtimeAIRecommendationService.voteOnRecommendation(
        recommendation.id,
        currentUserId,
        vote,
        comment || undefined
      );
      setUserVote(vote);
      setComment('');
    } catch (error) {
      console.error('Failed to vote:', error);
    } finally {
      setIsVoting(false);
    }
  };

  const handleApply = async () => {
    setIsApplying(true);
    try {
      await realtimeAIRecommendationService.applyRecommendation(recommendation.id, currentUserId);
      onApplied?.();
    } catch (error) {
      console.error('Failed to apply recommendation:', error);
    } finally {
      setIsApplying(false);
    }
  };

  const voteProgress = (recommendation.votes_for / recommendation.votes_required) * 100;
  const canApply = recommendation.votes_for >= recommendation.votes_required && recommendation.status === 'pending';

  return (
    <Card className="bg-gray-800 border-gray-700">
      <CardHeader>
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <CardTitle className="text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-blue-400" />
              {recommendation.title}
            </CardTitle>
            <p className="text-sm text-gray-400 mt-1">{recommendation.description}</p>
          </div>
          <Badge variant={recommendation.status === 'applied' ? 'default' : 'secondary'}>
            {recommendation.status}
          </Badge>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            <Users className="w-4 h-4 text-gray-400" />
            <span className="text-sm text-gray-300">
              {recommendation.votes_for} / {recommendation.votes_required} votes
            </span>
          </div>
          <div className="flex-1 bg-gray-700 rounded-full h-2">
            <div
              className="bg-green-500 h-2 rounded-full transition-all"
              style={{ width: `${Math.min(voteProgress, 100)}%` }}
            />
          </div>
        </div>

        {!userVote && recommendation.status === 'pending' && (
          <div className="space-y-3">
            <Textarea
              placeholder="Add a comment (optional)..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
              className="bg-gray-700 border-gray-600 text-white"
              rows={2}
            />
            <div className="flex gap-2">
              <Button
                onClick={() => handleVote('approve')}
                disabled={isVoting}
                className="flex-1 bg-green-600 hover:bg-green-700"
              >
                <ThumbsUp className="w-4 h-4 mr-2" />
                Approve
              </Button>
              <Button
                onClick={() => handleVote('reject')}
                disabled={isVoting}
                variant="destructive"
                className="flex-1"
              >
                <ThumbsDown className="w-4 h-4 mr-2" />
                Reject
              </Button>
            </div>
          </div>
        )}

        {userVote && (
          <div className="flex items-center gap-2 p-3 bg-gray-700 rounded-lg">
            {userVote === 'approve' ? (
              <CheckCircle className="w-5 h-5 text-green-400" />
            ) : (
              <XCircle className="w-5 h-5 text-red-400" />
            )}
            <span className="text-sm text-gray-300">
              You voted to {userVote} this recommendation
            </span>
          </div>
        )}

        {canApply && (
          <Button
            onClick={handleApply}
            disabled={isApplying}
            className="w-full bg-blue-600 hover:bg-blue-700"
          >
            <CheckCircle className="w-4 h-4 mr-2" />
            Apply Recommendation
          </Button>
        )}

        {recommendation.status === 'applied' && (
          <div className="flex items-center gap-2 p-3 bg-green-900/20 border border-green-700 rounded-lg">
            <CheckCircle className="w-5 h-5 text-green-400" />
            <span className="text-sm text-green-300">
              This recommendation has been applied
            </span>
          </div>
        )}

        {votes.length > 0 && (
          <div className="space-y-2">
            <h4 className="text-sm font-medium text-gray-300">Recent Votes</h4>
            <div className="space-y-1 max-h-32 overflow-y-auto">
              {votes.slice(-5).reverse().map((vote) => (
                <div key={vote.id} className="flex items-center gap-2 text-xs text-gray-400">
                  {vote.vote === 'approve' ? (
                    <ThumbsUp className="w-3 h-3 text-green-400" />
                  ) : (
                    <ThumbsDown className="w-3 h-3 text-red-400" />
                  )}
                  <span>User voted to {vote.vote}</span>
                  {vote.comment && <span className="text-gray-500">- {vote.comment}</span>}
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
};
