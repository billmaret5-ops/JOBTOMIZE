import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CheckCircle, Clock, XCircle, AlertCircle } from 'lucide-react';

const statusIcons: any = {
  'Applied': <Clock className="h-4 w-4" />,
  'In Review': <AlertCircle className="h-4 w-4" />,
  'Interview': <CheckCircle className="h-4 w-4" />,
  'Rejected': <XCircle className="h-4 w-4" />
};

const statusColors: any = {
  'Applied': 'bg-blue-500',
  'In Review': 'bg-yellow-500',
  'Interview': 'bg-green-500',
  'Rejected': 'bg-red-500'
};

export function ApplicationSyncDashboard() {
  const [applications, setApplications] = useState<any[]>([
    { id: '1', platform: 'indeed', jobTitle: 'Software Engineer', company: 'Tech Corp', status: 'In Review', appliedDate: '2024-01-15', lastUpdated: '2024-01-18' },
    { id: '2', platform: 'linkedin', jobTitle: 'Product Manager', company: 'Innovation Inc', status: 'Interview', appliedDate: '2024-01-10', lastUpdated: '2024-01-17' },
    { id: '3', platform: 'glassdoor', jobTitle: 'Data Scientist', company: 'AI Solutions', status: 'Applied', appliedDate: '2024-01-20', lastUpdated: '2024-01-20' }
  ]);

  const stats = {
    total: applications.length,
    inReview: applications.filter(a => a.status === 'In Review').length,
    interviews: applications.filter(a => a.status === 'Interview').length,
    rejected: applications.filter(a => a.status === 'Rejected').length
  };

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold">Application Tracking</h2>
        <p className="text-muted-foreground">Monitor your applications across all platforms</p>
      </div>

      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Total Applications</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{stats.total}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">In Review</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-yellow-500">{stats.inReview}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Interviews</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-500">{stats.interviews}</div>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium">Response Rate</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">67%</div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Recent Applications</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {applications.map(app => (
              <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-semibold">{app.jobTitle}</h3>
                    <Badge variant="outline">{app.platform}</Badge>
                  </div>
                  <p className="text-sm text-muted-foreground">{app.company}</p>
                  <p className="text-xs text-muted-foreground mt-1">Applied: {app.appliedDate}</p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={statusColors[app.status]}>
                    {statusIcons[app.status]}
                    <span className="ml-1">{app.status}</span>
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
