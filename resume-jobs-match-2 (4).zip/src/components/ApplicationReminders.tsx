import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useAuth } from '@/contexts/AuthContext';
import { 
  Bell, 
  Clock, 
  Mail, 
  MessageSquare, 
  Calendar,
  Plus,
  Trash2,
  Edit
} from 'lucide-react';
import { toast } from 'sonner';

interface ReminderRule {
  id: string;
  eventType: 'deadline' | 'interview' | 'follow_up' | 'networking';
  timing: '15min' | '1hour' | '1day' | '3days' | '1week';
  methods: {
    browser: boolean;
    email: boolean;
    sms: boolean;
  };
  enabled: boolean;
  customMessage?: string;
}

interface ActiveReminder {
  id: string;
  applicationId: string;
  eventType: string;
  eventDate: string;
  reminderDate: string;
  jobTitle: string;
  companyName: string;
  status: 'scheduled' | 'sent' | 'failed';
}

export function ApplicationReminders() {
  const { user } = useAuth();
  const [reminderRules, setReminderRules] = useState<ReminderRule[]>([]);
  const [activeReminders, setActiveReminders] = useState<ActiveReminder[]>([]);
  const [showAddRule, setShowAddRule] = useState(false);
  const [newRule, setNewRule] = useState<Partial<ReminderRule>>({
    eventType: 'deadline',
    timing: '1day',
    methods: { browser: true, email: false, sms: false },
    enabled: true
  });

  useEffect(() => {
    loadReminderRules();
    loadActiveReminders();
  }, [user]);

  const loadReminderRules = () => {
    // Mock data - replace with actual API call
    const mockRules: ReminderRule[] = [
      {
        id: '1',
        eventType: 'deadline',
        timing: '1day',
        methods: { browser: true, email: true, sms: false },
        enabled: true,
        customMessage: 'Application deadline approaching!'
      },
      {
        id: '2',
        eventType: 'interview',
        timing: '1hour',
        methods: { browser: true, email: false, sms: true },
        enabled: true,
        customMessage: 'Interview starting soon!'
      },
      {
        id: '3',
        eventType: 'follow_up',
        timing: '3days',
        methods: { browser: true, email: true, sms: false },
        enabled: true
      }
    ];
    setReminderRules(mockRules);
  };

  const loadActiveReminders = () => {
    // Mock data - replace with actual API call
    const mockReminders: ActiveReminder[] = [
      {
        id: '1',
        applicationId: '1',
        eventType: 'interview',
        eventDate: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(),
        reminderDate: new Date(Date.now() + 60 * 60 * 1000).toISOString(),
        jobTitle: 'Senior Software Engineer',
        companyName: 'TechFlow Inc',
        status: 'scheduled'
      },
      {
        id: '2',
        applicationId: '2',
        eventType: 'deadline',
        eventDate: new Date(Date.now() + 24 * 60 * 60 * 1000).toISOString(),
        reminderDate: new Date(Date.now() + 12 * 60 * 60 * 1000).toISOString(),
        jobTitle: 'Product Manager',
        companyName: 'InnovateCorp',
        status: 'scheduled'
      }
    ];
    setActiveReminders(mockReminders);
  };

  const addReminderRule = () => {
    if (!newRule.eventType || !newRule.timing) {
      toast.error('Please fill in all required fields');
      return;
    }

    const rule: ReminderRule = {
      id: Date.now().toString(),
      eventType: newRule.eventType as any,
      timing: newRule.timing as any,
      methods: newRule.methods || { browser: true, email: false, sms: false },
      enabled: newRule.enabled ?? true,
      customMessage: newRule.customMessage
    };

    setReminderRules(prev => [...prev, rule]);
    setNewRule({
      eventType: 'deadline',
      timing: '1day',
      methods: { browser: true, email: false, sms: false },
      enabled: true
    });
    setShowAddRule(false);
    toast.success('Reminder rule added');
  };

  const deleteReminderRule = (ruleId: string) => {
    setReminderRules(prev => prev.filter(rule => rule.id !== ruleId));
    toast.success('Reminder rule deleted');
  };

  const toggleRuleEnabled = (ruleId: string) => {
    setReminderRules(prev => 
      prev.map(rule => 
        rule.id === ruleId ? { ...rule, enabled: !rule.enabled } : rule
      )
    );
  };

  const getEventTypeLabel = (type: string) => {
    switch (type) {
      case 'deadline': return 'Application Deadline';
      case 'interview': return 'Interview';
      case 'follow_up': return 'Follow-up';
      case 'networking': return 'Networking Event';
      default: return type;
    }
  };

  const getTimingLabel = (timing: string) => {
    switch (timing) {
      case '15min': return '15 minutes before';
      case '1hour': return '1 hour before';
      case '1day': return '1 day before';
      case '3days': return '3 days before';
      case '1week': return '1 week before';
      default: return timing;
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'scheduled':
        return <Badge variant="outline">Scheduled</Badge>;
      case 'sent':
        return <Badge variant="default">Sent</Badge>;
      case 'failed':
        return <Badge variant="destructive">Failed</Badge>;
      default:
        return <Badge variant="secondary">{status}</Badge>;
    }
  };

  return (
    <div className="space-y-6">
      {/* Reminder Rules */}
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Bell className="w-5 h-5" />
              Reminder Rules
            </CardTitle>
            <Button onClick={() => setShowAddRule(true)}>
              <Plus className="w-4 h-4 mr-1" />
              Add Rule
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {showAddRule && (
            <Card className="mb-4">
              <CardContent className="pt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Event Type</Label>
                    <Select 
                      value={newRule.eventType} 
                      onValueChange={(value) => setNewRule(prev => ({ ...prev, eventType: value as any }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="deadline">Application Deadline</SelectItem>
                        <SelectItem value="interview">Interview</SelectItem>
                        <SelectItem value="follow_up">Follow-up</SelectItem>
                        <SelectItem value="networking">Networking Event</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <Label>Timing</Label>
                    <Select 
                      value={newRule.timing} 
                      onValueChange={(value) => setNewRule(prev => ({ ...prev, timing: value as any }))}
                    >
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="15min">15 minutes before</SelectItem>
                        <SelectItem value="1hour">1 hour before</SelectItem>
                        <SelectItem value="1day">1 day before</SelectItem>
                        <SelectItem value="3days">3 days before</SelectItem>
                        <SelectItem value="1week">1 week before</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="mt-4">
                  <Label>Notification Methods</Label>
                  <div className="flex gap-4 mt-2">
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={newRule.methods?.browser}
                        onCheckedChange={(checked) => 
                          setNewRule(prev => ({ 
                            ...prev, 
                            methods: { ...prev.methods!, browser: checked }
                          }))
                        }
                      />
                      <Label>Browser</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={newRule.methods?.email}
                        onCheckedChange={(checked) => 
                          setNewRule(prev => ({ 
                            ...prev, 
                            methods: { ...prev.methods!, email: checked }
                          }))
                        }
                      />
                      <Label>Email</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Switch
                        checked={newRule.methods?.sms}
                        onCheckedChange={(checked) => 
                          setNewRule(prev => ({ 
                            ...prev, 
                            methods: { ...prev.methods!, sms: checked }
                          }))
                        }
                      />
                      <Label>SMS</Label>
                    </div>
                  </div>
                </div>

                <div className="mt-4">
                  <Label>Custom Message (Optional)</Label>
                  <Input
                    value={newRule.customMessage || ''}
                    onChange={(e) => setNewRule(prev => ({ ...prev, customMessage: e.target.value }))}
                    placeholder="Custom notification message..."
                  />
                </div>

                <div className="flex gap-2 mt-4">
                  <Button onClick={addReminderRule}>Add Rule</Button>
                  <Button variant="outline" onClick={() => setShowAddRule(false)}>Cancel</Button>
                </div>
              </CardContent>
            </Card>
          )}

          <div className="space-y-3">
            {reminderRules.map((rule) => (
              <div key={rule.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center gap-3">
                  <Switch
                    checked={rule.enabled}
                    onCheckedChange={() => toggleRuleEnabled(rule.id)}
                  />
                  <div>
                    <div className="font-medium">{getEventTypeLabel(rule.eventType)}</div>
                    <div className="text-sm text-gray-600">
                      {getTimingLabel(rule.timing)} • 
                      {rule.methods.browser && ' Browser'}
                      {rule.methods.email && ' Email'}
                      {rule.methods.sms && ' SMS'}
                    </div>
                  </div>
                </div>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => deleteReminderRule(rule.id)}
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Active Reminders */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Clock className="w-5 h-5" />
            Active Reminders
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {activeReminders.map((reminder) => (
              <div key={reminder.id} className="p-3 border rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="font-medium">{reminder.jobTitle}</div>
                    <div className="text-sm text-gray-600">{reminder.companyName}</div>
                    <div className="text-xs text-gray-500 mt-1">
                      {getEventTypeLabel(reminder.eventType)} on {new Date(reminder.eventDate).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="text-right">
                    {getStatusBadge(reminder.status)}
                    <div className="text-xs text-gray-500 mt-1">
                      Reminder: {new Date(reminder.reminderDate).toLocaleString()}
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}

export default ApplicationReminders;