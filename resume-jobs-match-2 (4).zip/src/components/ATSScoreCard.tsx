import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Badge } from '@/components/ui/badge';
import { CheckCircle, AlertCircle, XCircle } from 'lucide-react';
import { ATSScore } from '@/types/resume';

interface ATSScoreCardProps {
  score: ATSScore;
}

export function ATSScoreCard({ score }: ATSScoreCardProps) {
  const getScoreColor = (value: number) => {
    if (value >= 80) return 'text-green-600';
    if (value >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreIcon = (value: number) => {
    if (value >= 80) return <CheckCircle className="h-5 w-5 text-green-600" />;
    if (value >= 60) return <AlertCircle className="h-5 w-5 text-yellow-600" />;
    return <XCircle className="h-5 w-5 text-red-600" />;
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span>ATS Optimization Score</span>
          <Badge className={getScoreColor(score.overall)}>
            {score.overall}%
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="space-y-3">
          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Formatting</span>
              <div className="flex items-center gap-2">
                {getScoreIcon(score.formatting)}
                <span className="text-sm">{score.formatting}%</span>
              </div>
            </div>
            <Progress value={score.formatting} />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Keywords</span>
              <div className="flex items-center gap-2">
                {getScoreIcon(score.keywords)}
                <span className="text-sm">{score.keywords}%</span>
              </div>
            </div>
            <Progress value={score.keywords} />
          </div>

          <div>
            <div className="flex items-center justify-between mb-2">
              <span className="text-sm font-medium">Sections</span>
              <div className="flex items-center gap-2">
                {getScoreIcon(score.sections)}
                <span className="text-sm">{score.sections}%</span>
              </div>
            </div>
            <Progress value={score.sections} />
          </div>
        </div>

        <div className="border-t pt-4">
          <h4 className="font-semibold mb-2">Suggestions</h4>
          <ul className="space-y-2">
            {score.suggestions.map((suggestion, i) => (
              <li key={i} className="text-sm text-gray-600 flex items-start gap-2">
                <span className="text-blue-500">•</span>
                {suggestion}
              </li>
            ))}
          </ul>
        </div>
      </CardContent>
    </Card>
  );
}
