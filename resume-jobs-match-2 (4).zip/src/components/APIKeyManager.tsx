import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Eye, EyeOff, Copy, Trash2, Plus, Check } from 'lucide-react';

interface APIKey {
  id: string;
  name: string;
  key: string;
  provider: string;
  createdAt: Date;
  isActive: boolean;
}

export default function APIKeyManager() {
  const [keys, setKeys] = useState<APIKey[]>([]);
  const [visibleKeys, setVisibleKeys] = useState<Set<string>>(new Set());
  const [copiedKey, setCopiedKey] = useState<string | null>(null);
  const [isAdding, setIsAdding] = useState(false);
  const [newKey, setNewKey] = useState({ name: '', key: '', provider: 'sendgrid' });

  const toggleKeyVisibility = (id: string) => {
    const newVisible = new Set(visibleKeys);
    if (newVisible.has(id)) {
      newVisible.delete(id);
    } else {
      newVisible.add(id);
    }
    setVisibleKeys(newVisible);
  };

  const copyToClipboard = async (key: string, id: string) => {
    await navigator.clipboard.writeText(key);
    setCopiedKey(id);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleAddKey = () => {
    if (newKey.name && newKey.key) {
      const key: APIKey = {
        id: Date.now().toString(),
        name: newKey.name,
        key: newKey.key,
        provider: newKey.provider,
        createdAt: new Date(),
        isActive: true
      };
      setKeys([...keys, key]);
      setNewKey({ name: '', key: '', provider: 'sendgrid' });
      setIsAdding(false);
    }
  };

  const maskKey = (key: string) => {
    if (key.length <= 8) return '••••••••';
    return key.substring(0, 4) + '••••••••••••' + key.substring(key.length - 4);
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">API Key Management</h2>
        <Button onClick={() => setIsAdding(!isAdding)}><Plus className="w-4 h-4 mr-2" />Add API Key</Button>
      </div>

      {isAdding && (
        <Card>
          <CardHeader><CardTitle>Add New API Key</CardTitle></CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div>
                <Label>Key Name</Label>
                <Input value={newKey.name} onChange={(e) => setNewKey({ ...newKey, name: e.target.value })} placeholder="Production SendGrid Key" />
              </div>
              <div>
                <Label>API Key</Label>
                <Input type="password" value={newKey.key} onChange={(e) => setNewKey({ ...newKey, key: e.target.value })} placeholder="Enter API key" />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddKey}>Add Key</Button>
                <Button variant="outline" onClick={() => setIsAdding(false)}>Cancel</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-4">
        {keys.map((key) => (
          <Card key={key.id}>
            <CardContent className="pt-6">
              <div className="flex justify-between items-start">
                <div className="flex-1">
                  <div className="flex items-center gap-2 mb-2">
                    <h3 className="font-semibold">{key.name}</h3>
                    <Badge>{key.provider}</Badge>
                  </div>
                  <div className="flex items-center gap-2">
                    <code className="text-sm bg-muted px-2 py-1 rounded">
                      {visibleKeys.has(key.id) ? key.key : maskKey(key.key)}
                    </code>
                    <Button size="sm" variant="ghost" onClick={() => toggleKeyVisibility(key.id)}>
                      {visibleKeys.has(key.id) ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </Button>
                    <Button size="sm" variant="ghost" onClick={() => copyToClipboard(key.key, key.id)}>
                      {copiedKey === key.id ? <Check className="w-4 h-4 text-green-500" /> : <Copy className="w-4 h-4" />}
                    </Button>
                  </div>
                </div>
                <Button size="sm" variant="destructive" onClick={() => setKeys(keys.filter(k => k.id !== key.id))}>
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
