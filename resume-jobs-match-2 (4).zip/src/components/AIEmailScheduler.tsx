import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Calendar, Clock, Brain, TrendingUp } from 'lucide-react';
import { RecipientBehaviorPatternService } from '../services/recipientBehaviorPatternService';

interface OptimalSendTime {
  recipientId: string;
  recommendedTime: Date;
  confidence: number;
  reason: string;
}

export default function AIEmailScheduler() {
  const [recipients, setRecipients] = useState<string[]>([]);
  const [optimalTimes, setOptimalTimes] = useState<OptimalSendTime[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [modelMetrics, setModelMetrics] = useState<any>(null);

  const analyzeOptimalTimes = async () => {
    setIsAnalyzing(true);
    try {
      const times = await RecipientBehaviorPatternService.getBulkOptimalSendTimes(
        'user-id', 
        recipients, 
        'sequence-id'
      );
      setOptimalTimes(times);
    } catch (error) {
      console.error('Error analyzing optimal times:', error);
    } finally {
      setIsAnalyzing(false);
    }
  };

  const trainModel = async () => {
    try {
      await RecipientBehaviorPatternService.trainSendTimeModel('user-id');
      // Simulate model metrics
      setModelMetrics({
        accuracy: 0.89,
        precision: 0.92,
        recall: 0.87,
        f1Score: 0.89
      });
    } catch (error) {
      console.error('Error training model:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Brain className="h-5 w-5" />
            AI Email Scheduler
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Button onClick={analyzeOptimalTimes} disabled={isAnalyzing}>
              {isAnalyzing ? 'Analyzing...' : 'Analyze Send Times'}
            </Button>
            <Button variant="outline" onClick={trainModel}>
              Train ML Model
            </Button>
          </div>

          {modelMetrics && (
            <div className="grid grid-cols-4 gap-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{(modelMetrics.accuracy * 100).toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Accuracy</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{(modelMetrics.precision * 100).toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Precision</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{(modelMetrics.recall * 100).toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">Recall</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold">{(modelMetrics.f1Score * 100).toFixed(1)}%</div>
                <div className="text-sm text-muted-foreground">F1 Score</div>
              </div>
            </div>
          )}

          <div className="space-y-3">
            {optimalTimes.map((time) => (
              <div key={time.recipientId} className="flex items-center justify-between p-3 border rounded">
                <div>
                  <div className="font-medium">{time.recipientId}</div>
                  <div className="text-sm text-muted-foreground">{time.reason}</div>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-2">
                    <Calendar className="h-4 w-4" />
                    {new Date(time.recommendedTime).toLocaleString()}
                  </div>
                  <Badge variant={time.confidence > 0.8 ? 'default' : 'secondary'}>
                    {(time.confidence * 100).toFixed(0)}% confidence
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}