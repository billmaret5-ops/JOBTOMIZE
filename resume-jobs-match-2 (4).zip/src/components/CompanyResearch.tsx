import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Building, Users, TrendingUp, MessageSquare, Search, Loader2 } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface CompanyResearchProps {
  companyName?: string;
  onResearchComplete?: (data: any) => void;
}

export default function CompanyResearch({ companyName, onResearchComplete }: CompanyResearchProps) {
  const [searchTerm, setSearchTerm] = useState(companyName || '');
  const [researchData, setResearchData] = useState<any>(null);
  const [loading, setLoading] = useState(false);
  const [savedResearch, setSavedResearch] = useState<any[]>([]);
  const { user } = useAuth();

  useEffect(() => {
    if (user) {
      loadSavedResearch();
    }
  }, [user]);

  const loadSavedResearch = async () => {
    const { data } = await supabase
      .from('company_research')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) setSavedResearch(data);
  };

  const conductResearch = async () => {
    if (!searchTerm.trim()) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('company-research', {
        body: { companyName: searchTerm }
      });

      if (error) throw error;

      if (data.success) {
        setResearchData(data.data);
        await saveResearch(data.data);
        onResearchComplete?.(data.data);
      }
    } catch (error) {
      console.error('Research failed:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveResearch = async (data: any) => {
    await supabase.from('company_research').insert({
      company_name: searchTerm,
      company_info: data.companyInfo,
      recent_news: data.recentNews,
      key_employees: data.keyEmployees,
      interview_tips: data.interviewTips
    });
    loadSavedResearch();
  };

  return (
    <div className="space-y-6">
      <div className="flex gap-2">
        <Input
          placeholder="Enter company name..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          onKeyPress={(e) => e.key === 'Enter' && conductResearch()}
        />
        <Button onClick={conductResearch} disabled={loading}>
          {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <Search className="h-4 w-4" />}
          Research
        </Button>
      </div>

      {researchData && (
        <Tabs defaultValue="overview" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="news">News</TabsTrigger>
            <TabsTrigger value="people">People</TabsTrigger>
            <TabsTrigger value="tips">Interview Tips</TabsTrigger>
          </TabsList>

          <TabsContent value="overview">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Building className="h-5 w-5" />
                  Company Overview
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold">Industry</h4>
                  <p>{researchData.companyInfo?.industry}</p>
                </div>
                <div>
                  <h4 className="font-semibold">Mission</h4>
                  <p>{researchData.companyInfo?.mission}</p>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="news">
            <div className="space-y-4">
              {researchData.recentNews?.map((news: any, index: number) => (
                <Card key={index}>
                  <CardContent className="pt-6">
                    <h4 className="font-semibold">{news.title}</h4>
                    <p className="text-sm text-gray-600 mt-2">{news.summary}</p>
                    <Badge variant="outline" className="mt-2">{news.source}</Badge>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="people">
            <div className="grid gap-4">
              {researchData.keyEmployees?.map((employee: any, index: number) => (
                <Card key={index}>
                  <CardContent className="pt-6">
                    <div className="flex items-start gap-4">
                      <Users className="h-8 w-8 text-blue-500 mt-1" />
                      <div>
                        <h4 className="font-semibold">{employee.name}</h4>
                        <p className="text-sm text-blue-600">{employee.position}</p>
                        <p className="text-sm text-gray-600 mt-2">{employee.background}</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="tips">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Interview Preparation
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <h4 className="font-semibold">Company Culture</h4>
                  <p>{researchData.interviewTips?.culture}</p>
                </div>
                <div>
                  <h4 className="font-semibold">Common Questions</h4>
                  <ul className="list-disc list-inside space-y-1">
                    {researchData.interviewTips?.commonQuestions?.map((q: string, i: number) => (
                      <li key={i} className="text-sm">{q}</li>
                    ))}
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold">What They Value</h4>
                  <div className="flex flex-wrap gap-2 mt-2">
                    {researchData.interviewTips?.whatTheyValue?.map((value: string, i: number) => (
                      <Badge key={i} variant="secondary">{value}</Badge>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      )}
    </div>
  );
}