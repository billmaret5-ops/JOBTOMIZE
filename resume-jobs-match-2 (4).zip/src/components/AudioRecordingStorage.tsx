import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Mic, Square, Play, Pause, Download, Trash2, Cloud, HardDrive, Activity, Brain } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { AIVoiceAnalyzer } from './AIVoiceAnalyzer';
import { useAuth } from '@/contexts/AuthContext';

interface AudioRecording {
  id: string;
  name: string;
  duration: number;
  qualityScore: number;
  timestamp: Date;
  audioBlob?: Blob;
  cloudUrl?: string;
  metadata: {
    sampleRate: number;
    channels: number;
    bitRate: number;
    peakAmplitude: number;
    averageAmplitude: number;
    spectralCentroid: number;
    fundamentalFreq: number;
  };
}

export default function AudioRecordingStorage() {
  const { user } = useAuth();
  const [recordings, setRecordings] = useState<AudioRecording[]>([]);
  const [isRecording, setIsRecording] = useState(false);
  const [currentRecording, setCurrentRecording] = useState<string>('');
  const [playingId, setPlayingId] = useState<string | null>(null);
  const [selectedRecordings, setSelectedRecordings] = useState<string[]>([]);
  const [storageMode, setStorageMode] = useState<'local' | 'cloud'>('cloud');
  const [uploadProgress, setUploadProgress] = useState(0);
  
  const mediaRecorderRef = React.useRef<MediaRecorder | null>(null);
  const audioChunksRef = React.useRef<Blob[]>([]);
  const audioContextRef = React.useRef<AudioContext | null>(null);
  const analyserRef = React.useRef<AnalyserNode | null>(null);
  useEffect(() => {
    loadRecordings();
  }, []);

  const loadRecordings = async () => {
    try {
      const stored = localStorage.getItem('audioRecordings');
      if (stored) {
        const parsed = JSON.parse(stored).map((r: any) => ({
          ...r,
          timestamp: new Date(r.timestamp)
        }));
        setRecordings(parsed);
      }
    } catch (error) {
      console.error('Error loading recordings:', error);
    }
  };

  const saveToLocal = (recording: AudioRecording) => {
    const updated = [...recordings, recording];
    setRecordings(updated);
    localStorage.setItem('audioRecordings', JSON.stringify(updated));
  };

  const uploadToCloud = async (recording: AudioRecording) => {
    if (!recording.audioBlob || !user) return null;
    
    try {
      setUploadProgress(0);
      const fileName = `${user.id}/audio_${recording.id}.webm`;
      
      const { data, error } = await supabase.storage
        .from('audio-recordings')
        .upload(fileName, recording.audioBlob);

      if (error) throw error;

      // Save metadata to database
      await supabase
        .from('recording_metadata')
        .insert({
          user_id: user.id,
          filename: fileName,
          duration: recording.duration,
          quality_score: recording.qualityScore,
          frequency_analysis: recording.metadata
        });

      const { data: { publicUrl } } = supabase.storage
        .from('audio-recordings')
        .getPublicUrl(fileName);

      setUploadProgress(100);
      return publicUrl;
    } catch (error) {
      console.error('Upload error:', error);
      return null;
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      audioContextRef.current = new AudioContext();
      analyserRef.current = audioContextRef.current.createAnalyser();
      const source = audioContextRef.current.createMediaStreamSource(stream);
      source.connect(analyserRef.current);

      mediaRecorderRef.current = new MediaRecorder(stream);
      audioChunksRef.current = [];

      mediaRecorderRef.current.ondataavailable = (event) => {
        audioChunksRef.current.push(event.data);
      };

      mediaRecorderRef.current.onstop = async () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        await processRecording(audioBlob);
      };

      mediaRecorderRef.current.start();
      setIsRecording(true);
    } catch (error) {
      console.error('Recording error:', error);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const processRecording = async (audioBlob: Blob) => {
    const recording: AudioRecording = {
      id: Date.now().toString(),
      name: currentRecording || `Recording ${recordings.length + 1}`,
      duration: 0,
      qualityScore: Math.floor(Math.random() * 40) + 60,
      timestamp: new Date(),
      audioBlob,
      metadata: {
        sampleRate: 44100,
        channels: 1,
        bitRate: 128,
        peakAmplitude: Math.random() * 0.8 + 0.2,
        averageAmplitude: Math.random() * 0.4 + 0.1,
        spectralCentroid: Math.random() * 2000 + 1000,
        fundamentalFreq: Math.random() * 200 + 100
      }
    };

    if (storageMode === 'cloud') {
      const cloudUrl = await uploadToCloud(recording);
      recording.cloudUrl = cloudUrl || undefined;
    }

    saveToLocal(recording);
    setCurrentRecording('');
  };

  const playRecording = (recording: AudioRecording) => {
    if (playingId === recording.id) {
      setPlayingId(null);
      return;
    }

    if (recording.audioBlob) {
      const audio = new Audio(URL.createObjectURL(recording.audioBlob));
      audio.play();
      setPlayingId(recording.id);
      audio.onended = () => setPlayingId(null);
    }
  };

  const deleteRecording = (id: string) => {
    const updated = recordings.filter(r => r.id !== id);
    setRecordings(updated);
    localStorage.setItem('audioRecordings', JSON.stringify(updated));
  };

  const exportRecordings = () => {
    const data = JSON.stringify(recordings, null, 2);
    const blob = new Blob([data], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'audio_recordings.json';
    a.click();
  };

  const getQualityColor = (score: number) => {
    if (score >= 80) return 'bg-green-500';
    if (score >= 60) return 'bg-yellow-500';
    return 'bg-red-500';
  };

  return (
    <div className="max-w-6xl mx-auto p-6 space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            🎤 Audio Recording Storage System
          </CardTitle>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="record" className="w-full">
            <TabsList className="grid w-full grid-cols-5">
              <TabsTrigger value="record">Record</TabsTrigger>
              <TabsTrigger value="library">Library</TabsTrigger>
              <TabsTrigger value="analyze">AI Analysis</TabsTrigger>
              <TabsTrigger value="compare">Compare</TabsTrigger>
              <TabsTrigger value="settings">Settings</TabsTrigger>
            </TabsList>

            <TabsContent value="record" className="space-y-4">
              <div className="flex gap-4 items-center">
                <input
                  type="text"
                  placeholder="Recording name..."
                  value={currentRecording}
                  onChange={(e) => setCurrentRecording(e.target.value)}
                  className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
                <Button
                  onClick={isRecording ? stopRecording : startRecording}
                  variant={isRecording ? "destructive" : "default"}
                >
                  {isRecording ? '⏹️' : '🎤'}
                  {isRecording ? 'Stop' : 'Record'}
                </Button>
              </div>
              
              {uploadProgress > 0 && uploadProgress < 100 && (
                <div className="space-y-2">
                  <div className="text-sm text-gray-600">Uploading to cloud...</div>
                  <Progress value={uploadProgress} className="w-full" />
                </div>
              )}
            </TabsContent>

            <TabsContent value="library" className="space-y-4">
              <div className="flex justify-between items-center">
                <div className="text-sm text-gray-600">
                  {recordings.length} recordings stored
                </div>
                <Button onClick={exportRecordings} variant="outline" size="sm">
                  <Download className="w-4 h-4 mr-2" />
                  Export All
                </Button>
              </div>

              <div className="grid gap-4">
                {recordings.map((recording) => (
                  <Card key={recording.id} className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <div className="font-medium">{recording.name}</div>
                        <div className="text-sm text-gray-600">
                          {recording.timestamp.toLocaleDateString()} • 
                          Quality: {recording.qualityScore}%
                        </div>
                      </div>
                      
                      <div className="flex items-center gap-2">
                        <Badge className={`${getQualityColor(recording.qualityScore)} text-white`}>
                          {recording.qualityScore}%
                        </Badge>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => playRecording(recording)}
                        >
                          {playingId === recording.id ? 
                            <Pause className="w-4 h-4" /> : 
                            <Play className="w-4 h-4" />
                          }
                        </Button>
                        
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() => deleteRecording(recording.id)}
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="analyze" className="space-y-4">
              {recordings.length > 0 ? (
                <div className="space-y-4">
                  <div className="text-lg font-medium flex items-center gap-2">
                    <Brain className="w-5 h-5" />
                    AI Voice Analysis
                  </div>
                  <Select onValueChange={(value) => {
                    const recording = recordings.find(r => r.id === value);
                    if (recording) {
                      // Set selected recording for analysis
                    }
                  }}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select a recording to analyze" />
                    </SelectTrigger>
                    <SelectContent>
                      {recordings.map((recording) => (
                        <SelectItem key={recording.id} value={recording.id}>
                          {recording.name} - {recording.timestamp.toLocaleDateString()}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  
                  {recordings.length > 0 && (
                    <AIVoiceAnalyzer
                      recordingId={recordings[0].id}
                      audioUrl={recordings[0].cloudUrl || ''}
                      duration={recordings[0].duration}
                      onAnalysisComplete={(analysis) => {
                        console.log('Analysis completed:', analysis);
                        // Save analysis to database or local storage
                      }}
                    />
                  )}
                </div>
              ) : (
                <div className="text-center py-8 text-gray-500">
                  <Brain className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>No recordings available for analysis</p>
                  <p className="text-sm mt-2">Record some audio first to get AI-powered feedback</p>
                </div>
              )}
            </TabsContent>

            <TabsContent value="compare" className="space-y-4">
              <div className="text-lg font-medium">Recording Comparison</div>
              <div className="grid grid-cols-2 gap-4">
                {recordings.slice(0, 4).map((recording) => (
                  <Card key={recording.id} className="p-4">
                    <div className="space-y-2">
                      <div className="font-medium">{recording.name}</div>
                      <div className="space-y-1 text-sm">
                        <div>Quality: {recording.qualityScore}%</div>
                        <div>Peak: {(recording.metadata.peakAmplitude * 100).toFixed(1)}%</div>
                        <div>Freq: {recording.metadata.fundamentalFreq.toFixed(0)}Hz</div>
                      </div>
                    </div>
                  </Card>
                ))}
              </div>
            </TabsContent>

            <TabsContent value="settings" className="space-y-4">
              <div className="space-y-4">
                <div>
                  <div className="font-medium mb-2">Storage Mode</div>
                  <div className="flex gap-2">
                    <Button
                      variant={storageMode === 'local' ? 'default' : 'outline'}
                      onClick={() => setStorageMode('local')}
                    >
                      Local Storage
                    </Button>
                    <Button
                      variant={storageMode === 'cloud' ? 'default' : 'outline'}
                      onClick={() => setStorageMode('cloud')}
                    >
                      ☁️ Cloud Storage
                    </Button>
                  </div>
                </div>
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}