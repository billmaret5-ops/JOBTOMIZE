import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Brain, Target, TrendingUp, Star, MapPin, Building, Clock } from 'lucide-react';
import { aiService } from '@/lib/aiService';
import { useAuth } from '@/contexts/AuthContext';

interface MatchedJob {
  id: string;
  title: string;
  company: string;
  location: string;
  salary: string;
  description: string;
  matchScore: number;
  skillsMatch: string[];
  missingSkills: string[];
  experienceMatch: number;
  cultureFit: number;
  reasons: string[];
}

interface JobMatcherProps {
  userProfile?: any;
  preferences?: any;
  onJobSelect?: (job: MatchedJob) => void;
}

export function AIJobMatcher({ userProfile, preferences, onJobSelect }: JobMatcherProps) {
  const [matchedJobs, setMatchedJobs] = useState<MatchedJob[]>([]);
  const [loading, setLoading] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const { user } = useAuth();

  useEffect(() => {
    if (userProfile) {
      analyzeJobMatches();
    }
  }, [userProfile]);

  const analyzeJobMatches = async () => {
    setLoading(true);
    try {
      const sampleJobs = [
        {
          id: '1',
          title: 'Senior React Developer',
          company: 'TechCorp Inc',
          location: 'San Francisco, CA',
          salary: '$120,000 - $150,000',
          description: 'We are looking for a Senior React Developer with 5+ years of experience...',
        },
        {
          id: '2', 
          title: 'Full Stack Engineer',
          company: 'StartupXYZ',
          location: 'Remote',
          salary: '$100,000 - $130,000',
          description: 'Join our fast-growing startup as a Full Stack Engineer...',
        },
        {
          id: '3',
          title: 'Frontend Developer',
          company: 'Design Studio',
          location: 'New York, NY',
          salary: '$90,000 - $110,000',
          description: 'Creative frontend developer needed for innovative projects...',
        }
      ];

      const analyzed = await Promise.all(
        sampleJobs.map(async (job) => {
          const analysis = await aiService.analyzeJobDescription(job.description);
          return {
            ...job,
            matchScore: Math.floor(Math.random() * 30) + 70,
            skillsMatch: ['React', 'JavaScript', 'TypeScript'],
            missingSkills: ['Python', 'AWS'],
            experienceMatch: Math.floor(Math.random() * 20) + 80,
            cultureFit: Math.floor(Math.random() * 25) + 75,
            reasons: [
              'Strong technical skills alignment',
              'Experience level matches requirements',
              'Location preference match'
            ]
          };
        })
      );

      setMatchedJobs(analyzed.sort((a, b) => b.matchScore - a.matchScore));
    } catch (error) {
      console.error('Error analyzing job matches:', error);
    } finally {
      setLoading(false);
    }
  };

  const getMatchColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-blue-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getMatchBadge = (score: number) => {
    if (score >= 90) return 'Excellent Match';
    if (score >= 75) return 'Good Match';
    if (score >= 60) return 'Fair Match';
    return 'Poor Match';
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Brain className="h-6 w-6 text-blue-600" />
          <h2 className="text-2xl font-bold">AI Job Matcher</h2>
        </div>
        <Button onClick={analyzeJobMatches} disabled={loading}>
          {loading ? 'Analyzing...' : 'Refresh Matches'}
        </Button>
      </div>

      <Tabs defaultValue="matches" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="matches">Job Matches</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>

        <TabsContent value="matches" className="space-y-4">
          {matchedJobs.map((job) => (
            <Card key={job.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-xl">{job.title}</CardTitle>
                    <div className="flex items-center gap-4 text-sm text-gray-600 mt-2">
                      <div className="flex items-center gap-1">
                        <Building className="h-4 w-4" />
                        {job.company}
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        {job.location}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        {job.salary}
                      </div>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className={`text-2xl font-bold ${getMatchColor(job.matchScore)}`}>
                      {job.matchScore}%
                    </div>
                    <Badge variant="outline">{getMatchBadge(job.matchScore)}</Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div>
                    <div className="text-sm font-medium mb-1">Skills Match</div>
                    <Progress value={job.skillsMatch.length * 20} className="h-2" />
                    <div className="text-xs text-gray-600 mt-1">
                      {job.skillsMatch.length} skills matched
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium mb-1">Experience</div>
                    <Progress value={job.experienceMatch} className="h-2" />
                    <div className="text-xs text-gray-600 mt-1">
                      {job.experienceMatch}% match
                    </div>
                  </div>
                  <div>
                    <div className="text-sm font-medium mb-1">Culture Fit</div>
                    <Progress value={job.cultureFit} className="h-2" />
                    <div className="text-xs text-gray-600 mt-1">
                      {job.cultureFit}% fit
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap gap-2">
                  {job.skillsMatch.map((skill) => (
                    <Badge key={skill} variant="secondary" className="bg-green-100 text-green-800">
                      ✓ {skill}
                    </Badge>
                  ))}
                  {job.missingSkills.map((skill) => (
                    <Badge key={skill} variant="outline" className="text-orange-600">
                      {skill}
                    </Badge>
                  ))}
                </div>

                <div className="space-y-2">
                  <div className="text-sm font-medium">Why this is a good match:</div>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {job.reasons.map((reason, index) => (
                      <li key={index} className="flex items-center gap-2">
                        <Star className="h-3 w-3 text-yellow-500" />
                        {reason}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="flex gap-2">
                  <Button 
                    onClick={() => onJobSelect?.(job)}
                    className="flex-1"
                  >
                    View Details
                  </Button>
                  <Button variant="outline" className="flex-1">
                    Save Job
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="insights" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Market Insights
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="p-4 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">87%</div>
                  <div className="text-sm text-gray-600">Average Match Score</div>
                </div>
                <div className="p-4 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">12</div>
                  <div className="text-sm text-gray-600">Jobs Above 80% Match</div>
                </div>
              </div>
              <div className="space-y-2">
                <h4 className="font-medium">Top Skills in Demand:</h4>
                <div className="flex flex-wrap gap-2">
                  {['React', 'TypeScript', 'Node.js', 'AWS', 'Python'].map((skill) => (
                    <Badge key={skill} variant="secondary">{skill}</Badge>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="recommendations" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                AI Recommendations
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-3">
                <div className="p-3 bg-yellow-50 border-l-4 border-yellow-400 rounded">
                  <h4 className="font-medium text-yellow-800">Skill Gap Analysis</h4>
                  <p className="text-sm text-yellow-700">
                    Consider learning AWS and Docker to increase your match rate by 15%
                  </p>
                </div>
                <div className="p-3 bg-blue-50 border-l-4 border-blue-400 rounded">
                  <h4 className="font-medium text-blue-800">Location Optimization</h4>
                  <p className="text-sm text-blue-700">
                    Remote positions show 23% higher match rates for your profile
                  </p>
                </div>
                <div className="p-3 bg-green-50 border-l-4 border-green-400 rounded">
                  <h4 className="font-medium text-green-800">Profile Strength</h4>
                  <p className="text-sm text-green-700">
                    Your React and TypeScript experience is highly valued in the current market
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}