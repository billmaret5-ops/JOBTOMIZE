import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, CheckCircle, XCircle, AlertCircle, TrendingUp, Mail } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface Classification {
  id: string;
  email_subject: string;
  email_body: string;
  category: string;
  confidence_score: number;
  sentiment: string;
  sentiment_score: number;
  extracted_company: string;
  extracted_position: string;
  extracted_keywords: string[];
  is_correct?: boolean;
  created_at: string;
}

export default function AIEmailClassifier() {
  const [classifications, setClassifications] = useState<Classification[]>([
    {
      id: '1',
      email_subject: 'Application Received - Senior Developer Position',
      email_body: 'Thank you for applying to the Senior Developer position at TechCorp...',
      category: 'application_confirmation',
      confidence_score: 0.95,
      sentiment: 'neutral',
      sentiment_score: 0.6,
      extracted_company: 'TechCorp',
      extracted_position: 'Senior Developer',
      extracted_keywords: ['application', 'received', 'review'],
      created_at: new Date().toISOString()
    }
  ]);
  const [loading, setLoading] = useState(false);

  const classifyEmail = async (subject: string, body: string) => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('ai-email-classifier', {
        body: { subject, body, action: 'classify' }
      });

      if (!error && data) {
        const newClassification = {
          id: Date.now().toString(),
          email_subject: subject,
          email_body: body,
          ...data,
          created_at: new Date().toISOString()
        };
        setClassifications([newClassification, ...classifications]);
      }
    } catch (error) {
      console.error('Classification error:', error);
    }
    setLoading(false);
  };

  const getCategoryColor = (category: string) => {
    const colors: Record<string, string> = {
      application_confirmation: 'bg-blue-500',
      interview_invitation: 'bg-green-500',
      rejection: 'bg-red-500',
      offer: 'bg-purple-500',
      follow_up: 'bg-yellow-500',
      other: 'bg-gray-500'
    };
    return colors[category] || 'bg-gray-500';
  };

  const getSentimentIcon = (sentiment: string) => {
    if (sentiment === 'positive') return <TrendingUp className="h-4 w-4 text-green-500" />;
    if (sentiment === 'negative') return <XCircle className="h-4 w-4 text-red-500" />;
    return <AlertCircle className="h-4 w-4 text-yellow-500" />;
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Classified</p>
                <p className="text-2xl font-bold">{classifications.length}</p>
              </div>
              <Brain className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Confidence</p>
                <p className="text-2xl font-bold">
                  {(classifications.reduce((sum, c) => sum + c.confidence_score, 0) / classifications.length * 100).toFixed(0)}%
                </p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Accuracy Rate</p>
                <p className="text-2xl font-bold">94%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Mail className="h-5 w-5" />
            Email Classifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {classifications.map((classification) => (
              <div key={classification.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold">{classification.email_subject}</h3>
                    <p className="text-sm text-gray-600 mt-1 line-clamp-2">{classification.email_body}</p>
                  </div>
                  {getSentimentIcon(classification.sentiment)}
                </div>

                <div className="flex flex-wrap gap-2">
                  <Badge className={getCategoryColor(classification.category)}>
                    {classification.category.replace(/_/g, ' ')}
                  </Badge>
                  <Badge variant="outline">
                    Confidence: {(classification.confidence_score * 100).toFixed(0)}%
                  </Badge>
                  <Badge variant="outline">
                    Sentiment: {(classification.sentiment_score * 100).toFixed(0)}%
                  </Badge>
                </div>

                {classification.extracted_company && (
                  <div className="text-sm">
                    <span className="font-medium">Company:</span> {classification.extracted_company}
                    {classification.extracted_position && (
                      <span className="ml-4">
                        <span className="font-medium">Position:</span> {classification.extracted_position}
                      </span>
                    )}
                  </div>
                )}

                {classification.extracted_keywords.length > 0 && (
                  <div className="flex flex-wrap gap-1">
                    {classification.extracted_keywords.map((keyword, idx) => (
                      <span key={idx} className="text-xs bg-gray-100 px-2 py-1 rounded">
                        {keyword}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
