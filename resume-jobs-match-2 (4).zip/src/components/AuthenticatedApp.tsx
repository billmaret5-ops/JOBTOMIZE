import React from 'react';
import { Routes, Route, Navigate } from 'react-router-dom';
import { useAuth } from '@/contexts/AuthContext';
import { Navigation } from './Navigation';
import { Footer } from './Footer';
import { RealTimeEmailAnalyticsDashboard } from './RealTimeEmailAnalyticsDashboard';
import { UserProfile } from './auth/UserProfile';
import { AdminDashboard } from './AdminDashboard';
import { ProtectedRoute } from './auth/ProtectedRoute';
import { RoleBasedRoute } from './auth/RoleBasedRoute';

export function AuthenticatedApp() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Navigation />
      
      <main className="pt-16">
        <Routes>
          <Route path="/" element={
            <ProtectedRoute>
              <RealTimeEmailAnalyticsDashboard />
            </ProtectedRoute>
          } />
          
          <Route path="/profile" element={
            <ProtectedRoute>
              <UserProfile />
            </ProtectedRoute>
          } />
          
          <Route path="/admin" element={
            <RoleBasedRoute requiredRole="admin">
              <AdminDashboard />
            </RoleBasedRoute>
          } />
          
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </main>

      <Footer />
    </div>
  );
}