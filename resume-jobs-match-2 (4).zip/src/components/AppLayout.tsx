import React from 'react';
import { useAuth } from '@/contexts/ProductionAuthContext';
import { JobSearchLandingPage } from '@/components/JobSearchLandingPage';
import { AuthenticatedLayout } from '@/components/AuthenticatedLayout';
import { Button } from '@/components/ui/button';
import { AlertCircle } from 'lucide-react';
import EdgeFunctionTester from '@/components/EdgeFunctionTester';
import FetchJobsDiagnostics from '@/components/FetchJobsDiagnostics';
import { OfflineIndicator } from '@/components/OfflineIndicator';
import { EnhancedPWAInstallPrompt } from '@/components/EnhancedPWAInstallPrompt';
import { PWAUpdateNotification } from '@/components/PWAUpdateNotification';


export default function AppLayout() {
  const { user, loading } = useAuth();

  // Simplified: Only check for essential query params
  const urlParams = new URLSearchParams(window.location.search);
  const showDiagnostics = urlParams.has('diagnostics');

  // Show loading spinner
  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-blue-50 to-indigo-100">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading Jobtomize...</p>
        </div>
      </div>
    );
  }

  // Diagnostics mode
  if (showDiagnostics) {
    return (
      <div className="min-h-screen bg-gray-50 p-8">
        <div className="max-w-6xl mx-auto space-y-6">
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-3">
                <AlertCircle className="h-6 w-6 text-blue-600" />
                <h1 className="text-xl font-bold text-blue-900">Diagnostics Mode</h1>
              </div>
              <Button onClick={() => window.location.href = '/'}>
                Exit Diagnostics
              </Button>
            </div>
            <div className="space-y-4 text-sm">
              <div>
                <p className="font-semibold text-gray-900">Auth Status:</p>
                <p className="text-gray-700">{user ? `Logged in as ${user.email}` : 'Not logged in (using anon key)'}</p>
              </div>
              <div>
                <p className="font-semibold text-gray-900">Supabase URL:</p>
                <p className="text-gray-700 font-mono text-xs break-all">
                  {import.meta.env.VITE_SUPABASE_URL || 'Not configured'}
                </p>
              </div>
            </div>
          </div>

          <EdgeFunctionTester />
          <FetchJobsDiagnostics />
        </div>
      </div>
    );
  }

  // Main app
  return (
    <>
      <OfflineIndicator />
      <EnhancedPWAInstallPrompt />
      <PWAUpdateNotification />
      {user ? <AuthenticatedLayout /> : <JobSearchLandingPage />}
    </>
  );
}
