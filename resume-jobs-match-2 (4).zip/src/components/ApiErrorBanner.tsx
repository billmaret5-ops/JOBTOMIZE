import { useState, useEffect } from 'react';
import { AlertTriangle, X, Wrench } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ApiErrorBanner() {
  const [visible, setVisible] = useState(false);
  const [dismissed, setDismissed] = useState(false);

  useEffect(() => {
    // Listen for console errors
    const originalError = console.error;
    console.error = (...args) => {
      const errorStr = args.join(' ');
      if (errorStr.includes('Invalid API key') || 
          errorStr.includes('401') || 
          errorStr.includes('AuthApiError')) {
        if (!dismissed) {
          setVisible(true);
        }
      }
      originalError.apply(console, args);
    };

    return () => {
      console.error = originalError;
    };
  }, [dismissed]);

  const goToConnectionTest = () => {
    window.location.href = window.location.origin + '/?test-connection';
  };

  const dismiss = () => {
    setDismissed(true);
    setVisible(false);
  };

  if (!visible) return null;

  return (
    <div className="fixed top-0 left-0 right-0 z-[99998] bg-red-600 text-white shadow-lg animate-in slide-in-from-top">
      <div className="max-w-7xl mx-auto px-4 py-3">
        <div className="flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <AlertTriangle className="w-5 h-5 flex-shrink-0" />
            <div>
              <p className="font-semibold">API Connection Error Detected</p>
              <p className="text-sm text-red-100">
                Supabase credentials may be invalid. Click "Test Connection" to diagnose.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <Button 
              onClick={goToConnectionTest}
              size="sm"
              variant="secondary"
              className="flex items-center gap-2"
            >
              <Wrench className="w-4 h-4" />
              Test Connection
            </Button>
            <button
              onClick={dismiss}
              className="p-1 hover:bg-red-700 rounded transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
