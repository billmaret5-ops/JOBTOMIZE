import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { FileText, Download, Shield, CheckCircle, AlertTriangle } from 'lucide-react';
import { backupEncryptionService, ComplianceReport } from '@/services/backupEncryptionService';

export const BackupComplianceReport: React.FC = () => {
  const [report, setReport] = useState<ComplianceReport | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadReport();
  }, []);

  const loadReport = async () => {
    setLoading(true);
    const endDate = new Date();
    const startDate = new Date();
    startDate.setDate(startDate.getDate() - 30);
    const data = await backupEncryptionService.getComplianceReport(startDate, endDate);
    setReport(data);
    setLoading(false);
  };

  const handleExportReport = () => {
    const reportData = JSON.stringify(report, null, 2);
    const blob = new Blob([reportData], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `compliance-report-${new Date().toISOString()}.json`;
    a.click();
  };

  if (loading || !report) {
    return <div>Loading compliance report...</div>;
  }

  const getComplianceLevel = (score: number) => {
    if (score >= 95) return { label: 'Excellent', color: 'text-green-600', bg: 'bg-green-50' };
    if (score >= 85) return { label: 'Good', color: 'text-blue-600', bg: 'bg-blue-50' };
    if (score >= 70) return { label: 'Fair', color: 'text-yellow-600', bg: 'bg-yellow-50' };
    return { label: 'Needs Improvement', color: 'text-red-600', bg: 'bg-red-50' };
  };

  const complianceLevel = getComplianceLevel(report.compliance_score);

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle className="flex items-center gap-2">
              <Shield className="h-5 w-5" />
              Compliance Overview
            </CardTitle>
            <Button onClick={handleExportReport} variant="outline" size="sm">
              <Download className="h-4 w-4 mr-2" />
              Export Report
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className={`p-6 rounded-lg ${complianceLevel.bg} mb-6`}>
            <div className="text-center">
              <div className={`text-5xl font-bold ${complianceLevel.color} mb-2`}>
                {report.compliance_score.toFixed(1)}%
              </div>
              <Badge className={complianceLevel.color}>
                {complianceLevel.label}
              </Badge>
              <div className="text-sm text-gray-600 mt-2">
                Compliance Score for {report.period}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 border rounded-lg">
              <div className="text-2xl font-bold">{report.total_backups}</div>
              <div className="text-sm text-gray-600">Total Backups</div>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="text-2xl font-bold text-green-600">{report.encrypted_backups}</div>
              <div className="text-sm text-gray-600">Encrypted Backups</div>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="text-2xl font-bold text-blue-600">{report.key_rotations}</div>
              <div className="text-sm text-gray-600">Key Rotations</div>
            </div>
            <div className="p-4 border rounded-lg">
              <div className="text-2xl font-bold text-red-600">{report.failed_operations}</div>
              <div className="text-sm text-gray-600">Failed Operations</div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Encryption Coverage</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <div className="flex justify-between mb-2">
              <span className="text-sm font-medium">Backup Encryption Rate</span>
              <span className="text-sm font-medium">{report.encryption_coverage.toFixed(1)}%</span>
            </div>
            <Progress value={report.encryption_coverage} className="h-2" />
          </div>

          <div className="space-y-2 mt-6">
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>All backups encrypted with AES-256 or higher</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Encryption keys rotated within policy timeframe</span>
            </div>
            <div className="flex items-center gap-2 text-sm">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <span>Audit logs maintained for all operations</span>
            </div>
            {report.failed_operations > 0 && (
              <div className="flex items-center gap-2 text-sm">
                <AlertTriangle className="h-4 w-4 text-yellow-600" />
                <span>{report.failed_operations} operations require attention</span>
              </div>
            )}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Compliance Standards</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {['GDPR', 'HIPAA', 'SOC 2', 'ISO 27001'].map((standard) => (
              <div key={standard} className="flex items-center justify-between p-3 border rounded-lg">
                <span className="font-medium">{standard}</span>
                <Badge variant="default">
                  <CheckCircle className="h-3 w-3 mr-1" />
                  Compliant
                </Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};
