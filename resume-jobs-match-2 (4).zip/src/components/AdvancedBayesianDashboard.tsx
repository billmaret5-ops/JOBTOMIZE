import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { LineChart, Line, ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, AreaChart, Area } from 'recharts';
import { Brain, TrendingUp, Activity, Download, Target } from 'lucide-react';
import { BayesianOptimizationService, OptimizationObservation } from '@/services/bayesianOptimizationService';

export default function AdvancedBayesianDashboard() {
  const [observations, setObservations] = useState<OptimizationObservation[]>([]);
  const [selectedMetric, setSelectedMetric] = useState<'ei' | 'ucb' | 'poi'>('ei');

  useEffect(() => {
    // Simulate some historical data
    const mockData: OptimizationObservation[] = [];
    for (let i = 0; i < 20; i++) {
      mockData.push({
        configuration: {
          exploration_rate: Math.random() * 0.3 + 0.05,
          ucb_constant: Math.random() * 3 + 0.5,
          confidence_level: Math.random() * 0.15 + 0.85,
          min_samples: Math.floor(Math.random() * 150) + 50,
          update_frequency_minutes: Math.floor(Math.random() * 50) + 10
        },
        metric_value: Math.random() * 0.3 + 0.1,
        conversions: Math.floor(Math.random() * 100),
        impressions: 1000,
        revenue: Math.random() * 500
      });
    }
    setObservations(mockData);
  }, []);

  const convergenceData = observations.map((obs, idx) => {
    const bestSoFar = Math.max(...observations.slice(0, idx + 1).map(o => o.metric_value));
    return {
      iteration: idx + 1,
      bestValue: bestSoFar,
      currentValue: obs.metric_value,
      regret: bestSoFar - obs.metric_value
    };
  });

  const parameterSpace = observations.map((obs, idx) => ({
    explorationRate: obs.configuration.exploration_rate,
    ucbConstant: obs.configuration.ucb_constant,
    metricValue: obs.metric_value,
    iteration: idx + 1
  }));

  const acquisitionData = observations.slice(-10).map((obs, idx) => {
    const bestValue = Math.max(...observations.map(o => o.metric_value));
    const { mean, std } = BayesianOptimizationService.predictPerformance(
      obs.configuration,
      observations
    );
    
    return {
      iteration: observations.length - 10 + idx + 1,
      ei: BayesianOptimizationService.calculateExpectedImprovement(mean, std, bestValue),
      ucb: BayesianOptimizationService.calculateUCB(mean, std),
      poi: BayesianOptimizationService.calculatePOI(mean, std, bestValue),
      mean,
      std
    };
  });

  const exportResults = () => {
    const dataStr = JSON.stringify(observations, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    const url = URL.createObjectURL(dataBlob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'bayesian-optimization-results.json';
    link.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="h-8 w-8 text-purple-600" />
            Bayesian Optimization Dashboard
          </h2>
          <p className="text-muted-foreground mt-1">
            Advanced analytics and visualization for hyperparameter optimization
          </p>
        </div>
        <Button onClick={exportResults} variant="outline">
          <Download className="h-4 w-4 mr-2" />
          Export Results
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Total Iterations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{observations.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Configurations tested</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Best Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {observations.length > 0 
                ? `${(Math.max(...observations.map(o => o.metric_value)) * 100).toFixed(2)}%`
                : 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Maximum metric value</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Avg Improvement</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold text-green-600">+12.4%</div>
            <p className="text-xs text-muted-foreground mt-1">Over baseline</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Convergence</CardTitle>
          </CardHeader>
          <CardContent>
            <Badge variant="default" className="text-sm">Converging</Badge>
            <p className="text-xs text-muted-foreground mt-1">Optimization status</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="convergence" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="convergence">Convergence</TabsTrigger>
          <TabsTrigger value="parameter-space">Parameter Space</TabsTrigger>
          <TabsTrigger value="acquisition">Acquisition Functions</TabsTrigger>
          <TabsTrigger value="predictions">GP Predictions</TabsTrigger>
        </TabsList>

        <TabsContent value="convergence">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Optimization Convergence
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={convergenceData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="iteration" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="bestValue" stroke="#8b5cf6" name="Best Value" strokeWidth={2} />
                  <Line type="monotone" dataKey="currentValue" stroke="#94a3b8" name="Current Value" strokeWidth={1} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="parameter-space">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Target className="h-5 w-5" />
                Parameter Space Exploration
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <ScatterChart>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="explorationRate" name="Exploration Rate" />
                  <YAxis dataKey="ucbConstant" name="UCB Constant" />
                  <Tooltip cursor={{ strokeDasharray: '3 3' }} />
                  <Legend />
                  <Scatter name="Configurations" data={parameterSpace} fill="#8b5cf6" />
                </ScatterChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="acquisition">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Activity className="h-5 w-5" />
                Acquisition Function Values
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-4">
                {(['ei', 'ucb', 'poi'] as const).map((metric) => (
                  <Badge
                    key={metric}
                    variant={selectedMetric === metric ? 'default' : 'outline'}
                    className="cursor-pointer"
                    onClick={() => setSelectedMetric(metric)}
                  >
                    {metric.toUpperCase()}
                  </Badge>
                ))}
              </div>
              <ResponsiveContainer width="100%" height={350}>
                <AreaChart data={acquisitionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="iteration" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Area type="monotone" dataKey={selectedMetric} stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="predictions">
          <Card>
            <CardHeader>
              <CardTitle>Gaussian Process Predictions</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={acquisitionData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="iteration" />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Line type="monotone" dataKey="mean" stroke="#8b5cf6" name="Predicted Mean" strokeWidth={2} />
                  <Line type="monotone" dataKey="std" stroke="#f59e0b" name="Std Deviation" strokeWidth={2} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
