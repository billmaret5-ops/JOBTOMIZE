import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Brain, TrendingUp, Zap, RefreshCw } from 'lucide-react';
import { warmupOptimizationService, WarmupRecommendation } from '@/services/warmupOptimizationService';
import { AIRecommendationVotingPanel } from './AIRecommendationVotingPanel';
import { realtimeAIRecommendationService, AIRecommendation } from '@/services/realtimeAIRecommendationService';

interface AIWarmupOptimizerProps {
  templateId: string;
  currentUserId: string;
  onApplyRecommendation: (recommendation: WarmupRecommendation) => void;
}

export default function AIWarmupOptimizer({ templateId, currentUserId, onApplyRecommendation }: AIWarmupOptimizerProps) {
  const [recommendations, setRecommendations] = useState<AIRecommendation[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadRecommendations();
    
    // Join real-time recommendation channel
    realtimeAIRecommendationService.joinRecommendationChannel(templateId, currentUserId);

    // Listen for new recommendations
    const handleNewRec = (rec: AIRecommendation) => {
      setRecommendations(prev => [rec, ...prev]);
    };

    const handleUpdatedRec = (rec: AIRecommendation) => {
      setRecommendations(prev => prev.map(r => r.id === rec.id ? rec : r));
    };

    const handleApplied = (payload: any) => {
      setRecommendations(prev => prev.map(r => 
        r.id === payload.recommendationId ? { ...r, status: 'applied' } : r
      ));
      // Convert to WarmupRecommendation format and call parent handler
      const appliedRec = recommendations.find(r => r.id === payload.recommendationId);
      if (appliedRec) {
        onApplyRecommendation({
          id: appliedRec.id,
          type: appliedRec.type as any,
          recommendation: appliedRec.title,
          reasoning: appliedRec.description,
          confidence: appliedRec.confidence,
          status: 'applied',
          data: appliedRec.data
        });
      }
    };

    realtimeAIRecommendationService.on('recommendation:new', handleNewRec);
    realtimeAIRecommendationService.on('recommendation:updated', handleUpdatedRec);
    realtimeAIRecommendationService.on('recommendation:applied', handleApplied);

    return () => {
      realtimeAIRecommendationService.off('recommendation:new', handleNewRec);
      realtimeAIRecommendationService.off('recommendation:updated', handleUpdatedRec);
      realtimeAIRecommendationService.off('recommendation:applied', handleApplied);
      realtimeAIRecommendationService.leaveChannel();
    };
  }, [templateId, currentUserId]);

  const loadRecommendations = async () => {
    setLoading(true);
    try {
      const data = await warmupOptimizationService.generateMLRecommendations(templateId);
      // Convert to AIRecommendation format
      const aiRecs: AIRecommendation[] = (data.recommendations || []).map(rec => ({
        id: rec.id,
        template_id: templateId,
        type: rec.type === 'volume_adjustment' ? 'volume_schedule' : rec.type === 'ab_test' ? 'ab_test' : 'optimization',
        title: rec.recommendation,
        description: rec.reasoning,
        confidence: rec.confidence,
        data: rec.data || {},
        status: rec.status,
        created_at: new Date().toISOString(),
        votes_for: 0,
        votes_against: 0,
        votes_required: 2
      }));
      setRecommendations(aiRecs);
    } catch (error) {
      console.error('Failed to load recommendations:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'volume_schedule': return <TrendingUp className="w-4 h-4" />;
      case 'ab_test': return <Zap className="w-4 h-4" />;
      default: return <Brain className="w-4 h-4" />;
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-white flex items-center gap-2">
          <Brain className="w-5 h-5 text-purple-500" />
          AI Recommendations
        </h3>
        <Button onClick={loadRecommendations} disabled={loading} size="sm" variant="outline">
          <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
          Refresh
        </Button>
      </div>

      <div className="space-y-3">
        {recommendations.length === 0 && !loading && (
          <Card className="p-8 bg-gray-800 border-gray-700 text-center">
            <Brain className="w-12 h-12 mx-auto mb-3 text-gray-600" />
            <p className="text-gray-400">No recommendations yet</p>
            <p className="text-sm text-gray-500 mt-1">AI will analyze your discussions and generate suggestions</p>
          </Card>
        )}
        
        {recommendations.map((rec) => (
          <AIRecommendationVotingPanel
            key={rec.id}
            recommendation={rec}
            currentUserId={currentUserId}
            onApplied={loadRecommendations}
          />
        ))}
      </div>
    </div>
  );
}

