import React, { useState, useEffect } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Textarea } from '@/components/ui/textarea';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface ApplicationFormModalProps {
  open: boolean;
  onClose: () => void;
  application?: any;
  onSuccess: () => void;
}

export function ApplicationFormModal({ open, onClose, application, onSuccess }: ApplicationFormModalProps) {
  const { user } = useAuth();
  const [loading, setLoading] = useState(false);
  const [formData, setFormData] = useState({
    job_title: '',
    company_name: '',
    location: '',
    salary_range: '',
    status: 'saved',
    job_url: '',
    notes: '',
    priority: 'medium',
    applied_date: '',
    follow_up_date: '',
    interview_date: ''
  });

  useEffect(() => {
    if (application) {
      setFormData({
        job_title: application.job_title || '',
        company_name: application.company_name || '',
        location: application.location || '',
        salary_range: application.salary_range || '',
        status: application.status || 'saved',
        job_url: application.job_url || '',
        notes: application.notes || '',
        priority: application.priority || 'medium',
        applied_date: application.applied_date || '',
        follow_up_date: application.follow_up_date || '',
        interview_date: application.interview_date || ''
      });
    }
  }, [application]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      const data = { ...formData, user_id: user?.id };
      
      if (application) {
        const { error } = await supabase
          .from('job_applications')
          .update(data)
          .eq('id', application.id);
        if (error) throw error;
        toast.success('Application updated successfully');
      } else {
        const { error } = await supabase
          .from('job_applications')
          .insert([data]);
        if (error) throw error;
        toast.success('Application added successfully');
      }
      
      onSuccess();
      onClose();
    } catch (error) {
      toast.error('Failed to save application');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{application ? 'Edit' : 'Add'} Application</DialogTitle>
          <DialogDescription>
            Add or edit job application information including dates, status, and notes
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Job Title *</Label>
              <Input required value={formData.job_title} onChange={(e) => setFormData({...formData, job_title: e.target.value})} />
            </div>
            <div>
              <Label>Company *</Label>
              <Input required value={formData.company_name} onChange={(e) => setFormData({...formData, company_name: e.target.value})} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Location</Label>
              <Input value={formData.location} onChange={(e) => setFormData({...formData, location: e.target.value})} />
            </div>
            <div>
              <Label>Salary Range</Label>
              <Input value={formData.salary_range} onChange={(e) => setFormData({...formData, salary_range: e.target.value})} />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div>
              <Label>Status</Label>
              <Select value={formData.status} onValueChange={(value) => setFormData({...formData, status: value})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="saved">Saved</SelectItem>
                  <SelectItem value="applied">Applied</SelectItem>
                  <SelectItem value="interviewing">Interviewing</SelectItem>
                  <SelectItem value="offer">Offer</SelectItem>
                  <SelectItem value="rejected">Rejected</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Priority</Label>
              <Select value={formData.priority} onValueChange={(value) => setFormData({...formData, priority: value})}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="low">Low</SelectItem>
                  <SelectItem value="medium">Medium</SelectItem>
                  <SelectItem value="high">High</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <div>
            <Label>Job URL</Label>
            <Input type="url" value={formData.job_url} onChange={(e) => setFormData({...formData, job_url: e.target.value})} />
          </div>
          <div className="grid grid-cols-3 gap-4">
            <div>
              <Label>Applied Date</Label>
              <Input type="date" value={formData.applied_date} onChange={(e) => setFormData({...formData, applied_date: e.target.value})} />
            </div>
            <div>
              <Label>Interview Date</Label>
              <Input type="date" value={formData.interview_date} onChange={(e) => setFormData({...formData, interview_date: e.target.value})} />
            </div>
            <div>
              <Label>Follow-up Date</Label>
              <Input type="date" value={formData.follow_up_date} onChange={(e) => setFormData({...formData, follow_up_date: e.target.value})} />
            </div>
          </div>
          <div>
            <Label>Notes</Label>
            <Textarea rows={3} value={formData.notes} onChange={(e) => setFormData({...formData, notes: e.target.value})} />
          </div>
          <div className="flex justify-end gap-2">
            <Button type="button" variant="outline" onClick={onClose}>Cancel</Button>
            <Button type="submit" disabled={loading}>{loading ? 'Saving...' : 'Save'}</Button>
          </div>
        </form>
      </DialogContent>
    </Dialog>
  );
}