import React, { useState, useEffect } from 'react';
import { Plus, Filter, Users, Trash2 } from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { supabase } from '@/lib/supabase';

interface Condition {
  field: string;
  operator: string;
  value: string;
}

interface Segment {
  id: string;
  name: string;
  description: string;
  conditions: Condition[];
  total_contacts: number;
}

export const ContactSegmentBuilder = () => {
  const [segments, setSegments] = useState<Segment[]>([]);
  const [newSegment, setNewSegment] = useState({
    name: '',
    description: '',
    conditions: [{ field: 'email', operator: 'contains', value: '' }] as Condition[]
  });
  const [loading, setLoading] = useState(false);

  const fieldOptions = [
    { value: 'email', label: 'Email' },
    { value: 'first_name', label: 'First Name' },
    { value: 'last_name', label: 'Last Name' },
    { value: 'company', label: 'Company' },
    { value: 'tags', label: 'Tags' },
    { value: 'status', label: 'Status' },
    { value: 'created_at', label: 'Created Date' }
  ];

  const operatorOptions = [
    { value: 'contains', label: 'Contains' },
    { value: 'equals', label: 'Equals' },
    { value: 'starts_with', label: 'Starts With' },
    { value: 'ends_with', label: 'Ends With' },
    { value: 'not_empty', label: 'Not Empty' },
    { value: 'is_empty', label: 'Is Empty' }
  ];

  useEffect(() => {
    loadSegments();
  }, []);

  const loadSegments = async () => {
    try {
      const { data, error } = await supabase
        .from('contact_segments')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setSegments(data || []);
    } catch (error) {
      console.error('Error loading segments:', error);
    }
  };

  const addCondition = () => {
    setNewSegment(prev => ({
      ...prev,
      conditions: [...prev.conditions, { field: 'email', operator: 'contains', value: '' }]
    }));
  };

  const updateCondition = (index: number, field: keyof Condition, value: string) => {
    setNewSegment(prev => ({
      ...prev,
      conditions: prev.conditions.map((condition, i) => 
        i === index ? { ...condition, [field]: value } : condition
      )
    }));
  };

  const removeCondition = (index: number) => {
    setNewSegment(prev => ({
      ...prev,
      conditions: prev.conditions.filter((_, i) => i !== index)
    }));
  };

  const saveSegment = async () => {
    if (!newSegment.name.trim()) return;

    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('contact-segment-manager', {
        body: {
          action: 'create',
          segment: newSegment
        }
      });

      if (error) throw error;
      
      setNewSegment({
        name: '',
        description: '',
        conditions: [{ field: 'email', operator: 'contains', value: '' }]
      });
      loadSegments();
    } catch (error) {
      console.error('Error saving segment:', error);
    } finally {
      setLoading(false);
    }
  };

  const deleteSegment = async (id: string) => {
    try {
      const { error } = await supabase
        .from('contact_segments')
        .delete()
        .eq('id', id);

      if (error) throw error;
      loadSegments();
    } catch (error) {
      console.error('Error deleting segment:', error);
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Create New Segment
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <Input
              placeholder="Segment name"
              value={newSegment.name}
              onChange={(e) => setNewSegment(prev => ({ ...prev, name: e.target.value }))}
            />
            <Input
              placeholder="Description (optional)"
              value={newSegment.description}
              onChange={(e) => setNewSegment(prev => ({ ...prev, description: e.target.value }))}
            />
          </div>

          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h4 className="font-medium">Conditions</h4>
              <Button size="sm" onClick={addCondition}>
                <Plus className="h-4 w-4 mr-1" />
                Add Condition
              </Button>
            </div>

            {newSegment.conditions.map((condition, index) => (
              <div key={index} className="flex gap-2 items-center">
                <Select
                  value={condition.field}
                  onValueChange={(value) => updateCondition(index, 'field', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {fieldOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Select
                  value={condition.operator}
                  onValueChange={(value) => updateCondition(index, 'operator', value)}
                >
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {operatorOptions.map(option => (
                      <SelectItem key={option.value} value={option.value}>
                        {option.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>

                <Input
                  placeholder="Value"
                  value={condition.value}
                  onChange={(e) => updateCondition(index, 'value', e.target.value)}
                  className="flex-1"
                />

                {newSegment.conditions.length > 1 && (
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => removeCondition(index)}
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                )}
              </div>
            ))}
          </div>

          <Button onClick={saveSegment} disabled={loading || !newSegment.name.trim()}>
            {loading ? 'Creating...' : 'Create Segment'}
          </Button>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Existing Segments</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {segments.map(segment => (
              <div key={segment.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div>
                  <h4 className="font-medium">{segment.name}</h4>
                  {segment.description && (
                    <p className="text-sm text-gray-600">{segment.description}</p>
                  )}
                  <div className="flex items-center gap-2 mt-1">
                    <Badge variant="secondary">
                      <Users className="h-3 w-3 mr-1" />
                      {segment.total_contacts} contacts
                    </Badge>
                    <Badge variant="outline">
                      {segment.conditions.length} condition{segment.conditions.length !== 1 ? 's' : ''}
                    </Badge>
                  </div>
                </div>
                <Button
                  size="sm"
                  variant="outline"
                  onClick={() => deleteSegment(segment.id)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            ))}
            {segments.length === 0 && (
              <p className="text-center text-gray-500 py-8">
                No segments created yet. Create your first segment above.
              </p>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};