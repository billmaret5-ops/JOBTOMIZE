import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Fingerprint, Smartphone, Trash2, Shield, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface BiometricCredential {
  id: string;
  credential_id: string;
  device_type: string;
  device_name: string;
  created_at: string;
  last_used_at: string | null;
}

export function BiometricAuth() {
  const { user } = useAuth();
  const [credentials, setCredentials] = useState<BiometricCredential[]>([]);
  const [isSupported, setIsSupported] = useState(false);
  const [isRegistering, setIsRegistering] = useState(false);
  const [deviceName, setDeviceName] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  useEffect(() => {
    checkWebAuthnSupport();
    loadCredentials();
  }, []);

  const checkWebAuthnSupport = () => {
    const supported = window.PublicKeyCredential && 
                     navigator.credentials && 
                     navigator.credentials.create;
    setIsSupported(supported);
  };

  const loadCredentials = async () => {
    if (!user) return;

    try {
      const { data } = await supabase.functions.invoke('biometric-auth-manager', {
        body: { action: 'get_credentials', userId: user.id }
      });

      if (data?.credentials) {
        setCredentials(data.credentials);
      }
    } catch (err) {
      console.error('Failed to load credentials:', err);
    }
  };

  const registerBiometric = async () => {
    if (!user || !deviceName.trim()) return;

    setIsRegistering(true);
    setError('');
    setSuccess('');

    try {
      // Generate challenge
      const challenge = new Uint8Array(32);
      crypto.getRandomValues(challenge);

      const createCredentialOptions: CredentialCreationOptions = {
        publicKey: {
          challenge,
          rp: {
            name: 'JobHunter Pro',
            id: window.location.hostname,
          },
          user: {
            id: new TextEncoder().encode(user.id),
            name: user.email || '',
            displayName: user.email || '',
          },
          pubKeyCredParams: [
            { alg: -7, type: 'public-key' }, // ES256
            { alg: -257, type: 'public-key' }, // RS256
          ],
          authenticatorSelection: {
            authenticatorAttachment: 'platform',
            userVerification: 'required',
            requireResidentKey: false,
          },
          timeout: 60000,
          attestation: 'direct',
        },
      };

      const credential = await navigator.credentials.create(createCredentialOptions) as PublicKeyCredential;
      
      if (!credential) {
        throw new Error('Failed to create credential');
      }

      const response = credential.response as AuthenticatorAttestationResponse;
      const publicKey = Array.from(new Uint8Array(response.publicKey!));
      const credentialId = Array.from(new Uint8Array(credential.rawId));

      // Register with backend
      const { data, error } = await supabase.functions.invoke('biometric-auth-manager', {
        body: {
          action: 'register_credential',
          userId: user.id,
          credentialId: btoa(String.fromCharCode(...credentialId)),
          publicKey: btoa(String.fromCharCode(...publicKey)),
          deviceType: 'platform',
          deviceName: deviceName.trim(),
        }
      });

      if (error) throw error;

      setSuccess('Biometric authentication registered successfully!');
      setDeviceName('');
      loadCredentials();
    } catch (err: any) {
      setError(err.message || 'Failed to register biometric authentication');
    } finally {
      setIsRegistering(false);
    }
  };

  const deleteCredential = async (credentialId: string) => {
    try {
      const { error } = await supabase.functions.invoke('biometric-auth-manager', {
        body: {
          action: 'delete_credential',
          userId: user?.id,
          credentialId,
        }
      });

      if (error) throw error;
      
      setSuccess('Biometric credential removed successfully');
      loadCredentials();
    } catch (err: any) {
      setError(err.message || 'Failed to remove credential');
    }
  };

  if (!isSupported) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Fingerprint className="h-5 w-5" />
            Biometric Authentication
          </CardTitle>
          <CardDescription>
            Secure your account with fingerprint or face recognition
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Alert>
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>
              Biometric authentication is not supported on this device or browser.
            </AlertDescription>
          </Alert>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Fingerprint className="h-5 w-5" />
          Biometric Authentication
        </CardTitle>
        <CardDescription>
          Secure your account with fingerprint or face recognition
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {error && (
          <Alert variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <AlertDescription>{error}</AlertDescription>
          </Alert>
        )}

        {success && (
          <Alert>
            <Shield className="h-4 w-4" />
            <AlertDescription>{success}</AlertDescription>
          </Alert>
        )}

        <div className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="deviceName">Device Name</Label>
            <Input
              id="deviceName"
              value={deviceName}
              onChange={(e) => setDeviceName(e.target.value)}
              placeholder="e.g., iPhone 15, MacBook Pro"
            />
          </div>
          
          <Button 
            onClick={registerBiometric}
            disabled={isRegistering || !deviceName.trim()}
            className="w-full"
          >
            {isRegistering ? 'Registering...' : 'Register Biometric Authentication'}
          </Button>
        </div>

        {credentials.length > 0 && (
          <div className="space-y-4">
            <h4 className="font-medium">Registered Devices</h4>
            <div className="space-y-2">
              {credentials.map((cred) => (
                <div key={cred.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Smartphone className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{cred.device_name}</p>
                      <p className="text-sm text-muted-foreground">
                        Added {new Date(cred.created_at).toLocaleDateString()}
                        {cred.last_used_at && (
                          <> • Last used {new Date(cred.last_used_at).toLocaleDateString()}</>
                        )}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <Badge variant="secondary">{cred.device_type}</Badge>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => deleteCredential(cred.credential_id)}
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}