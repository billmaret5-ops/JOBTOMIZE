import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { RefreshCw, CheckCircle, AlertCircle, Clock } from 'lucide-react';

interface SyncItem {
  id: string;
  type: 'application' | 'resume' | 'profile';
  status: 'pending' | 'syncing' | 'synced' | 'failed';
  data: any;
  timestamp: number;
}

export function BackgroundSyncManager() {
  const [syncQueue, setSyncQueue] = useState<SyncItem[]>([]);
  const [isSyncing, setIsSyncing] = useState(false);

  useEffect(() => {
    loadSyncQueue();

    if ('serviceWorker' in navigator && 'sync' in ServiceWorkerRegistration.prototype) {
      navigator.serviceWorker.addEventListener('message', handleSyncMessage);
    }

    return () => {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.removeEventListener('message', handleSyncMessage);
      }
    };
  }, []);

  const loadSyncQueue = () => {
    const queue = localStorage.getItem('sync-queue');
    if (queue) {
      setSyncQueue(JSON.parse(queue));
    }
  };

  const handleSyncMessage = (event: MessageEvent) => {
    if (event.data.type === 'SYNC_APPLICATIONS') {
      syncPendingItems();
    }
  };

  const addToSyncQueue = (item: Omit<SyncItem, 'id' | 'status' | 'timestamp'>) => {
    const newItem: SyncItem = {
      ...item,
      id: Date.now().toString(),
      status: 'pending',
      timestamp: Date.now()
    };

    const updated = [...syncQueue, newItem];
    setSyncQueue(updated);
    localStorage.setItem('sync-queue', JSON.stringify(updated));

    if (navigator.onLine) {
      requestBackgroundSync();
    }
  };

  const requestBackgroundSync = async () => {
    if ('serviceWorker' in navigator && 'sync' in ServiceWorkerRegistration.prototype) {
      try {
        const registration = await navigator.serviceWorker.ready;
        await registration.sync.register('sync-applications');
      } catch (error) {
        console.error('Background sync registration failed:', error);
        syncPendingItems();
      }
    } else {
      syncPendingItems();
    }
  };

  const syncPendingItems = async () => {
    setIsSyncing(true);
    const pending = syncQueue.filter(item => item.status === 'pending');

    for (const item of pending) {
      try {
        await syncItem(item);
        updateItemStatus(item.id, 'synced');
      } catch (error) {
        updateItemStatus(item.id, 'failed');
      }
    }

    setIsSyncing(false);
  };

  const syncItem = async (item: SyncItem) => {
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    return true;
  };

  const updateItemStatus = (id: string, status: SyncItem['status']) => {
    const updated = syncQueue.map(item =>
      item.id === id ? { ...item, status } : item
    );
    setSyncQueue(updated);
    localStorage.setItem('sync-queue', JSON.stringify(updated));
  };

  const pendingCount = syncQueue.filter(i => i.status === 'pending').length;
  const syncedCount = syncQueue.filter(i => i.status === 'synced').length;
  const progress = syncQueue.length > 0 ? (syncedCount / syncQueue.length) * 100 : 0;

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">Background Sync</CardTitle>
          <Button
            size="sm"
            variant="outline"
            onClick={syncPendingItems}
            disabled={isSyncing || pendingCount === 0}
          >
            <RefreshCw className={`h-4 w-4 mr-2 ${isSyncing ? 'animate-spin' : ''}`} />
            Sync Now
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        {syncQueue.length > 0 && (
          <>
            <div className="space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-muted-foreground">Progress</span>
                <span className="font-medium">{syncedCount}/{syncQueue.length}</span>
              </div>
              <Progress value={progress} />
            </div>

            <div className="space-y-2">
              {syncQueue.slice(-5).reverse().map((item) => (
                <div key={item.id} className="flex items-center justify-between p-2 rounded-lg bg-muted/50">
                  <div className="flex items-center gap-2">
                    {item.status === 'synced' && <CheckCircle className="h-4 w-4 text-green-600" />}
                    {item.status === 'pending' && <Clock className="h-4 w-4 text-orange-600" />}
                    {item.status === 'failed' && <AlertCircle className="h-4 w-4 text-red-600" />}
                    {item.status === 'syncing' && <RefreshCw className="h-4 w-4 animate-spin text-blue-600" />}
                    <span className="text-sm capitalize">{item.type}</span>
                  </div>
                  <Badge variant={
                    item.status === 'synced' ? 'default' :
                    item.status === 'failed' ? 'destructive' : 'secondary'
                  }>
                    {item.status}
                  </Badge>
                </div>
              ))}
            </div>
          </>
        )}

        {syncQueue.length === 0 && (
          <div className="text-center py-6 text-muted-foreground">
            <CheckCircle className="h-12 w-12 mx-auto mb-2 opacity-50" />
            <p className="text-sm">All changes synced</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
