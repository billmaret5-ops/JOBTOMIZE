import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Progress } from './ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { EmailClientPreview } from './email-preview/EmailClientPreview';
import { DevicePreviewFrame } from './email-preview/DevicePreviewFrame';
import { 
  CheckCircle, XCircle, AlertCircle, Mail, 
  Smartphone, Monitor, Tablet, RefreshCw, Download, Eye, Code
} from 'lucide-react';

interface CompatibilityResult {
  client: string;
  version: string;
  status: 'pass' | 'warning' | 'fail';
  score: number;
  issues: string[];
  recommendations: string[];
  renderingIssues: {
    css: string[];
    html: string[];
    images: string[];
    fonts: string[];
  };
}

interface EmailCompatibilityTesterProps {
  emailContent: string;
  subject?: string;
  sender?: string;
  onTest?: (results: CompatibilityResult[]) => void;
}

export default function EmailCompatibilityTester({ 
  emailContent, 
  subject = "Test Email",
  sender = "test@example.com",
  onTest 
}: EmailCompatibilityTesterProps) {
  const [isLoading, setIsLoading] = useState(false);
  const [results, setResults] = useState<CompatibilityResult[]>([]);
  const [selectedClient, setSelectedClient] = useState<string>('all');
  const [activeTab, setActiveTab] = useState('overview');
  const [previewMode, setPreviewMode] = useState<'visual' | 'code'>('visual');

  const emailClients = [
    { id: 'gmail', name: 'Gmail', icon: Mail, marketShare: 35, color: 'bg-red-500' },
    { id: 'outlook', name: 'Outlook', icon: Mail, marketShare: 28, color: 'bg-blue-500' },
    { id: 'apple-mail', name: 'Apple Mail', icon: Mail, marketShare: 15, color: 'bg-gray-800' },
    { id: 'yahoo', name: 'Yahoo Mail', icon: Mail, marketShare: 8, color: 'bg-purple-500' },
    { id: 'thunderbird', name: 'Thunderbird', icon: Mail, marketShare: 5, color: 'bg-orange-500' },
    { id: 'others', name: 'Others', icon: Mail, marketShare: 9, color: 'bg-gray-500' }
  ];

  const mockResults: CompatibilityResult[] = [
    {
      client: 'Gmail',
      version: 'Web/Mobile',
      status: 'pass',
      score: 95,
      issues: [],
      recommendations: ['Consider using web fonts for better typography'],
      renderingIssues: { css: [], html: [], images: [], fonts: ['Web fonts may not load'] }
    },
    {
      client: 'Outlook',
      version: '2016-2021',
      status: 'warning',
      score: 78,
      issues: [
        'CSS flexbox not fully supported',
        'Background images may not display',
        'Custom fonts fallback to system fonts'
      ],
      recommendations: [
        'Use table-based layouts for complex designs',
        'Provide fallback colors for background images',
        'Test with web-safe fonts'
      ],
      renderingIssues: {
        css: ['Flexbox', 'Grid layouts', 'CSS transforms'],
        html: ['HTML5 semantic elements'],
        images: ['Background images in divs'],
        fonts: ['Custom web fonts', 'Google Fonts']
      }
    },
    {
      client: 'Apple Mail',
      version: 'iOS/macOS',
      status: 'pass',
      score: 92,
      issues: ['Dark mode compatibility needs testing'],
      recommendations: ['Add dark mode CSS media queries'],
      renderingIssues: { css: ['Dark mode queries'], html: [], images: [], fonts: [] }
    },
    {
      client: 'Yahoo Mail',
      version: 'Web',
      status: 'warning',
      score: 72,
      issues: [
        'Limited CSS support',
        'Media queries not supported',
        'Some HTML5 elements ignored'
      ],
      recommendations: [
        'Use inline styles instead of CSS classes',
        'Avoid complex layouts',
        'Test with basic HTML structure'
      ],
      renderingIssues: {
        css: ['Media queries', 'CSS3 properties', 'External stylesheets'],
        html: ['HTML5 elements', 'Semantic tags'],
        images: ['SVG images'],
        fonts: ['Web fonts']
      }
    }
  ];

  const runCompatibilityTest = async () => {
    setIsLoading(true);
    
    // Simulate API call
    setTimeout(() => {
      setResults(mockResults);
      setIsLoading(false);
      onTest?.(mockResults);
    }, 2000);
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'pass':
        return <CheckCircle className="w-5 h-5 text-green-500" />;
      case 'warning':
        return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'fail':
        return <XCircle className="w-5 h-5 text-red-500" />;
      default:
        return <AlertCircle className="w-5 h-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'pass':
        return 'text-green-600 bg-green-50';
      case 'warning':
        return 'text-yellow-600 bg-yellow-50';
      case 'fail':
        return 'text-red-600 bg-red-50';
      default:
        return 'text-gray-600 bg-gray-50';
    }
  };

  const overallScore = results.length > 0 
    ? Math.round(results.reduce((sum, result) => sum + result.score, 0) / results.length)
    : 0;

  const filteredResults = selectedClient === 'all' 
    ? results 
    : results.filter(result => result.client.toLowerCase() === selectedClient);

  return (
    <div className="max-w-6xl mx-auto p-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <div>
              <CardTitle>Email Client Compatibility Testing</CardTitle>
              <p className="text-gray-600 mt-1">
                Test your email across different clients and devices
              </p>
            </div>
            <Button 
              onClick={runCompatibilityTest}
              disabled={isLoading || !emailContent}
            >
              {isLoading ? (
                <>
                  <RefreshCw className="w-4 h-4 mr-2 animate-spin" />
                  Testing...
                </>
              ) : (
                'Run Compatibility Test'
              )}
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          {results.length === 0 && !isLoading && (
            <div className="text-center py-12">
              <Mail className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Ready to test your email
              </h3>
              <p className="text-gray-600 mb-4">
                Click "Run Compatibility Test" to check how your email renders across different clients.
              </p>
            </div>
          )}

          {isLoading && (
            <div className="text-center py-12">
              <RefreshCw className="w-8 h-8 text-blue-500 mx-auto mb-4 animate-spin" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">
                Testing email compatibility...
              </h3>
              <p className="text-gray-600">
                This may take a few moments while we test across multiple email clients.
              </p>
            </div>
          )}

          {results.length > 0 && (
            <div className="space-y-6">
              {/* Overall Score */}
              <Card className="bg-gradient-to-r from-blue-50 to-indigo-50">
                <CardContent className="p-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">
                        Overall Compatibility Score
                      </h3>
                      <p className="text-gray-600 mt-1">
                        Based on testing across {results.length} email clients
                      </p>
                    </div>
                    <div className="text-right">
                      <div className="text-4xl font-bold text-blue-600">
                        {overallScore}%
                      </div>
                      <Progress value={overallScore} className="w-32 mt-2" />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Client Filter */}
              <div className="flex flex-wrap gap-2">
                <Button
                  variant={selectedClient === 'all' ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => setSelectedClient('all')}
                >
                  All Clients
                </Button>
                {emailClients.map((client) => (
                  <Button
                    key={client.id}
                    variant={selectedClient === client.id ? 'default' : 'outline'}
                    size="sm"
                    onClick={() => setSelectedClient(client.id)}
                  >
                    {client.name}
                  </Button>
                ))}
              </div>

              {/* Results */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {filteredResults.map((result, index) => (
                  <Card key={index}>
                    <CardHeader>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-3">
                          {getStatusIcon(result.status)}
                          <div>
                            <CardTitle className="text-lg">{result.client}</CardTitle>
                            <p className="text-sm text-gray-600">{result.version}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold">{result.score}%</div>
                          <Badge className={getStatusColor(result.status)}>
                            {result.status.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent className="space-y-4">
                      <Progress value={result.score} />
                      
                      {result.issues.length > 0 && (
                        <div>
                          <h4 className="font-medium text-red-700 mb-2">Issues Found:</h4>
                          <ul className="space-y-1">
                            {result.issues.map((issue, idx) => (
                              <li key={idx} className="text-sm text-red-600 flex items-start gap-2">
                                <XCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                                {issue}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}

                      {result.recommendations.length > 0 && (
                        <div>
                          <h4 className="font-medium text-blue-700 mb-2">Recommendations:</h4>
                          <ul className="space-y-1">
                            {result.recommendations.map((rec, idx) => (
                              <li key={idx} className="text-sm text-blue-600 flex items-start gap-2">
                                <CheckCircle className="w-3 h-3 mt-0.5 flex-shrink-0" />
                                {rec}
                              </li>
                            ))}
                          </ul>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                ))}
              </div>

              {/* Export Results */}
              <div className="flex justify-center">
                <Button variant="outline">
                  <Download className="w-4 h-4 mr-2" />
                  Export Test Results
                </Button>
              </div>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}