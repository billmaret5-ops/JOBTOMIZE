import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Bell, BarChart3, Truck, Eye, Settings, Download } from 'lucide-react';
import RealTimeEmailTracker from './RealTimeEmailTracker';
import EmailAnalyticsHeatmap from './EmailAnalyticsHeatmap';
import EmailDeliveryTracker from './EmailDeliveryTracker';
import RealTimeEmailAnalytics from './RealTimeEmailAnalytics';

interface NotificationSettings {
  emailOpens: boolean;
  deliveryFailures: boolean;
  responseReceived: boolean;
  weeklyReports: boolean;
}

export default function ComprehensiveEmailTrackingSystem() {
  const [activeTab, setActiveTab] = useState('tracker');
  const [notifications, setNotifications] = useState<NotificationSettings>({
    emailOpens: true,
    deliveryFailures: true,
    responseReceived: true,
    weeklyReports: false
  });

  const quickStats = [
    { label: 'Emails Sent Today', value: '47', change: '+12%', color: 'blue' },
    { label: 'Open Rate', value: '68.5%', change: '+5.2%', color: 'green' },
    { label: 'Response Rate', value: '8.3%', change: '+1.5%', color: 'purple' },
    { label: 'Delivery Rate', value: '94.7%', change: '-0.8%', color: 'orange' }
  ];

  const recentActivity = [
    { type: 'open', message: 'Email opened by hr@techcorp.com', time: '2 min ago' },
    { type: 'click', message: 'Link clicked in follow-up email', time: '5 min ago' },
    { type: 'response', message: 'New response from hiring@startup.io', time: '12 min ago' },
    { type: 'delivery', message: 'Email delivered to recruiter@company.com', time: '18 min ago' }
  ];

  const getStatColor = (color: string) => {
    const colors = {
      blue: 'text-blue-600 bg-blue-50',
      green: 'text-green-600 bg-green-50',
      purple: 'text-purple-600 bg-purple-50',
      orange: 'text-orange-600 bg-orange-50'
    };
    return colors[color as keyof typeof colors];
  };

  const getActivityIcon = (type: string) => {
    switch (type) {
      case 'open': return <Eye className="h-4 w-4 text-purple-500" />;
      case 'click': return <BarChart3 className="h-4 w-4 text-orange-500" />;
      case 'response': return <Bell className="h-4 w-4 text-green-500" />;
      case 'delivery': return <Truck className="h-4 w-4 text-blue-500" />;
      default: return <Bell className="h-4 w-4 text-gray-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold">Email Tracking & Analytics</h1>
          <p className="text-gray-600 mt-1">Monitor email performance and optimize your job application strategy</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" size="sm">
            <Settings className="h-4 w-4 mr-2" />
            Settings
          </Button>
          <Button size="sm">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {quickStats.map((stat, index) => (
          <Card key={index}>
            <CardContent className="p-4">
              <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mb-2 ${getStatColor(stat.color)}`}>
                {stat.change}
              </div>
              <div className="text-2xl font-bold mb-1">{stat.value}</div>
              <div className="text-sm text-gray-600">{stat.label}</div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-4">
        {/* Main Content */}
        <div className="lg:col-span-3">
          <Tabs value={activeTab} onValueChange={setActiveTab} className="space-y-4">
            <TabsList className="grid w-full grid-cols-4">
              <TabsTrigger value="tracker" className="flex items-center gap-2">
                <Eye className="h-4 w-4" />
                Live Tracking
              </TabsTrigger>
              <TabsTrigger value="analytics" className="flex items-center gap-2">
                <BarChart3 className="h-4 w-4" />
                Analytics
              </TabsTrigger>
              <TabsTrigger value="heatmap" className="flex items-center gap-2">
                <Settings className="h-4 w-4" />
                Heatmap
              </TabsTrigger>
              <TabsTrigger value="delivery" className="flex items-center gap-2">
                <Truck className="h-4 w-4" />
                Delivery
              </TabsTrigger>
            </TabsList>

            <TabsContent value="tracker">
              <RealTimeEmailTracker />
            </TabsContent>

            <TabsContent value="analytics">
              <RealTimeEmailAnalytics />
            </TabsContent>

            <TabsContent value="heatmap">
              <EmailAnalyticsHeatmap />
            </TabsContent>

            <TabsContent value="delivery">
              <EmailDeliveryTracker />
            </TabsContent>
          </Tabs>
        </div>

        {/* Sidebar */}
        <div className="space-y-4">
          {/* Recent Activity */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Recent Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3">
                  {getActivityIcon(activity.type)}
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium truncate">{activity.message}</p>
                    <p className="text-xs text-gray-500">{activity.time}</p>
                  </div>
                </div>
              ))}
            </CardContent>
          </Card>

          {/* Notification Settings */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg flex items-center gap-2">
                <Bell className="h-5 w-5" />
                Notifications
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {Object.entries(notifications).map(([key, enabled]) => (
                <div key={key} className="flex items-center justify-between">
                  <span className="text-sm capitalize">{key.replace(/([A-Z])/g, ' $1').trim()}</span>
                  <Badge variant={enabled ? 'default' : 'outline'}>
                    {enabled ? 'On' : 'Off'}
                  </Badge>
                </div>
              ))}
              <Button variant="outline" size="sm" className="w-full mt-3">
                Configure Alerts
              </Button>
            </CardContent>
          </Card>

          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Quick Actions</CardTitle>
            </CardHeader>
            <CardContent className="space-y-2">
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Download className="h-4 w-4 mr-2" />
                Export Analytics
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Settings className="h-4 w-4 mr-2" />
                Setup Tracking
              </Button>
              <Button variant="outline" size="sm" className="w-full justify-start">
                <Bell className="h-4 w-4 mr-2" />
                Create Alert
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}