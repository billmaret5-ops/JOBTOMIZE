import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer, ScatterChart, Scatter } from 'recharts';
import { Brain, TrendingUp, Settings, Play, Pause, RefreshCw } from 'lucide-react';
import { BayesianOptimizationService, HyperparameterConfig, OptimizationObservation } from '@/services/bayesianOptimizationService';

export default function BayesianOptimizationEngine() {
  const [isRunning, setIsRunning] = useState(false);
  const [observations, setObservations] = useState<OptimizationObservation[]>([]);
  const [currentBest, setCurrentBest] = useState<{ config: HyperparameterConfig; value: number } | null>(null);
  const [recommendation, setRecommendation] = useState<{ configuration: HyperparameterConfig; acquisitionValue: number } | null>(null);
  const [acquisitionFunction, setAcquisitionFunction] = useState<'ei' | 'ucb' | 'poi'>('ei');

  const generateRecommendation = () => {
    if (observations.length === 0) {
      const initialConfig = BayesianOptimizationService.generateCandidateConfigurations(1)[0];
      setRecommendation({ configuration: initialConfig, acquisitionValue: 1.0 });
      return;
    }

    const bestValue = currentBest?.value || Math.max(...observations.map(o => o.metric_value));
    const rec = BayesianOptimizationService.recommendNextConfiguration(
      observations,
      bestValue,
      acquisitionFunction
    );
    setRecommendation(rec);
  };

  const testConfiguration = async () => {
    if (!recommendation) return;

    // Simulate testing the configuration
    const simulatedMetric = Math.random() * 0.3 + 0.1; // 10-40% conversion rate
    const newObservation: OptimizationObservation = {
      configuration: recommendation.configuration,
      metric_value: simulatedMetric,
      conversions: Math.floor(Math.random() * 100),
      impressions: 1000,
      revenue: Math.random() * 500
    };

    setObservations([...observations, newObservation]);

    if (!currentBest || simulatedMetric > currentBest.value) {
      setCurrentBest({ config: recommendation.configuration, value: simulatedMetric });
    }

    generateRecommendation();
  };

  const chartData = observations.map((obs, idx) => ({
    iteration: idx + 1,
    metricValue: obs.metric_value,
    explorationRate: obs.configuration.exploration_rate,
    ucbConstant: obs.configuration.ucb_constant
  }));

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold flex items-center gap-2">
            <Brain className="h-8 w-8 text-purple-600" />
            Bayesian Optimization Engine
          </h2>
          <p className="text-muted-foreground mt-1">
            Automated hyperparameter tuning using Gaussian Process models
          </p>
        </div>
        <div className="flex gap-2">
          <Button
            onClick={() => setIsRunning(!isRunning)}
            variant={isRunning ? 'destructive' : 'default'}
          >
            {isRunning ? <Pause className="h-4 w-4 mr-2" /> : <Play className="h-4 w-4 mr-2" />}
            {isRunning ? 'Pause' : 'Start'} Optimization
          </Button>
          <Button onClick={generateRecommendation} variant="outline">
            <RefreshCw className="h-4 w-4 mr-2" />
            Generate Recommendation
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Iterations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">{observations.length}</div>
            <p className="text-xs text-muted-foreground mt-1">Configurations tested</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Best Performance</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-3xl font-bold">
              {currentBest ? `${(currentBest.value * 100).toFixed(2)}%` : 'N/A'}
            </div>
            <p className="text-xs text-muted-foreground mt-1">Conversion rate</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-sm font-medium">Acquisition Function</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex gap-2">
              {(['ei', 'ucb', 'poi'] as const).map((func) => (
                <Badge
                  key={func}
                  variant={acquisitionFunction === func ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => setAcquisitionFunction(func)}
                >
                  {func.toUpperCase()}
                </Badge>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      {recommendation && (
        <Card className="border-purple-200 bg-purple-50">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Recommended Configuration
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 md:grid-cols-5 gap-4 mb-4">
              <div>
                <p className="text-sm font-medium">Exploration Rate</p>
                <p className="text-2xl font-bold">{recommendation.configuration.exploration_rate.toFixed(3)}</p>
              </div>
              <div>
                <p className="text-sm font-medium">UCB Constant</p>
                <p className="text-2xl font-bold">{recommendation.configuration.ucb_constant.toFixed(2)}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Confidence Level</p>
                <p className="text-2xl font-bold">{recommendation.configuration.confidence_level.toFixed(3)}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Min Samples</p>
                <p className="text-2xl font-bold">{recommendation.configuration.min_samples}</p>
              </div>
              <div>
                <p className="text-sm font-medium">Update Freq (min)</p>
                <p className="text-2xl font-bold">{recommendation.configuration.update_frequency_minutes}</p>
              </div>
            </div>
            <Button onClick={testConfiguration} className="w-full">
              <Settings className="h-4 w-4 mr-2" />
              Test This Configuration
            </Button>
          </CardContent>
        </Card>
      )}

      <Card>
        <CardHeader>
          <CardTitle>Optimization Progress</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="iteration" />
              <YAxis />
              <Tooltip />
              <Legend />
              <Line type="monotone" dataKey="metricValue" stroke="#8b5cf6" name="Metric Value" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
