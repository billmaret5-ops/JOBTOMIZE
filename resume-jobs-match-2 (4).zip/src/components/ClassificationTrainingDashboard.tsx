import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Brain, CheckCircle, XCircle, RefreshCw, TrendingUp, AlertTriangle } from 'lucide-react';

interface TrainingItem {
  id: string;
  email_subject: string;
  predicted_category: string;
  confidence: number;
  actual_category?: string;
  status: 'pending' | 'corrected' | 'confirmed';
}

export default function ClassificationTrainingDashboard() {
  const [trainingItems, setTrainingItems] = useState<TrainingItem[]>([
    {
      id: '1',
      email_subject: 'RE: Your Application for Software Engineer',
      predicted_category: 'application_confirmation',
      confidence: 0.87,
      status: 'pending'
    },
    {
      id: '2',
      email_subject: 'Interview Invitation - Product Manager Role',
      predicted_category: 'interview_invitation',
      confidence: 0.95,
      status: 'confirmed',
      actual_category: 'interview_invitation'
    },
    {
      id: '3',
      email_subject: 'Thank you for your interest',
      predicted_category: 'rejection',
      confidence: 0.72,
      status: 'corrected',
      actual_category: 'application_confirmation'
    }
  ]);

  const categories = [
    'application_confirmation',
    'interview_invitation',
    'rejection',
    'offer',
    'follow_up',
    'other'
  ];

  const handleCorrection = (id: string, correctCategory: string) => {
    setTrainingItems(items =>
      items.map(item =>
        item.id === id
          ? { ...item, actual_category: correctCategory, status: 'corrected' as const }
          : item
      )
    );
  };

  const handleConfirm = (id: string) => {
    setTrainingItems(items =>
      items.map(item =>
        item.id === id
          ? { ...item, actual_category: item.predicted_category, status: 'confirmed' as const }
          : item
      )
    );
  };

  const stats = {
    total: trainingItems.length,
    corrected: trainingItems.filter(i => i.status === 'corrected').length,
    confirmed: trainingItems.filter(i => i.status === 'confirmed').length,
    pending: trainingItems.filter(i => i.status === 'pending').length
  };

  const accuracy = stats.total > 0 
    ? ((stats.confirmed / (stats.confirmed + stats.corrected)) * 100).toFixed(1)
    : '0';

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Items</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <Brain className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Confirmed</p>
                <p className="text-2xl font-bold">{stats.confirmed}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Corrected</p>
                <p className="text-2xl font-bold">{stats.corrected}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Accuracy</p>
                <p className="text-2xl font-bold">{accuracy}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <CardTitle>Training Queue</CardTitle>
            <Button variant="outline" size="sm">
              <RefreshCw className="h-4 w-4 mr-2" />
              Retrain Model
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {trainingItems.map((item) => (
              <div key={item.id} className="border rounded-lg p-4 space-y-3">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <h3 className="font-semibold">{item.email_subject}</h3>
                    <div className="flex items-center gap-2 mt-2">
                      <Badge variant="outline">
                        Predicted: {item.predicted_category.replace(/_/g, ' ')}
                      </Badge>
                      <Badge variant="outline">
                        Confidence: {(item.confidence * 100).toFixed(0)}%
                      </Badge>
                      {item.confidence < 0.8 && (
                        <AlertTriangle className="h-4 w-4 text-yellow-500" />
                      )}
                    </div>
                  </div>
                  <Badge
                    variant={
                      item.status === 'confirmed' ? 'default' :
                      item.status === 'corrected' ? 'destructive' :
                      'secondary'
                    }
                  >
                    {item.status}
                  </Badge>
                </div>

                {item.status === 'pending' && (
                  <div className="flex items-center gap-2">
                    <Select onValueChange={(value) => handleCorrection(item.id, value)}>
                      <SelectTrigger className="w-[200px]">
                        <SelectValue placeholder="Correct category" />
                      </SelectTrigger>
                      <SelectContent>
                        {categories.map((cat) => (
                          <SelectItem key={cat} value={cat}>
                            {cat.replace(/_/g, ' ')}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => handleConfirm(item.id)}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Confirm
                    </Button>
                  </div>
                )}

                {item.actual_category && item.actual_category !== item.predicted_category && (
                  <div className="text-sm text-red-600">
                    Corrected to: <span className="font-medium">{item.actual_category.replace(/_/g, ' ')}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
