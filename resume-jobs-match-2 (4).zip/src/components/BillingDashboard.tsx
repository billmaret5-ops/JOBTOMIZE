import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  CreditCard,
  Download,
  Calendar,
  TrendingUp,
  AlertCircle,
  CheckCircle,
  XCircle,
  Settings
} from 'lucide-react';
import { stripe, Subscription, UsageMetrics, PaymentHistory, SUBSCRIPTION_PLANS } from '@/lib/stripe';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from '@/hooks/use-toast';
import { PaymentHistoryTable } from './PaymentHistoryTable';
import { SubscriptionManager } from './SubscriptionManager';
import { UsageTracker } from './UsageTracker';

export function BillingDashboard() {
  const { user } = useAuth();
  const [subscription, setSubscription] = useState<Subscription | null>(null);
  const [usage, setUsage] = useState<UsageMetrics | null>(null);
  const [paymentHistory, setPaymentHistory] = useState<PaymentHistory[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadBillingData();
    }
  }, [user]);

  const loadBillingData = async () => {
    if (!user) return;
    
    setLoading(true);
    try {
      const [subData, usageData, historyData] = await Promise.all([
        stripe.getSubscription(user.id),
        stripe.getUsageMetrics(user.id),
        stripe.getPaymentHistory(user.id)
      ]);
      
      setSubscription(subData);
      setUsage(usageData);
      setPaymentHistory(historyData);
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to load billing data",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  const handleManageBilling = async () => {
    if (!subscription) return;
    
    try {
      const { url } = await stripe.createPortalSession(subscription.stripeCustomerId);
      window.location.href = url;
    } catch (error) {
      toast({
        title: "Error",
        description: "Failed to open billing portal",
        variant: "destructive",
      });
    }
  };

  const currentPlan = subscription ? SUBSCRIPTION_PLANS.find(p => p.id === subscription.planId) : null;

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-blue-600"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Billing & Usage</h1>
          <p className="text-gray-600">Manage your subscription and view usage metrics</p>
        </div>
        {subscription && (
          <Button onClick={handleManageBilling} variant="outline">
            <Settings className="w-4 h-4 mr-2" />
            Manage Billing
          </Button>
        )}
      </div>

      {/* Current Plan Overview */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Current Plan</span>
            {subscription && (
              <Badge 
                variant={subscription.status === 'active' ? 'default' : 'destructive'}
                className="ml-2"
              >
                {subscription.status === 'active' ? (
                  <CheckCircle className="w-3 h-3 mr-1" />
                ) : (
                  <XCircle className="w-3 h-3 mr-1" />
                )}
                {subscription.status}
              </Badge>
            )}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {subscription && currentPlan ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <div>
                  <h3 className="text-xl font-semibold">{currentPlan.name}</h3>
                  <p className="text-gray-600">${currentPlan.price}/{currentPlan.interval}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-gray-600">Next billing date</p>
                  <p className="font-medium">
                    {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                  </p>
                </div>
              </div>
              
              {subscription.cancelAtPeriodEnd && (
                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <div className="flex items-center">
                    <AlertCircle className="w-5 h-5 text-yellow-600 mr-2" />
                    <span className="text-yellow-800">
                      Your subscription will cancel on {new Date(subscription.currentPeriodEnd).toLocaleDateString()}
                    </span>
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="text-center py-8">
              <p className="text-gray-600 mb-4">No active subscription</p>
              <Button onClick={() => window.location.href = '/pricing'}>
                View Plans
              </Button>
            </div>
          )}
        </CardContent>
      </Card>

      <Tabs defaultValue="usage" className="space-y-6">
        <TabsList>
          <TabsTrigger value="usage">Usage & Limits</TabsTrigger>
          <TabsTrigger value="history">Payment History</TabsTrigger>
          <TabsTrigger value="subscription">Subscription</TabsTrigger>
        </TabsList>

        <TabsContent value="usage">
          <UsageTracker usage={usage} currentPlan={currentPlan} />
        </TabsContent>

        <TabsContent value="history">
          <PaymentHistoryTable paymentHistory={paymentHistory} />
        </TabsContent>

        <TabsContent value="subscription">
          <SubscriptionManager 
            subscription={subscription} 
            onUpdate={loadBillingData} 
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}