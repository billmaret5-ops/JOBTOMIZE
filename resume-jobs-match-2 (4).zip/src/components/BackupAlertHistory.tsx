import { useEffect, useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Mail, MessageSquare, Slack, Users, AlertCircle, AlertTriangle, Info, XCircle } from 'lucide-react';
import { backupAlertService } from '@/services/backupAlertService';
import { supabase } from '@/lib/supabase';

interface Alert {
  id: string;
  alert_type: string;
  severity: string;
  title: string;
  message: string;
  sent_at: string;
  status: string;
}

export default function BackupAlertHistory() {
  const [alerts, setAlerts] = useState<Alert[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadAlerts();
    const subscription = subscribeToAlerts();
    return () => { subscription?.unsubscribe(); };
  }, []);

  const loadAlerts = async () => {
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) return;

      const data = await backupAlertService.getAlertHistory(user.id, 50);
      setAlerts(data || []);
    } catch (error) {
      console.error('Failed to load alerts:', error);
    } finally {
      setLoading(false);
    }
  };

  const subscribeToAlerts = () => {
    return supabase
      .channel('backup_alerts')
      .on('postgres_changes', {
        event: 'INSERT',
        schema: 'public',
        table: 'backup_alerts'
      }, () => {
        loadAlerts();
      })
      .subscribe();
  };

  const getAlertIcon = (type: string) => {
    switch (type) {
      case 'email': return <Mail className="h-4 w-4" />;
      case 'sms': return <MessageSquare className="h-4 w-4" />;
      case 'slack': return <Slack className="h-4 w-4" />;
      case 'teams': return <Users className="h-4 w-4" />;
      default: return <Info className="h-4 w-4" />;
    }
  };

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case 'critical': return <XCircle className="h-4 w-4 text-red-600" />;
      case 'error': return <AlertCircle className="h-4 w-4 text-red-500" />;
      case 'warning': return <AlertTriangle className="h-4 w-4 text-yellow-600" />;
      default: return <Info className="h-4 w-4 text-blue-600" />;
    }
  };

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-100 text-red-800';
      case 'error': return 'bg-red-50 text-red-700';
      case 'warning': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alert History</CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-[400px]">
          <div className="space-y-3">
            {alerts.map((alert) => (
              <div key={alert.id} className="flex items-start gap-3 p-3 border rounded-lg">
                <div className="flex-shrink-0 mt-1">
                  {getSeverityIcon(alert.severity)}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 mb-1">
                    <h4 className="font-medium text-sm">{alert.title}</h4>
                    <Badge variant="outline" className={getSeverityColor(alert.severity)}>
                      {alert.severity}
                    </Badge>
                  </div>
                  <p className="text-sm text-muted-foreground mb-2">{alert.message}</p>
                  <div className="flex items-center gap-3 text-xs text-muted-foreground">
                    <span className="flex items-center gap-1">
                      {getAlertIcon(alert.alert_type)}
                      {alert.alert_type}
                    </span>
                    <span>{new Date(alert.sent_at).toLocaleString()}</span>
                    <Badge variant={alert.status === 'sent' ? 'default' : 'destructive'} className="text-xs">
                      {alert.status}
                    </Badge>
                  </div>
                </div>
              </div>
            ))}
            {alerts.length === 0 && !loading && (
              <p className="text-center text-muted-foreground py-8">No alerts yet</p>
            )}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}
