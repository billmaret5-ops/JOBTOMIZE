import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { DatePickerWithRange } from '@/components/ui/date-picker';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { CalendarIcon, Download, Filter, RefreshCw } from 'lucide-react';
import MetricsOverview from './analytics/MetricsOverview';
import PerformanceChart from './analytics/PerformanceChart';
import ABTestComparison from './analytics/ABTestComparison';


import TemplateUsageStats from './analytics/TemplateUsageStats';

export const EmailAnalyticsDashboard = () => {
  const [dateRange, setDateRange] = useState<any>(null);
  const [selectedCampaign, setSelectedCampaign] = useState('all');
  const [selectedTemplate, setSelectedTemplate] = useState('all');
  const [isLoading, setIsLoading] = useState(false);

  // Mock data - in real app, this would come from API
  const metrics = {
    openRate: { value: 24.5, change: 5.2 },
    clickRate: { value: 3.8, change: -1.1 },
    conversionRate: { value: 2.1, change: 0.8 },
    totalSent: { value: 125000, change: 12.5 }
  };

  const performanceData = [
    { date: '2024-01-01', openRate: 22.1, clickRate: 3.2, conversionRate: 1.8, sent: 12000 },
    { date: '2024-01-02', openRate: 23.5, clickRate: 3.5, conversionRate: 2.0, sent: 13500 },
    { date: '2024-01-03', openRate: 24.2, clickRate: 3.8, conversionRate: 2.1, sent: 14200 },
    { date: '2024-01-04', openRate: 25.1, clickRate: 4.1, conversionRate: 2.3, sent: 15100 },
    { date: '2024-01-05', openRate: 24.8, clickRate: 3.9, conversionRate: 2.2, sent: 14800 },
    { date: '2024-01-06', openRate: 26.2, clickRate: 4.3, conversionRate: 2.5, sent: 16200 },
    { date: '2024-01-07', openRate: 24.5, clickRate: 3.8, conversionRate: 2.1, sent: 15500 }
  ];

  const abTests = [
    {
      id: '1',
      name: 'Welcome Email Subject Line Test',
      status: 'completed' as const,
      variants: [
        { name: 'Variant A', openRate: 28.5, clickRate: 4.2, conversionRate: 2.8, sent: 5000, confidence: 95 },
        { name: 'Variant B', openRate: 22.1, clickRate: 3.1, conversionRate: 1.9, sent: 5000, confidence: 95 }
      ],
      winner: 'Variant A'
    },
    {
      id: '2',
      name: 'Product Launch CTA Button Test',
      status: 'running' as const,
      variants: [
        { name: 'Variant A', openRate: 24.8, clickRate: 3.9, conversionRate: 2.2, sent: 3500, confidence: 78 },
        { name: 'Variant B', openRate: 26.2, clickRate: 4.1, conversionRate: 2.4, sent: 3500, confidence: 78 }
      ]
    }
  ];

  const templateStats = [
    { name: 'Welcome Series #1', usage: 15420, performance: 85, category: 'Onboarding' },
    { name: 'Product Launch', usage: 12350, performance: 78, category: 'Marketing' },
    { name: 'Newsletter Template', usage: 9800, performance: 72, category: 'Newsletter' },
    { name: 'Abandoned Cart', usage: 8750, performance: 68, category: 'E-commerce' },
    { name: 'Event Invitation', usage: 7200, performance: 65, category: 'Events' },
    { name: 'Survey Request', usage: 6100, performance: 58, category: 'Feedback' },
    { name: 'Holiday Promotion', usage: 5800, performance: 82, category: 'Marketing' },
    { name: 'Re-engagement', usage: 4900, performance: 45, category: 'Retention' }
  ];

  const categoryStats = [
    { name: 'Marketing', value: 35, color: '#3b82f6' },
    { name: 'Onboarding', value: 25, color: '#10b981' },
    { name: 'Newsletter', value: 20, color: '#8b5cf6' },
    { name: 'E-commerce', value: 12, color: '#f59e0b' },
    { name: 'Events', value: 8, color: '#ef4444' }
  ];

  const handleRefresh = () => {
    setIsLoading(true);
    // Simulate API call
    setTimeout(() => setIsLoading(false), 1000);
  };

  const handleExport = () => {
    // Export functionality
    console.log('Exporting analytics data...');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
        <div>
          <h1 className="text-3xl font-bold">Email Analytics Dashboard</h1>
          <p className="text-muted-foreground">Track and analyze your email campaign performance</p>
        </div>
        <div className="flex gap-2">
          <Button variant="outline" onClick={handleRefresh} disabled={isLoading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
            Refresh
          </Button>
          <Button variant="outline" onClick={handleExport}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="h-5 w-5 mr-2" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div>
              <label className="text-sm font-medium mb-2 block">Date Range</label>
              <DatePickerWithRange date={dateRange} setDate={setDateRange} />
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Campaign</label>
              <Select value={selectedCampaign} onValueChange={setSelectedCampaign}>
                <SelectTrigger>
                  <SelectValue placeholder="Select campaign" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Campaigns</SelectItem>
                  <SelectItem value="welcome">Welcome Series</SelectItem>
                  <SelectItem value="newsletter">Newsletter</SelectItem>
                  <SelectItem value="promotional">Promotional</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="text-sm font-medium mb-2 block">Template Type</label>
              <Select value={selectedTemplate} onValueChange={setSelectedTemplate}>
                <SelectTrigger>
                  <SelectValue placeholder="Select template" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Templates</SelectItem>
                  <SelectItem value="marketing">Marketing</SelectItem>
                  <SelectItem value="transactional">Transactional</SelectItem>
                  <SelectItem value="newsletter">Newsletter</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-end">
              <Button className="w-full">Apply Filters</Button>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Overview */}
      <MetricsOverview metrics={metrics} />

      {/* Main Content Tabs */}
      <Tabs defaultValue="performance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="performance">Performance</TabsTrigger>
          <TabsTrigger value="abtests">A/B Tests</TabsTrigger>
          <TabsTrigger value="templates">Templates</TabsTrigger>
          <TabsTrigger value="insights">Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="performance" className="space-y-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <PerformanceChart 
              data={performanceData} 
              chartType="line" 
              title="Email Performance Trends"
            />
            <PerformanceChart 
              data={performanceData} 
              chartType="bar" 
              title="Emails Sent Volume"
            />
          </div>
        </TabsContent>

        <TabsContent value="abtests">
          <ABTestComparison tests={abTests} />
        </TabsContent>

        <TabsContent value="templates">
          <TemplateUsageStats 
            templateStats={templateStats}
            categoryStats={categoryStats}
          />
        </TabsContent>

        <TabsContent value="insights">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Performance Insights</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h4 className="font-semibold text-green-800">Best Performing Day</h4>
                  <p className="text-green-700">Saturdays show 15% higher open rates</p>
                </div>
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h4 className="font-semibold text-blue-800">Optimal Send Time</h4>
                  <p className="text-blue-700">10 AM - 12 PM generates highest engagement</p>
                </div>
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h4 className="font-semibold text-yellow-800">Subject Line Insight</h4>
                  <p className="text-yellow-700">Personalized subjects increase opens by 26%</p>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recommendations</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold">Improve Mobile Experience</h4>
                  <p className="text-sm text-muted-foreground">45% of opens are on mobile devices</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold">Test More CTAs</h4>
                  <p className="text-sm text-muted-foreground">Single CTA emails perform 42% better</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <h4 className="font-semibold">Segment Your Audience</h4>
                  <p className="text-sm text-muted-foreground">Segmented campaigns show 14% higher CTR</p>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}