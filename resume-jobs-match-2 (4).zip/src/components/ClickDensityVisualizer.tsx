import React, { useEffect, useRef, useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { Settings, Download, RefreshCw } from 'lucide-react';

interface ClickPoint {
  x: number;
  y: number;
  count: number;
  timestamp: Date;
}

interface ClickDensityVisualizerProps {
  clickData: ClickPoint[];
  width?: number;
  height?: number;
  onSettingsChange?: (settings: HeatmapSettings) => void;
}

interface HeatmapSettings {
  radius: number;
  intensity: number;
  blur: number;
  colorScheme: 'red' | 'blue' | 'green' | 'rainbow';
}

export function ClickDensityVisualizer({ 
  clickData, 
  width = 800, 
  height = 600,
  onSettingsChange 
}: ClickDensityVisualizerProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [settings, setSettings] = useState<HeatmapSettings>({
    radius: 25,
    intensity: 0.5,
    blur: 15,
    colorScheme: 'red'
  });
  const [showSettings, setShowSettings] = useState(false);

  useEffect(() => {
    drawHeatmap();
  }, [clickData, settings]);

  const getColorScheme = (intensity: number) => {
    const alpha = Math.min(intensity, 1);
    
    switch (settings.colorScheme) {
      case 'blue':
        return `rgba(0, 123, 255, ${alpha})`;
      case 'green':
        return `rgba(40, 167, 69, ${alpha})`;
      case 'rainbow':
        if (intensity < 0.3) return `rgba(0, 255, 0, ${alpha})`;
        if (intensity < 0.6) return `rgba(255, 255, 0, ${alpha})`;
        if (intensity < 0.8) return `rgba(255, 165, 0, ${alpha})`;
        return `rgba(255, 0, 0, ${alpha})`;
      default:
        return `rgba(255, 0, 0, ${alpha})`;
    }
  };

  const drawHeatmap = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    canvas.width = width;
    canvas.height = height;

    ctx.clearRect(0, 0, width, height);

    // Create a temporary canvas for the heatmap
    const heatmapCanvas = document.createElement('canvas');
    heatmapCanvas.width = width;
    heatmapCanvas.height = height;
    const heatmapCtx = heatmapCanvas.getContext('2d');
    
    if (!heatmapCtx) return;

    // Draw each click point
    clickData.forEach(point => {
      const gradient = heatmapCtx.createRadialGradient(
        point.x, point.y, 0,
        point.x, point.y, settings.radius
      );

      const intensity = Math.min(point.count * settings.intensity, 1);
      
      gradient.addColorStop(0, getColorScheme(intensity));
      gradient.addColorStop(1, getColorScheme(0));

      heatmapCtx.fillStyle = gradient;
      heatmapCtx.beginPath();
      heatmapCtx.arc(point.x, point.y, settings.radius, 0, 2 * Math.PI);
      heatmapCtx.fill();
    });

    // Apply blur effect
    if (settings.blur > 0) {
      heatmapCtx.filter = `blur(${settings.blur}px)`;
      heatmapCtx.drawImage(heatmapCanvas, 0, 0);
    }

    // Draw the heatmap onto the main canvas
    ctx.drawImage(heatmapCanvas, 0, 0);

    // Draw click count labels
    ctx.fillStyle = '#000';
    ctx.font = '12px Arial';
    ctx.textAlign = 'center';
    
    clickData.forEach(point => {
      if (point.count > 5) {
        ctx.fillText(point.count.toString(), point.x, point.y - settings.radius - 5);
      }
    });
  };

  const handleSettingChange = (key: keyof HeatmapSettings, value: any) => {
    const newSettings = { ...settings, [key]: value };
    setSettings(newSettings);
    onSettingsChange?.(newSettings);
  };

  const downloadHeatmap = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const link = document.createElement('a');
    link.download = `heatmap-${Date.now()}.png`;
    link.href = canvas.toDataURL();
    link.click();
  };

  const resetSettings = () => {
    const defaultSettings = {
      radius: 25,
      intensity: 0.5,
      blur: 15,
      colorScheme: 'red' as const
    };
    setSettings(defaultSettings);
    onSettingsChange?.(defaultSettings);
  };

  const totalClicks = clickData.reduce((sum, point) => sum + point.count, 0);
  const maxClicks = Math.max(...clickData.map(point => point.count), 0);

  return (
    <Card className="p-4">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold">Click Density Heatmap</h3>
          <div className="flex items-center gap-4 mt-1">
            <Badge variant="outline">Total Clicks: {totalClicks}</Badge>
            <Badge variant="outline">Max Clicks: {maxClicks}</Badge>
            <Badge variant="outline">Hotspots: {clickData.length}</Badge>
          </div>
        </div>
        
        <div className="flex items-center gap-2">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowSettings(!showSettings)}
          >
            <Settings className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={downloadHeatmap}
          >
            <Download className="h-4 w-4" />
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={resetSettings}
          >
            <RefreshCw className="h-4 w-4" />
          </Button>
        </div>
      </div>

      {showSettings && (
        <div className="mb-4 p-4 bg-gray-50 rounded-lg space-y-4">
          <div>
            <label className="block text-sm font-medium mb-2">Radius: {settings.radius}px</label>
            <Slider
              value={[settings.radius]}
              onValueChange={([value]) => handleSettingChange('radius', value)}
              max={50}
              min={10}
              step={5}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Intensity: {settings.intensity}</label>
            <Slider
              value={[settings.intensity]}
              onValueChange={([value]) => handleSettingChange('intensity', value)}
              max={1}
              min={0.1}
              step={0.1}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Blur: {settings.blur}px</label>
            <Slider
              value={[settings.blur]}
              onValueChange={([value]) => handleSettingChange('blur', value)}
              max={30}
              min={0}
              step={5}
            />
          </div>
          
          <div>
            <label className="block text-sm font-medium mb-2">Color Scheme</label>
            <div className="flex gap-2">
              {(['red', 'blue', 'green', 'rainbow'] as const).map(scheme => (
                <Button
                  key={scheme}
                  variant={settings.colorScheme === scheme ? 'default' : 'outline'}
                  size="sm"
                  onClick={() => handleSettingChange('colorScheme', scheme)}
                  className="capitalize"
                >
                  {scheme}
                </Button>
              ))}
            </div>
          </div>
        </div>
      )}

      <div className="border rounded-lg overflow-hidden">
        <canvas
          ref={canvasRef}
          className="max-w-full h-auto"
          style={{ display: 'block' }}
        />
      </div>

      <div className="mt-4 text-sm text-gray-600">
        <p>Hover over hotspots to see click counts. Brighter areas indicate higher engagement.</p>
      </div>
    </Card>
  );
}