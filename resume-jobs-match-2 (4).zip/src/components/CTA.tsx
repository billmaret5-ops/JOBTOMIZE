import React from 'react';
import { Button } from '@/components/ui/button';
import { ArrowRight, UserPlus } from 'lucide-react';

export default function CTA() {
  return (
    <section className="py-20 bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4 text-center">
        <h2 className="text-4xl font-bold mb-6">
          Stop Getting Rejected. Start Getting Hired.
        </h2>
        <p className="text-xl mb-8 max-w-2xl mx-auto opacity-90">
          Join thousands who've beaten the hiring robots and landed 3x more interviews. 
          Our AI fights for you 24/7 - completely free to start.
        </p>

        
        <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
          <Button size="lg" className="bg-white text-blue-600 hover:bg-gray-100 font-semibold px-8">
            <UserPlus className="w-5 h-5 mr-2" />
            Create Free Account
          </Button>
          <Button size="lg" variant="outline" className="border-white text-white hover:bg-white hover:text-blue-600 font-semibold px-8">
            Browse Jobs
            <ArrowRight className="w-5 h-5 ml-2" />
          </Button>
        </div>
        
        <div className="mt-8 text-sm opacity-75">
          <p>Free to start • AI working 24/7 • 3x more interviews guaranteed</p>

        </div>
      </div>
    </section>
  );
}