import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { 
  TrendingUp, 
  Users, 
  UserPlus, 
  UserMinus,
  Star,
  Activity,
  Mail,
  Phone,
  Building
} from 'lucide-react';
import { LineChart, Line, AreaChart, Area, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';

interface AnalyticsData {
  growth: Array<{ date: string; contacts: number; leads: number; customers: number }>;
  lifecycle: Array<{ stage: string; count: number; color: string }>;
  sources: Array<{ source: string; count: number; percentage: number }>;
  engagement: Array<{ score_range: string; count: number }>;
  activity: Array<{ date: string; interactions: number }>;
}

export function ContactAnalytics() {
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [timeRange, setTimeRange] = useState('30d');
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    
    // Mock analytics data
    const mockData: AnalyticsData = {
      growth: [
        { date: '2024-01-01', contacts: 1200, leads: 800, customers: 400 },
        { date: '2024-01-08', contacts: 1350, leads: 900, customers: 450 },
        { date: '2024-01-15', contacts: 1480, leads: 980, customers: 500 },
        { date: '2024-01-22', contacts: 1620, leads: 1080, customers: 540 },
        { date: '2024-01-29', contacts: 1750, leads: 1150, customers: 600 }
      ],
      lifecycle: [
        { stage: 'Lead', count: 1150, color: '#3B82F6' },
        { stage: 'Prospect', count: 320, color: '#F59E0B' },
        { stage: 'Customer', count: 600, color: '#10B981' },
        { stage: 'Evangelist', count: 80, color: '#8B5CF6' }
      ],
      sources: [
        { source: 'Website Form', count: 650, percentage: 35 },
        { source: 'Email Campaign', count: 480, percentage: 26 },
        { source: 'Social Media', count: 320, percentage: 17 },
        { source: 'Referral', count: 240, percentage: 13 },
        { source: 'Direct Import', count: 160, percentage: 9 }
      ],
      engagement: [
        { score_range: '0-20', count: 180 },
        { score_range: '21-40', count: 320 },
        { score_range: '41-60', count: 480 },
        { score_range: '61-80', count: 620 },
        { score_range: '81-100', count: 250 }
      ],
      activity: [
        { date: '2024-01-01', interactions: 1200 },
        { date: '2024-01-02', interactions: 1350 },
        { date: '2024-01-03', interactions: 980 },
        { date: '2024-01-04', interactions: 1680 },
        { date: '2024-01-05', interactions: 1420 },
        { date: '2024-01-06', interactions: 1150 },
        { date: '2024-01-07', interactions: 1380 }
      ]
    };

    setData(mockData);
    setLoading(false);
  };

  const stats = {
    totalContacts: 1750,
    newThisMonth: 150,
    churnRate: 2.3,
    avgEngagement: 68,
    topSource: 'Website Form'
  };

  if (loading || !data) {
    return (
      <div className="space-y-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {[...Array(4)].map((_, i) => (
            <Card key={i}>
              <CardContent className="p-6">
                <div className="space-y-2">
                  <div className="h-4 bg-gray-200 rounded animate-pulse" />
                  <div className="h-8 bg-gray-200 rounded animate-pulse" />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Contact Analytics</h2>
          <p className="text-muted-foreground">Track contact growth and engagement</p>
        </div>
        <Select value={timeRange} onValueChange={setTimeRange}>
          <SelectTrigger className="w-40">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="7d">Last 7 days</SelectItem>
            <SelectItem value="30d">Last 30 days</SelectItem>
            <SelectItem value="90d">Last 90 days</SelectItem>
            <SelectItem value="1y">Last year</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Total Contacts</p>
                <p className="text-2xl font-bold">{stats.totalContacts.toLocaleString()}</p>
              </div>
              <Users className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">New This Month</p>
                <p className="text-2xl font-bold text-green-600">+{stats.newThisMonth}</p>
              </div>
              <UserPlus className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Churn Rate</p>
                <p className="text-2xl font-bold text-red-600">{stats.churnRate}%</p>
              </div>
              <UserMinus className="h-8 w-8 text-red-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Avg Engagement</p>
                <p className="text-2xl font-bold text-purple-600">{stats.avgEngagement}</p>
              </div>
              <Star className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Top Source</p>
                <p className="text-lg font-bold">{stats.topSource}</p>
              </div>
              <Activity className="h-8 w-8 text-orange-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <Tabs defaultValue="growth" className="space-y-4">
        <TabsList>
          <TabsTrigger value="growth">Growth Trends</TabsTrigger>
          <TabsTrigger value="lifecycle">Lifecycle Stages</TabsTrigger>
          <TabsTrigger value="sources">Acquisition Sources</TabsTrigger>
          <TabsTrigger value="engagement">Engagement Scores</TabsTrigger>
        </TabsList>

        <TabsContent value="growth">
          <Card>
            <CardHeader>
              <CardTitle>Contact Growth Over Time</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <AreaChart data={data.growth}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="date" />
                  <YAxis />
                  <Tooltip />
                  <Area type="monotone" dataKey="contacts" stackId="1" stroke="#3B82F6" fill="#3B82F6" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="leads" stackId="2" stroke="#F59E0B" fill="#F59E0B" fillOpacity={0.6} />
                  <Area type="monotone" dataKey="customers" stackId="3" stroke="#10B981" fill="#10B981" fillOpacity={0.6} />
                </AreaChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="lifecycle">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Lifecycle Distribution</CardTitle>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={300}>
                  <PieChart>
                    <Pie
                      data={data.lifecycle}
                      cx="50%"
                      cy="50%"
                      outerRadius={80}
                      dataKey="count"
                      label={({ stage, count }) => `${stage}: ${count}`}
                    >
                      {data.lifecycle.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Lifecycle Breakdown</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.lifecycle.map((stage) => (
                    <div key={stage.stage} className="space-y-2">
                      <div className="flex justify-between items-center">
                        <span className="font-medium">{stage.stage}</span>
                        <Badge variant="secondary">{stage.count}</Badge>
                      </div>
                      <Progress 
                        value={(stage.count / stats.totalContacts) * 100} 
                        className="h-2"
                      />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="sources">
          <Card>
            <CardHeader>
              <CardTitle>Acquisition Sources</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {data.sources.map((source) => (
                  <div key={source.source} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      <div className="p-2 rounded-full bg-blue-100">
                        <Building className="h-4 w-4 text-blue-600" />
                      </div>
                      <span className="font-medium">{source.source}</span>
                    </div>
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">{source.percentage}%</Badge>
                      <span className="font-bold">{source.count}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="engagement">
          <Card>
            <CardHeader>
              <CardTitle>Engagement Score Distribution</CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={400}>
                <BarChart data={data.engagement}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="score_range" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="count" fill="#8B5CF6" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}