import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { History, RotateCcw, TrendingUp, Settings, Calendar } from 'lucide-react';
import { warmupCollaborationService, TemplateChange } from '../services/warmupCollaborationService';

interface CollaborativeChangeTrackerProps {
  templateId: string;
}

export const CollaborativeChangeTracker: React.FC<CollaborativeChangeTrackerProps> = ({ 
  templateId 
}) => {
  const [changes, setChanges] = useState<TemplateChange[]>([]);
  const [filter, setFilter] = useState<string>('all');

  useEffect(() => {
    loadChanges();
  }, [templateId]);

  const loadChanges = () => {
    setChanges(warmupCollaborationService.getChanges());
  };

  const getChangeIcon = (type: string) => {
    switch (type) {
      case 'volume': return <TrendingUp className="w-4 h-4" />;
      case 'schedule': return <Calendar className="w-4 h-4" />;
      case 'settings': return <Settings className="w-4 h-4" />;
      default: return <History className="w-4 h-4" />;
    }
  };

  const filteredChanges = filter === 'all' 
    ? changes 
    : changes.filter(c => c.changeType === filter);

  return (
    <Card className="mt-4 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <History className="w-5 h-5" />
          <h3 className="text-lg font-semibold">Change History</h3>
          <Badge>{changes.length}</Badge>
        </div>
        <div className="flex gap-2">
          <Button
            variant={filter === 'all' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('all')}
          >
            All
          </Button>
          <Button
            variant={filter === 'volume' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('volume')}
          >
            Volume
          </Button>
          <Button
            variant={filter === 'schedule' ? 'default' : 'outline'}
            size="sm"
            onClick={() => setFilter('schedule')}
          >
            Schedule
          </Button>
        </div>
      </div>

      <div className="space-y-2 max-h-96 overflow-y-auto">
        {filteredChanges.map((change) => (
          <div key={change.id} className="flex items-start gap-3 p-3 border rounded hover:bg-gray-50">
            <div className="mt-1">{getChangeIcon(change.changeType)}</div>
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-1">
                <span className="font-semibold text-sm">{change.userName}</span>
                <Badge variant="outline">{change.changeType}</Badge>
                <span className="text-xs text-gray-500">{change.section}</span>
              </div>
              <div className="text-sm text-gray-700">
                Changed from <span className="font-mono bg-gray-100 px-1">{change.oldValue}</span>
                {' to '}
                <span className="font-mono bg-gray-100 px-1">{change.newValue}</span>
              </div>
              <p className="text-xs text-gray-500 mt-1">
                {new Date(change.timestamp).toLocaleString()}
              </p>
            </div>
            <Button size="sm" variant="ghost">
              <RotateCcw className="w-4 h-4" />
            </Button>
          </div>
        ))}
      </div>
    </Card>
  );
};
