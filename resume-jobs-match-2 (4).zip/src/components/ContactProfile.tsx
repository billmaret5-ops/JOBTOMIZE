import React, { useState, useEffect } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import {
  Mail,
  Phone,
  Building,
  MapPin,
  Calendar,
  Star,
  TrendingUp,
  Activity,
  Tag,
  Edit
} from 'lucide-react';

interface Contact {
  id: string;
  email: string;
  first_name?: string;
  last_name?: string;
  company?: string;
  job_title?: string;
  phone?: string;
  location?: string;
  lifecycle_stage: string;
  lead_score: number;
  engagement_score: number;
  tags: string[];
  last_activity_at?: string;
}

interface Interaction {
  id: string;
  type: string;
  details: string;
  occurred_at: string;
  value?: number;
}

interface ContactProfileProps {
  contact: Contact;
  open: boolean;
  onClose: () => void;
}

export function ContactProfile({ contact, open, onClose }: ContactProfileProps) {
  const [interactions, setInteractions] = useState<Interaction[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (open) {
      loadInteractions();
    }
  }, [open]);

  const loadInteractions = async () => {
    setLoading(true);
    // Mock interaction data
    const mockInteractions: Interaction[] = [
      {
        id: '1',
        type: 'email_opened',
        details: 'Opened "Welcome to our platform" email',
        occurred_at: '2024-01-15T10:30:00Z'
      },
      {
        id: '2',
        type: 'email_clicked',
        details: 'Clicked "Learn More" button in newsletter',
        occurred_at: '2024-01-14T15:45:00Z'
      },
      {
        id: '3',
        type: 'form_submitted',
        details: 'Submitted contact form on pricing page',
        occurred_at: '2024-01-13T09:20:00Z',
        value: 50
      },
      {
        id: '4',
        type: 'page_visited',
        details: 'Visited product demo page',
        occurred_at: '2024-01-12T14:15:00Z'
      }
    ];
    setInteractions(mockInteractions);
    setLoading(false);
  };

  const getInteractionIcon = (type: string) => {
    const icons = {
      email_opened: Mail,
      email_clicked: TrendingUp,
      form_submitted: Activity,
      page_visited: Activity
    };
    const Icon = icons[type as keyof typeof icons] || Activity;
    return <Icon className="h-4 w-4" />;
  };

  const getInteractionColor = (type: string) => {
    const colors = {
      email_opened: 'text-blue-600',
      email_clicked: 'text-green-600',
      form_submitted: 'text-purple-600',
      page_visited: 'text-orange-600'
    };
    return colors[type as keyof typeof colors] || 'text-gray-600';
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Contact Profile</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Header */}
          <div className="flex items-start gap-4">
            <Avatar className="h-16 w-16">
              <AvatarFallback className="text-lg">
                {contact.first_name?.[0]}{contact.last_name?.[0]}
              </AvatarFallback>
            </Avatar>
            
            <div className="flex-1">
              <div className="flex items-center gap-2 mb-2">
                <h2 className="text-2xl font-bold">
                  {contact.first_name} {contact.last_name}
                </h2>
                <Badge variant="secondary">
                  {contact.lifecycle_stage}
                </Badge>
              </div>
              
              <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                <div className="flex items-center gap-2">
                  <Mail className="h-4 w-4" />
                  {contact.email}
                </div>
                {contact.phone && (
                  <div className="flex items-center gap-2">
                    <Phone className="h-4 w-4" />
                    {contact.phone}
                  </div>
                )}
                {contact.company && (
                  <div className="flex items-center gap-2">
                    <Building className="h-4 w-4" />
                    {contact.company}
                  </div>
                )}
                {contact.location && (
                  <div className="flex items-center gap-2">
                    <MapPin className="h-4 w-4" />
                    {contact.location}
                  </div>
                )}
              </div>

              <div className="flex items-center gap-2 mt-3">
                {contact.tags.map((tag) => (
                  <Badge key={tag} variant="outline">
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>

            <Button variant="outline" size="sm">
              <Edit className="h-4 w-4 mr-2" />
              Edit
            </Button>
          </div>

          {/* Score Cards */}
          <div className="grid grid-cols-3 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Lead Score</p>
                    <p className="text-2xl font-bold text-blue-600">
                      {contact.lead_score}
                    </p>
                  </div>
                  <Star className="h-8 w-8 text-blue-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Engagement</p>
                    <p className="text-2xl font-bold text-green-600">
                      {contact.engagement_score}
                    </p>
                  </div>
                  <TrendingUp className="h-8 w-8 text-green-500" />
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">Last Activity</p>
                    <p className="text-sm font-medium">
                      {contact.last_activity_at ? 
                        formatDate(contact.last_activity_at) : 
                        'Never'
                      }
                    </p>
                  </div>
                  <Calendar className="h-8 w-8 text-orange-500" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Tabs */}
          <Tabs defaultValue="activity" className="space-y-4">
            <TabsList>
              <TabsTrigger value="activity">Activity History</TabsTrigger>
              <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
              <TabsTrigger value="lists">Lists & Segments</TabsTrigger>
            </TabsList>

            <TabsContent value="activity">
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activity</CardTitle>
                </CardHeader>
                <CardContent>
                  {loading ? (
                    <div className="space-y-4">
                      {[...Array(3)].map((_, i) => (
                        <div key={i} className="flex items-center space-x-3">
                          <div className="w-8 h-8 bg-gray-200 rounded animate-pulse" />
                          <div className="flex-1 space-y-2">
                            <div className="h-4 bg-gray-200 rounded animate-pulse" />
                            <div className="h-3 bg-gray-200 rounded w-1/3 animate-pulse" />
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="space-y-4">
                      {interactions.map((interaction) => (
                        <div key={interaction.id} className="flex items-start gap-3 p-3 border rounded-lg">
                          <div className={`p-2 rounded-full bg-muted ${getInteractionColor(interaction.type)}`}>
                            {getInteractionIcon(interaction.type)}
                          </div>
                          <div className="flex-1">
                            <p className="font-medium">{interaction.details}</p>
                            <p className="text-sm text-muted-foreground">
                              {formatDate(interaction.occurred_at)}
                            </p>
                            {interaction.value && (
                              <Badge variant="secondary" className="mt-1">
                                +{interaction.value} points
                              </Badge>
                            )}
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="campaigns">
              <Card>
                <CardHeader>
                  <CardTitle>Campaign History</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Campaign history will be displayed here.</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="notes">
              <Card>
                <CardHeader>
                  <CardTitle>Notes</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">Contact notes will be displayed here.</p>
                </CardContent>
              </Card>
            </TabsContent>

            <TabsContent value="lists">
              <Card>
                <CardHeader>
                  <CardTitle>Lists & Segments</CardTitle>
                </CardHeader>
                <CardContent>
                  <p className="text-muted-foreground">List and segment memberships will be displayed here.</p>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}