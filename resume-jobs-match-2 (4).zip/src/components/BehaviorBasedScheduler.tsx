import { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Clock, TrendingUp, Mail, Calendar } from 'lucide-react';
import { behaviorSchedulingService, RecipientBehavior } from '@/services/behaviorSchedulingService';

interface Props {
  contactId: string;
}

export default function BehaviorBasedScheduler({ contactId }: Props) {
  const [behavior, setBehavior] = useState<RecipientBehavior | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadBehavior();
  }, [contactId]);

  const loadBehavior = async () => {
    try {
      const data = await behaviorSchedulingService.analyzeRecipientBehavior(contactId);
      setBehavior(data);
    } catch (error) {
      console.error('Error loading behavior:', error);
    } finally {
      setLoading(false);
    }
  };

  if (loading) return <div>Loading behavior analysis...</div>;
  if (!behavior) return <div>No behavior data available</div>;

  const getEngagementLevel = (score: number) => {
    if (score >= 70) return { label: 'High', color: 'bg-green-500' };
    if (score >= 40) return { label: 'Medium', color: 'bg-yellow-500' };
    return { label: 'Low', color: 'bg-red-500' };
  };

  const engagement = getEngagementLevel(behavior.engagement_score);

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <TrendingUp className="w-5 h-5" />
            Engagement Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Engagement Score</span>
              <Badge className={engagement.color}>{engagement.label} ({behavior.engagement_score.toFixed(1)}%)</Badge>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Opens</span>
              <span className="font-semibold">{behavior.open_times.length}</span>
            </div>

            <div className="flex items-center justify-between">
              <span className="text-sm text-muted-foreground">Total Clicks</span>
              <span className="font-semibold">{behavior.click_times.length}</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {behavior.preferred_send_time && (
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Clock className="w-5 h-5" />
              Optimal Send Time
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-muted-foreground" />
              <span className="font-semibold">
                {behavior.preferred_send_time.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </span>
            </div>
            <p className="text-sm text-muted-foreground mt-2">
              Based on historical engagement patterns
            </p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
