import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { WorkflowCanvas } from './WorkflowCanvas';
import { CampaignMonitoringDashboard } from './CampaignMonitoringDashboard';
import { 
  Plus, 
  Save, 
  Play, 
  Settings, 
  BarChart3, 
  Workflow,
  Mail,
  Clock,
  Users
} from 'lucide-react';

interface EmailSequence {
  id: string;
  name: string;
  description: string;
  status: 'draft' | 'active' | 'paused';
  triggerType: string;
  totalSteps: number;
  activeRecipients: number;
  createdAt: string;
}

export const AutomatedEmailSequenceBuilder: React.FC = () => {
  const [sequences, setSequences] = useState<EmailSequence[]>([
    {
      id: '1',
      name: 'Job Application Follow-up',
      description: 'Automated follow-up sequence for job applications',
      status: 'active',
      triggerType: 'Application Submitted',
      totalSteps: 5,
      activeRecipients: 127,
      createdAt: '2024-01-15',
    },
    {
      id: '2',
      name: 'Interview Preparation',
      description: 'Pre-interview preparation and reminder sequence',
      status: 'active',
      triggerType: 'Interview Scheduled',
      totalSteps: 3,
      activeRecipients: 43,
      createdAt: '2024-01-12',
    },
    {
      id: '3',
      name: 'Post-Interview Thank You',
      description: 'Thank you and follow-up after interviews',
      status: 'draft',
      triggerType: 'Interview Completed',
      totalSteps: 2,
      activeRecipients: 0,
      createdAt: '2024-01-18',
    },
  ]);

  const [selectedSequence, setSelectedSequence] = useState<string | null>(null);
  const [isCreating, setIsCreating] = useState(false);
  const [newSequence, setNewSequence] = useState({
    name: '',
    description: '',
    triggerType: 'application_submitted',
  });

  const createSequence = () => {
    if (!newSequence.name.trim()) return;
    
    const sequence: EmailSequence = {
      id: Date.now().toString(),
      name: newSequence.name,
      description: newSequence.description,
      status: 'draft',
      triggerType: newSequence.triggerType,
      totalSteps: 0,
      activeRecipients: 0,
      createdAt: new Date().toISOString().split('T')[0],
    };
    
    setSequences(prev => [...prev, sequence]);
    setNewSequence({ name: '', description: '', triggerType: 'application_submitted' });
    setIsCreating(false);
    setSelectedSequence(sequence.id);
  };

  const toggleSequenceStatus = (id: string) => {
    setSequences(prev => prev.map(seq => 
      seq.id === id 
        ? { ...seq, status: seq.status === 'active' ? 'paused' : 'active' }
        : seq
    ));
  };

  const getStatusColor = (status: EmailSequence['status']) => {
    switch (status) {
      case 'active': return 'bg-green-100 text-green-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (selectedSequence) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <Button 
              variant="outline" 
              onClick={() => setSelectedSequence(null)}
              className="mb-2"
            >
              ← Back to Sequences
            </Button>
            <h1 className="text-3xl font-bold">
              {sequences.find(s => s.id === selectedSequence)?.name}
            </h1>
          </div>
        </div>

        <Tabs defaultValue="workflow" className="space-y-4">
          <TabsList>
            <TabsTrigger value="workflow">
              <Workflow className="w-4 h-4 mr-2" />
              Workflow Builder
            </TabsTrigger>
            <TabsTrigger value="monitoring">
              <BarChart3 className="w-4 h-4 mr-2" />
              Campaign Monitoring
            </TabsTrigger>
            <TabsTrigger value="settings">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </TabsTrigger>
          </TabsList>

          <TabsContent value="workflow">
            <WorkflowCanvas 
              workflowId={selectedSequence}
              onSave={(workflow) => {
                console.log('Saving workflow:', workflow);
                // Update sequence with workflow data
                setSequences(prev => prev.map(seq => 
                  seq.id === selectedSequence 
                    ? { ...seq, totalSteps: workflow.nodes?.length || 0 }
                    : seq
                ));
              }}
            />
          </TabsContent>

          <TabsContent value="monitoring">
            <CampaignMonitoringDashboard />
          </TabsContent>

          <TabsContent value="settings">
            <Card>
              <CardHeader>
                <CardTitle>Sequence Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Sequence Name</Label>
                  <Input 
                    value={sequences.find(s => s.id === selectedSequence)?.name || ''}
                    onChange={(e) => {
                      setSequences(prev => prev.map(seq => 
                        seq.id === selectedSequence 
                          ? { ...seq, name: e.target.value }
                          : seq
                      ));
                    }}
                  />
                </div>
                <div>
                  <Label>Description</Label>
                  <Textarea 
                    value={sequences.find(s => s.id === selectedSequence)?.description || ''}
                    onChange={(e) => {
                      setSequences(prev => prev.map(seq => 
                        seq.id === selectedSequence 
                          ? { ...seq, description: e.target.value }
                          : seq
                      ));
                    }}
                    rows={3}
                  />
                </div>
                <Button>Save Settings</Button>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Email Sequence Builder</h1>
          <p className="text-gray-600 mt-1">
            Create automated drip campaigns for job applications
          </p>
        </div>
        <Button onClick={() => setIsCreating(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Sequence
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Sequences</p>
                <p className="text-2xl font-bold">
                  {sequences.filter(s => s.status === 'active').length}
                </p>
              </div>
              <Workflow className="w-8 h-8 text-blue-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Recipients</p>
                <p className="text-2xl font-bold">
                  {sequences.reduce((sum, seq) => sum + seq.activeRecipients, 0)}
                </p>
              </div>
              <Users className="w-8 h-8 text-green-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Steps</p>
                <p className="text-2xl font-bold">
                  {sequences.reduce((sum, seq) => sum + seq.totalSteps, 0)}
                </p>
              </div>
              <Mail className="w-8 h-8 text-purple-600" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg. Response Time</p>
                <p className="text-2xl font-bold">2.3h</p>
              </div>
              <Clock className="w-8 h-8 text-orange-600" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Create New Sequence Modal */}
      {isCreating && (
        <Card className="border-2 border-blue-200">
          <CardHeader>
            <CardTitle>Create New Email Sequence</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label>Sequence Name</Label>
              <Input
                value={newSequence.name}
                onChange={(e) => setNewSequence({ ...newSequence, name: e.target.value })}
                placeholder="e.g., Job Application Follow-up"
              />
            </div>
            <div>
              <Label>Description</Label>
              <Textarea
                value={newSequence.description}
                onChange={(e) => setNewSequence({ ...newSequence, description: e.target.value })}
                placeholder="Describe the purpose of this sequence"
                rows={3}
              />
            </div>
            <div className="flex gap-2">
              <Button onClick={createSequence}>
                <Save className="w-4 h-4 mr-2" />
                Create Sequence
              </Button>
              <Button variant="outline" onClick={() => setIsCreating(false)}>
                Cancel
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Existing Sequences */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {sequences.map((sequence) => (
          <Card 
            key={sequence.id} 
            className="cursor-pointer hover:shadow-lg transition-shadow"
            onClick={() => setSelectedSequence(sequence.id)}
          >
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{sequence.name}</CardTitle>
                <Badge className={getStatusColor(sequence.status)}>
                  {sequence.status}
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-gray-600 mb-4">{sequence.description}</p>
              
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span>Trigger:</span>
                  <span className="font-medium">{sequence.triggerType}</span>
                </div>
                <div className="flex justify-between">
                  <span>Steps:</span>
                  <span className="font-medium">{sequence.totalSteps}</span>
                </div>
                <div className="flex justify-between">
                  <span>Active Recipients:</span>
                  <span className="font-medium">{sequence.activeRecipients}</span>
                </div>
                <div className="flex justify-between">
                  <span>Created:</span>
                  <span className="font-medium">
                    {new Date(sequence.createdAt).toLocaleDateString()}
                  </span>
                </div>
              </div>

              <div className="flex gap-2 mt-4">
                <Button
                  size="sm"
                  variant={sequence.status === 'active' ? 'destructive' : 'default'}
                  onClick={(e) => {
                    e.stopPropagation();
                    toggleSequenceStatus(sequence.id);
                  }}
                >
                  {sequence.status === 'active' ? 'Pause' : 'Activate'}
                </Button>
                <Button size="sm" variant="outline">
                  <BarChart3 className="w-4 h-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
};