import React, { useState, useEffect } from 'react';
import { useAuth } from '@/contexts/AuthContext';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Calendar, Clock, AlertTriangle, CheckCircle, Bell } from 'lucide-react';
import { toast } from 'sonner';

interface ApplicationDeadline {
  id: string;
  job_title: string;
  company_name: string;
  deadline_date: string;
  status: string;
  priority: 'high' | 'medium' | 'low';
  days_remaining: number;
}

export default function ApplicationDeadlineTracker() {
  const { user } = useAuth();
  const [deadlines, setDeadlines] = useState<ApplicationDeadline[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchDeadlines();
    }
  }, [user]);

  const fetchDeadlines = async () => {
    try {
      const { data, error } = await supabase
        .from('job_applications')
        .select('id, job_title, company_name, deadline_date, status, priority')
        .eq('user_id', user?.id)
        .not('deadline_date', 'is', null)
        .order('deadline_date', { ascending: true });

      if (error) throw error;

      const processedDeadlines = data?.map(app => {
        const deadlineDate = new Date(app.deadline_date);
        const today = new Date();
        const timeDiff = deadlineDate.getTime() - today.getTime();
        const daysDiff = Math.ceil(timeDiff / (1000 * 3600 * 24));

        return {
          ...app,
          days_remaining: daysDiff
        };
      }) || [];

      setDeadlines(processedDeadlines);
    } catch (error) {
      toast.error('Failed to fetch deadlines');
    } finally {
      setLoading(false);
    }
  };

  const getUrgencyColor = (daysRemaining: number) => {
    if (daysRemaining < 0) return 'bg-red-100 text-red-800';
    if (daysRemaining <= 2) return 'bg-orange-100 text-orange-800';
    if (daysRemaining <= 7) return 'bg-yellow-100 text-yellow-800';
    return 'bg-green-100 text-green-800';
  };

  const getUrgencyIcon = (daysRemaining: number) => {
    if (daysRemaining < 0) return <AlertTriangle className="h-4 w-4" />;
    if (daysRemaining <= 2) return <Clock className="h-4 w-4" />;
    if (daysRemaining <= 7) return <Bell className="h-4 w-4" />;
    return <CheckCircle className="h-4 w-4" />;
  };

  if (loading) {
    return <div className="flex justify-center items-center h-32">Loading deadlines...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Calendar className="h-5 w-5" />
          Application Deadlines
        </CardTitle>
      </CardHeader>
      <CardContent>
        {deadlines.length === 0 ? (
          <p className="text-gray-500 text-center py-4">No upcoming deadlines</p>
        ) : (
          <div className="space-y-3">
            {deadlines.map((deadline) => (
              <div key={deadline.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex-1">
                  <h4 className="font-medium">{deadline.job_title}</h4>
                  <p className="text-sm text-gray-600">{deadline.company_name}</p>
                  <p className="text-xs text-gray-500">
                    Deadline: {new Date(deadline.deadline_date).toLocaleDateString()}
                  </p>
                </div>
                <div className="flex items-center gap-2">
                  <Badge className={getUrgencyColor(deadline.days_remaining)}>
                    {getUrgencyIcon(deadline.days_remaining)}
                    <span className="ml-1">
                      {deadline.days_remaining < 0 
                        ? `${Math.abs(deadline.days_remaining)} days overdue`
                        : deadline.days_remaining === 0 
                        ? 'Due today'
                        : `${deadline.days_remaining} days left`
                      }
                    </span>
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
    </Card>
  );
}