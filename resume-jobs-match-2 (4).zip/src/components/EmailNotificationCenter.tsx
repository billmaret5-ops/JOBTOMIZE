import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Bell, Mail, Calendar, CheckCircle, Clock, Settings } from 'lucide-react';
import { useAuth } from '../contexts/AuthContext';
import { supabase } from '../lib/supabase';
import { toast } from './ui/use-toast';

interface EmailNotificationSettings {
  id: string;
  userId: string;
  applicationStatusUpdates: boolean;
  interviewReminders: boolean;
  jobMatchAlerts: boolean;
  resumeUpdateNotifications: boolean;
  followUpReminders: boolean;
  weeklyDigest: boolean;
  emailFrequency: 'immediate' | 'daily' | 'weekly';
}

interface ScheduledEmail {
  id: string;
  type: string;
  recipient: string;
  subject: string;
  scheduledFor: string;
  status: 'pending' | 'sent' | 'failed';
  template: string;
}

export const EmailNotificationCenter: React.FC = () => {
  const { user } = useAuth();
  const [settings, setSettings] = useState<EmailNotificationSettings | null>(null);
  const [scheduledEmails, setScheduledEmails] = useState<ScheduledEmail[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadSettings();
      loadScheduledEmails();
    }
  }, [user]);

  const loadSettings = async () => {
    try {
      const { data, error } = await supabase
        .from('email_notification_settings')
        .select('*')
        .eq('user_id', user?.id)
        .single();

      if (error && error.code !== 'PGRST116') {
        throw error;
      }

      if (data) {
        setSettings(data);
      } else {
        // Create default settings
        const defaultSettings = {
          user_id: user?.id,
          application_status_updates: true,
          interview_reminders: true,
          job_match_alerts: true,
          resume_update_notifications: false,
          follow_up_reminders: true,
          weekly_digest: true,
          email_frequency: 'immediate'
        };

        const { data: newSettings, error: createError } = await supabase
          .from('email_notification_settings')
          .insert(defaultSettings)
          .select()
          .single();

        if (createError) throw createError;
        setSettings(newSettings);
      }
    } catch (error) {
      console.error('Error loading settings:', error);
      toast({
        title: 'Error',
        description: 'Failed to load notification settings',
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const loadScheduledEmails = async () => {
    try {
      const { data, error } = await supabase
        .from('scheduled_emails')
        .select('*')
        .eq('user_id', user?.id)
        .order('scheduled_for', { ascending: true })
        .limit(10);

      if (error) throw error;
      setScheduledEmails(data || []);
    } catch (error) {
      console.error('Error loading scheduled emails:', error);
    }
  };

  const updateSetting = async (key: keyof EmailNotificationSettings, value: boolean | string) => {
    if (!settings) return;

    try {
      const { error } = await supabase
        .from('email_notification_settings')
        .update({ [key]: value })
        .eq('id', settings.id);

      if (error) throw error;

      setSettings({ ...settings, [key]: value });
      toast({
        title: 'Settings Updated',
        description: 'Your email notification preferences have been saved.'
      });
    } catch (error) {
      console.error('Error updating setting:', error);
      toast({
        title: 'Error',
        description: 'Failed to update settings',
        variant: 'destructive'
      });
    }
  };

  const testNotification = async (type: string) => {
    try {
      const { error } = await supabase.functions.invoke('send-test-notification', {
        body: { type, userId: user?.id }
      });

      if (error) throw error;

      toast({
        title: 'Test Email Sent',
        description: `A test ${type} notification has been sent to your email.`
      });
    } catch (error) {
      console.error('Error sending test notification:', error);
      toast({
        title: 'Error',
        description: 'Failed to send test notification',
        variant: 'destructive'
      });
    }
  };

  if (loading) {
    return <div className="flex justify-center p-8">Loading...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Bell className="h-5 w-5" />
            Email Notification Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {settings && (
            <>
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Application Status Updates</h4>
                  <p className="text-sm text-muted-foreground">
                    Get notified when your application status changes
                  </p>
                </div>
                <Switch
                  checked={settings.applicationStatusUpdates}
                  onCheckedChange={(checked) => updateSetting('applicationStatusUpdates', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Interview Reminders</h4>
                  <p className="text-sm text-muted-foreground">
                    Receive reminders before scheduled interviews
                  </p>
                </div>
                <Switch
                  checked={settings.interviewReminders}
                  onCheckedChange={(checked) => updateSetting('interviewReminders', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Job Match Alerts</h4>
                  <p className="text-sm text-muted-foreground">
                    Get notified about new job matches based on your profile
                  </p>
                </div>
                <Switch
                  checked={settings.jobMatchAlerts}
                  onCheckedChange={(checked) => updateSetting('jobMatchAlerts', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Resume Update Notifications</h4>
                  <p className="text-sm text-muted-foreground">
                    Get notified when your resume is updated or optimized
                  </p>
                </div>
                <Switch
                  checked={settings.resumeUpdateNotifications}
                  onCheckedChange={(checked) => updateSetting('resumeUpdateNotifications', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Follow-up Reminders</h4>
                  <p className="text-sm text-muted-foreground">
                    Reminders to follow up on applications and interviews
                  </p>
                </div>
                <Switch
                  checked={settings.followUpReminders}
                  onCheckedChange={(checked) => updateSetting('followUpReminders', checked)}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium">Weekly Digest</h4>
                  <p className="text-sm text-muted-foreground">
                    Weekly summary of your job search activity
                  </p>
                </div>
                <Switch
                  checked={settings.weeklyDigest}
                  onCheckedChange={(checked) => updateSetting('weeklyDigest', checked)}
                />
              </div>
            </>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Scheduled Emails
          </CardTitle>
        </CardHeader>
        <CardContent>
          {scheduledEmails.length === 0 ? (
            <p className="text-muted-foreground text-center py-4">
              No scheduled emails
            </p>
          ) : (
            <div className="space-y-3">
              {scheduledEmails.map((email) => (
                <div key={email.id} className="flex items-center justify-between p-3 border rounded-lg">
                  <div className="flex items-center gap-3">
                    <Mail className="h-4 w-4 text-muted-foreground" />
                    <div>
                      <p className="font-medium">{email.subject}</p>
                      <p className="text-sm text-muted-foreground">
                        Scheduled for {new Date(email.scheduledFor).toLocaleString()}
                      </p>
                    </div>
                  </div>
                  <Badge
                    variant={
                      email.status === 'sent' ? 'default' :
                      email.status === 'failed' ? 'destructive' : 'secondary'
                    }
                  >
                    {email.status === 'sent' && <CheckCircle className="h-3 w-3 mr-1" />}
                    {email.status === 'pending' && <Clock className="h-3 w-3 mr-1" />}
                    {email.status}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="h-5 w-5" />
            Test Notifications
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 gap-3">
            <Button
              variant="outline"
              onClick={() => testNotification('application_status')}
            >
              Test Status Update
            </Button>
            <Button
              variant="outline"
              onClick={() => testNotification('interview_reminder')}
            >
              Test Interview Reminder
            </Button>
            <Button
              variant="outline"
              onClick={() => testNotification('job_match')}
            >
              Test Job Match
            </Button>
            <Button
              variant="outline"
              onClick={() => testNotification('follow_up')}
            >
              Test Follow-up
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};