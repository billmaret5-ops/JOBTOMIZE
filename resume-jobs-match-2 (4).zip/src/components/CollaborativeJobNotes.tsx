import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback } from '@/components/ui/avatar';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { Label } from '@/components/ui/label';
import { MessageSquare, Send, Reply, Eye, EyeOff, AtSign, Clock, Lightbulb, AlertCircle } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface JobNote {
  id: string;
  job_id: string;
  group_id: string;
  author_id: string;
  content: string;
  note_type: 'feedback' | 'suggestion' | 'reminder';
  visibility: 'public' | 'private';
  mentions: string[];
  parent_note_id?: string;
  created_at: string;
  author_name?: string;
  replies?: JobNote[];
}

interface CollaborativeJobNotesProps {
  jobId: string;
  groupId: string;
  groupMembers: Array<{ id: string; name: string; email: string }>;
}

const noteTypeIcons = {
  feedback: MessageSquare,
  suggestion: Lightbulb,
  reminder: Clock
};

const noteTypeColors = {
  feedback: 'bg-blue-100 text-blue-800',
  suggestion: 'bg-green-100 text-green-800',
  reminder: 'bg-orange-100 text-orange-800'
};

export function CollaborativeJobNotes({ jobId, groupId, groupMembers }: CollaborativeJobNotesProps) {
  const { user } = useAuth();
  const [notes, setNotes] = useState<JobNote[]>([]);
  const [newNote, setNewNote] = useState('');
  const [noteType, setNoteType] = useState<'feedback' | 'suggestion' | 'reminder'>('feedback');
  const [isPrivate, setIsPrivate] = useState(false);
  const [replyingTo, setReplyingTo] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  useEffect(() => {
    fetchNotes();
    
    // Subscribe to real-time updates
    const subscription = supabase
      .channel(`job_notes_${jobId}_${groupId}`)
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'job_notes',
        filter: `job_id=eq.${jobId}`
      }, () => {
        fetchNotes();
      })
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, [jobId, groupId]);

  const fetchNotes = async () => {
    try {
      const { data, error } = await supabase
        .from('job_notes')
        .select(`
          *,
          profiles!author_id(full_name, email)
        `)
        .eq('job_id', jobId)
        .eq('group_id', groupId)
        .order('created_at', { ascending: true });

      if (error) throw error;

      // Organize notes into threads
      const notesWithReplies = organizeNotes(data || []);
      setNotes(notesWithReplies);
    } catch (error) {
      console.error('Error fetching notes:', error);
    }
  };

  const organizeNotes = (flatNotes: any[]): JobNote[] => {
    const noteMap = new Map();
    const rootNotes: JobNote[] = [];

    // First pass: create all notes
    flatNotes.forEach(note => {
      const formattedNote: JobNote = {
        ...note,
        author_name: note.profiles?.full_name || note.profiles?.email || 'Unknown',
        replies: []
      };
      noteMap.set(note.id, formattedNote);
    });

    // Second pass: organize into threads
    flatNotes.forEach(note => {
      const formattedNote = noteMap.get(note.id);
      if (note.parent_note_id) {
        const parent = noteMap.get(note.parent_note_id);
        if (parent) {
          parent.replies = parent.replies || [];
          parent.replies.push(formattedNote);
        }
      } else {
        rootNotes.push(formattedNote);
      }
    });

    return rootNotes;
  };

  const handleSubmitNote = async () => {
    if (!newNote.trim() || !user) return;

    setLoading(true);
    try {
      const mentions = extractMentions(newNote);
      
      const { error } = await supabase
        .from('job_notes')
        .insert({
          job_id: jobId,
          group_id: groupId,
          author_id: user.id,
          content: newNote,
          note_type: noteType,
          visibility: isPrivate ? 'private' : 'public',
          mentions,
          parent_note_id: replyingTo
        });

      if (error) throw error;

      setNewNote('');
      setReplyingTo(null);
      fetchNotes();
    } catch (error) {
      console.error('Error creating note:', error);
    } finally {
      setLoading(false);
    }
  };

  const extractMentions = (text: string): string[] => {
    const mentionRegex = /@(\w+)/g;
    const mentions: string[] = [];
    let match;

    while ((match = mentionRegex.exec(text)) !== null) {
      const mentionedUser = groupMembers.find(member => 
        member.name.toLowerCase().includes(match[1].toLowerCase()) ||
        member.email.toLowerCase().includes(match[1].toLowerCase())
      );
      if (mentionedUser) {
        mentions.push(mentionedUser.id);
      }
    }

    return mentions;
  };

  const handleReply = (noteId: string) => {
    setReplyingTo(noteId);
    textareaRef.current?.focus();
  };

  const renderNote = (note: JobNote, isReply = false) => {
    const IconComponent = noteTypeIcons[note.note_type];
    
    return (
      <div key={note.id} className={`${isReply ? 'ml-8 mt-2' : 'mb-4'}`}>
        <Card className="border-l-4 border-l-blue-500">
          <CardContent className="p-4">
            <div className="flex items-start justify-between mb-2">
              <div className="flex items-center space-x-2">
                <Avatar className="h-6 w-6">
                  <AvatarFallback className="text-xs">
                    {note.author_name?.charAt(0) || 'U'}
                  </AvatarFallback>
                </Avatar>
                <span className="text-sm font-medium">{note.author_name}</span>
                <Badge className={`text-xs ${noteTypeColors[note.note_type]}`}>
                  <IconComponent className="h-3 w-3 mr-1" />
                  {note.note_type}
                </Badge>
                {note.visibility === 'private' && (
                  <EyeOff className="h-3 w-3 text-gray-500" />
                )}
              </div>
              <span className="text-xs text-gray-500">
                {new Date(note.created_at).toLocaleString()}
              </span>
            </div>
            
            <p className="text-sm text-gray-700 mb-2">{note.content}</p>
            
            {note.mentions && note.mentions.length > 0 && (
              <div className="flex items-center space-x-1 mb-2">
                <AtSign className="h-3 w-3 text-gray-500" />
                <span className="text-xs text-gray-500">
                  Mentioned: {note.mentions.length} user(s)
                </span>
              </div>
            )}
            
            <Button
              variant="ghost"
              size="sm"
              onClick={() => handleReply(note.id)}
              className="text-xs"
            >
              <Reply className="h-3 w-3 mr-1" />
              Reply
            </Button>
          </CardContent>
        </Card>
        
        {note.replies && note.replies.map(reply => renderNote(reply, true))}
      </div>
    );
  };

  return (
    <div className="space-y-4">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <MessageSquare className="h-5 w-5" />
            <span>Collaborative Notes</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {replyingTo && (
            <div className="bg-blue-50 p-2 rounded text-sm">
              Replying to note...
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setReplyingTo(null)}
                className="ml-2 h-6 px-2"
              >
                Cancel
              </Button>
            </div>
          )}
          
          <div className="space-y-3">
            <Textarea
              ref={textareaRef}
              placeholder="Add a note, feedback, or suggestion... Use @name to mention someone"
              value={newNote}
              onChange={(e) => setNewNote(e.target.value)}
              className="min-h-[80px]"
            />
            
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4">
                <Select value={noteType} onValueChange={(value: any) => setNoteType(value)}>
                  <SelectTrigger className="w-32">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="feedback">Feedback</SelectItem>
                    <SelectItem value="suggestion">Suggestion</SelectItem>
                    <SelectItem value="reminder">Reminder</SelectItem>
                  </SelectContent>
                </Select>
                
                <div className="flex items-center space-x-2">
                  <Switch
                    id="private-note"
                    checked={isPrivate}
                    onCheckedChange={setIsPrivate}
                  />
                  <Label htmlFor="private-note" className="text-sm">
                    Private note
                  </Label>
                </div>
              </div>
              
              <Button
                onClick={handleSubmitNote}
                disabled={!newNote.trim() || loading}
                size="sm"
              >
                <Send className="h-4 w-4 mr-1" />
                {replyingTo ? 'Reply' : 'Add Note'}
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="space-y-4">
        {notes.length === 0 ? (
          <Card>
            <CardContent className="p-8 text-center text-gray-500">
              <MessageSquare className="h-12 w-12 mx-auto mb-4 opacity-50" />
              <p>No notes yet. Be the first to add feedback or suggestions!</p>
            </CardContent>
          </Card>
        ) : (
          notes.map(note => renderNote(note))
        )}
      </div>
    </div>
  );
}