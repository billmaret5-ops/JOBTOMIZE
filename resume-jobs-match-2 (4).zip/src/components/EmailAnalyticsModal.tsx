import React from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { BarChart3, TrendingUp, Mail, MousePointer } from 'lucide-react';

interface EmailAnalyticsModalProps {
  template: any;
  onClose: () => void;
}

export const EmailAnalyticsModal: React.FC<EmailAnalyticsModalProps> = ({ template, onClose }) => {
  const openRate = template.sent > 0 ? Math.round((template.opens / template.sent) * 100) : 0;
  const clickRate = template.opens > 0 ? Math.round((template.clicks / template.opens) * 100) : 0;

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-4xl">
        <DialogHeader>
          <DialogTitle>Analytics: {template.name}</DialogTitle>
        </DialogHeader>
        
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <Card>
            <CardContent className="p-4 text-center">
              <Mail className="w-8 h-8 mx-auto mb-2 text-blue-600" />
              <div className="text-2xl font-bold">{template.sent}</div>
              <div className="text-sm text-gray-600">Sent</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <TrendingUp className="w-8 h-8 mx-auto mb-2 text-green-600" />
              <div className="text-2xl font-bold">{openRate}%</div>
              <div className="text-sm text-gray-600">Open Rate</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <MousePointer className="w-8 h-8 mx-auto mb-2 text-purple-600" />
              <div className="text-2xl font-bold">{clickRate}%</div>
              <div className="text-sm text-gray-600">Click Rate</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="p-4 text-center">
              <BarChart3 className="w-8 h-8 mx-auto mb-2 text-orange-600" />
              <div className="text-2xl font-bold">{template.clicks}</div>
              <div className="text-sm text-gray-600">Total Clicks</div>
            </CardContent>
          </Card>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Performance Over Time</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center bg-gray-50 rounded">
              <div className="text-center text-gray-500">
                <BarChart3 className="w-12 h-12 mx-auto mb-2" />
                <p>Analytics chart would display here</p>
                <p className="text-sm">Showing opens, clicks, and engagement trends</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </DialogContent>
    </Dialog>
  );
};