import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Brain, Sparkles, TrendingUp, Target, Zap } from 'lucide-react';
import AIPersonalizationEngine from './AIPersonalizationEngine';
import SmartVariableSuggestions from './SmartVariableSuggestions';
import CompanyResearchAnalyzer from './CompanyResearchAnalyzer';
import IndustryPersonalizationEngine from './IndustryPersonalizationEngine';

interface PersonalizationMetrics {
  responseRate: number;
  openRate: number;
  interviewRate: number;
  templatesPersonalized: number;
  avgPersonalizationScore: number;
}

export const ComprehensiveAIPersonalizationSystem: React.FC = () => {
  const [metrics] = useState<PersonalizationMetrics>({
    responseRate: 47,
    openRate: 32,
    interviewRate: 28,
    templatesPersonalized: 156,
    avgPersonalizationScore: 87
  });

  const [activeFeatures] = useState([
    { name: 'Job Analysis', status: 'active', improvement: '+47%' },
    { name: 'Company Research', status: 'active', improvement: '+35%' },
    { name: 'Smart Variables', status: 'active', improvement: '+28%' },
    { name: 'Industry Adaptation', status: 'active', improvement: '+41%' },
    { name: 'Tone Optimization', status: 'active', improvement: '+23%' }
  ]);

  return (
    <div className="min-h-screen bg-gray-50 p-6">
      <div className="max-w-7xl mx-auto space-y-6">
        {/* Header */}
        <div className="text-center space-y-4">
          <div className="flex items-center justify-center gap-3">
            <Brain className="h-8 w-8 text-blue-600" />
            <h1 className="text-3xl font-bold text-gray-900">
              AI-Powered Template Personalization System
            </h1>
          </div>
          <p className="text-lg text-gray-600 max-w-3xl mx-auto">
            Automatically customize email templates based on job posting analysis, company research, 
            and recipient data to improve response rates and interview opportunities.
          </p>
        </div>

        {/* Metrics Dashboard */}
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-green-600">+{metrics.responseRate}%</div>
                  <div className="text-sm text-gray-600">Response Rate</div>
                </div>
                <TrendingUp className="h-8 w-8 text-green-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-blue-600">+{metrics.openRate}%</div>
                  <div className="text-sm text-gray-600">Open Rate</div>
                </div>
                <Zap className="h-8 w-8 text-blue-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-purple-600">+{metrics.interviewRate}%</div>
                  <div className="text-sm text-gray-600">Interview Rate</div>
                </div>
                <Target className="h-8 w-8 text-purple-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-orange-600">{metrics.templatesPersonalized}</div>
                  <div className="text-sm text-gray-600">Templates Created</div>
                </div>
                <Sparkles className="h-8 w-8 text-orange-600" />
              </div>
            </CardContent>
          </Card>
          
          <Card>
            <CardContent className="pt-6">
              <div className="flex items-center justify-between">
                <div>
                  <div className="text-2xl font-bold text-indigo-600">{metrics.avgPersonalizationScore}%</div>
                  <div className="text-sm text-gray-600">Avg. Score</div>
                </div>
                <Brain className="h-8 w-8 text-indigo-600" />
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Active Features Status */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Sparkles className="h-5 w-5 text-green-600" />
              AI Personalization Features
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
              {activeFeatures.map((feature, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-green-50 rounded-lg">
                  <div>
                    <div className="font-medium text-sm">{feature.name}</div>
                    <Badge className="mt-1 bg-green-100 text-green-800">
                      {feature.improvement} improvement
                    </Badge>
                  </div>
                  <div className="h-2 w-2 bg-green-500 rounded-full"></div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Main AI Personalization System */}
        <Tabs defaultValue="engine" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="engine">AI Engine</TabsTrigger>
            <TabsTrigger value="variables">Smart Variables</TabsTrigger>
            <TabsTrigger value="research">Company Research</TabsTrigger>
            <TabsTrigger value="industry">Industry Adaptation</TabsTrigger>
          </TabsList>

          <TabsContent value="engine">
            <AIPersonalizationEngine />
          </TabsContent>

          <TabsContent value="variables">
            <SmartVariableSuggestions />
          </TabsContent>

          <TabsContent value="research">
            <CompanyResearchAnalyzer />
          </TabsContent>

          <TabsContent value="industry">
            <IndustryPersonalizationEngine />
          </TabsContent>
        </Tabs>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <Button className="h-20 flex flex-col items-center justify-center gap-2">
                <Brain className="h-6 w-6" />
                <span>Analyze New Job</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-2">
                <Sparkles className="h-6 w-6" />
                <span>Generate Template</span>
              </Button>
              <Button variant="outline" className="h-20 flex flex-col items-center justify-center gap-2">
                <TrendingUp className="h-6 w-6" />
                <span>View Analytics</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default ComprehensiveAIPersonalizationSystem;