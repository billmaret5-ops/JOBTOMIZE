import React, { useState, useEffect } from 'react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { MessageSquare, Check, X } from 'lucide-react';
import { warmupCollaborationService, TemplateComment } from '../services/warmupCollaborationService';

interface CollaborativeCommentsProps {
  templateId: string;
  currentUser: { id: string; name: string };
}

export const CollaborativeComments: React.FC<CollaborativeCommentsProps> = ({ 
  templateId, 
  currentUser 
}) => {
  const [comments, setComments] = useState<TemplateComment[]>([]);
  const [newComment, setNewComment] = useState('');
  const [selectedSection, setSelectedSection] = useState('General');

  useEffect(() => {
    loadComments();
  }, [templateId]);

  const loadComments = () => {
    setComments(warmupCollaborationService.getComments());
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;

    await warmupCollaborationService.addComment({
      userId: currentUser.id,
      userName: currentUser.name,
      section: selectedSection,
      content: newComment,
      position: 0,
      resolved: false
    });

    setNewComment('');
    loadComments();
  };

  return (
    <Card className="mt-4 p-4">
      <div className="flex items-center gap-2 mb-4">
        <MessageSquare className="w-5 h-5" />
        <h3 className="text-lg font-semibold">Comments</h3>
        <Badge>{comments.length}</Badge>
      </div>

      <div className="space-y-4">
        <div>
          <Textarea
            placeholder="Add a comment..."
            value={newComment}
            onChange={(e) => setNewComment(e.target.value)}
            className="mb-2"
          />
          <div className="flex justify-between">
            <select
              value={selectedSection}
              onChange={(e) => setSelectedSection(e.target.value)}
              className="px-3 py-1 border rounded"
            >
              <option>General</option>
              <option>Volume Schedule</option>
              <option>Settings</option>
            </select>
            <Button onClick={handleAddComment} size="sm">Post Comment</Button>
          </div>
        </div>

        <div className="space-y-3">
          {comments.map((comment) => (
            <div key={comment.id} className="border rounded p-3">
              <div className="flex items-start justify-between mb-2">
                <div>
                  <span className="font-semibold text-sm">{comment.userName}</span>
                  <Badge variant="outline" className="ml-2">{comment.section}</Badge>
                </div>
                <div className="flex gap-1">
                  {!comment.resolved && (
                    <Button size="sm" variant="ghost">
                      <Check className="w-4 h-4" />
                    </Button>
                  )}
                </div>
              </div>
              <p className="text-sm text-gray-700">{comment.content}</p>
              <p className="text-xs text-gray-500 mt-2">
                {new Date(comment.createdAt).toLocaleString()}
              </p>
            </div>
          ))}
        </div>
      </div>
    </Card>
  );
};
