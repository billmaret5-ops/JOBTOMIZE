import React from 'react';
import { Alert, AlertDescription, AlertTitle } from '@/components/ui/alert';
import { Button } from '@/components/ui/button';
import { AlertTriangle } from 'lucide-react';
import { Conflict } from '@/lib/conflictResolution';

interface ConflictIndicatorProps {
  conflicts: Conflict[];
  onResolveClick: (conflict: Conflict) => void;
}

export function ConflictIndicator({ conflicts, onResolveClick }: ConflictIndicatorProps) {
  if (conflicts.length === 0) return null;

  return (
    <Alert variant="destructive" className="mb-4">
      <AlertTriangle className="h-4 w-4" />
      <AlertTitle>Editing Conflicts Detected</AlertTitle>
      <AlertDescription>
        <p className="mb-2">
          {conflicts.length} conflict{conflicts.length > 1 ? 's' : ''} detected. 
          Please resolve to continue editing.
        </p>
        <div className="space-y-2">
          {conflicts.map((conflict) => (
            <div key={conflict.id} className="flex items-center justify-between bg-white p-2 rounded">
              <span className="text-sm text-gray-900">
                Field: <strong>{conflict.field}</strong>
              </span>
              <Button
                size="sm"
                variant="outline"
                onClick={() => onResolveClick(conflict)}
              >
                Resolve
              </Button>
            </div>
          ))}
        </div>
      </AlertDescription>
    </Alert>
  );
}
