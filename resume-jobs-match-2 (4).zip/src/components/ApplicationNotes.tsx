import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Save, 
  X, 
  MessageSquare,
  Calendar,
  User,
  Phone,
  Mail
} from 'lucide-react';
import { toast } from 'sonner';

interface Note {
  id: string;
  content: string;
  type: 'general' | 'interview' | 'follow-up' | 'research';
  created_at: string;
  updated_at: string;
}

interface ApplicationNotesProps {
  applicationId: string;
  notes: Note[];
  onNotesUpdate: (notes: Note[]) => void;
}

export function ApplicationNotes({ applicationId, notes, onNotesUpdate }: ApplicationNotesProps) {
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [newNote, setNewNote] = useState({ content: '', type: 'general' as Note['type'] });
  const [editContent, setEditContent] = useState('');

  const noteTypes = [
    { value: 'general', label: 'General', color: 'bg-gray-100 text-gray-800' },
    { value: 'interview', label: 'Interview', color: 'bg-blue-100 text-blue-800' },
    { value: 'follow-up', label: 'Follow-up', color: 'bg-yellow-100 text-yellow-800' },
    { value: 'research', label: 'Research', color: 'bg-green-100 text-green-800' }
  ];

  const handleAddNote = () => {
    if (!newNote.content.trim()) return;

    const note: Note = {
      id: Date.now().toString(),
      content: newNote.content,
      type: newNote.type,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString()
    };

    onNotesUpdate([...notes, note]);
    setNewNote({ content: '', type: 'general' });
    setIsAdding(false);
    toast.success('Note added successfully');
  };

  const handleEditNote = (id: string) => {
    const note = notes.find(n => n.id === id);
    if (note) {
      setEditingId(id);
      setEditContent(note.content);
    }
  };

  const handleSaveEdit = (id: string) => {
    if (!editContent.trim()) return;

    const updatedNotes = notes.map(note => 
      note.id === id 
        ? { ...note, content: editContent, updated_at: new Date().toISOString() }
        : note
    );

    onNotesUpdate(updatedNotes);
    setEditingId(null);
    setEditContent('');
    toast.success('Note updated successfully');
  };

  const handleDeleteNote = (id: string) => {
    const updatedNotes = notes.filter(note => note.id !== id);
    onNotesUpdate(updatedNotes);
    toast.success('Note deleted successfully');
  };

  const getTypeColor = (type: string) => {
    return noteTypes.find(t => t.value === type)?.color || 'bg-gray-100 text-gray-800';
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case 'interview': return <User className="w-3 h-3" />;
      case 'follow-up': return <Phone className="w-3 h-3" />;
      case 'research': return <Mail className="w-3 h-3" />;
      default: return <MessageSquare className="w-3 h-3" />;
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <MessageSquare className="w-5 h-5" />
            Notes ({notes.length})
          </div>
          <Button 
            size="sm" 
            onClick={() => setIsAdding(true)}
            disabled={isAdding}
          >
            <Plus className="w-4 h-4 mr-1" />
            Add Note
          </Button>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Add Note Form */}
        {isAdding && (
          <div className="p-4 border rounded-lg bg-gray-50">
            <div className="space-y-3">
              <div className="flex gap-2">
                {noteTypes.map(type => (
                  <Button
                    key={type.value}
                    size="sm"
                    variant={newNote.type === type.value ? "default" : "outline"}
                    onClick={() => setNewNote({ ...newNote, type: type.value as Note['type'] })}
                  >
                    {type.label}
                  </Button>
                ))}
              </div>
              <Textarea
                placeholder="Add your note here..."
                value={newNote.content}
                onChange={(e) => setNewNote({ ...newNote, content: e.target.value })}
                rows={3}
              />
              <div className="flex gap-2">
                <Button size="sm" onClick={handleAddNote}>
                  <Save className="w-4 h-4 mr-1" />
                  Save
                </Button>
                <Button 
                  size="sm" 
                  variant="outline" 
                  onClick={() => {
                    setIsAdding(false);
                    setNewNote({ content: '', type: 'general' });
                  }}
                >
                  <X className="w-4 h-4 mr-1" />
                  Cancel
                </Button>
              </div>
            </div>
          </div>
        )}

        {/* Notes List */}
        <div className="space-y-3">
          {notes.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
              <p>No notes yet</p>
              <p className="text-sm">Add notes to track your progress and thoughts</p>
            </div>
          ) : (
            notes.map((note) => (
              <div key={note.id} className="p-4 border rounded-lg hover:bg-gray-50 transition-colors">
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Badge className={getTypeColor(note.type)}>
                      {getTypeIcon(note.type)}
                      {noteTypes.find(t => t.value === note.type)?.label}
                    </Badge>
                    <div className="flex items-center gap-1 text-xs text-gray-500">
                      <Calendar className="w-3 h-3" />
                      {new Date(note.created_at).toLocaleDateString()}
                    </div>
                  </div>
                  <div className="flex gap-1">
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleEditNote(note.id)}
                      disabled={editingId === note.id}
                    >
                      <Edit className="w-3 h-3" />
                    </Button>
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleDeleteNote(note.id)}
                      className="text-red-600 hover:text-red-700"
                    >
                      <Trash2 className="w-3 h-3" />
                    </Button>
                  </div>
                </div>

                {editingId === note.id ? (
                  <div className="space-y-2">
                    <Textarea
                      value={editContent}
                      onChange={(e) => setEditContent(e.target.value)}
                      rows={3}
                    />
                    <div className="flex gap-2">
                      <Button size="sm" onClick={() => handleSaveEdit(note.id)}>
                        <Save className="w-4 h-4 mr-1" />
                        Save
                      </Button>
                      <Button 
                        size="sm" 
                        variant="outline" 
                        onClick={() => {
                          setEditingId(null);
                          setEditContent('');
                        }}
                      >
                        <X className="w-4 h-4 mr-1" />
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <p className="text-sm text-gray-700 whitespace-pre-wrap">{note.content}</p>
                )}

                {note.updated_at !== note.created_at && (
                  <p className="text-xs text-gray-400 mt-2">
                    Updated {new Date(note.updated_at).toLocaleDateString()}
                  </p>
                )}
              </div>
            ))
          )}
        </div>
      </CardContent>
    </Card>
  );
}