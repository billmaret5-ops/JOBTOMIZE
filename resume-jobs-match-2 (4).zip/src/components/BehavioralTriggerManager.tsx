import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';
import { behavioralTrackingService, TriggerRule } from '../services/behavioralTrackingService';
import { webhookHandlerService, WebhookEndpoint } from '../services/webhookHandlerService';

interface BehavioralTriggerManagerProps {
  workflowId?: string;
  onTriggerCreated?: (triggerId: string) => void;
}

export const BehavioralTriggerManager: React.FC<BehavioralTriggerManagerProps> = ({
  workflowId,
  onTriggerCreated
}) => {
  const [triggers, setTriggers] = useState<TriggerRule[]>([]);
  const [webhooks, setWebhooks] = useState<WebhookEndpoint[]>([]);
  const [loading, setLoading] = useState(false);
  
  // Trigger form state
  const [triggerForm, setTriggerForm] = useState({
    name: '',
    event_type: '',
    conditions: {},
    time_delay: 0,
    is_active: true
  });

  // Webhook form state
  const [webhookForm, setWebhookForm] = useState({
    name: '',
    url: '',
    event_types: [] as string[],
    is_active: true
  });

  useEffect(() => {
    loadTriggers();
    loadWebhooks();
  }, [workflowId]);

  const loadTriggers = async () => {
    setLoading(true);
    try {
      const data = await behavioralTrackingService.getTriggerRules(workflowId);
      setTriggers(data);
    } catch (error) {
      console.error('Error loading triggers:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadWebhooks = async () => {
    try {
      const data = await webhookHandlerService.getWebhookEndpoints();
      setWebhooks(data);
    } catch (error) {
      console.error('Error loading webhooks:', error);
    }
  };

  const handleCreateTrigger = async () => {
    if (!workflowId) return;

    setLoading(true);
    try {
      const triggerId = await behavioralTrackingService.createTriggerRule({
        ...triggerForm,
        workflow_id: workflowId
      });
      
      onTriggerCreated?.(triggerId);
      await loadTriggers();
      
      // Reset form
      setTriggerForm({
        name: '',
        event_type: '',
        conditions: {},
        time_delay: 0,
        is_active: true
      });
    } catch (error) {
      console.error('Error creating trigger:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleCreateWebhook = async () => {
    setLoading(true);
    try {
      await webhookHandlerService.createWebhookEndpoint(webhookForm);
      await loadWebhooks();
      
      // Reset form
      setWebhookForm({
        name: '',
        url: '',
        event_types: [],
        is_active: true
      });
    } catch (error) {
      console.error('Error creating webhook:', error);
    } finally {
      setLoading(false);
    }
  };

  const eventTypes = [
    { value: 'page_visit', label: 'Page Visit' },
    { value: 'purchase', label: 'Purchase' },
    { value: 'cart_abandon', label: 'Cart Abandonment' },
    { value: 'email_open', label: 'Email Open' },
    { value: 'email_click', label: 'Email Click' },
    { value: 'form_submit', label: 'Form Submit' },
    { value: 'custom', label: 'Custom Event' }
  ];

  const webhookEventTypes = [
    'purchase.completed',
    'cart.abandoned',
    'user.signup',
    'subscription.created',
    'user.login',
    'product.viewed'
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Behavioral Triggers</h2>
        <Badge variant="secondary">{triggers.length} Active Triggers</Badge>
      </div>

      <Tabs defaultValue="triggers" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="triggers">Behavioral Triggers</TabsTrigger>
          <TabsTrigger value="webhooks">Webhook Integration</TabsTrigger>
          <TabsTrigger value="analytics">Performance Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="triggers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Create Behavioral Trigger</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="trigger-name">Trigger Name</Label>
                  <Input
                    id="trigger-name"
                    value={triggerForm.name}
                    onChange={(e) => setTriggerForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Cart Abandonment Follow-up"
                  />
                </div>
                <div>
                  <Label htmlFor="event-type">Event Type</Label>
                  <Select
                    value={triggerForm.event_type}
                    onValueChange={(value) => setTriggerForm(prev => ({ ...prev, event_type: value }))}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select event type" />
                    </SelectTrigger>
                    <SelectContent>
                      {eventTypes.map(type => (
                        <SelectItem key={type.value} value={type.value}>
                          {type.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="time-delay">Time Delay (minutes)</Label>
                  <Input
                    id="time-delay"
                    type="number"
                    value={triggerForm.time_delay}
                    onChange={(e) => setTriggerForm(prev => ({ ...prev, time_delay: parseInt(e.target.value) || 0 }))}
                    placeholder="0"
                  />
                </div>
                <div className="flex items-center space-x-2">
                  <Switch
                    checked={triggerForm.is_active}
                    onCheckedChange={(checked) => setTriggerForm(prev => ({ ...prev, is_active: checked }))}
                  />
                  <Label>Active</Label>
                </div>
              </div>

              <Button onClick={handleCreateTrigger} disabled={loading || !triggerForm.name || !triggerForm.event_type}>
                Create Trigger
              </Button>
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {triggers.map(trigger => (
              <Card key={trigger.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{trigger.name}</h3>
                      <p className="text-sm text-muted-foreground">
                        Event: {eventTypes.find(t => t.value === trigger.event_type)?.label}
                        {trigger.time_delay > 0 && ` • Delay: ${trigger.time_delay}m`}
                      </p>
                    </div>
                    <Badge variant={trigger.is_active ? 'default' : 'secondary'}>
                      {trigger.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Create Webhook Endpoint</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="webhook-name">Webhook Name</Label>
                  <Input
                    id="webhook-name"
                    value={webhookForm.name}
                    onChange={(e) => setWebhookForm(prev => ({ ...prev, name: e.target.value }))}
                    placeholder="e.g., Shopify Integration"
                  />
                </div>
                <div>
                  <Label htmlFor="webhook-url">Endpoint URL</Label>
                  <Input
                    id="webhook-url"
                    value={webhookForm.url}
                    onChange={(e) => setWebhookForm(prev => ({ ...prev, url: e.target.value }))}
                    placeholder="https://your-app.com/webhook"
                  />
                </div>
              </div>

              <div>
                <Label>Event Types</Label>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {webhookEventTypes.map(eventType => (
                    <label key={eventType} className="flex items-center space-x-2">
                      <input
                        type="checkbox"
                        checked={webhookForm.event_types.includes(eventType)}
                        onChange={(e) => {
                          if (e.target.checked) {
                            setWebhookForm(prev => ({
                              ...prev,
                              event_types: [...prev.event_types, eventType]
                            }));
                          } else {
                            setWebhookForm(prev => ({
                              ...prev,
                              event_types: prev.event_types.filter(t => t !== eventType)
                            }));
                          }
                        }}
                      />
                      <span className="text-sm">{eventType}</span>
                    </label>
                  ))}
                </div>
              </div>

              <Button onClick={handleCreateWebhook} disabled={loading || !webhookForm.name || !webhookForm.url}>
                Create Webhook
              </Button>
            </CardContent>
          </Card>

          <div className="grid gap-4">
            {webhooks.map(webhook => (
              <Card key={webhook.id}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <h3 className="font-semibold">{webhook.name}</h3>
                      <p className="text-sm text-muted-foreground">{webhook.url}</p>
                      <div className="flex flex-wrap gap-1 mt-2">
                        {webhook.event_types.map(type => (
                          <Badge key={type} variant="outline" className="text-xs">
                            {type}
                          </Badge>
                        ))}
                      </div>
                    </div>
                    <Badge variant={webhook.is_active ? 'default' : 'secondary'}>
                      {webhook.is_active ? 'Active' : 'Inactive'}
                    </Badge>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Trigger Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <p>Analytics dashboard will show trigger execution rates, conversion metrics, and performance insights.</p>
                <p className="mt-2">Select a specific trigger to view detailed analytics.</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};