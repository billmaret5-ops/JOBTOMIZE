import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Search, Filter, Download, Eye, Edit, Trash, Mail, User, Shield } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface ActivityLog {
  id: string;
  action: string;
  resource_type: string;
  resource_id?: string;
  details: any;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

interface ActivityHistoryProps {
  userId: string;
}

export const ActivityHistory: React.FC<ActivityHistoryProps> = ({ userId }) => {
  const [activities, setActivities] = useState<ActivityLog[]>([]);
  const [filteredActivities, setFilteredActivities] = useState<ActivityLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState('all');
  const [dateRange, setDateRange] = useState('30');

  useEffect(() => {
    loadActivityHistory();
  }, [userId, dateRange]);

  useEffect(() => {
    filterActivities();
  }, [activities, searchTerm, filterType]);

  const loadActivityHistory = async () => {
    try {
      const startDate = new Date();
      startDate.setDate(startDate.getDate() - parseInt(dateRange));

      const { data, error } = await supabase
        .from('audit_logs')
        .select('*')
        .eq('user_id', userId)
        .gte('created_at', startDate.toISOString())
        .order('created_at', { ascending: false })
        .limit(100);

      if (error) throw error;
      setActivities(data || []);
    } catch (error) {
      console.error('Error loading activity history:', error);
    } finally {
      setLoading(false);
    }
  };

  const filterActivities = () => {
    let filtered = activities;

    if (searchTerm) {
      filtered = filtered.filter(activity =>
        activity.action.toLowerCase().includes(searchTerm.toLowerCase()) ||
        activity.resource_type.toLowerCase().includes(searchTerm.toLowerCase()) ||
        JSON.stringify(activity.details).toLowerCase().includes(searchTerm.toLowerCase())
      );
    }

    if (filterType !== 'all') {
      filtered = filtered.filter(activity => activity.resource_type === filterType);
    }

    setFilteredActivities(filtered);
  };

  const getActionIcon = (action: string, resourceType: string) => {
    if (action.includes('login') || action.includes('auth')) {
      return <Shield className="h-4 w-4" />;
    }
    if (action.includes('view') || action.includes('read')) {
      return <Eye className="h-4 w-4" />;
    }
    if (action.includes('create') || action.includes('add')) {
      return <Edit className="h-4 w-4" />;
    }
    if (action.includes('delete') || action.includes('remove')) {
      return <Trash className="h-4 w-4" />;
    }
    if (resourceType === 'email' || resourceType === 'campaign') {
      return <Mail className="h-4 w-4" />;
    }
    return <User className="h-4 w-4" />;
  };

  const getActionColor = (action: string) => {
    if (action.includes('delete') || action.includes('remove')) {
      return 'destructive';
    }
    if (action.includes('create') || action.includes('add')) {
      return 'default';
    }
    if (action.includes('login') || action.includes('auth')) {
      return 'secondary';
    }
    return 'outline';
  };

  const formatTimestamp = (timestamp: string) => {
    return new Date(timestamp).toLocaleString();
  };

  const exportHistory = async () => {
    try {
      const csv = [
        ['Timestamp', 'Action', 'Resource Type', 'Details', 'IP Address'].join(','),
        ...filteredActivities.map(activity => [
          formatTimestamp(activity.created_at),
          activity.action,
          activity.resource_type,
          JSON.stringify(activity.details).replace(/,/g, ';'),
          activity.ip_address || 'N/A'
        ].join(','))
      ].join('\n');

      const blob = new Blob([csv], { type: 'text/csv' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `activity-history-${new Date().toISOString().split('T')[0]}.csv`;
      a.click();
      window.URL.revokeObjectURL(url);
    } catch (error) {
      console.error('Error exporting history:', error);
    }
  };

  if (loading) {
    return <div>Loading activity history...</div>;
  }

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle>Account Activity</CardTitle>
          <Button variant="outline" size="sm" onClick={exportHistory}>
            <Download className="h-4 w-4 mr-2" />
            Export
          </Button>
        </div>
      </CardHeader>
      <CardContent className="space-y-4">
        <div className="flex flex-col sm:flex-row gap-4">
          <div className="flex-1">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search activities..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
          </div>
          
          <Select value={filterType} onValueChange={setFilterType}>
            <SelectTrigger className="w-40">
              <Filter className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Types</SelectItem>
              <SelectItem value="auth">Authentication</SelectItem>
              <SelectItem value="profile">Profile</SelectItem>
              <SelectItem value="email">Email</SelectItem>
              <SelectItem value="campaign">Campaigns</SelectItem>
              <SelectItem value="template">Templates</SelectItem>
            </SelectContent>
          </Select>

          <Select value={dateRange} onValueChange={setDateRange}>
            <SelectTrigger className="w-32">
              <Calendar className="h-4 w-4 mr-2" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="7">Last 7 days</SelectItem>
              <SelectItem value="30">Last 30 days</SelectItem>
              <SelectItem value="90">Last 90 days</SelectItem>
              <SelectItem value="365">Last year</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <div className="space-y-3">
          {filteredActivities.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">
              No activities found for the selected criteria.
            </div>
          ) : (
            filteredActivities.map((activity) => (
              <div key={activity.id} className="flex items-start space-x-3 p-3 border rounded-lg">
                <div className="flex-shrink-0 mt-0.5">
                  {getActionIcon(activity.action, activity.resource_type)}
                </div>
                
                <div className="flex-1 min-w-0">
                  <div className="flex items-center space-x-2 mb-1">
                    <Badge variant={getActionColor(activity.action) as any}>
                      {activity.action}
                    </Badge>
                    <span className="text-sm text-muted-foreground">
                      {activity.resource_type}
                    </span>
                  </div>
                  
                  <p className="text-sm">
                    {activity.details?.description || 
                     `${activity.action} on ${activity.resource_type}`}
                  </p>
                  
                  <div className="flex items-center space-x-4 mt-2 text-xs text-muted-foreground">
                    <span>{formatTimestamp(activity.created_at)}</span>
                    {activity.ip_address && (
                      <span>IP: {activity.ip_address}</span>
                    )}
                    {activity.details?.location && (
                      <span>{activity.details.location}</span>
                    )}
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {filteredActivities.length > 0 && (
          <div className="text-center text-sm text-muted-foreground">
            Showing {filteredActivities.length} of {activities.length} activities
          </div>
        )}
      </CardContent>
    </Card>
  );
};