import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ChartContainer, ChartTooltip, ChartTooltipContent } from '@/components/ui/chart';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, ResponsiveContainer } from 'recharts';
import { TrendingUp, Clock, DollarSign, Target, Building, Calendar } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface AnalyticsData {
  applicationTrends: Array<{ month: string; applications: number; interviews: number; offers: number }>;
  conversionRates: Array<{ status: string; count: number; percentage: number }>;
  responseTimesByCompany: Array<{ company: string; avgDays: number; applications: number }>;
  salaryAnalysis: Array<{ range: string; count: number; avgSalary: number }>;
  industryBreakdown: Array<{ industry: string; applications: number; successRate: number }>;
  insights: string[];
}

const COLORS = ['#3b82f6', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6', '#06b6d4'];

export function ApplicationAnalytics() {
  const { user } = useAuth();
  const [data, setData] = useState<AnalyticsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      fetchAnalytics();
    }
  }, [user]);

  const fetchAnalytics = async () => {
    try {
      const { data: applications, error } = await supabase
        .from('job_applications')
        .select('*')
        .eq('user_id', user?.id)
        .order('created_at', { ascending: false });

      if (error) throw error;
      if (!applications?.length) {
        setData(null);
        setLoading(false);
        return;
      }

      // Process analytics data
      const analytics = processAnalyticsData(applications);
      setData(analytics);
    } catch (error) {
      console.error('Error fetching analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const processAnalyticsData = (applications: any[]): AnalyticsData => {
    // Application trends by month
    const monthlyData = applications.reduce((acc, app) => {
      const month = new Date(app.created_at).toLocaleDateString('en-US', { month: 'short', year: '2-digit' });
      if (!acc[month]) acc[month] = { applications: 0, interviews: 0, offers: 0 };
      acc[month].applications++;
      if (app.status === 'interviewing') acc[month].interviews++;
      if (app.status === 'offer') acc[month].offers++;
      return acc;
    }, {} as Record<string, any>);

    const applicationTrends = Object.entries(monthlyData).map(([month, data]) => ({ month, ...data }));

    // Conversion rates
    const statusCounts = applications.reduce((acc, app) => {
      acc[app.status] = (acc[app.status] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    const total = applications.length;
    const conversionRates = Object.entries(statusCounts).map(([status, count]) => ({
      status: status.charAt(0).toUpperCase() + status.slice(1),
      count,
      percentage: Math.round((count / total) * 100)
    }));

    // Response times by company
    const companyData = applications.reduce((acc, app) => {
      if (!acc[app.company]) acc[app.company] = { applications: 0, totalDays: 0 };
      acc[app.company].applications++;
      if (app.last_activity_date) {
        const daysDiff = Math.floor((new Date(app.last_activity_date).getTime() - new Date(app.created_at).getTime()) / (1000 * 60 * 60 * 24));
        acc[app.company].totalDays += daysDiff;
      }
      return acc;
    }, {} as Record<string, any>);

    const responseTimesByCompany = Object.entries(companyData)
      .map(([company, data]) => ({
        company,
        avgDays: Math.round(data.totalDays / data.applications) || 0,
        applications: data.applications
      }))
      .slice(0, 10);

    // Salary analysis
    const salaryRanges = applications.filter(app => app.salary_min && app.salary_max);
    const salaryData = salaryRanges.reduce((acc, app) => {
      const avg = (app.salary_min + app.salary_max) / 2;
      let range = '';
      if (avg < 60000) range = '$40K-$60K';
      else if (avg < 80000) range = '$60K-$80K';
      else if (avg < 100000) range = '$80K-$100K';
      else if (avg < 120000) range = '$100K-$120K';
      else range = '$120K+';
      
      if (!acc[range]) acc[range] = { count: 0, total: 0 };
      acc[range].count++;
      acc[range].total += avg;
      return acc;
    }, {} as Record<string, any>);

    const salaryAnalysis = Object.entries(salaryData).map(([range, data]) => ({
      range,
      count: data.count,
      avgSalary: Math.round(data.total / data.count)
    }));

    // Industry breakdown
    const industryData = applications.reduce((acc, app) => {
      const industry = app.industry || 'Other';
      if (!acc[industry]) acc[industry] = { applications: 0, offers: 0 };
      acc[industry].applications++;
      if (app.status === 'offer') acc[industry].offers++;
      return acc;
    }, {} as Record<string, any>);

    const industryBreakdown = Object.entries(industryData).map(([industry, data]) => ({
      industry,
      applications: data.applications,
      successRate: Math.round((data.offers / data.applications) * 100) || 0
    }));

    // Generate insights
    const insights = generateInsights(applications, conversionRates, responseTimesByCompany);

    return {
      applicationTrends,
      conversionRates,
      responseTimesByCompany,
      salaryAnalysis,
      industryBreakdown,
      insights
    };
  };

  const generateInsights = (applications: any[], conversionRates: any[], responseData: any[]): string[] => {
    const insights = [];
    
    const interviewRate = conversionRates.find(c => c.status === 'Interviewing')?.percentage || 0;
    if (interviewRate > 20) {
      insights.push(`Strong interview rate of ${interviewRate}% - your applications are getting noticed!`);
    } else if (interviewRate < 10) {
      insights.push('Consider optimizing your resume and cover letters to improve interview rates.');
    }

    const avgResponseTime = responseData.reduce((sum, c) => sum + c.avgDays, 0) / responseData.length || 0;
    if (avgResponseTime > 14) {
      insights.push('Companies are taking longer to respond - consider following up after 2 weeks.');
    }

    const recentApps = applications.filter(app => {
      const daysSince = (Date.now() - new Date(app.created_at).getTime()) / (1000 * 60 * 60 * 24);
      return daysSince <= 30;
    }).length;
    
    if (recentApps < 5) {
      insights.push('Increase your application volume - aim for 5-10 applications per week.');
    }

    return insights;
  };

  if (loading) {
    return <div className="text-center py-8">Loading analytics...</div>;
  }

  if (!data) {
    return (
      <Card>
        <CardContent className="text-center py-8">
          <Target className="h-12 w-12 mx-auto mb-4 text-gray-400" />
          <p className="text-gray-500">Apply to jobs to see analytics</p>
        </CardContent>
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Application Analytics</h2>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Target className="h-5 w-5 text-blue-500" />
              <div>
                <p className="text-sm text-gray-600">Success Rate</p>
                <p className="text-2xl font-bold">
                  {data.conversionRates.find(c => c.status === 'Offer')?.percentage || 0}%
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Clock className="h-5 w-5 text-green-500" />
              <div>
                <p className="text-sm text-gray-600">Avg Response</p>
                <p className="text-2xl font-bold">
                  {Math.round(data.responseTimesByCompany.reduce((sum, c) => sum + c.avgDays, 0) / data.responseTimesByCompany.length) || 0}d
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <DollarSign className="h-5 w-5 text-purple-500" />
              <div>
                <p className="text-sm text-gray-600">Avg Salary</p>
                <p className="text-2xl font-bold">
                  ${Math.round(data.salaryAnalysis.reduce((sum, s) => sum + s.avgSalary, 0) / data.salaryAnalysis.length / 1000) || 0}K
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center gap-2">
              <Building className="h-5 w-5 text-orange-500" />
              <div>
                <p className="text-sm text-gray-600">Companies</p>
                <p className="text-2xl font-bold">{data.responseTimesByCompany.length}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Application Trends */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <TrendingUp className="h-5 w-5" />
              Application Trends
            </CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{
              applications: { label: 'Applications', color: '#3b82f6' },
              interviews: { label: 'Interviews', color: '#10b981' },
              offers: { label: 'Offers', color: '#f59e0b' }
            }}>
              <LineChart data={data.applicationTrends}>
                <XAxis dataKey="month" />
                <YAxis />
                <ChartTooltip content={<ChartTooltipContent />} />
                <Line type="monotone" dataKey="applications" stroke="#3b82f6" strokeWidth={2} />
                <Line type="monotone" dataKey="interviews" stroke="#10b981" strokeWidth={2} />
                <Line type="monotone" dataKey="offers" stroke="#f59e0b" strokeWidth={2} />
              </LineChart>
            </ChartContainer>
          </CardContent>
        </Card>

        {/* Status Distribution */}
        <Card>
          <CardHeader>
            <CardTitle>Status Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ChartContainer config={{}}>
              <PieChart>
                <Pie
                  data={data.conversionRates}
                  cx="50%"
                  cy="50%"
                  outerRadius={80}
                  dataKey="count"
                  label={({ status, percentage }) => `${status}: ${percentage}%`}
                >
                  {data.conversionRates.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <ChartTooltip content={<ChartTooltipContent />} />
              </PieChart>
            </ChartContainer>
          </CardContent>
        </Card>
      </div>

      {/* Insights */}
      <Card>
        <CardHeader>
          <CardTitle>Personalized Insights</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2">
            {data.insights.map((insight, index) => (
              <li key={index} className="flex items-start gap-2">
                <span className="text-blue-500 mt-1">•</span>
                <span className="text-sm">{insight}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}