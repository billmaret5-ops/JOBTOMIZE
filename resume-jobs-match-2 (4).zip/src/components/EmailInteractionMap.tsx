import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { MapPin, Globe, Users, TrendingUp } from 'lucide-react';

interface LocationData {
  city: string;
  country: string;
  latitude: number;
  longitude: number;
  interactions: number;
  lastInteraction: Date;
  types: {
    opens: number;
    clicks: number;
    responses: number;
  };
}

const EmailInteractionMap: React.FC = () => {
  const [locationData, setLocationData] = useState<LocationData[]>([
    {
      city: 'New York',
      country: 'USA',
      latitude: 40.7128,
      longitude: -74.0060,
      interactions: 15,
      lastInteraction: new Date(),
      types: { opens: 8, clicks: 5, responses: 2 }
    },
    {
      city: 'San Francisco',
      country: 'USA',
      latitude: 37.7749,
      longitude: -122.4194,
      interactions: 12,
      lastInteraction: new Date(Date.now() - 300000),
      types: { opens: 7, clicks: 4, responses: 1 }
    },
    {
      city: 'London',
      country: 'UK',
      latitude: 51.5074,
      longitude: -0.1278,
      interactions: 9,
      lastInteraction: new Date(Date.now() - 600000),
      types: { opens: 5, clicks: 3, responses: 1 }
    },
    {
      city: 'Toronto',
      country: 'Canada',
      latitude: 43.6532,
      longitude: -79.3832,
      interactions: 7,
      lastInteraction: new Date(Date.now() - 900000),
      types: { opens: 4, clicks: 2, responses: 1 }
    },
    {
      city: 'Sydney',
      country: 'Australia',
      latitude: -33.8688,
      longitude: 151.2093,
      interactions: 5,
      lastInteraction: new Date(Date.now() - 1200000),
      types: { opens: 3, clicks: 2, responses: 0 }
    }
  ]);

  const [selectedLocation, setSelectedLocation] = useState<LocationData | null>(null);

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setLocationData(prev => 
        prev.map(location => {
          if (Math.random() < 0.3) {
            const newInteractionType = Math.random();
            const updatedTypes = { ...location.types };
            
            if (newInteractionType < 0.6) {
              updatedTypes.opens += 1;
            } else if (newInteractionType < 0.85) {
              updatedTypes.clicks += 1;
            } else {
              updatedTypes.responses += 1;
            }

            return {
              ...location,
              interactions: location.interactions + 1,
              lastInteraction: new Date(),
              types: updatedTypes
            };
          }
          return location;
        })
      );
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const totalInteractions = locationData.reduce((sum, loc) => sum + loc.interactions, 0);
  const totalCountries = new Set(locationData.map(loc => loc.country)).size;

  const getInteractionIntensity = (interactions: number) => {
    const maxInteractions = Math.max(...locationData.map(loc => loc.interactions));
    return (interactions / maxInteractions) * 100;
  };

  const getTimeAgo = (date: Date) => {
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / 60000);
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return `${Math.floor(diffInMinutes / 60)}h ago`;
    return `${Math.floor(diffInMinutes / 1440)}d ago`;
  };

  return (
    <div className="space-y-6">
      {/* Geographic Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Locations</p>
                <p className="text-2xl font-bold">{locationData.length}</p>
                <p className="text-xs text-blue-600">Active cities</p>
              </div>
              <MapPin className="h-8 w-8 text-blue-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Countries</p>
                <p className="text-2xl font-bold">{totalCountries}</p>
                <p className="text-xs text-green-600">Global reach</p>
              </div>
              <Globe className="h-8 w-8 text-green-500" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-gray-600">Total Interactions</p>
                <p className="text-2xl font-bold">{totalInteractions}</p>
                <p className="text-xs text-purple-600">All locations</p>
              </div>
              <Users className="h-8 w-8 text-purple-500" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Interactive Map Visualization */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Globe className="h-5 w-5" />
            Geographic Email Interaction Map
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="relative bg-gradient-to-br from-blue-50 to-indigo-100 rounded-lg p-8 min-h-96">
            {/* World Map Background (Simplified) */}
            <div className="absolute inset-0 opacity-10">
              <svg viewBox="0 0 800 400" className="w-full h-full">
                <path d="M100,100 L200,80 L300,120 L400,100 L500,90 L600,110 L700,100" 
                      stroke="currentColor" strokeWidth="2" fill="none" />
                <path d="M150,200 L250,180 L350,220 L450,200 L550,190 L650,210" 
                      stroke="currentColor" strokeWidth="2" fill="none" />
              </svg>
            </div>

            {/* Location Markers */}
            {locationData.map((location, index) => {
              const x = ((location.longitude + 180) / 360) * 100;
              const y = ((90 - location.latitude) / 180) * 100;
              const intensity = getInteractionIntensity(location.interactions);

              return (
                <div
                  key={index}
                  className="absolute transform -translate-x-1/2 -translate-y-1/2 cursor-pointer"
                  style={{ left: `${x}%`, top: `${y}%` }}
                  onClick={() => setSelectedLocation(location)}
                >
                  <div 
                    className="relative animate-pulse"
                    style={{
                      width: `${Math.max(20, intensity * 0.5)}px`,
                      height: `${Math.max(20, intensity * 0.5)}px`
                    }}
                  >
                    <div className="absolute inset-0 bg-blue-500 rounded-full opacity-30 animate-ping"></div>
                    <div className="relative w-full h-full bg-blue-600 rounded-full border-2 border-white shadow-lg flex items-center justify-center">
                      <span className="text-white text-xs font-bold">
                        {location.interactions}
                      </span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Location Details */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Location List */}
        <Card>
          <CardHeader>
            <CardTitle>Top Locations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {locationData
                .sort((a, b) => b.interactions - a.interactions)
                .map((location, index) => (
                  <div 
                    key={index} 
                    className={`flex items-center justify-between p-3 rounded-lg cursor-pointer transition-colors ${
                      selectedLocation?.city === location.city ? 'bg-blue-50 border border-blue-200' : 'hover:bg-gray-50'
                    }`}
                    onClick={() => setSelectedLocation(location)}
                  >
                    <div className="flex items-center gap-3">
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4 text-gray-500" />
                        <span className="font-medium">{location.city}</span>
                        <span className="text-gray-500">{location.country}</span>
                      </div>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant="secondary">{location.interactions}</Badge>
                      <span className="text-xs text-gray-500">
                        {getTimeAgo(location.lastInteraction)}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>

        {/* Selected Location Details */}
        <Card>
          <CardHeader>
            <CardTitle>
              {selectedLocation ? `${selectedLocation.city}, ${selectedLocation.country}` : 'Select a Location'}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedLocation ? (
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 bg-blue-50 rounded-lg">
                    <p className="text-2xl font-bold text-blue-600">{selectedLocation.types.opens}</p>
                    <p className="text-sm text-gray-600">Opens</p>
                  </div>
                  <div className="text-center p-3 bg-green-50 rounded-lg">
                    <p className="text-2xl font-bold text-green-600">{selectedLocation.types.clicks}</p>
                    <p className="text-sm text-gray-600">Clicks</p>
                  </div>
                  <div className="text-center p-3 bg-purple-50 rounded-lg">
                    <p className="text-2xl font-bold text-purple-600">{selectedLocation.types.responses}</p>
                    <p className="text-sm text-gray-600">Responses</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Total Interactions:</span>
                    <span className="font-medium">{selectedLocation.interactions}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Last Activity:</span>
                    <span className="font-medium">{getTimeAgo(selectedLocation.lastInteraction)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-sm text-gray-600">Response Rate:</span>
                    <span className="font-medium">
                      {((selectedLocation.types.responses / selectedLocation.interactions) * 100).toFixed(1)}%
                    </span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="text-center py-8 text-gray-500">
                <Globe className="h-12 w-12 mx-auto mb-4 opacity-50" />
                <p>Click on a location marker to view detailed analytics</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default EmailInteractionMap;