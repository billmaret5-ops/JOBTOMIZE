import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Switch } from './ui/switch';
import { Badge } from './ui/badge';
import { Calendar, Clock, Send, Zap } from 'lucide-react';

export const CampaignScheduler: React.FC = () => {
  const [sendOption, setSendOption] = useState('now');
  const [scheduledDate, setScheduledDate] = useState('');
  const [scheduledTime, setScheduledTime] = useState('');
  const [timezone, setTimezone] = useState('UTC');
  const [optimizeSendTime, setOptimizeSendTime] = useState(false);
  const [throttleEnabled, setThrottleEnabled] = useState(false);
  const [throttleRate, setThrottleRate] = useState('1000');
  const [throttlePeriod, setThrottlePeriod] = useState('hour');

  const timezones = [
    'UTC',
    'America/New_York',
    'America/Chicago',
    'America/Denver',
    'America/Los_Angeles',
    'Europe/London',
    'Europe/Paris',
    'Asia/Tokyo',
    'Australia/Sydney'
  ];

  const getScheduleStatus = () => {
    if (sendOption === 'now') return 'Ready to Send';
    if (sendOption === 'scheduled' && scheduledDate && scheduledTime) {
      return `Scheduled for ${scheduledDate} at ${scheduledTime} ${timezone}`;
    }
    return 'Configuration Required';
  };

  const getStatusBadgeVariant = () => {
    const status = getScheduleStatus();
    if (status === 'Ready to Send') return 'default';
    if (status.startsWith('Scheduled')) return 'secondary';
    return 'destructive';
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Calendar className="h-5 w-5" />
            Campaign Scheduling
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div>
            <Label className="text-base font-medium">Send Options</Label>
            <div className="mt-3 space-y-3">
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="send-now"
                  name="send-option"
                  value="now"
                  checked={sendOption === 'now'}
                  onChange={(e) => setSendOption(e.target.value)}
                  className="rounded"
                />
                <Label htmlFor="send-now" className="flex items-center gap-2">
                  <Zap className="h-4 w-4" />
                  Send Immediately
                </Label>
              </div>
              <div className="flex items-center space-x-2">
                <input
                  type="radio"
                  id="send-scheduled"
                  name="send-option"
                  value="scheduled"
                  checked={sendOption === 'scheduled'}
                  onChange={(e) => setSendOption(e.target.value)}
                  className="rounded"
                />
                <Label htmlFor="send-scheduled" className="flex items-center gap-2">
                  <Clock className="h-4 w-4" />
                  Schedule for Later
                </Label>
              </div>
            </div>
          </div>

          {sendOption === 'scheduled' && (
            <div className="space-y-4 p-4 border rounded-lg">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label>Date</Label>
                  <Input
                    type="date"
                    value={scheduledDate}
                    onChange={(e) => setScheduledDate(e.target.value)}
                    min={new Date().toISOString().split('T')[0]}
                  />
                </div>
                <div>
                  <Label>Time</Label>
                  <Input
                    type="time"
                    value={scheduledTime}
                    onChange={(e) => setScheduledTime(e.target.value)}
                  />
                </div>
              </div>

              <div>
                <Label>Timezone</Label>
                <Select value={timezone} onValueChange={setTimezone}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {timezones.map((tz) => (
                      <SelectItem key={tz} value={tz}>
                        {tz}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label>Optimize Send Time</Label>
                  <p className="text-sm text-muted-foreground">
                    Send at the optimal time for each recipient
                  </p>
                </div>
                <Switch
                  checked={optimizeSendTime}
                  onCheckedChange={setOptimizeSendTime}
                />
              </div>
            </div>
          )}

          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">Delivery Throttling</CardTitle>
                <Switch
                  checked={throttleEnabled}
                  onCheckedChange={setThrottleEnabled}
                />
              </div>
            </CardHeader>
            {throttleEnabled && (
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label>Send Rate</Label>
                    <Input
                      type="number"
                      value={throttleRate}
                      onChange={(e) => setThrottleRate(e.target.value)}
                      min="1"
                      placeholder="1000"
                    />
                  </div>
                  <div>
                    <Label>Per</Label>
                    <Select value={throttlePeriod} onValueChange={setThrottlePeriod}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="minute">Minute</SelectItem>
                        <SelectItem value="hour">Hour</SelectItem>
                        <SelectItem value="day">Day</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                <p className="text-sm text-muted-foreground">
                  Limit sending to {throttleRate} emails per {throttlePeriod} to maintain deliverability
                </p>
              </CardContent>
            )}
          </Card>

          <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
            <div>
              <div className="font-medium">Campaign Status</div>
              <div className="text-sm text-muted-foreground">
                {getScheduleStatus()}
              </div>
            </div>
            <Badge variant={getStatusBadgeVariant()}>
              {getScheduleStatus()}
            </Badge>
          </div>

          <div className="flex gap-2">
            <Button variant="outline" className="flex-1">
              Save as Draft
            </Button>
            <Button className="flex-1 flex items-center gap-2">
              <Send className="h-4 w-4" />
              {sendOption === 'now' ? 'Send Campaign' : 'Schedule Campaign'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};