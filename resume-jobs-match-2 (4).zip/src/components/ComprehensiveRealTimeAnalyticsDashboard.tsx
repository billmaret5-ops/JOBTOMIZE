import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Alert, AlertDescription } from './ui/alert';
import { Progress } from './ui/progress';
import { useRealTimeAnalytics } from '@/hooks/useRealTimeAnalytics';
import { 
  Activity, 
  Users, 
  Mail, 
  TrendingUp, 
  TrendingDown, 
  AlertTriangle, 
  CheckCircle, 
  XCircle,
  Wifi,
  WifiOff,
  RefreshCw,
  Clock,
  Globe,
  Smartphone,
  Monitor,
  Tablet
} from 'lucide-react';

export function ComprehensiveRealTimeAnalyticsDashboard() {
  const {
    data,
    isConnected,
    connectionStatus,
    lastUpdated,
    subscribe,
    unsubscribe,
    refreshData
  } = useRealTimeAnalytics();

  const [selectedTab, setSelectedTab] = useState('overview');

  const getConnectionStatusIcon = () => {
    switch (connectionStatus) {
      case 'connected':
        return <Wifi className="h-4 w-4 text-green-500" />;
      case 'connecting':
        return <RefreshCw className="h-4 w-4 text-yellow-500 animate-spin" />;
      case 'error':
        return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default:
        return <WifiOff className="h-4 w-4 text-gray-500" />;
    }
  };

  const getConnectionStatusText = () => {
    switch (connectionStatus) {
      case 'connected':
        return 'Connected';
      case 'connecting':
        return 'Connecting...';
      case 'error':
        return 'Connection Error';
      default:
        return 'Disconnected';
    }
  };
  const handleConnectionToggle = async () => {
    if (isConnected) {
      await unsubscribe();
    } else {
      await subscribe();
    }
  };

  return (
    <div className="space-y-6 p-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Real-Time Analytics Dashboard</h1>
          <p className="text-muted-foreground">Live email campaign performance with WebSocket streaming</p>
        </div>
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2">
            {getConnectionStatusIcon()}
            <span className="text-sm">{getConnectionStatusText()}</span>
          </div>
          <Button onClick={handleConnectionToggle} variant="outline" size="sm">
            {isConnected ? 'Disconnect' : 'Connect'}
          </Button>
          <Button onClick={refreshData} variant="outline" size="sm">
            <RefreshCw className="h-4 w-4 mr-2" />
            Refresh
          </Button>
        </div>
      </div>

      {/* Connection Status Alert */}
      {connectionStatus === 'error' && (
        <Alert className="border-red-200">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>
            Connection error. Real-time updates are not available. 
            <Button onClick={refreshData} variant="link" className="p-0 ml-2">
              Try reconnecting
            </Button>
          </AlertDescription>
        </Alert>
      )}

      {/* Live Alerts */}
      {data.alerts.length > 0 && (
        <div className="space-y-2">
          {data.alerts.slice(0, 2).map((alert) => (
            <Alert key={alert.id} className={alert.severity === 'high' ? 'border-red-200' : 'border-yellow-200'}>
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>
                <strong>{alert.type.toUpperCase()}:</strong> {alert.message}
                <span className="text-xs text-muted-foreground ml-2">
                  {new Date(alert.timestamp).toLocaleTimeString()}
                </span>
              </AlertDescription>
            </Alert>
          ))}
        </div>
      )}

      {/* Real-Time Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Open Rate</p>
                <p className="text-2xl font-bold">{(data.campaignMetrics.openRate * 100).toFixed(1)}%</p>
              </div>
              <Mail className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Active Campaigns</p>
                <p className="text-2xl font-bold">{data.campaignMetrics.activeCampaigns}</p>
              </div>
              <Activity className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">ML Accuracy</p>
                <p className="text-2xl font-bold">{(data.mlModelPerformance.accuracy * 100).toFixed(1)}%</p>
              </div>
              <TrendingUp className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">A/B Tests</p>
                <p className="text-2xl font-bold">{data.abTestResults.activeTests}</p>
              </div>
              <Users className="h-5 w-5 text-muted-foreground" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Detailed Tabs */}
      <Tabs value={selectedTab} onValueChange={setSelectedTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="campaigns">Campaigns</TabsTrigger>
          <TabsTrigger value="abtests">A/B Tests</TabsTrigger>
          <TabsTrigger value="ml">ML Models</TabsTrigger>
        </TabsList>

        <TabsContent value="overview">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Engagement Patterns</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.engagementPatterns.deviceBreakdown.map((device) => (
                    <div key={device.device} className="flex justify-between items-center">
                      <span className="capitalize">{device.device}</span>
                      <Badge variant="secondary">{device.percentage.toFixed(1)}%</Badge>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Location Data</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {data.engagementPatterns.locationData.slice(0, 5).map((location) => (
                    <div key={location.country} className="flex justify-between items-center">
                      <span>{location.country}</span>
                      <div className="flex gap-2">
                        <Badge variant="outline">{location.opens} opens</Badge>
                        <Badge variant="outline">{location.clicks} clicks</Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="campaigns">
          <Card>
            <CardHeader>
              <CardTitle>Campaign Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <p className="text-sm text-muted-foreground">Click Rate</p>
                  <p className="text-xl font-bold">{(data.campaignMetrics.clickRate * 100).toFixed(2)}%</p>
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Conversion Rate</p>
                  <p className="text-xl font-bold">{(data.campaignMetrics.conversionRate * 100).toFixed(2)}%</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="abtests">
          <Card>
            <CardHeader>
              <CardTitle>A/B Test Results</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex justify-between">
                  <span>Completed Tests</span>
                  <Badge>{data.abTestResults.completedTests}</Badge>
                </div>
                <div className="flex justify-between">
                  <span>Average Lift</span>
                  <Badge variant="secondary">{data.abTestResults.averageLift.toFixed(1)}%</Badge>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="ml">
          <Card>
            <CardHeader>
              <CardTitle>ML Model Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Precision</span>
                    <span>{(data.mlModelPerformance.precision * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={data.mlModelPerformance.precision * 100} />
                </div>
                <div>
                  <div className="flex justify-between mb-2">
                    <span>Recall</span>
                    <span>{(data.mlModelPerformance.recall * 100).toFixed(1)}%</span>
                  </div>
                  <Progress value={data.mlModelPerformance.recall * 100} />
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {lastUpdated && (
        <div className="text-xs text-muted-foreground text-center">
          Last updated: {lastUpdated.toLocaleTimeString()} • 
          <span className={isConnected ? 'text-green-600' : 'text-red-600'}>
            {isConnected ? ' Live' : ' Offline'}
          </span>
        </div>
      )}
    </div>
  );
}