import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Target, Upload, FileText, CheckCircle, AlertTriangle } from 'lucide-react';

interface ATSScore {
  overall: number;
  keywords: number;
  formatting: number;
  readability: number;
  sections: number;
}

interface OptimizationSuggestion {
  type: 'critical' | 'important' | 'minor';
  title: string;
  description: string;
  fix: string;
}

export function ATSResumeOptimizer() {
  const [resumeText, setResumeText] = useState('');
  const [jobDescription, setJobDescription] = useState('');
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [atsScore, setATSScore] = useState<ATSScore | null>(null);
  const [suggestions, setSuggestions] = useState<OptimizationSuggestion[]>([]);
  const [optimizedResume, setOptimizedResume] = useState('');

  const resumeImages = [
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758882098539_1bea9f0b.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758882100266_8f0a01c7.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758882101991_660807f4.webp',
    'https://d64gsuwffb70l.cloudfront.net/68cb246d5bfd2123dc8db5cb_1758882103689_8875fa08.webp'
  ];

  const analyzeResume = async () => {
    if (!resumeText || !jobDescription) return;
    
    setIsAnalyzing(true);
    
    // Simulate AI analysis
    setTimeout(() => {
      const mockScore: ATSScore = {
        overall: Math.floor(Math.random() * 20) + 75,
        keywords: Math.floor(Math.random() * 25) + 70,
        formatting: Math.floor(Math.random() * 15) + 85,
        readability: Math.floor(Math.random() * 20) + 80,
        sections: Math.floor(Math.random() * 10) + 90
      };
      
      const mockSuggestions: OptimizationSuggestion[] = [
        {
          type: 'critical',
          title: 'Missing Key Skills',
          description: 'Your resume lacks important keywords from the job description',
          fix: 'Add skills like "React", "TypeScript", "Node.js" to your skills section'
        },
        {
          type: 'important',
          title: 'Weak Action Verbs',
          description: 'Use stronger action verbs to describe achievements',
          fix: 'Replace "worked on" with "developed", "led", "implemented"'
        },
        {
          type: 'minor',
          title: 'Formatting Inconsistency',
          description: 'Date formats are inconsistent throughout the resume',
          fix: 'Use consistent date format (MM/YYYY) throughout'
        }
      ];
      
      setATSScore(mockScore);
      setSuggestions(mockSuggestions);
      setOptimizedResume(resumeText + '\n\n[AI-OPTIMIZED VERSION WOULD APPEAR HERE]');
      setIsAnalyzing(false);
    }, 2000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 90) return 'text-green-600';
    if (score >= 75) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getSuggestionIcon = (type: string) => {
    switch (type) {
      case 'critical': return <AlertTriangle className="w-4 h-4 text-red-500" />;
      case 'important': return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      default: return <CheckCircle className="w-4 h-4 text-blue-500" />;
    }
  };

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="w-5 h-5 text-red-600" />
            Beat The Hiring Robots
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-gray-600 mb-6">
            Companies use AI robots to auto-reject 75% of resumes. Upload your resume and we'll 
            reverse-engineer their algorithms to get you past the screening and into the interview.
          </p>

          
          <div className="grid md:grid-cols-4 gap-4 mb-6">
            {resumeImages.map((image, index) => (
              <div key={index} className="text-center">
                <img 
                  src={image} 
                  alt={`Resume template ${index + 1}`}
                  className="w-full h-32 object-cover rounded-lg mb-2 border-2 border-gray-200 hover:border-blue-500 cursor-pointer transition-colors"
                  onClick={() => console.log(`Selected template ${index + 1}`)}
                />
                <p className="text-xs text-gray-500">Template {index + 1}</p>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid md:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <FileText className="w-5 h-5" />
              Your Resume
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Paste your resume text here..."
              value={resumeText}
              onChange={(e) => setResumeText(e.target.value)}
              className="min-h-64 mb-4"
            />
            <Button variant="outline" className="w-full">
              <Upload className="w-4 h-4 mr-2" />
              Upload Resume File
            </Button>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Job Description</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Paste the job description here..."
              value={jobDescription}
              onChange={(e) => setJobDescription(e.target.value)}
              className="min-h-64"
            />
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardContent className="p-6">
          <Button 
            onClick={analyzeResume}
            disabled={!resumeText || !jobDescription || isAnalyzing}
            className="w-full"
            size="lg"
          >
            {isAnalyzing ? 'Analyzing...' : 'Analyze & Optimize Resume'}
          </Button>
        </CardContent>
      </Card>

      {atsScore && (
        <div className="grid md:grid-cols-2 gap-6">
          <Card>
            <CardHeader>
              <CardTitle>Robot Rejection Score</CardTitle>
            </CardHeader>

            <CardContent>
              <div className="space-y-4">
                <div className="text-center">
                  <div className={`text-4xl font-bold ${getScoreColor(atsScore.overall)}`}>
                    {atsScore.overall}%
                  </div>
                  <p className="text-gray-600">Overall ATS Score</p>
                </div>
                
                <div className="space-y-3">
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Keywords</span>
                      <span className={getScoreColor(atsScore.keywords)}>{atsScore.keywords}%</span>
                    </div>
                    <Progress value={atsScore.keywords} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Formatting</span>
                      <span className={getScoreColor(atsScore.formatting)}>{atsScore.formatting}%</span>
                    </div>
                    <Progress value={atsScore.formatting} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Readability</span>
                      <span className={getScoreColor(atsScore.readability)}>{atsScore.readability}%</span>
                    </div>
                    <Progress value={atsScore.readability} />
                  </div>
                  
                  <div>
                    <div className="flex justify-between text-sm mb-1">
                      <span>Sections</span>
                      <span className={getScoreColor(atsScore.sections)}>{atsScore.sections}%</span>
                    </div>
                    <Progress value={atsScore.sections} />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Optimization Suggestions</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {suggestions.map((suggestion, index) => (
                  <div key={index} className="border rounded-lg p-4">
                    <div className="flex items-start gap-3">
                      {getSuggestionIcon(suggestion.type)}
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <h4 className="font-medium">{suggestion.title}</h4>
                          <Badge variant={
                            suggestion.type === 'critical' ? 'destructive' : 
                            suggestion.type === 'important' ? 'default' : 'secondary'
                          }>
                            {suggestion.type}
                          </Badge>
                        </div>
                        <p className="text-sm text-gray-600 mb-2">{suggestion.description}</p>
                        <p className="text-sm text-green-700 bg-green-50 p-2 rounded">
                          <strong>Fix:</strong> {suggestion.fix}
                        </p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      )}

      {optimizedResume && (
        <Card>
          <CardHeader>
            <CardTitle>AI-Optimized Resume</CardTitle>
          </CardHeader>
          <CardContent>
            <Textarea
              value={optimizedResume}
              onChange={(e) => setOptimizedResume(e.target.value)}
              className="min-h-64 mb-4"
            />
            <div className="flex gap-2">
              <Button>Download Optimized Resume</Button>
              <Button variant="outline">Copy to Clipboard</Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

export default ATSResumeOptimizer;