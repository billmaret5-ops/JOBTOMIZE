import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { behavioralTrackingService } from '../services/behavioralTrackingService';
import { webhookHandlerService } from '../services/webhookHandlerService';

interface AnalyticsData {
  totalEvents: number;
  eventsByType: { type: string; count: number }[];
  triggerPerformance: { id: string; name: string; executions: number; conversionRate: number }[];
  webhookStats: { totalEvents: number; successRate: number; recentEvents: any[] };
}

export const BehaviorAnalyticsDashboard: React.FC = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalEvents: 0,
    eventsByType: [],
    triggerPerformance: [],
    webhookStats: { totalEvents: 0, successRate: 0, recentEvents: [] }
  });
  const [loading, setLoading] = useState(false);
  const [timeRange, setTimeRange] = useState('7d');
  const [selectedTrigger, setSelectedTrigger] = useState<string>('');

  useEffect(() => {
    loadAnalytics();
  }, [timeRange]);

  const loadAnalytics = async () => {
    setLoading(true);
    try {
      // Load webhook analytics
      const webhookStats = await webhookHandlerService.getWebhookAnalytics();
      
      // Mock analytics data for demonstration
      const mockAnalytics: AnalyticsData = {
        totalEvents: 1247,
        eventsByType: [
          { type: 'page_visit', count: 523 },
          { type: 'email_open', count: 312 },
          { type: 'email_click', count: 156 },
          { type: 'purchase', count: 89 },
          { type: 'cart_abandon', count: 167 }
        ],
        triggerPerformance: [
          { id: '1', name: 'Cart Abandonment Follow-up', executions: 167, conversionRate: 23.5 },
          { id: '2', name: 'Welcome Series', executions: 89, conversionRate: 45.2 },
          { id: '3', name: 'Re-engagement Campaign', executions: 234, conversionRate: 12.8 }
        ],
        webhookStats
      };

      setAnalytics(mockAnalytics);
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  const getTriggerAnalytics = async (triggerId: string) => {
    try {
      const data = await behavioralTrackingService.getTriggerAnalytics(triggerId);
      return data;
    } catch (error) {
      console.error('Error loading trigger analytics:', error);
      return null;
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat().format(num);
  };

  const formatPercentage = (num: number) => {
    return `${num.toFixed(1)}%`;
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-2xl font-bold">Behavior Analytics Dashboard</h2>
        <div className="flex items-center gap-4">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="24h">Last 24h</SelectItem>
              <SelectItem value="7d">Last 7 days</SelectItem>
              <SelectItem value="30d">Last 30 days</SelectItem>
              <SelectItem value="90d">Last 90 days</SelectItem>
            </SelectContent>
          </Select>
          <Button onClick={loadAnalytics} disabled={loading}>
            {loading ? 'Loading...' : 'Refresh'}
          </Button>
        </div>
      </div>

      <Tabs defaultValue="overview" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="triggers">Trigger Performance</TabsTrigger>
          <TabsTrigger value="webhooks">Webhook Analytics</TabsTrigger>
          <TabsTrigger value="insights">AI Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{formatNumber(analytics.totalEvents)}</div>
                <p className="text-sm text-muted-foreground">Total Events</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{analytics.eventsByType.length}</div>
                <p className="text-sm text-muted-foreground">Event Types</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{analytics.triggerPerformance.length}</div>
                <p className="text-sm text-muted-foreground">Active Triggers</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{formatPercentage(analytics.webhookStats.successRate)}</div>
                <p className="text-sm text-muted-foreground">Webhook Success Rate</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Events by Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.eventsByType.map(event => (
                  <div key={event.type} className="flex items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Badge variant="outline">{event.type.replace('_', ' ')}</Badge>
                      <span className="font-medium">{formatNumber(event.count)} events</span>
                    </div>
                    <div className="w-32 bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-blue-600 h-2 rounded-full"
                        style={{
                          width: `${(event.count / analytics.totalEvents) * 100}%`
                        }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="triggers" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Trigger Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analytics.triggerPerformance.map(trigger => (
                  <div key={trigger.id} className="p-4 border rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <h3 className="font-semibold">{trigger.name}</h3>
                      <Badge variant="default">
                        {formatPercentage(trigger.conversionRate)} conversion
                      </Badge>
                    </div>
                    <div className="grid grid-cols-2 gap-4 text-sm text-muted-foreground">
                      <div>
                        <span className="font-medium">Executions:</span> {formatNumber(trigger.executions)}
                      </div>
                      <div>
                        <span className="font-medium">Conversion Rate:</span> {formatPercentage(trigger.conversionRate)}
                      </div>
                    </div>
                    <div className="mt-3">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => setSelectedTrigger(trigger.id)}
                      >
                        View Details
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="webhooks" className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{formatNumber(analytics.webhookStats.totalEvents)}</div>
                <p className="text-sm text-muted-foreground">Total Webhook Events</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{formatPercentage(analytics.webhookStats.successRate)}</div>
                <p className="text-sm text-muted-foreground">Success Rate</p>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-6">
                <div className="text-2xl font-bold">{analytics.webhookStats.recentEvents.length}</div>
                <p className="text-sm text-muted-foreground">Recent Events</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Recent Webhook Events</CardTitle>
            </CardHeader>
            <CardContent>
              {analytics.webhookStats.recentEvents.length > 0 ? (
                <div className="space-y-3">
                  {analytics.webhookStats.recentEvents.map((event, index) => (
                    <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                      <div>
                        <p className="font-medium">{event.event_type}</p>
                        <p className="text-sm text-muted-foreground">
                          {event.processed_at ? new Date(event.processed_at).toLocaleString() : 'Pending'}
                        </p>
                      </div>
                      <Badge variant={event.status === 'processed' ? 'default' : event.status === 'failed' ? 'destructive' : 'secondary'}>
                        {event.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <p>No recent webhook events</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="insights" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>AI-Powered Insights</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="p-4 bg-blue-50 border border-blue-200 rounded-lg">
                  <h3 className="font-semibold text-blue-900">Optimization Opportunity</h3>
                  <p className="text-blue-800 mt-1">
                    Your cart abandonment trigger has a 23.5% conversion rate. Consider A/B testing different time delays 
                    to potentially increase conversions.
                  </p>
                </div>
                
                <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                  <h3 className="font-semibold text-green-900">High Performer</h3>
                  <p className="text-green-800 mt-1">
                    Welcome series trigger shows excellent 45.2% conversion rate. Consider expanding this workflow 
                    with additional touchpoints.
                  </p>
                </div>
                
                <div className="p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
                  <h3 className="font-semibold text-yellow-900">Attention Needed</h3>
                  <p className="text-yellow-800 mt-1">
                    Re-engagement campaign has low 12.8% conversion rate. Review targeting criteria and message content 
                    for improvements.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};