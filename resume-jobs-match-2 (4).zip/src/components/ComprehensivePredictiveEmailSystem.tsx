import React, { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import PredictiveEmailResponseSystem from './PredictiveEmailResponseSystem';
import ResponseTimingRecommender from './ResponseTimingRecommender';
import SmartResponseComposer from './SmartResponseComposer';
import { Mail, Clock, Sparkles, BarChart3 } from 'lucide-react';

const ComprehensivePredictiveEmailSystem = () => {
  return (
    <div className="container mx-auto p-6">
      <div className="mb-6">
        <h1 className="text-3xl font-bold mb-2">Predictive Email Response System</h1>
        <p className="text-muted-foreground">AI-powered email analysis and response suggestions</p>
      </div>

      <Tabs defaultValue="responses" className="space-y-6">
        <TabsList>
          <TabsTrigger value="responses"><Mail className="h-4 w-4 mr-2" />Responses</TabsTrigger>
          <TabsTrigger value="timing"><Clock className="h-4 w-4 mr-2" />Timing</TabsTrigger>
          <TabsTrigger value="composer"><Sparkles className="h-4 w-4 mr-2" />Composer</TabsTrigger>
          <TabsTrigger value="analytics"><BarChart3 className="h-4 w-4 mr-2" />Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="responses">
          <PredictiveEmailResponseSystem />
        </TabsContent>

        <TabsContent value="timing">
          <ResponseTimingRecommender />
        </TabsContent>

        <TabsContent value="composer">
          <SmartResponseComposer />
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Response Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 border rounded-lg">
                  <div className="text-2xl font-bold">156</div>
                  <p className="text-sm text-muted-foreground">Total Responses</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-2xl font-bold">94%</div>
                  <p className="text-sm text-muted-foreground">Template Accuracy</p>
                </div>
                <div className="p-4 border rounded-lg">
                  <div className="text-2xl font-bold">3.2h</div>
                  <p className="text-sm text-muted-foreground">Avg Response Time</p>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default ComprehensivePredictiveEmailSystem;
