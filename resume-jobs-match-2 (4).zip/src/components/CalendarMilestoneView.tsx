import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Progress } from '@/components/ui/progress';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, Calendar, Clock, TrendingUp, CheckCircle2 } from 'lucide-react';

interface Milestone {
  id: string;
  title: string;
  description: string;
  dueDate: Date;
  completed: boolean;
  applicationId: string;
  companyName: string;
  priority: 'high' | 'medium' | 'low';
  category: 'application' | 'interview' | 'followup' | 'research';
}

interface ApplicationProgress {
  applicationId: string;
  companyName: string;
  position: string;
  totalMilestones: number;
  completedMilestones: number;
  nextMilestone?: Milestone;
  overdueMilestones: number;
}

export default function CalendarMilestoneView() {
  const [milestones, setMilestones] = useState<Milestone[]>([]);
  const [applications, setApplications] = useState<ApplicationProgress[]>([]);
  const [viewMode, setViewMode] = useState<'timeline' | 'progress'>('timeline');
  const [filterCategory, setFilterCategory] = useState<string>('all');

  useEffect(() => {
    // Mock data - replace with actual API calls
    const mockMilestones: Milestone[] = [
      {
        id: '1',
        title: 'Submit Application',
        description: 'Complete and submit application for Software Engineer position',
        dueDate: new Date(2024, 2, 15),
        completed: true,
        applicationId: 'app-1',
        companyName: 'TechCorp',
        priority: 'high',
        category: 'application'
      },
      {
        id: '2',
        title: 'Follow-up Email',
        description: 'Send follow-up email after application submission',
        dueDate: new Date(2024, 2, 22),
        completed: false,
        applicationId: 'app-1',
        companyName: 'TechCorp',
        priority: 'medium',
        category: 'followup'
      },
      {
        id: '3',
        title: 'Prepare for Technical Interview',
        description: 'Review algorithms and system design concepts',
        dueDate: new Date(2024, 2, 25),
        completed: false,
        applicationId: 'app-1',
        companyName: 'TechCorp',
        priority: 'high',
        category: 'interview'
      }
    ];

    const mockApplications: ApplicationProgress[] = [
      {
        applicationId: 'app-1',
        companyName: 'TechCorp',
        position: 'Software Engineer',
        totalMilestones: 5,
        completedMilestones: 2,
        nextMilestone: mockMilestones[1],
        overdueMilestones: 0
      },
      {
        applicationId: 'app-2',
        companyName: 'DataCorp',
        position: 'Data Scientist',
        totalMilestones: 4,
        completedMilestones: 1,
        overdueMilestones: 1
      }
    ];

    setMilestones(mockMilestones);
    setApplications(mockApplications);
  }, []);

  const toggleMilestone = (milestoneId: string) => {
    setMilestones(prev => prev.map(m => 
      m.id === milestoneId ? { ...m, completed: !m.completed } : m
    ));
  };

  const filteredMilestones = milestones.filter(m => 
    filterCategory === 'all' || m.category === filterCategory
  );

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case 'application': return <Target className="h-4 w-4" />;
      case 'interview': return <Calendar className="h-4 w-4" />;
      case 'followup': return <Clock className="h-4 w-4" />;
      case 'research': return <TrendingUp className="h-4 w-4" />;
      default: return <Target className="h-4 w-4" />;
    }
  };

  const isOverdue = (date: Date) => new Date() > date;

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <div className="flex justify-between items-center">
            <CardTitle className="flex items-center gap-2">
              <Target className="h-5 w-5" />
              Application Milestones
            </CardTitle>
            <div className="flex gap-2">
              <Select value={filterCategory} onValueChange={setFilterCategory}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Categories</SelectItem>
                  <SelectItem value="application">Applications</SelectItem>
                  <SelectItem value="interview">Interviews</SelectItem>
                  <SelectItem value="followup">Follow-ups</SelectItem>
                  <SelectItem value="research">Research</SelectItem>
                </SelectContent>
              </Select>
              <Button
                variant={viewMode === 'timeline' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('timeline')}
              >
                Timeline
              </Button>
              <Button
                variant={viewMode === 'progress' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('progress')}
              >
                Progress
              </Button>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          {viewMode === 'timeline' ? (
            <div className="space-y-4">
              {filteredMilestones.map(milestone => (
                <div
                  key={milestone.id}
                  className={`border rounded-lg p-4 ${
                    milestone.completed ? 'bg-green-50 border-green-200' : 
                    isOverdue(milestone.dueDate) ? 'bg-red-50 border-red-200' : ''
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-start gap-3">
                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => toggleMilestone(milestone.id)}
                        className="mt-1 p-0 h-6 w-6"
                      >
                        <CheckCircle2 
                          className={`h-5 w-5 ${
                            milestone.completed ? 'text-green-600' : 'text-gray-400'
                          }`}
                        />
                      </Button>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          {getCategoryIcon(milestone.category)}
                          <h4 className={`font-medium ${
                            milestone.completed ? 'line-through text-gray-500' : ''
                          }`}>
                            {milestone.title}
                          </h4>
                        </div>
                        <p className="text-sm text-muted-foreground mb-2">
                          {milestone.description}
                        </p>
                        <div className="flex items-center gap-2 text-sm">
                          <span className="font-medium">{milestone.companyName}</span>
                          <span className="text-muted-foreground">•</span>
                          <span className={
                            isOverdue(milestone.dueDate) && !milestone.completed 
                              ? 'text-red-600 font-medium' 
                              : 'text-muted-foreground'
                          }>
                            Due: {milestone.dueDate.toLocaleDateString()}
                          </span>
                        </div>
                      </div>
                    </div>
                    <Badge className={getPriorityColor(milestone.priority)}>
                      {milestone.priority}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="space-y-6">
              {applications.map(app => (
                <div key={app.applicationId} className="border rounded-lg p-4">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h4 className="font-medium">{app.position}</h4>
                      <p className="text-sm text-muted-foreground">{app.companyName}</p>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-medium">
                        {app.completedMilestones}/{app.totalMilestones} completed
                      </div>
                      {app.overdueMilestones > 0 && (
                        <div className="text-sm text-red-600">
                          {app.overdueMilestones} overdue
                        </div>
                      )}
                    </div>
                  </div>
                  
                  <Progress 
                    value={(app.completedMilestones / app.totalMilestones) * 100} 
                    className="mb-3"
                  />
                  
                  {app.nextMilestone && (
                    <div className="bg-blue-50 rounded-lg p-3">
                      <div className="flex items-center gap-2 mb-1">
                        <Clock className="h-4 w-4 text-blue-600" />
                        <span className="text-sm font-medium text-blue-800">
                          Next Milestone
                        </span>
                      </div>
                      <p className="text-sm text-blue-700">
                        {app.nextMilestone.title} - Due {app.nextMilestone.dueDate.toLocaleDateString()}
                      </p>
                    </div>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}