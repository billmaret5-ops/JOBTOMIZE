import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Calendar, Download, Filter, TrendingUp, Users, MapPin } from 'lucide-react';
import ApplicationMetricsChart from './analytics/ApplicationMetricsChart';
import JobBoardPerformanceChart from './analytics/JobBoardPerformanceChart';
import { ApplicationAnalyticsService, ApplicationMetrics, JobBoardMetrics } from '../services/applicationAnalyticsService';

export default function ComprehensiveApplicationAnalytics() {
  const [applications, setApplications] = useState<any[]>([]);
  const [filteredApplications, setFilteredApplications] = useState<any[]>([]);
  const [metrics, setMetrics] = useState<ApplicationMetrics | null>(null);
  const [jobBoardMetrics, setJobBoardMetrics] = useState<JobBoardMetrics[]>([]);
  const [filters, setFilters] = useState({
    dateRange: 'all',
    jobType: 'all',
    location: 'all',
    jobBoard: 'all'
  });

  // Mock data - in real app, this would come from API
  useEffect(() => {
    const mockApplications = [
      {
        id: 1,
        company: 'TechCorp',
        position: 'Software Engineer',
        jobBoard: 'LinkedIn',
        appliedDate: '2024-01-15',
        responseDate: '2024-01-20',
        status: 'interview',
        salary: 120000,
        location: 'San Francisco',
        jobType: 'full-time'
      },
      {
        id: 2,
        company: 'StartupXYZ',
        position: 'Frontend Developer',
        jobBoard: 'Indeed',
        appliedDate: '2024-01-18',
        responseDate: null,
        status: 'pending',
        salary: 95000,
        location: 'Remote',
        jobType: 'full-time'
      },
      {
        id: 3,
        company: 'BigTech Inc',
        position: 'Senior Developer',
        jobBoard: 'Glassdoor',
        appliedDate: '2024-01-10',
        responseDate: '2024-01-25',
        status: 'offer',
        salary: 150000,
        location: 'New York',
        jobType: 'full-time'
      }
    ];
    
    setApplications(mockApplications);
    setFilteredApplications(mockApplications);
  }, []);

  useEffect(() => {
    const filtered = applications.filter(app => {
      if (filters.jobType !== 'all' && app.jobType !== filters.jobType) return false;
      if (filters.location !== 'all' && app.location !== filters.location) return false;
      if (filters.jobBoard !== 'all' && app.jobBoard !== filters.jobBoard) return false;
      return true;
    });
    
    setFilteredApplications(filtered);
    setMetrics(ApplicationAnalyticsService.calculateMetrics(filtered));
    setJobBoardMetrics(ApplicationAnalyticsService.getJobBoardMetrics(filtered));
  }, [applications, filters]);

  const handleExport = (format: string) => {
    if (format === 'csv') {
      ApplicationAnalyticsService.exportToCSV(filteredApplications, 'application_analytics.csv');
    }
  };

  const getStatusBadgeVariant = (status: string) => {
    switch (status) {
      case 'offer': return 'default';
      case 'interview': return 'secondary';
      case 'responded': return 'outline';
      default: return 'destructive';
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold">Application Analytics</h2>
        <div className="flex space-x-2">
          <Button variant="outline" onClick={() => handleExport('csv')}>
            <Download className="w-4 h-4 mr-2" />
            Export CSV
          </Button>
        </div>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <Filter className="w-5 h-5 mr-2" />
            Filters
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Select value={filters.dateRange} onValueChange={(value) => setFilters(prev => ({ ...prev, dateRange: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Date Range" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Time</SelectItem>
                <SelectItem value="7d">Last 7 Days</SelectItem>
                <SelectItem value="30d">Last 30 Days</SelectItem>
                <SelectItem value="90d">Last 90 Days</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.jobType} onValueChange={(value) => setFilters(prev => ({ ...prev, jobType: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Job Type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="full-time">Full Time</SelectItem>
                <SelectItem value="part-time">Part Time</SelectItem>
                <SelectItem value="contract">Contract</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.location} onValueChange={(value) => setFilters(prev => ({ ...prev, location: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                <SelectItem value="Remote">Remote</SelectItem>
                <SelectItem value="San Francisco">San Francisco</SelectItem>
                <SelectItem value="New York">New York</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filters.jobBoard} onValueChange={(value) => setFilters(prev => ({ ...prev, jobBoard: value }))}>
              <SelectTrigger>
                <SelectValue placeholder="Job Board" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Boards</SelectItem>
                <SelectItem value="LinkedIn">LinkedIn</SelectItem>
                <SelectItem value="Indeed">Indeed</SelectItem>
                <SelectItem value="Glassdoor">Glassdoor</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Metrics Overview */}
      {metrics && <ApplicationMetricsChart metrics={metrics} />}

      <Tabs defaultValue="boards" className="space-y-4">
        <TabsList>
          <TabsTrigger value="boards">Job Boards</TabsTrigger>
          <TabsTrigger value="companies">Companies</TabsTrigger>
          <TabsTrigger value="trends">Trends</TabsTrigger>
        </TabsList>

        <TabsContent value="boards">
          <JobBoardPerformanceChart jobBoardMetrics={jobBoardMetrics} />
        </TabsContent>

        <TabsContent value="companies">
          <Card>
            <CardHeader>
              <CardTitle>Company Performance</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {filteredApplications.map((app) => (
                  <div key={app.id} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <h3 className="font-medium">{app.company}</h3>
                      <p className="text-sm text-muted-foreground">{app.position}</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Badge variant={getStatusBadgeVariant(app.status)}>
                        {app.status}
                      </Badge>
                      <span className="text-sm">${app.salary?.toLocaleString()}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="trends">
          <Card>
            <CardHeader>
              <CardTitle>Application Trends</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <TrendingUp className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
                <p className="text-muted-foreground">Trend analysis coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}