import React, { useState } from 'react';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Progress } from '@/components/ui/progress';
import { Plus, Play, Pause, BarChart3, Copy, Eye } from 'lucide-react';

interface ABTestVariant {
  id: string;
  name: string;
  subject: string;
  template: any;
  trafficPercentage: number;
  metrics: {
    sent: number;
    opened: number;
    clicked: number;
    replied: number;
    openRate: number;
    clickRate: number;
    replyRate: number;
  };
}

interface ABTest {
  id: string;
  name: string;
  status: 'draft' | 'running' | 'completed' | 'paused';
  variants: ABTestVariant[];
  testDuration: number;
  winner?: string;
  createdAt: Date;
}

export const ABTestEmailManager: React.FC = () => {
  const [tests, setTests] = useState<ABTest[]>([
    {
      id: '1',
      name: 'Job Application Subject Line Test',
      status: 'running',
      testDuration: 7,
      createdAt: new Date(),
      variants: [
        {
          id: 'a',
          name: 'Variant A - Direct',
          subject: 'Application for Software Engineer Position',
          template: {},
          trafficPercentage: 50,
          metrics: {
            sent: 150,
            opened: 75,
            clicked: 15,
            replied: 8,
            openRate: 50,
            clickRate: 20,
            replyRate: 10.7
          }
        },
        {
          id: 'b',
          name: 'Variant B - Personal',
          subject: 'Excited to Join Your Engineering Team',
          template: {},
          trafficPercentage: 50,
          metrics: {
            sent: 150,
            opened: 90,
            clicked: 22,
            replied: 12,
            openRate: 60,
            clickRate: 24.4,
            replyRate: 13.3
          }
        }
      ]
    }
  ]);

  const [newTestName, setNewTestName] = useState('');
  const [selectedTest, setSelectedTest] = useState<string | null>(null);

  const createNewTest = () => {
    if (newTestName) {
      const newTest: ABTest = {
        id: Date.now().toString(),
        name: newTestName,
        status: 'draft',
        testDuration: 7,
        createdAt: new Date(),
        variants: [
          {
            id: 'a',
            name: 'Variant A',
            subject: '',
            template: {},
            trafficPercentage: 50,
            metrics: {
              sent: 0,
              opened: 0,
              clicked: 0,
              replied: 0,
              openRate: 0,
              clickRate: 0,
              replyRate: 0
            }
          },
          {
            id: 'b',
            name: 'Variant B',
            subject: '',
            template: {},
            trafficPercentage: 50,
            metrics: {
              sent: 0,
              opened: 0,
              clicked: 0,
              replied: 0,
              openRate: 0,
              clickRate: 0,
              replyRate: 0
            }
          }
        ]
      };
      setTests([...tests, newTest]);
      setNewTestName('');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'running': return 'bg-green-100 text-green-800';
      case 'completed': return 'bg-blue-100 text-blue-800';
      case 'paused': return 'bg-yellow-100 text-yellow-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getWinningVariant = (test: ABTest) => {
    if (test.variants.length < 2) return null;
    return test.variants.reduce((prev, current) => 
      current.metrics.replyRate > prev.metrics.replyRate ? current : prev
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">A/B Test Manager</h2>
          <p className="text-gray-600">Create and manage A/B tests for your email campaigns</p>
        </div>
        <div className="flex gap-2">
          <Input
            placeholder="Test name"
            value={newTestName}
            onChange={(e) => setNewTestName(e.target.value)}
            className="w-48"
          />
          <Button onClick={createNewTest}>
            <Plus className="w-4 h-4 mr-2" />
            New Test
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {tests.map((test) => {
          const winner = getWinningVariant(test);
          return (
            <Card key={test.id} className="hover:shadow-lg transition-shadow">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-lg">{test.name}</CardTitle>
                    <p className="text-sm text-gray-600">
                      Created {test.createdAt.toLocaleDateString()}
                    </p>
                  </div>
                  <Badge className={getStatusColor(test.status)}>
                    {test.status}
                  </Badge>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {test.variants.map((variant) => (
                    <div key={variant.id} className="border rounded-lg p-4">
                      <div className="flex items-center justify-between mb-3">
                        <div className="flex items-center gap-2">
                          <h4 className="font-medium">{variant.name}</h4>
                          {winner?.id === variant.id && test.status === 'completed' && (
                            <Badge className="bg-green-100 text-green-800">Winner</Badge>
                          )}
                        </div>
                        <div className="flex gap-1">
                          <Button size="sm" variant="outline">
                            <Eye className="w-3 h-3" />
                          </Button>
                          <Button size="sm" variant="outline">
                            <Copy className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                      
                      <div className="text-sm text-gray-600 mb-3">
                        <strong>Subject:</strong> {variant.subject || 'Not set'}
                      </div>

                      <div className="grid grid-cols-3 gap-4 text-sm">
                        <div>
                          <div className="text-gray-600">Open Rate</div>
                          <div className="font-semibold text-lg">
                            {variant.metrics.openRate}%
                          </div>
                          <Progress value={variant.metrics.openRate} className="h-2" />
                        </div>
                        <div>
                          <div className="text-gray-600">Click Rate</div>
                          <div className="font-semibold text-lg">
                            {variant.metrics.clickRate}%
                          </div>
                          <Progress value={variant.metrics.clickRate} className="h-2" />
                        </div>
                        <div>
                          <div className="text-gray-600">Reply Rate</div>
                          <div className="font-semibold text-lg">
                            {variant.metrics.replyRate}%
                          </div>
                          <Progress value={variant.metrics.replyRate} className="h-2" />
                        </div>
                      </div>

                      <div className="grid grid-cols-4 gap-2 mt-3 text-xs text-gray-600">
                        <div>Sent: {variant.metrics.sent}</div>
                        <div>Opened: {variant.metrics.opened}</div>
                        <div>Clicked: {variant.metrics.clicked}</div>
                        <div>Replied: {variant.metrics.replied}</div>
                      </div>
                    </div>
                  ))}

                  <div className="flex gap-2 pt-4 border-t">
                    {test.status === 'draft' && (
                      <Button size="sm" className="flex-1">
                        <Play className="w-3 h-3 mr-1" />
                        Start Test
                      </Button>
                    )}
                    {test.status === 'running' && (
                      <Button size="sm" variant="outline" className="flex-1">
                        <Pause className="w-3 h-3 mr-1" />
                        Pause
                      </Button>
                    )}
                    <Button size="sm" variant="outline" className="flex-1">
                      <BarChart3 className="w-3 h-3 mr-1" />
                      Analytics
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>
    </div>
  );
};