import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Users, MessageCircle, FileText, Share2, Plus, Send } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { useAuth } from '@/contexts/AuthContext';

interface Group {
  id: string;
  name: string;
  description: string;
  owner_id: string;
  created_at: string;
}

interface Message {
  id: string;
  sender_id: string;
  content: string;
  created_at: string;
  sender?: { full_name: string; email: string };
}

export default function CollaborationHub() {
  const { user } = useAuth();
  const [groups, setGroups] = useState<Group[]>([]);
  const [selectedGroup, setSelectedGroup] = useState<Group | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [newGroupName, setNewGroupName] = useState('');
  const [newGroupDesc, setNewGroupDesc] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteRole, setInviteRole] = useState('member');

  useEffect(() => {
    if (user) {
      loadGroups();
    }
  }, [user]);

  useEffect(() => {
    if (selectedGroup) {
      loadMessages();
      const subscription = supabase
        .channel(`group-${selectedGroup.id}`)
        .on('postgres_changes', 
          { event: 'INSERT', schema: 'public', table: 'collaboration_messages', filter: `group_id=eq.${selectedGroup.id}` },
          (payload) => {
            setMessages(prev => [...prev, payload.new as Message]);
          }
        )
        .subscribe();

      return () => {
        subscription.unsubscribe();
      };
    }
  }, [selectedGroup]);

  const loadGroups = async () => {
    const { data } = await supabase
      .from('collaboration_groups')
      .select('*')
      .order('created_at', { ascending: false });
    
    if (data) setGroups(data);
  };

  const loadMessages = async () => {
    if (!selectedGroup) return;
    
    const { data } = await supabase
      .from('collaboration_messages')
      .select(`
        *,
        sender:profiles(full_name, email)
      `)
      .eq('group_id', selectedGroup.id)
      .order('created_at', { ascending: true });
    
    if (data) setMessages(data);
  };

  const createGroup = async () => {
    if (!newGroupName.trim() || !user) return;

    const { data } = await supabase.functions.invoke('collaboration-manager', {
      body: {
        action: 'create_group',
        data: {
          name: newGroupName,
          description: newGroupDesc,
          owner_id: user.id
        }
      }
    });

    if (data?.success) {
      setNewGroupName('');
      setNewGroupDesc('');
      loadGroups();
    }
  };

  const sendMessage = async () => {
    if (!newMessage.trim() || !selectedGroup || !user) return;

    const { data } = await supabase.functions.invoke('collaboration-manager', {
      body: {
        action: 'send_message',
        data: {
          group_id: selectedGroup.id,
          sender_id: user.id,
          content: newMessage
        }
      }
    });

    if (data?.success) {
      setNewMessage('');
    }
  };

  const inviteMember = async () => {
    if (!inviteEmail.trim() || !selectedGroup) return;

    const { data } = await supabase.functions.invoke('collaboration-manager', {
      body: {
        action: 'invite_member',
        data: {
          group_id: selectedGroup.id,
          user_email: inviteEmail,
          role: inviteRole
        }
      }
    });

    if (data?.success) {
      setInviteEmail('');
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-bold">Collaboration Hub</h1>
        <Dialog>
          <DialogTrigger asChild>
            <Button><Plus className="w-4 h-4 mr-2" />Create Group</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create Collaboration Group</DialogTitle>
            </DialogHeader>
            <div className="space-y-4">
              <Input
                placeholder="Group name"
                value={newGroupName}
                onChange={(e) => setNewGroupName(e.target.value)}
              />
              <Textarea
                placeholder="Description (optional)"
                value={newGroupDesc}
                onChange={(e) => setNewGroupDesc(e.target.value)}
              />
              <Button onClick={createGroup} className="w-full">Create Group</Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Users className="w-5 h-5" />
              Your Groups
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {groups.map((group) => (
              <div
                key={group.id}
                className={`p-3 rounded-lg border cursor-pointer transition-colors ${
                  selectedGroup?.id === group.id ? 'bg-primary/10 border-primary' : 'hover:bg-muted'
                }`}
                onClick={() => setSelectedGroup(group)}
              >
                <div className="font-medium">{group.name}</div>
                <div className="text-sm text-muted-foreground">{group.description}</div>
              </div>
            ))}
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <MessageCircle className="w-5 h-5" />
                {selectedGroup ? selectedGroup.name : 'Select a Group'}
              </div>
              {selectedGroup && (
                <Dialog>
                  <DialogTrigger asChild>
                    <Button variant="outline" size="sm">
                      <Share2 className="w-4 h-4 mr-2" />
                      Invite
                    </Button>
                  </DialogTrigger>
                  <DialogContent>
                    <DialogHeader>
                      <DialogTitle>Invite Member</DialogTitle>
                    </DialogHeader>
                    <div className="space-y-4">
                      <Input
                        placeholder="Email address"
                        type="email"
                        value={inviteEmail}
                        onChange={(e) => setInviteEmail(e.target.value)}
                      />
                      <Select value={inviteRole} onValueChange={setInviteRole}>
                        <SelectTrigger>
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="member">Member</SelectItem>
                          <SelectItem value="mentor">Mentor</SelectItem>
                        </SelectContent>
                      </Select>
                      <Button onClick={inviteMember} className="w-full">Send Invite</Button>
                    </div>
                  </DialogContent>
                </Dialog>
              )}
            </CardTitle>
          </CardHeader>
          <CardContent>
            {selectedGroup ? (
              <div className="space-y-4">
                <div className="h-96 overflow-y-auto space-y-3 p-4 bg-muted/20 rounded-lg">
                  {messages.map((message) => (
                    <div key={message.id} className="flex gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/10 flex items-center justify-center text-sm font-medium">
                        {message.sender?.full_name?.[0] || 'U'}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2 mb-1">
                          <span className="font-medium text-sm">
                            {message.sender?.full_name || 'Unknown User'}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {new Date(message.created_at).toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="text-sm">{message.content}</div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex gap-2">
                  <Input
                    placeholder="Type your message..."
                    value={newMessage}
                    onChange={(e) => setNewMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                  />
                  <Button onClick={sendMessage}>
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="text-center text-muted-foreground py-12">
                Select a group to start collaborating
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}