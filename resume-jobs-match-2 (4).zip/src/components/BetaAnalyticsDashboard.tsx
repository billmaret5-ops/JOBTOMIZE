import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { TrendingUp, Users, Activity, Target, Clock, CheckCircle } from 'lucide-react';
import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';

export default function BetaAnalyticsDashboard() {
  const [loading, setLoading] = useState(true);
  const [metrics, setMetrics] = useState({
    dailyActiveUsers: 0,
    weeklyActiveUsers: 0,
    avgSessionDuration: '0m',
    featureAdoption: 0,
    bugReports: 0,
    feedbackCount: 0
  });

  const [activityData, setActivityData] = useState([
    { date: 'Mon', users: 12, sessions: 45 },
    { date: 'Tue', users: 19, sessions: 67 },
    { date: 'Wed', users: 15, sessions: 52 },
    { date: 'Thu', users: 22, sessions: 78 },
    { date: 'Fri', users: 18, sessions: 61 },
    { date: 'Sat', users: 8, sessions: 23 },
    { date: 'Sun', users: 10, sessions: 31 }
  ]);

  const featureUsage = [
    { name: 'Job Search', value: 85, color: '#3b82f6' },
    { name: 'Resume Builder', value: 72, color: '#10b981' },
    { name: 'Email Campaigns', value: 58, color: '#f59e0b' },
    { name: 'Interview Prep', value: 45, color: '#8b5cf6' }
  ];

  const engagementData = [
    { metric: 'High', count: 45, color: '#10b981' },
    { metric: 'Medium', count: 32, color: '#f59e0b' },
    { metric: 'Low', count: 18, color: '#ef4444' }
  ];

  useEffect(() => {
    loadAnalytics();
  }, []);

  const loadAnalytics = async () => {
    try {
      const { data: accessData } = await supabase
        .from('beta_access')
        .select('*');

      setMetrics({
        dailyActiveUsers: accessData?.length || 0,
        weeklyActiveUsers: accessData?.length || 0,
        avgSessionDuration: '24m',
        featureAdoption: 68,
        bugReports: 12,
        feedbackCount: 34
      });
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Daily Active Users</p>
              <p className="text-3xl font-bold">{metrics.dailyActiveUsers}</p>
              <p className="text-xs text-green-500 mt-1">↑ 12% from yesterday</p>
            </div>
            <Users className="w-10 h-10 text-blue-500" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Avg Session</p>
              <p className="text-3xl font-bold">{metrics.avgSessionDuration}</p>
              <p className="text-xs text-green-500 mt-1">↑ 8% this week</p>
            </div>
            <Clock className="w-10 h-10 text-green-500" />
          </div>
        </Card>

        <Card className="p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-muted-foreground">Feature Adoption</p>
              <p className="text-3xl font-bold">{metrics.featureAdoption}%</p>
              <p className="text-xs text-green-500 mt-1">↑ 5% this week</p>
            </div>
            <Target className="w-10 h-10 text-purple-500" />
          </div>
        </Card>
      </div>

      <Tabs defaultValue="activity" className="space-y-4">
        <TabsList>
          <TabsTrigger value="activity">User Activity</TabsTrigger>
          <TabsTrigger value="features">Feature Usage</TabsTrigger>
          <TabsTrigger value="engagement">Engagement</TabsTrigger>
        </TabsList>

        <TabsContent value="activity">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Daily Activity Trends</h3>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={activityData}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Legend />
                <Line type="monotone" dataKey="users" stroke="#3b82f6" name="Active Users" />
                <Line type="monotone" dataKey="sessions" stroke="#10b981" name="Sessions" />
              </LineChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="features">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">Feature Adoption Rates</h3>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={featureUsage}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#3b82f6" />
              </BarChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>

        <TabsContent value="engagement">
          <Card className="p-6">
            <h3 className="text-lg font-semibold mb-4">User Engagement Levels</h3>
            <ResponsiveContainer width="100%" height={300}>
              <PieChart>
                <Pie data={engagementData} dataKey="count" nameKey="metric" cx="50%" cy="50%" outerRadius={100} label>
                  {engagementData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
                <Legend />
              </PieChart>
            </ResponsiveContainer>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
