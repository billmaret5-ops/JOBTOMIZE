import { useState, useEffect } from 'react';
import { Search, Filter, Download, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { exportToCSV, exportToJSON } from '@/lib/exportUtils';

interface FilterConfig {
  field: string;
  operator: string;
  value: string;
}

interface AdvancedFiltersProps {
  onSearch: (query: string) => void;
  onFilter: (filters: FilterConfig[]) => void;
  onSort: (field: string, direction: 'asc' | 'desc') => void;
  onExport: (format: 'csv' | 'json') => void;
  onSaveSearch: (name: string, config: any) => void;
  fields: { label: string; value: string; type: string }[];
  data?: any[];
}

export default function AdvancedFilters({
  onSearch, onFilter, onSort, onExport, onSaveSearch, fields, data = []
}: AdvancedFiltersProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [filters, setFilters] = useState<FilterConfig[]>([]);
  const [sortField, setSortField] = useState('');
  const [sortDir, setSortDir] = useState<'asc' | 'desc'>('asc');
  const [showFilters, setShowFilters] = useState(false);

  useEffect(() => {
    const timer = setTimeout(() => onSearch(searchQuery), 300);
    return () => clearTimeout(timer);
  }, [searchQuery, onSearch]);

  const addFilter = () => {
    setFilters([...filters, { field: fields[0].value, operator: 'equals', value: '' }]);
  };

  const updateFilter = (index: number, key: keyof FilterConfig, value: string) => {
    const newFilters = [...filters];
    newFilters[index][key] = value;
    setFilters(newFilters);
    onFilter(newFilters);
  };

  const removeFilter = (index: number) => {
    const newFilters = filters.filter((_, i) => i !== index);
    setFilters(newFilters);
    onFilter(newFilters);
  };

  const handleSort = (field: string) => {
    const newDir = field === sortField && sortDir === 'asc' ? 'desc' : 'asc';
    setSortField(field);
    setSortDir(newDir);
    onSort(field, newDir);
  };

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
          <Input
            placeholder="Search..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-10"
          />
        </div>
        <Button variant="outline" onClick={() => setShowFilters(!showFilters)}>
          <Filter className="h-4 w-4 mr-2" />
          Filters
        </Button>
        <Select onValueChange={(v) => onExport(v as 'csv' | 'json')}>
          <SelectTrigger className="w-32">
            <Download className="h-4 w-4 mr-2" />
            Export
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="csv">CSV</SelectItem>
            <SelectItem value="json">JSON</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {showFilters && (
        <div className="border rounded-lg p-4 space-y-3">
          {filters.map((filter, index) => (
            <div key={index} className="flex gap-2 items-center">
              <Select value={filter.field} onValueChange={(v) => updateFilter(index, 'field', v)}>
                <SelectTrigger className="w-40">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {fields.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
                </SelectContent>
              </Select>
              <Select value={filter.operator} onValueChange={(v) => updateFilter(index, 'operator', v)}>
                <SelectTrigger className="w-32">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="equals">Equals</SelectItem>
                  <SelectItem value="contains">Contains</SelectItem>
                  <SelectItem value="gt">Greater than</SelectItem>
                  <SelectItem value="lt">Less than</SelectItem>
                </SelectContent>
              </Select>
              <Input
                value={filter.value}
                onChange={(e) => updateFilter(index, 'value', e.target.value)}
                placeholder="Value"
                className="flex-1"
              />
              <Button variant="ghost" size="icon" onClick={() => removeFilter(index)}>
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}
          <Button variant="outline" onClick={addFilter}>Add Filter</Button>
        </div>
      )}

      <div className="flex gap-2 items-center">
        <span className="text-sm text-gray-600">Sort by:</span>
        <Select value={sortField} onValueChange={handleSort}>
          <SelectTrigger className="w-40">
            <SelectValue placeholder="Select field" />
          </SelectTrigger>
          <SelectContent>
            {fields.map(f => <SelectItem key={f.value} value={f.value}>{f.label}</SelectItem>)}
          </SelectContent>
        </Select>
        {sortField && (
          <Badge variant="secondary">{sortDir === 'asc' ? '↑' : '↓'}</Badge>
        )}
      </div>
    </div>
  );
}
