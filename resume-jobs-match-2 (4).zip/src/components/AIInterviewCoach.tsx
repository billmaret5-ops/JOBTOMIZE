import React, { useState, useEffect, useRef } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { 
  Mic, 
  Video, 
  Eye, 
  Brain, 
  TrendingUp, 
  AlertTriangle,
  CheckCircle,
  Volume2,
  Smile,
  MessageSquare
} from 'lucide-react';

interface AnalysisMetrics {
  speechClarity: number;
  voiceTone: number;
  confidence: number;
  eyeContact: number;
  bodyLanguage: number;
  facialExpression: number;
  pacing: number;
  filler_words: number;
}

interface CoachingTip {
  type: 'warning' | 'success' | 'info';
  category: string;
  message: string;
  timestamp: number;
}

export function AIInterviewCoach() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [metrics, setMetrics] = useState<AnalysisMetrics>({
    speechClarity: 85,
    voiceTone: 78,
    confidence: 72,
    eyeContact: 68,
    bodyLanguage: 80,
    facialExpression: 75,
    pacing: 82,
    filler_words: 15
  });
  
  const [realtimeTips, setRealtimeTips] = useState<CoachingTip[]>([]);
  const [overallScore, setOverallScore] = useState(76);
  const videoRef = useRef<HTMLVideoElement>(null);

  const startAnalysis = async () => {
    setIsAnalyzing(true);
    
    // Simulate real-time analysis updates
    const interval = setInterval(() => {
      setMetrics(prev => ({
        ...prev,
        confidence: Math.min(100, prev.confidence + Math.random() * 5 - 2),
        eyeContact: Math.min(100, prev.eyeContact + Math.random() * 4 - 1),
        voiceTone: Math.min(100, prev.voiceTone + Math.random() * 3 - 1)
      }));
      
      // Add random coaching tips
      if (Math.random() > 0.7) {
        const tips = [
          { type: 'info' as const, category: 'Eye Contact', message: 'Great eye contact! Keep looking at the camera.' },
          { type: 'warning' as const, category: 'Speech', message: 'Try to speak a bit slower for clarity.' },
          { type: 'success' as const, category: 'Confidence', message: 'Your confidence is showing through!' }
        ];
        const tip = tips[Math.floor(Math.random() * tips.length)];
        setRealtimeTips(prev => [...prev.slice(-4), { ...tip, timestamp: Date.now() }]);
      }
    }, 2000);

    setTimeout(() => {
      clearInterval(interval);
      setIsAnalyzing(false);
    }, 30000);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-green-600';
    if (score >= 60) return 'text-yellow-600';
    return 'text-red-600';
  };

  const getScoreLabel = (score: number) => {
    if (score >= 80) return 'Excellent';
    if (score >= 60) return 'Good';
    return 'Needs Improvement';
  };

  return (
    <div className="space-y-6">
      {/* Video Preview and Controls */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Video className="h-5 w-5" />
            Live Interview Analysis
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            <div className="lg:col-span-2">
              <div className="relative bg-gray-900 rounded-lg aspect-video">
                <video
                  ref={videoRef}
                  className="w-full h-full rounded-lg"
                  autoPlay
                  muted
                  playsInline
                />
                <div className="absolute top-4 left-4">
                  <Badge variant={isAnalyzing ? "default" : "secondary"}>
                    {isAnalyzing ? "Analyzing..." : "Ready"}
                  </Badge>
                </div>
                <div className="absolute top-4 right-4">
                  <div className={`text-2xl font-bold ${getScoreColor(overallScore)}`}>
                    {overallScore}%
                  </div>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button 
                  onClick={startAnalysis}
                  disabled={isAnalyzing}
                  className="flex-1"
                >
                  {isAnalyzing ? "Analyzing..." : "Start Analysis"}
                </Button>
                <Button variant="outline" disabled={!isAnalyzing}>
                  Stop
                </Button>
              </div>
            </div>
            
            {/* Real-time Tips */}
            <div>
              <h3 className="font-semibold mb-3">Real-time Coaching</h3>
              <div className="space-y-2 max-h-80 overflow-y-auto">
                {realtimeTips.map((tip, index) => (
                  <div
                    key={index}
                    className={`p-3 rounded-lg border-l-4 ${
                      tip.type === 'success' ? 'bg-green-50 border-green-400' :
                      tip.type === 'warning' ? 'bg-yellow-50 border-yellow-400' :
                      'bg-blue-50 border-blue-400'
                    }`}
                  >
                    <div className="flex items-start gap-2">
                      {tip.type === 'success' && <CheckCircle className="h-4 w-4 text-green-600 mt-0.5" />}
                      {tip.type === 'warning' && <AlertTriangle className="h-4 w-4 text-yellow-600 mt-0.5" />}
                      {tip.type === 'info' && <Brain className="h-4 w-4 text-blue-600 mt-0.5" />}
                      <div>
                        <div className="font-medium text-sm">{tip.category}</div>
                        <div className="text-sm text-gray-600">{tip.message}</div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Performance Metrics */}
      <Tabs defaultValue="metrics" className="w-full">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="metrics">Performance Metrics</TabsTrigger>
          <TabsTrigger value="analysis">Detailed Analysis</TabsTrigger>
          <TabsTrigger value="recommendations">Recommendations</TabsTrigger>
        </TabsList>
        
        <TabsContent value="metrics" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Mic className="h-4 w-4 text-blue-600" />
                  <span className="font-medium">Speech Clarity</span>
                </div>
                <div className="text-2xl font-bold mb-1">{metrics.speechClarity}%</div>
                <Progress value={metrics.speechClarity} className="h-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Volume2 className="h-4 w-4 text-purple-600" />
                  <span className="font-medium">Voice Tone</span>
                </div>
                <div className="text-2xl font-bold mb-1">{metrics.voiceTone}%</div>
                <Progress value={metrics.voiceTone} className="h-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-4 w-4 text-green-600" />
                  <span className="font-medium">Confidence</span>
                </div>
                <div className="text-2xl font-bold mb-1">{metrics.confidence}%</div>
                <Progress value={metrics.confidence} className="h-2" />
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-4">
                <div className="flex items-center gap-2 mb-2">
                  <Eye className="h-4 w-4 text-orange-600" />
                  <span className="font-medium">Eye Contact</span>
                </div>
                <div className="text-2xl font-bold mb-1">{metrics.eyeContact}%</div>
                <Progress value={metrics.eyeContact} className="h-2" />
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="analysis" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <MessageSquare className="h-5 w-5" />
                  Speech Analysis
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Speaking Pace</span>
                  <span className="font-medium">{metrics.pacing}% Optimal</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Filler Words</span>
                  <span className="font-medium">{metrics.filler_words} per minute</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Voice Modulation</span>
                  <Badge variant="outline">Good</Badge>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <Smile className="h-5 w-5" />
                  Non-verbal Communication
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="flex justify-between items-center">
                  <span>Facial Expression</span>
                  <span className="font-medium">{metrics.facialExpression}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Body Language</span>
                  <span className="font-medium">{metrics.bodyLanguage}%</span>
                </div>
                <div className="flex justify-between items-center">
                  <span>Posture</span>
                  <Badge variant="outline">Professional</Badge>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
        
        <TabsContent value="recommendations" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="text-green-600">Strengths</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Clear Speech</div>
                    <div className="text-sm text-gray-600">Your articulation is excellent</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <CheckCircle className="h-5 w-5 text-green-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Professional Posture</div>
                    <div className="text-sm text-gray-600">Maintaining good body language</div>
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader>
                <CardTitle className="text-orange-600">Areas for Improvement</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Eye Contact</div>
                    <div className="text-sm text-gray-600">Look directly at the camera more often</div>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <AlertTriangle className="h-5 w-5 text-orange-600 mt-0.5" />
                  <div>
                    <div className="font-medium">Confidence Level</div>
                    <div className="text-sm text-gray-600">Practice power poses before interviews</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
}