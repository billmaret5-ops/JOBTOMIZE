import React, { useState } from 'react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import EmailProviderConfiguration from './EmailProviderConfiguration';
import ProviderHealthMonitor from './ProviderHealthMonitor';
import APIKeyManager from './APIKeyManager';
import RealTimeProviderDashboard from './RealTimeProviderDashboard';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Settings, Activity, Key, BarChart3 } from 'lucide-react';

export default function EmailIntegrationDashboard() {
  const [activeTab, setActiveTab] = useState('overview');

  return (
    <div className="container mx-auto p-6 space-y-6">
      <div>
        <h1 className="text-3xl font-bold mb-2">Email Provider Integration</h1>
        <p className="text-muted-foreground">Manage multiple email service providers with automatic failover and load balancing</p>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="overview" className="flex items-center gap-2"><Activity className="w-4 h-4" />Overview</TabsTrigger>
          <TabsTrigger value="providers" className="flex items-center gap-2"><Settings className="w-4 h-4" />Providers</TabsTrigger>
          <TabsTrigger value="keys" className="flex items-center gap-2"><Key className="w-4 h-4" />API Keys</TabsTrigger>
          <TabsTrigger value="analytics" className="flex items-center gap-2"><BarChart3 className="w-4 h-4" />Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <RealTimeProviderDashboard />
        </TabsContent>

        <TabsContent value="providers" className="space-y-6">
          <div className="grid gap-6 md:grid-cols-2">
            <EmailProviderConfiguration />
            <ProviderHealthMonitor />
          </div>
        </TabsContent>

        <TabsContent value="keys" className="space-y-6">
          <APIKeyManager />
        </TabsContent>

        <TabsContent value="analytics" className="space-y-6">
          <Card>
            <CardHeader><CardTitle>Provider Performance Analytics</CardTitle></CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="p-4 border rounded-lg">
                    <p className="text-sm text-muted-foreground">Total Emails Sent</p>
                    <p className="text-3xl font-bold">125,432</p>
                    <p className="text-xs text-green-500">+12% from last month</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p className="text-sm text-muted-foreground">Delivery Rate</p>
                    <p className="text-3xl font-bold">98.7%</p>
                    <p className="text-xs text-green-500">+0.3% from last month</p>
                  </div>
                  <div className="p-4 border rounded-lg">
                    <p className="text-sm text-muted-foreground">Avg Response Time</p>
                    <p className="text-3xl font-bold">245ms</p>
                    <p className="text-xs text-green-500">-15ms from last month</p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
