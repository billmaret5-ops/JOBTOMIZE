import { useState } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Switch } from '@/components/ui/switch';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Zap, Plus, Edit, Trash2 } from 'lucide-react';

interface AutomationRule {
  id: string;
  name: string;
  trigger: { type: string; value: string };
  action: { type: string; value: string };
  isActive: boolean;
  matchCount: number;
}

export default function EmailAutomationRules() {
  const [rules, setRules] = useState<AutomationRule[]>([
    {
      id: '1',
      name: 'Auto-create from sent applications',
      trigger: { type: 'subject_contains', value: 'application' },
      action: { type: 'create_application', value: 'auto' },
      isActive: true,
      matchCount: 15
    },
    {
      id: '2',
      name: 'Interview invite detection',
      trigger: { type: 'subject_contains', value: 'interview' },
      action: { type: 'update_status', value: 'interviewing' },
      isActive: true,
      matchCount: 8
    }
  ]);

  const [showDialog, setShowDialog] = useState(false);

  const toggleRule = (id: string) => {
    setRules(rules.map(r => r.id === id ? { ...r, isActive: !r.isActive } : r));
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h2 className="text-2xl font-bold">Automation Rules</h2>
          <p className="text-muted-foreground">Auto-process emails based on rules</p>
        </div>
        <Button onClick={() => setShowDialog(true)}>
          <Plus className="h-4 w-4 mr-2" />
          New Rule
        </Button>
      </div>

      <div className="space-y-3">
        {rules.map((rule) => (
          <Card key={rule.id} className="p-6">
            <div className="flex items-start justify-between">
              <div className="flex items-start gap-4 flex-1">
                <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                  <Zap className="h-5 w-5 text-purple-600" />
                </div>
                <div className="flex-1">
                  <div className="flex items-center gap-3 mb-2">
                    <h3 className="font-semibold">{rule.name}</h3>
                    <Badge variant={rule.isActive ? 'default' : 'secondary'}>
                      {rule.isActive ? 'Active' : 'Paused'}
                    </Badge>
                  </div>
                  <div className="space-y-1 text-sm">
                    <p className="text-muted-foreground">
                      <strong>When:</strong> {rule.trigger.type.replace('_', ' ')} "{rule.trigger.value}"
                    </p>
                    <p className="text-muted-foreground">
                      <strong>Then:</strong> {rule.action.type.replace('_', ' ')}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      Matched {rule.matchCount} emails
                    </p>
                  </div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Switch checked={rule.isActive} onCheckedChange={() => toggleRule(rule.id)} />
                <Button variant="ghost" size="sm">
                  <Edit className="h-4 w-4" />
                </Button>
                <Button variant="ghost" size="sm">
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </div>
          </Card>
        ))}
      </div>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Create Automation Rule</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <Label>Rule Name</Label>
              <Input placeholder="e.g., Auto-detect rejections" />
            </div>
            <div>
              <Label>Trigger Type</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select trigger" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="subject_contains">Subject contains</SelectItem>
                  <SelectItem value="from_domain">From domain</SelectItem>
                  <SelectItem value="body_contains">Body contains</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Trigger Value</Label>
              <Input placeholder="e.g., interview, rejection" />
            </div>
            <div>
              <Label>Action</Label>
              <Select>
                <SelectTrigger>
                  <SelectValue placeholder="Select action" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="create_application">Create application</SelectItem>
                  <SelectItem value="update_status">Update status</SelectItem>
                  <SelectItem value="set_reminder">Set reminder</SelectItem>
                  <SelectItem value="add_tag">Add tag</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setShowDialog(false)}>Cancel</Button>
              <Button onClick={() => setShowDialog(false)}>Create Rule</Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
}
