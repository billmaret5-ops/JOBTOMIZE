import { useState, useEffect } from 'react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Copy, Mail, Users, Trash2, RefreshCw, Check } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { supabase } from '@/lib/supabase';

interface Invite {
  id: string;
  code: string;
  email: string | null;
  max_uses: number;
  current_uses: number;
  status: string;
  created_at: string;
  expires_at: string | null;
}

export default function BetaInviteSystem() {
  const [invites, setInvites] = useState<Invite[]>([]);
  const [email, setEmail] = useState('');
  const [maxUses, setMaxUses] = useState(1);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState<string | null>(null);
  const { toast } = useToast();

  useEffect(() => {
    loadInvites();
  }, []);

  const loadInvites = async () => {
    try {
      const { data, error } = await supabase
        .from('beta_invites')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) throw error;
      setInvites(data || []);
    } catch (error) {
      console.error('Error loading invites:', error);
    }
  };

  const generateInvite = async () => {
    setLoading(true);
    try {
      const code = `BETA-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      const { data: { user } } = await supabase.auth.getUser();
      
      const { error } = await supabase.from('beta_invites').insert({
        code,
        email: email || null,
        max_uses: maxUses,
        current_uses: 0,
        status: 'active',
        created_by: user?.id
      });

      if (error) throw error;

      toast({
        title: 'Invite Generated',
        description: `Code: ${code}`,
      });

      setEmail('');
      setMaxUses(1);
      loadInvites();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    } finally {
      setLoading(false);
    }
  };

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(code);
    setTimeout(() => setCopied(null), 2000);
    toast({
      title: 'Copied!',
      description: 'Invite code copied to clipboard'
    });
  };

  const revokeInvite = async (id: string) => {
    try {
      const { error } = await supabase
        .from('beta_invites')
        .update({ status: 'revoked' })
        .eq('id', id);

      if (error) throw error;
      
      toast({
        title: 'Invite Revoked',
        description: 'The invite code has been revoked'
      });
      
      loadInvites();
    } catch (error: any) {
      toast({
        title: 'Error',
        description: error.message,
        variant: 'destructive'
      });
    }
  };

  return (
    <div className="space-y-6">
      <Card className="p-6">
        <h2 className="text-2xl font-bold mb-4">Generate Beta Invite</h2>
        <div className="space-y-4">
          <Input
            placeholder="Email (optional)"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            type="number"
            min="1"
            placeholder="Max uses"
            value={maxUses}
            onChange={(e) => setMaxUses(Number(e.target.value))}
          />
          <Button onClick={generateInvite} className="w-full" disabled={loading}>
            <Mail className="w-4 h-4 mr-2" />
            {loading ? 'Generating...' : 'Generate Invite Code'}
          </Button>
        </div>
      </Card>

      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold">Active Invites ({invites.length})</h3>
        <Button variant="outline" size="sm" onClick={loadInvites}>
          <RefreshCw className="w-4 h-4 mr-2" />
          Refresh
        </Button>
      </div>

      <div className="grid gap-4">
        {invites.map((invite) => (
          <Card key={invite.id} className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-2">
                  <code className="text-lg font-mono font-bold">{invite.code}</code>
                  <Button 
                    size="sm" 
                    variant="ghost" 
                    onClick={() => copyCode(invite.code)}
                  >
                    {copied === invite.code ? (
                      <Check className="w-4 h-4 text-green-500" />
                    ) : (
                      <Copy className="w-4 h-4" />
                    )}
                  </Button>
                </div>
                {invite.email && (
                  <p className="text-sm text-muted-foreground mb-2">{invite.email}</p>
                )}
                <div className="flex items-center gap-4 text-sm">
                  <span className="flex items-center gap-1">
                    <Users className="w-4 h-4" />
                    {invite.current_uses}/{invite.max_uses} uses
                  </span>
                  <span className="text-muted-foreground">
                    Created {new Date(invite.created_at).toLocaleDateString()}
                  </span>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Badge variant={invite.status === 'active' ? 'default' : 'secondary'}>
                  {invite.status}
                </Badge>
                {invite.status === 'active' && (
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => revokeInvite(invite.id)}
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                )}
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}