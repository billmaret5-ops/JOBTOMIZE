import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { CheckCircle2, XCircle, AlertCircle, Loader2 } from 'lucide-react';

interface TestResult {
  name: string;
  status: 'success' | 'error' | 'warning' | 'loading';
  message: string;
  details?: any;
}

export default function DatabaseConnectionTest() {
  const [results, setResults] = useState<TestResult[]>([]);
  const [testing, setTesting] = useState(false);

  const updateResult = (name: string, status: TestResult['status'], message: string, details?: any) => {
    setResults(prev => {
      const filtered = prev.filter(r => r.name !== name);
      return [...filtered, { name, status, message, details }];
    });
  };

  const runTests = async () => {
    setTesting(true);
    setResults([]);

    // Test 1: Check Supabase Configuration
    updateResult('config', 'loading', 'Checking configuration...');
    try {
      const url = import.meta.env.VITE_SUPABASE_URL;
      const key = import.meta.env.VITE_SUPABASE_ANON_KEY;
      
      if (!url || !key) {
        updateResult('config', 'error', 'Missing environment variables', { url: !!url, key: !!key });
      } else {
        updateResult('config', 'success', 'Configuration loaded', {
          url: url.substring(0, 30) + '...',
          keyLength: key.length
        });
      }
    } catch (error: any) {
      updateResult('config', 'error', 'Configuration error', error.message);
    }

    // Test 2: Check Auth State
    updateResult('auth', 'loading', 'Checking authentication...');
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (error) throw error;
      
      if (session) {
        updateResult('auth', 'success', 'User authenticated', {
          userId: session.user.id,
          email: session.user.email
        });
      } else {
        updateResult('auth', 'warning', 'No active session', { message: 'User not logged in' });
      }
    } catch (error: any) {
      updateResult('auth', 'error', 'Auth check failed', error.message);
    }

    // Test 3: Database Connection
    updateResult('connection', 'loading', 'Testing database connection...');
    try {
      const { data, error } = await supabase.from('user_profiles').select('count', { count: 'exact', head: true });
      if (error) throw error;
      updateResult('connection', 'success', 'Database connected', { message: 'Query executed successfully' });
    } catch (error: any) {
      updateResult('connection', 'error', 'Connection failed', error.message);
    }

    // Test 4: RLS Policies Check
    updateResult('rls', 'loading', 'Checking RLS policies...');
    try {
      const { data, error } = await supabase.from('user_profiles').select('*').limit(1);
      if (error) {
        if (error.message.includes('RLS') || error.message.includes('policy')) {
          updateResult('rls', 'warning', 'RLS policy restriction', error.message);
        } else {
          throw error;
        }
      } else {
        updateResult('rls', 'success', 'RLS policies working', { rowsReturned: data?.length || 0 });
      }
    } catch (error: any) {
      updateResult('rls', 'error', 'RLS check failed', error.message);
    }

    setTesting(false);
  };

  useEffect(() => {
    runTests();
  }, []);

  const getIcon = (status: TestResult['status']) => {
    switch (status) {
      case 'success': return <CheckCircle2 className="w-5 h-5 text-green-500" />;
      case 'error': return <XCircle className="w-5 h-5 text-red-500" />;
      case 'warning': return <AlertCircle className="w-5 h-5 text-yellow-500" />;
      case 'loading': return <Loader2 className="w-5 h-5 text-blue-500 animate-spin" />;
    }
  };

  const getStatusBadge = (status: TestResult['status']) => {
    const variants: any = {
      success: 'default',
      error: 'destructive',
      warning: 'secondary',
      loading: 'outline'
    };
    return <Badge variant={variants[status]}>{status}</Badge>;
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center justify-between">
            <span>Database Connection Diagnostics</span>
            <Button onClick={runTests} disabled={testing}>
              {testing ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : null}
              Run Tests
            </Button>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {results.map((result) => (
            <div key={result.name} className="border rounded-lg p-4">
              <div className="flex items-start justify-between mb-2">
                <div className="flex items-center gap-3">
                  {getIcon(result.status)}
                  <div>
                    <h3 className="font-semibold capitalize">{result.name}</h3>
                    <p className="text-sm text-muted-foreground">{result.message}</p>
                  </div>
                </div>
                {getStatusBadge(result.status)}
              </div>
              {result.details && (
                <pre className="mt-2 p-2 bg-muted rounded text-xs overflow-auto">
                  {JSON.stringify(result.details, null, 2)}
                </pre>
              )}
            </div>
          ))}
        </CardContent>
      </Card>
    </div>
  );
}
