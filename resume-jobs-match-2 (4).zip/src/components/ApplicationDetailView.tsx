import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription } from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Card, CardContent } from '@/components/ui/card';
import { ApplicationLifecycleTimeline } from './ApplicationLifecycleTimeline';
import { ApplicationReminderManager } from './ApplicationReminderManager';
import { ApplicationNotes } from './ApplicationNotes';
import { ExternalLink, MapPin, DollarSign, Calendar, Edit, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { supabase } from '@/lib/supabase';

interface ApplicationDetailViewProps {
  application: any;
  open: boolean;
  onClose: () => void;
  onEdit: () => void;
  onDelete: () => void;
}

export function ApplicationDetailView({ application, open, onClose, onEdit, onDelete }: ApplicationDetailViewProps) {
  const [notes, setNotes] = useState(application?.notes || []);

  if (!application) return null;

  const handleDelete = async () => {
    if (confirm('Are you sure you want to delete this application?')) {
      const { error } = await supabase
        .from('job_applications')
        .delete()
        .eq('id', application.id);

      if (error) {
        toast.error('Failed to delete application');
      } else {
        toast.success('Application deleted');
        onDelete();
        onClose();
      }
    }
  };

  const statusColors = {
    saved: 'bg-gray-100 text-gray-800',
    applied: 'bg-blue-100 text-blue-800',
    interviewing: 'bg-yellow-100 text-yellow-800',
    offer: 'bg-green-100 text-green-800',
    rejected: 'bg-red-100 text-red-800'
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center justify-between">
            <div>
              <h2 className="text-2xl font-bold">{application.job_title}</h2>
              <p className="text-lg text-gray-600">{application.company_name}</p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" variant="outline" onClick={onEdit}>
                <Edit className="w-4 h-4 mr-1" />
                Edit
              </Button>
              <Button size="sm" variant="destructive" onClick={handleDelete}>
                <Trash2 className="w-4 h-4 mr-1" />
                Delete
              </Button>
            </div>
          </DialogTitle>
          <DialogDescription>
            View complete details, timeline, notes, and reminders for this job application
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-wrap gap-4">
                <Badge className={statusColors[application.status as keyof typeof statusColors]}>
                  {application.status.toUpperCase()}
                </Badge>
                {application.priority && (
                  <Badge variant={application.priority === 'high' ? 'destructive' : 'secondary'}>
                    {application.priority.toUpperCase()} PRIORITY
                  </Badge>
                )}
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                {application.location && (
                  <div className="flex items-center gap-2 text-sm">
                    <MapPin className="w-4 h-4 text-gray-500" />
                    <span>{application.location}</span>
                  </div>
                )}
                {application.salary_range && (
                  <div className="flex items-center gap-2 text-sm">
                    <DollarSign className="w-4 h-4 text-gray-500" />
                    <span>{application.salary_range}</span>
                  </div>
                )}
                {application.applied_date && (
                  <div className="flex items-center gap-2 text-sm">
                    <Calendar className="w-4 h-4 text-gray-500" />
                    <span>Applied: {new Date(application.applied_date).toLocaleDateString()}</span>
                  </div>
                )}
                {application.job_url && (
                  <a href={application.job_url} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-sm text-blue-600 hover:underline">
                    <ExternalLink className="w-4 h-4" />
                    <span>View Job Posting</span>
                  </a>
                )}
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="timeline" className="w-full">
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="timeline">Timeline</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
              <TabsTrigger value="reminders">Reminders</TabsTrigger>
            </TabsList>

            <TabsContent value="timeline" className="mt-4">
              <ApplicationLifecycleTimeline application={application} />
            </TabsContent>

            <TabsContent value="notes" className="mt-4">
              <ApplicationNotes
                applicationId={application.id}
                notes={notes}
                onNotesUpdate={setNotes}
              />
            </TabsContent>

            <TabsContent value="reminders" className="mt-4">
              <ApplicationReminderManager applicationId={application.id} />
            </TabsContent>
          </Tabs>
        </div>
      </DialogContent>
    </Dialog>
  );
}