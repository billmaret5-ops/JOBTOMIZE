import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Badge } from '@/components/ui/badge';
import { Calendar, Trash2, Save, Plus } from 'lucide-react';
import { supabase } from '@/lib/supabase';
import { RetentionPolicy } from '@/services/backupVersioningService';

export function BackupRetentionPolicyManager() {
  const [policies, setPolicies] = useState<RetentionPolicy[]>([]);
  const [editingPolicy, setEditingPolicy] = useState<Partial<RetentionPolicy>>({
    name: '',
    keep_daily: 7,
    keep_weekly: 4,
    keep_monthly: 12,
    keep_yearly: 5,
    keep_tagged: true
  });
  const [isCreating, setIsCreating] = useState(false);

  useEffect(() => {
    loadPolicies();
  }, []);

  const loadPolicies = async () => {
    const { data } = await supabase
      .from('retention_policies')
      .select('*')
      .order('created_at', { ascending: false });
    setPolicies(data || []);
  };

  const handleSave = async () => {
    if (!editingPolicy.name) return;

    const { error } = await supabase
      .from('retention_policies')
      .insert(editingPolicy);

    if (!error) {
      loadPolicies();
      setEditingPolicy({
        name: '',
        keep_daily: 7,
        keep_weekly: 4,
        keep_monthly: 12,
        keep_yearly: 5,
        keep_tagged: true
      });
      setIsCreating(false);
    }
  };

  const handleDelete = async (id: string) => {
    await supabase.from('retention_policies').delete().eq('id', id);
    loadPolicies();
  };

  return (
    <Card className="p-6">
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-semibold">Retention Policies</h3>
        <Button onClick={() => setIsCreating(true)} size="sm">
          <Plus className="w-4 h-4 mr-2" />
          New Policy
        </Button>
      </div>

      {isCreating && (
        <Card className="p-4 mb-4 bg-blue-50">
          <h4 className="font-semibold mb-4">Create Retention Policy</h4>
          
          <div className="space-y-4">
            <div>
              <Label>Policy Name</Label>
              <Input
                value={editingPolicy.name}
                onChange={(e) => setEditingPolicy({ ...editingPolicy, name: e.target.value })}
                placeholder="e.g., Standard Retention"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <Label>Keep Daily Backups</Label>
                <Input
                  type="number"
                  value={editingPolicy.keep_daily}
                  onChange={(e) => setEditingPolicy({ ...editingPolicy, keep_daily: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <Label>Keep Weekly Backups</Label>
                <Input
                  type="number"
                  value={editingPolicy.keep_weekly}
                  onChange={(e) => setEditingPolicy({ ...editingPolicy, keep_weekly: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <Label>Keep Monthly Backups</Label>
                <Input
                  type="number"
                  value={editingPolicy.keep_monthly}
                  onChange={(e) => setEditingPolicy({ ...editingPolicy, keep_monthly: parseInt(e.target.value) })}
                />
              </div>
              <div>
                <Label>Keep Yearly Backups</Label>
                <Input
                  type="number"
                  value={editingPolicy.keep_yearly}
                  onChange={(e) => setEditingPolicy({ ...editingPolicy, keep_yearly: parseInt(e.target.value) })}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <Label>Keep Tagged Backups Forever</Label>
              <Switch
                checked={editingPolicy.keep_tagged}
                onCheckedChange={(checked) => setEditingPolicy({ ...editingPolicy, keep_tagged: checked })}
              />
            </div>

            <div className="flex gap-2">
              <Button onClick={handleSave} className="flex-1">
                <Save className="w-4 h-4 mr-2" />
                Save Policy
              </Button>
              <Button onClick={() => setIsCreating(false)} variant="outline">
                Cancel
              </Button>
            </div>
          </div>
        </Card>
      )}

      <div className="space-y-3">
        {policies.map((policy) => (
          <Card key={policy.id} className="p-4">
            <div className="flex items-start justify-between mb-3">
              <div>
                <h4 className="font-semibold">{policy.name}</h4>
                {policy.keep_tagged && (
                  <Badge variant="secondary" className="text-xs mt-1">
                    Keeps tagged backups
                  </Badge>
                )}
              </div>
              <Button
                size="sm"
                variant="ghost"
                onClick={() => handleDelete(policy.id)}
              >
                <Trash2 className="w-4 h-4" />
              </Button>
            </div>

            <div className="grid grid-cols-4 gap-3 text-sm">
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="font-medium">{policy.keep_daily}</div>
                  <div className="text-gray-600 text-xs">Daily</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="font-medium">{policy.keep_weekly}</div>
                  <div className="text-gray-600 text-xs">Weekly</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="font-medium">{policy.keep_monthly}</div>
                  <div className="text-gray-600 text-xs">Monthly</div>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <Calendar className="w-4 h-4 text-gray-500" />
                <div>
                  <div className="font-medium">{policy.keep_yearly}</div>
                  <div className="text-gray-600 text-xs">Yearly</div>
                </div>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {policies.length === 0 && !isCreating && (
        <div className="text-center py-8 text-gray-500">
          No retention policies configured
        </div>
      )}
    </Card>
  );
}
