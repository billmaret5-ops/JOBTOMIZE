import React, { useState } from 'react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from './ui/dialog';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Card, CardContent } from './ui/card';
import { Plus, X, Eye, Code, Palette, Type } from 'lucide-react';

interface EmailBuilderModalProps {
  template: any;
  onSave: (templateData: any) => void;
  onClose: () => void;
}

const personalizationTokens = [
  { token: '{{first_name}}', description: 'Candidate first name' },
  { token: '{{last_name}}', description: 'Candidate last name' },
  { token: '{{position}}', description: 'Job position title' },
  { token: '{{company}}', description: 'Company name' },
  { token: '{{hiring_manager}}', description: 'Hiring manager name' },
  { token: '{{interviewer}}', description: 'Interviewer name' },
  { token: '{{interview_date}}', description: 'Interview date' },
  { token: '{{application_date}}', description: 'Application submission date' }
];

const emailComponents = [
  { type: 'text', label: 'Text Block', icon: Type },
  { type: 'button', label: 'Call-to-Action Button', icon: Plus },
  { type: 'divider', label: 'Divider', icon: Code },
  { type: 'image', label: 'Image', icon: Palette }
];

export const EmailBuilderModal: React.FC<EmailBuilderModalProps> = ({
  template,
  onSave,
  onClose
}) => {
  const [formData, setFormData] = useState({
    name: template?.name || '',
    subject: template?.subject || '',
    category: template?.category || 'follow-up',
    content: template?.content || ''
  });
  const [activeTab, setActiveTab] = useState('design');
  const [showPreview, setShowPreview] = useState(false);

  const handleSave = () => {
    onSave(formData);
  };

  const insertToken = (token: string) => {
    const textarea = document.getElementById('email-content') as HTMLTextAreaElement;
    if (textarea) {
      const start = textarea.selectionStart;
      const end = textarea.selectionEnd;
      const text = formData.content;
      const newText = text.substring(0, start) + token + text.substring(end);
      setFormData(prev => ({ ...prev, content: newText }));
      
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(start + token.length, start + token.length);
      }, 0);
    }
  };

  const addComponent = (componentType: string) => {
    let componentHtml = '';
    switch (componentType) {
      case 'text':
        componentHtml = '<p>Your text here...</p>';
        break;
      case 'button':
        componentHtml = '<div style="text-align: center; margin: 20px 0;"><a href="#" style="background-color: #3B82F6; color: white; padding: 12px 24px; text-decoration: none; border-radius: 6px; display: inline-block;">Call to Action</a></div>';
        break;
      case 'divider':
        componentHtml = '<hr style="border: none; border-top: 1px solid #E5E7EB; margin: 20px 0;">';
        break;
      case 'image':
        componentHtml = '<div style="text-align: center; margin: 20px 0;"><img src="https://via.placeholder.com/300x150" alt="Image" style="max-width: 100%; height: auto;"></div>';
        break;
    }
    setFormData(prev => ({ ...prev, content: prev.content + '\n' + componentHtml }));
  };

  const previewContent = formData.content
    .replace(/{{first_name}}/g, 'John')
    .replace(/{{last_name}}/g, 'Doe')
    .replace(/{{position}}/g, 'Software Engineer')
    .replace(/{{company}}/g, 'TechCorp Inc.')
    .replace(/{{hiring_manager}}/g, 'Sarah Johnson')
    .replace(/{{interviewer}}/g, 'Mike Smith')
    .replace(/{{interview_date}}/g, 'March 15, 2024')
    .replace(/{{application_date}}/g, 'March 1, 2024');

  return (
    <Dialog open onOpenChange={onClose}>
      <DialogContent className="max-w-6xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle>
            {template ? 'Edit Email Template' : 'Create New Email Template'}
          </DialogTitle>
        </DialogHeader>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[70vh]">
          <div className="lg:col-span-2">
            <Tabs value={activeTab} onValueChange={setActiveTab}>
              <TabsList className="grid w-full grid-cols-3">
                <TabsTrigger value="design">Design</TabsTrigger>
                <TabsTrigger value="content">Content</TabsTrigger>
                <TabsTrigger value="preview">Preview</TabsTrigger>
              </TabsList>

              <TabsContent value="design" className="space-y-4 mt-4">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <Label htmlFor="template-name">Template Name</Label>
                    <Input
                      id="template-name"
                      value={formData.name}
                      onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                      placeholder="Enter template name"
                    />
                  </div>
                  <div>
                    <Label htmlFor="category">Category</Label>
                    <Select value={formData.category} onValueChange={(value) => setFormData(prev => ({ ...prev, category: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="follow-up">Follow-up</SelectItem>
                        <SelectItem value="interview">Interview</SelectItem>
                        <SelectItem value="outreach">Outreach</SelectItem>
                        <SelectItem value="thank-you">Thank You</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div>
                  <Label htmlFor="subject">Subject Line</Label>
                  <Input
                    id="subject"
                    value={formData.subject}
                    onChange={(e) => setFormData(prev => ({ ...prev, subject: e.target.value }))}
                    placeholder="Enter email subject"
                  />
                </div>

                <div>
                  <Label>Add Components</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {emailComponents.map((component) => (
                      <Button
                        key={component.type}
                        variant="outline"
                        size="sm"
                        onClick={() => addComponent(component.type)}
                        className="justify-start"
                      >
                        <component.icon className="w-4 h-4 mr-2" />
                        {component.label}
                      </Button>
                    ))}
                  </div>
                </div>
              </TabsContent>

              <TabsContent value="content" className="mt-4">
                <div>
                  <Label htmlFor="email-content">Email Content</Label>
                  <Textarea
                    id="email-content"
                    value={formData.content}
                    onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                    placeholder="Enter your email content here..."
                    className="min-h-[400px] font-mono text-sm"
                  />
                </div>
              </TabsContent>

              <TabsContent value="preview" className="mt-4">
                <Card>
                  <CardContent className="p-6">
                    <div className="border-b pb-4 mb-4">
                      <div className="text-sm text-gray-600">Subject:</div>
                      <div className="font-semibold">{formData.subject.replace(/{{(\w+)}}/g, (match, token) => {
                        const replacements: { [key: string]: string } = {
                          'first_name': 'John',
                          'last_name': 'Doe',
                          'position': 'Software Engineer',
                          'company': 'TechCorp Inc.'
                        };
                        return replacements[token] || match;
                      })}</div>
                    </div>
                    <div 
                      className="prose max-w-none"
                      dangerouslySetInnerHTML={{ __html: previewContent }}
                    />
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="font-semibold mb-3">Personalization Tokens</h3>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {personalizationTokens.map((token) => (
                  <div
                    key={token.token}
                    className="p-2 border rounded-lg cursor-pointer hover:bg-gray-50"
                    onClick={() => insertToken(token.token)}
                  >
                    <div className="font-mono text-sm text-blue-600">{token.token}</div>
                    <div className="text-xs text-gray-600">{token.description}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={onClose}>
            Cancel
          </Button>
          <div className="space-x-2">
            <Button variant="outline" onClick={() => setActiveTab('preview')}>
              <Eye className="w-4 h-4 mr-2" />
              Preview
            </Button>
            <Button onClick={handleSave} className="bg-blue-600 hover:bg-blue-700">
              Save Template
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
};