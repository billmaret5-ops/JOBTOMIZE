import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Settings, Shield, Clock, AlertTriangle } from 'lucide-react';
import { supabase } from '@/lib/supabase';

interface AuditConfig {
  id: string;
  retention_days: number;
  log_levels: string[];
  tracked_actions: string[];
  compliance_enabled: boolean;
  real_time_alerts: boolean;
  export_format: string;
}

export function AuditConfigurationManager() {
  const [config, setConfig] = useState<AuditConfig | null>(null);
  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  const defaultActions = ['create', 'update', 'delete', 'login', 'logout', 'permission_change'];
  const defaultLevels = ['info', 'warning', 'error', 'critical'];

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('audit_configurations')
        .select('*')
        .single();

      if (error && error.code !== 'PGRST116') throw error;
      
      if (data) {
        setConfig(data);
      } else {
        // Create default config
        const defaultConfig = {
          retention_days: 2555,
          log_levels: defaultLevels,
          tracked_actions: defaultActions,
          compliance_enabled: true,
          real_time_alerts: false,
          export_format: 'json'
        };
        setConfig(defaultConfig as AuditConfig);
      }
    } catch (error) {
      console.error('Error fetching config:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveConfig = async () => {
    if (!config) return;
    
    setSaving(true);
    try {
      const { error } = await supabase
        .from('audit_configurations')
        .upsert({
          tenant_id: 'current-tenant-id', // Replace with actual tenant ID
          ...config,
          updated_at: new Date().toISOString()
        });

      if (error) throw error;
    } catch (error) {
      console.error('Error saving config:', error);
    } finally {
      setSaving(false);
    }
  };

  const toggleAction = (action: string) => {
    if (!config) return;
    
    const updatedActions = config.tracked_actions.includes(action)
      ? config.tracked_actions.filter(a => a !== action)
      : [...config.tracked_actions, action];
    
    setConfig({ ...config, tracked_actions: updatedActions });
  };

  const toggleLogLevel = (level: string) => {
    if (!config) return;
    
    const updatedLevels = config.log_levels.includes(level)
      ? config.log_levels.filter(l => l !== level)
      : [...config.log_levels, level];
    
    setConfig({ ...config, log_levels: updatedLevels });
  };

  if (loading || !config) {
    return <div className="flex justify-center p-8">Loading configuration...</div>;
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Settings className="w-5 h-5" />
            Audit Configuration
          </CardTitle>
          <CardDescription>
            Configure audit logging settings, retention policies, and compliance options
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="retention">Data Retention (days)</Label>
                <Input
                  id="retention"
                  type="number"
                  value={config.retention_days}
                  onChange={(e) => setConfig({ ...config, retention_days: parseInt(e.target.value) })}
                  className="mt-1"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Default: 2555 days (7 years) for compliance
                </p>
              </div>

              <div>
                <Label>Export Format</Label>
                <Select 
                  value={config.export_format} 
                  onValueChange={(value) => setConfig({ ...config, export_format: value })}
                >
                  <SelectTrigger className="mt-1">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="json">JSON</SelectItem>
                    <SelectItem value="csv">CSV</SelectItem>
                    <SelectItem value="xml">XML</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label className="flex items-center gap-2">
                    <Shield className="w-4 h-4" />
                    Compliance Mode
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Enhanced logging for regulatory compliance
                  </p>
                </div>
                <Switch
                  checked={config.compliance_enabled}
                  onCheckedChange={(checked) => setConfig({ ...config, compliance_enabled: checked })}
                />
              </div>

              <div className="flex items-center justify-between">
                <div>
                  <Label className="flex items-center gap-2">
                    <AlertTriangle className="w-4 h-4" />
                    Real-time Alerts
                  </Label>
                  <p className="text-xs text-muted-foreground">
                    Instant notifications for critical events
                  </p>
                </div>
                <Switch
                  checked={config.real_time_alerts}
                  onCheckedChange={(checked) => setConfig({ ...config, real_time_alerts: checked })}
                />
              </div>
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Tracked Actions</Label>
            <p className="text-sm text-muted-foreground mb-3">
              Select which user actions should be logged
            </p>
            <div className="flex flex-wrap gap-2">
              {defaultActions.map((action) => (
                <Badge
                  key={action}
                  variant={config.tracked_actions.includes(action) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => toggleAction(action)}
                >
                  {action}
                </Badge>
              ))}
            </div>
          </div>

          <div>
            <Label className="text-base font-medium">Log Levels</Label>
            <p className="text-sm text-muted-foreground mb-3">
              Select which severity levels to capture
            </p>
            <div className="flex flex-wrap gap-2">
              {defaultLevels.map((level) => (
                <Badge
                  key={level}
                  variant={config.log_levels.includes(level) ? 'default' : 'outline'}
                  className="cursor-pointer"
                  onClick={() => toggleLogLevel(level)}
                >
                  {level}
                </Badge>
              ))}
            </div>
          </div>

          <Button onClick={saveConfig} disabled={saving} className="w-full">
            {saving ? 'Saving...' : 'Save Configuration'}
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}