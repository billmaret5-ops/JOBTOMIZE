import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { TrendingUp, TrendingDown, Mail, AlertTriangle, CheckCircle, XCircle } from 'lucide-react';
import { emailProviderService, DeliverabilityMetrics, DeliveryLog } from '@/services/emailProviderService';

export const DeliverabilityDashboard: React.FC = () => {
  const [metrics, setMetrics] = useState<DeliverabilityMetrics[]>([]);
  const [recentLogs, setRecentLogs] = useState<DeliveryLog[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [metricsData, logsData] = await Promise.all([
        emailProviderService.getDeliverabilityMetrics(),
        emailProviderService.getDeliveryLogs()
      ]);
      setMetrics(metricsData);
      setRecentLogs(logsData.slice(0, 10));
    } catch (error) {
      console.error('Error loading deliverability data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'delivered': return <CheckCircle className="h-4 w-4 text-green-500" />;
      case 'bounced': return <XCircle className="h-4 w-4 text-red-500" />;
      case 'opened': return <Mail className="h-4 w-4 text-blue-500" />;
      case 'failed': return <AlertTriangle className="h-4 w-4 text-red-500" />;
      default: return <Mail className="h-4 w-4 text-gray-500" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'delivered': return 'default';
      case 'bounced': return 'destructive';
      case 'opened': return 'secondary';
      case 'failed': return 'destructive';
      default: return 'outline';
    }
  };

  const totalMetrics = metrics.reduce((acc, curr) => ({
    sent: acc.sent + curr.emailsSent,
    delivered: acc.delivered + curr.emailsDelivered,
    bounced: acc.bounced + curr.emailsBounced,
    opened: acc.opened + curr.emailsOpened,
    clicked: acc.clicked + curr.emailsClicked
  }), { sent: 0, delivered: 0, bounced: 0, opened: 0, clicked: 0 });

  const deliveryRate = totalMetrics.sent > 0 ? (totalMetrics.delivered / totalMetrics.sent) * 100 : 0;
  const bounceRate = totalMetrics.sent > 0 ? (totalMetrics.bounced / totalMetrics.sent) * 100 : 0;
  const openRate = totalMetrics.delivered > 0 ? (totalMetrics.opened / totalMetrics.delivered) * 100 : 0;
  const clickRate = totalMetrics.opened > 0 ? (totalMetrics.clicked / totalMetrics.opened) * 100 : 0;

  if (loading) {
    return <div className="flex justify-center p-8">Loading deliverability data...</div>;
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="text-2xl font-bold mb-2">Email Deliverability Dashboard</h2>
        <p className="text-muted-foreground">Monitor email delivery performance and engagement metrics</p>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Delivery Rate</p>
                <p className="text-2xl font-bold">{deliveryRate.toFixed(1)}%</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-green-100 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-green-600" />
              </div>
            </div>
            <Progress value={deliveryRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Bounce Rate</p>
                <p className="text-2xl font-bold">{bounceRate.toFixed(1)}%</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-red-100 flex items-center justify-center">
                <TrendingDown className="h-4 w-4 text-red-600" />
              </div>
            </div>
            <Progress value={bounceRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Open Rate</p>
                <p className="text-2xl font-bold">{openRate.toFixed(1)}%</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-blue-100 flex items-center justify-center">
                <Mail className="h-4 w-4 text-blue-600" />
              </div>
            </div>
            <Progress value={openRate} className="mt-2" />
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Click Rate</p>
                <p className="text-2xl font-bold">{clickRate.toFixed(1)}%</p>
              </div>
              <div className="h-8 w-8 rounded-full bg-purple-100 flex items-center justify-center">
                <TrendingUp className="h-4 w-4 text-purple-600" />
              </div>
            </div>
            <Progress value={clickRate} className="mt-2" />
          </CardContent>
        </Card>
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card>
          <CardHeader>
            <CardTitle>Delivery Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={metrics.slice(-7)}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Line type="monotone" dataKey="deliveryRate" stroke="#8884d8" name="Delivery Rate %" />
                <Line type="monotone" dataKey="bounceRate" stroke="#82ca9d" name="Bounce Rate %" />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Email Volume</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={metrics.slice(-7)}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis dataKey="date" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="emailsSent" fill="#8884d8" name="Sent" />
                <Bar dataKey="emailsDelivered" fill="#82ca9d" name="Delivered" />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Recent Delivery Logs */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Email Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentLogs.map((log) => (
              <div key={log.id} className="flex items-center justify-between p-3 border rounded-lg">
                <div className="flex items-center space-x-3">
                  {getStatusIcon(log.status)}
                  <div>
                    <p className="font-medium">{log.emailAddress}</p>
                    <p className="text-sm text-muted-foreground">
                      {new Date(log.createdAt).toLocaleString()}
                    </p>
                  </div>
                </div>
                <div className="flex items-center space-x-2">
                  <Badge variant={getStatusColor(log.status)}>
                    {log.status}
                  </Badge>
                  <Badge variant="outline">{log.provider}</Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
};