import React, { useState, useEffect } from 'react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Progress } from '@/components/ui/progress';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Bot, Send, Clock, CheckCircle, AlertCircle, TrendingUp, Calendar, Settings } from 'lucide-react';

interface JobApplication {
  id: string;
  jobTitle: string;
  company: string;
  status: 'pending' | 'submitted' | 'interview' | 'rejected' | 'offer';
  appliedDate: string;
  source: 'linkedin' | 'indeed' | 'company' | 'glassdoor';
  matchScore: number;
  followUpDate?: string;
}

export function AutomatedJobApplicationSystem() {
  const [applications, setApplications] = useState<JobApplication[]>([
    {
      id: '1',
      jobTitle: 'Senior Frontend Developer',
      company: 'TechCorp Inc',
      status: 'interview',
      appliedDate: '2024-01-15',
      source: 'linkedin',
      matchScore: 95,
      followUpDate: '2024-01-22'
    },
    {
      id: '2',
      jobTitle: 'Full Stack Engineer',
      company: 'StartupXYZ',
      status: 'submitted',
      appliedDate: '2024-01-14',
      source: 'indeed',
      matchScore: 88
    },
    {
      id: '3',
      jobTitle: 'React Developer',
      company: 'WebSolutions',
      status: 'pending',
      appliedDate: '2024-01-13',
      source: 'company',
      matchScore: 82
    }
  ]);

  const [metrics, setMetrics] = useState({
    totalApplications: 47,
    responseRate: 34,
    interviewRate: 15,
    offerRate: 8
  });

  const getStatusColor = (status: string) => {
    const colors = {
      pending: 'bg-yellow-100 text-yellow-800',
      submitted: 'bg-blue-100 text-blue-800',
      interview: 'bg-green-100 text-green-800',
      rejected: 'bg-red-100 text-red-800',
      offer: 'bg-purple-100 text-purple-800'
    };
    return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800';
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'submitted': return <Send className="w-4 h-4 text-blue-500" />;
      case 'interview': return <Calendar className="w-4 h-4 text-green-500" />;
      case 'pending': return <Clock className="w-4 h-4 text-yellow-500" />;
      case 'rejected': return <AlertCircle className="w-4 h-4 text-red-500" />;
      case 'offer': return <CheckCircle className="w-4 h-4 text-purple-500" />;
      default: return null;
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center">
        <h1 className="text-3xl font-bold mb-2">Automated Job Application System</h1>
        <p className="text-gray-600">Streamline your job search with AI-powered automation</p>
      </div>

      <div className="grid md:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-blue-600">{metrics.totalApplications}</div>
            <div className="text-sm text-gray-600">Total Applications</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-green-600">{metrics.responseRate}%</div>
            <div className="text-sm text-gray-600">Response Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-purple-600">{metrics.interviewRate}%</div>
            <div className="text-sm text-gray-600">Interview Rate</div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="p-4 text-center">
            <div className="text-2xl font-bold text-orange-600">{metrics.offerRate}%</div>
            <div className="text-sm text-gray-600">Offer Rate</div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="dashboard" className="w-full">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="dashboard">Dashboard</TabsTrigger>
          <TabsTrigger value="applications">Applications</TabsTrigger>
          <TabsTrigger value="automation">Automation</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="dashboard" className="space-y-6">
          <div className="grid md:grid-cols-2 gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Application Pipeline</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <span>Applied</span>
                    <span className="font-medium">47</span>
                  </div>
                  <Progress value={100} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Responses</span>
                    <span className="font-medium">16</span>
                  </div>
                  <Progress value={34} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Interviews</span>
                    <span className="font-medium">7</span>
                  </div>
                  <Progress value={15} className="h-2" />
                  
                  <div className="flex justify-between items-center">
                    <span>Offers</span>
                    <span className="font-medium">4</span>
                  </div>
                  <Progress value={8} className="h-2" />
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Recent Activity</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="flex items-center gap-3">
                    <CheckCircle className="w-4 h-4 text-green-500" />
                    <span className="text-sm">Interview scheduled at TechCorp</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Send className="w-4 h-4 text-blue-500" />
                    <span className="text-sm">Applied to 3 new positions</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Bot className="w-4 h-4 text-purple-500" />
                    <span className="text-sm">Cover letters auto-generated</span>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        <TabsContent value="applications" className="space-y-4">
          {applications.map((app) => (
            <Card key={app.id}>
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    {getStatusIcon(app.status)}
                    <div>
                      <h4 className="font-medium">{app.jobTitle}</h4>
                      <p className="text-sm text-gray-600">{app.company}</p>
                      <p className="text-xs text-gray-500">Applied: {app.appliedDate}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Badge variant="outline">{app.matchScore}% match</Badge>
                    <Badge className={getStatusColor(app.status)}>
                      {app.status}
                    </Badge>
                    <Badge variant="secondary">{app.source}</Badge>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </TabsContent>

        <TabsContent value="automation">
          <Card>
            <CardHeader>
              <CardTitle>Automation Controls</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <Button className="w-full">
                  <Bot className="w-4 h-4 mr-2" />
                  Start Bulk Application Process
                </Button>
                <Button variant="outline" className="w-full">
                  <Settings className="w-4 h-4 mr-2" />
                  Configure Automation Settings
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="analytics">
          <Card>
            <CardHeader>
              <CardTitle>Performance Analytics</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8">
                <TrendingUp className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">Detailed analytics coming soon</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}