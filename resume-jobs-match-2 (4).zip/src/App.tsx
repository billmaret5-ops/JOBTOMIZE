import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from '@/contexts/ProductionAuthContext';
import { ThemeProvider } from '@/components/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import { ErrorBoundary } from '@/components/ErrorBoundary';

// Lazy load pages for better performance
import Index from '@/pages/Index';
import FreeATSChecker from '@/pages/FreeATSChecker';
import ResumeRejectedByATS from '@/pages/ResumeRejectedByATS';
import BeatApplicantTrackingSystem from '@/pages/BeatApplicantTrackingSystem';
import ATSResumeScanner from '@/pages/ATSResumeScanner';
import ResumeNotGettingInterviews from '@/pages/ResumeNotGettingInterviews';
import ATSOptimizationTool from '@/pages/ATSOptimizationTool';
import TestJobMatching from '@/pages/TestJobMatching';
import PasswordReset from '@/pages/PasswordReset';
import UserProfilePage from '@/pages/UserProfilePage';
import { SupabaseAuthTest } from '@/components/SupabaseAuthTest';
import AdminLoginPage from '@/components/AdminLoginPage';
import ComprehensiveAdminDashboard from '@/components/ComprehensiveAdminDashboard';

import { AdminProtectedRoute } from '@/components/AdminProtectedRoute';
import DatabaseConnectionTest from '@/components/DatabaseConnectionTest';
import FetchJobsDiagnostics from '@/components/FetchJobsDiagnostics';
import { FetchJobsRealTest } from '@/components/FetchJobsRealTest';
import { JSearchVerification } from '@/components/JSearchVerification';
import RealDiagnosticPanel from '@/components/RealDiagnosticPanel';
import LiveJobSearch from '@/pages/LiveJobSearch';




import JobAlerts from '@/pages/JobAlerts';
import ResumeBuilder from '@/pages/ResumeBuilder';
import ResumeManagement from '@/pages/ResumeManagement';
import AutomatedFollowUpSystem from '@/components/AutomatedFollowUpSystem';
import { AdminAccessHub } from '@/components/AdminAccessHub';
import { UnifiedAnalyticsDashboard } from '@/components/UnifiedAnalyticsDashboard';
import PredictiveAnalyticsDashboard from '@/components/PredictiveAnalyticsDashboard';
import AdvancedMLDashboard from '@/pages/AdvancedMLDashboard';
import { JobSearchAnalyticsDashboard } from '@/components/JobSearchAnalyticsDashboard';
import Applications from '@/pages/Applications';


import NotFound from '@/pages/NotFound';

import './App.css';

console.log('🎨 App component rendering...');

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light" storageKey="vite-ui-theme">
        <AuthProvider>
          <Router>
            <div className="min-h-screen bg-background">
              <Routes>
                <Route path="/" element={<Index />} />
                <Route path="/auth-test" element={<SupabaseAuthTest />} />
                <Route path="/db-test" element={<DatabaseConnectionTest />} />
                <Route path="/jobs-test" element={<FetchJobsDiagnostics />} />
                <Route path="/jobs-real-test" element={<FetchJobsRealTest />} />
                <Route path="/verify-jsearch" element={<JSearchVerification />} />
                <Route path="/diagnostic" element={<RealDiagnosticPanel />} />



                
                {/* Admin Routes */}
                <Route path="/admin-login" element={<AdminLoginPage />} />
                <Route 
                  path="/admin-dashboard" 
                  element={
                    <AdminProtectedRoute>
                      <ComprehensiveAdminDashboard />
                    </AdminProtectedRoute>
                  } 
                />
                <Route path="/admin" element={<AdminLoginPage />} />
                <Route path="/admin-hub" element={<AdminAccessHub />} />
                
                <Route path="/profile" element={<UserProfilePage />} />
                <Route path="/free-ats-checker" element={<FreeATSChecker />} />
                <Route path="/resume-rejected-by-ats" element={<ResumeRejectedByATS />} />
                <Route path="/beat-applicant-tracking-system" element={<BeatApplicantTrackingSystem />} />
                <Route path="/ats-resume-scanner" element={<ATSResumeScanner />} />
                <Route path="/resume-not-getting-interviews" element={<ResumeNotGettingInterviews />} />
                <Route path="/ats-optimization-tool" element={<ATSOptimizationTool />} />
                <Route path="/test-job-matching" element={<TestJobMatching />} />
                <Route path="/reset-password" element={<PasswordReset />} />
                <Route path="/live-jobs" element={<LiveJobSearch />} />
                <Route path="/job-alerts" element={<JobAlerts />} />
                <Route path="/resume-builder" element={<ResumeBuilder />} />
                <Route path="/resume-management" element={<ResumeManagement />} />
                <Route path="/automated-sequences" element={<AutomatedFollowUpSystem />} />
                <Route path="/unified-analytics" element={<UnifiedAnalyticsDashboard />} />
                <Route path="/predictive-analytics" element={<PredictiveAnalyticsDashboard />} />
                <Route path="/advanced-ml" element={<AdvancedMLDashboard />} />
                <Route path="/applications" element={<Applications />} />
                <Route path="/job-analytics" element={<JobSearchAnalyticsDashboard />} />


                <Route path="*" element={<NotFound />} />
              </Routes>
              <Toaster />

            </div>
          </Router>
        </AuthProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
