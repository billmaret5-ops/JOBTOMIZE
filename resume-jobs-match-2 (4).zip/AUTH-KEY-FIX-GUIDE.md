# Auth Key Fix - Using Service Role Key for User Creation

## Problem Identified
Using **anon key** for admin operations (creating users) results in 401/403 errors.

## Solution Implemented

### ✅ Correct Approach: Edge Function with Service Role Key

**Edge Function: `user-auth-manager`**
- Location: `supabase/functions/user-auth-manager/index.ts`
- Uses `SUPABASE_SERVICE_ROLE_KEY` (auto-injected by Supabase)
- Implements `auth.admin.createUser()` for proper user creation

**Frontend Service: `adminAuthService.ts`**
- Location: `src/services/adminAuthService.ts`
- Calls Edge Function for user creation
- Uses anon key for client operations (sign in, sign out)

## Key Differences

### ❌ WRONG: Client-Side with Anon Key
```typescript
// This FAILS for admin operations
const { data, error } = await supabase.auth.signUp({
  email, password
});
```

### ✅ CORRECT: Edge Function with Service Role Key
```typescript
// Edge Function (server-side)
const supabaseAdmin = createClient(
  Deno.env.get('SUPABASE_URL'),
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') // Service role key!
);

const { data, error } = await supabaseAdmin.auth.admin.createUser({
  email, password, email_confirm: true
});
```

## Implementation Steps

### 1. Edge Function Already Exists
The `user-auth-manager` function has been updated with:
- `create_user` action
- Uses `auth.admin.createUser()`
- Auto-creates profile
- Auto-confirms email

### 2. Frontend Service Created
`AdminAuthService` provides:
- `createUser()` - Calls edge function
- `signIn()` - Client-side (anon key OK)
- `resetPassword()` - Client-side (anon key OK)
- `signOut()` - Client-side (anon key OK)

### 3. Update Components to Use New Service

**SignUpForm.tsx:**
```typescript
import { AdminAuthService } from '@/services/adminAuthService';

const { data, error } = await AdminAuthService.createUser({
  email: formData.email,
  password: formData.password,
  full_name: formData.full_name,
  phone: formData.phone,
  user_type: 'job_seeker'
});
```

**AuthFlowTester.tsx:**
```typescript
import { AdminAuthService } from '@/services/adminAuthService';

const { data, error } = await AdminAuthService.createUser({
  email: testEmail,
  password: 'TestPass123!',
  full_name: 'Test User'
});
```

## Testing

Run the Auth Flow Tester:
1. Navigate to `/?auth-flow-test`
2. Click "Run All Tests"
3. Should see successful user creation

## Environment Variables

Edge functions automatically have access to:
- `SUPABASE_URL` - Auto-injected
- `SUPABASE_SERVICE_ROLE_KEY` - Auto-injected
- `SUPABASE_ANON_KEY` - Auto-injected

No manual configuration needed!

## Summary

✅ **Service Role Key** = Admin operations (create users, manage users)
✅ **Anon Key** = Client operations (sign in, sign out, client-side auth)
✅ **Edge Functions** = Server-side with service_role key access
✅ **Frontend** = Calls edge functions for admin ops, direct client for user ops
