# 🚀 DEPLOY SERVICE ROLE KEY FIX NOW

## Step 1: Set the Service Role Key Secret
```bash
supabase secrets set SUPABASE_SERVICE_ROLE_KEY=sb_secret_FgXdNUI0-o1p-Wr5FfEzgA_8s4pe8I5
```

## Step 2: Create/Update the Edge Function

Create file: `supabase/functions/user-auth-manager/index.ts`

```typescript
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, email, password, metadata } = await req.json();

    if (action === 'create_user') {
      const serviceRoleKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY');
      
      if (!serviceRoleKey) {
        throw new Error('Service role key not configured');
      }

      const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
      const supabaseAdmin = createClient(supabaseUrl, serviceRoleKey, {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      });

      const { data, error } = await supabaseAdmin.auth.admin.createUser({
        email,
        password,
        email_confirm: true,
        user_metadata: metadata || {}
      });

      if (error) {
        return new Response(JSON.stringify({ error: error.message }), {
          status: 400,
          headers: { 'Content-Type': 'application/json', ...corsHeaders }
        });
      }

      return new Response(JSON.stringify({ user: data.user }), {
        status: 200,
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    return new Response(JSON.stringify({ error: 'Invalid action' }), {
      status: 400,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });

  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
```

## Step 3: Deploy the Function
```bash
supabase functions deploy user-auth-manager
```

## Step 4: Test the Fix
Navigate to: `http://localhost:5173/?service-role-test`

Click "Test User Creation" and verify:
- ✅ User created successfully
- ✅ No 401/403 errors
- ✅ User appears in Supabase Auth dashboard

## Troubleshooting

### If you get "Unauthorized" error:
1. Verify you're logged in: `supabase login`
2. Link your project: `supabase link --project-ref YOUR_PROJECT_REF`

### If function deployment fails:
1. Check you're in the project root directory
2. Ensure `supabase/functions/user-auth-manager/index.ts` exists
3. Run `supabase functions list` to verify

### If test still fails:
1. Check function logs: `supabase functions logs user-auth-manager`
2. Verify secret is set: `supabase secrets list`
3. Check the service_role key is correct in Supabase dashboard
