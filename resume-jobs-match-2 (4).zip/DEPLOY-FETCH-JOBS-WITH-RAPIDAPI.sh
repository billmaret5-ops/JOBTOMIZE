#!/bin/bash
# Deploy the fetch-jobs edge function with RapidAPI key

echo "Deploying fetch-jobs edge function with JSearch integration..."

# Create the function directory if it doesn't exist
mkdir -p supabase/functions/fetch-jobs

# Write the function code
cat > supabase/functions/fetch-jobs/index.ts << 'EOF'
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  remote?: boolean;
}

const transformJSearchJob = (job: any): JobListing => {
  return {
    id: job.job_id || \`jsearch_\${Date.now()}_\${Math.random()}\`,
    title: job.job_title || 'Unknown Position',
    company: job.employer_name || 'Unknown Company',
    location: \`\${job.job_city || ''}, \${job.job_state || ''}\`.trim() || job.job_country || 'Remote',
    description: job.job_description || 'No description available',
    salary: job.job_salary || (job.job_min_salary ? \`$\${job.job_min_salary} - $\${job.job_max_salary}\` : undefined),
    type: job.job_employment_type || 'Full-time',
    posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
    apply_url: job.job_apply_link || job.job_google_link || '#',
    source: 'jsearch',
    skills: job.job_required_skills || [],
    remote: job.job_is_remote || false
  };
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { query = 'software engineer', location = '', page = 1 } = await req.json();
    
    const rapidApiKey = 'deffa6f1acmsh652e385a84f17fep1c4a3fjsna3d001bcfb82';
    const searchQuery = location ? \`\${query} in \${location}\` : query;
    const jsearchUrl = \`https://jsearch.p.rapidapi.com/search?query=\${encodeURIComponent(searchQuery)}&page=\${page}&num_pages=1&country=us&date_posted=all\`;
    
    console.log('Fetching jobs from JSearch:', searchQuery);
    
    const response = await fetch(jsearchUrl, {
      headers: {
        'x-rapidapi-host': 'jsearch.p.rapidapi.com',
        'x-rapidapi-key': rapidApiKey
      }
    });

    if (!response.ok) {
      throw new Error(\`JSearch API error: \${response.status}\`);
    }

    const data = await response.json();
    const jobs = (data.data || []).map(transformJSearchJob);

    console.log(\`Fetched \${jobs.length} jobs from JSearch\`);

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      source: 'jsearch_live'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error: any) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      jobs: [],
      total: 0
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
EOF

echo "Function code created. Now deploying..."
npx supabase functions deploy fetch-jobs

echo "✅ Deployment complete! Test at /verify-jsearch"
