#!/bin/bash

# RapidAPI Integration Deployment Script
# This script will set up and deploy the fetch-jobs function with RapidAPI integration

echo "🚀 Setting up RapidAPI Integration for fetch-jobs..."
echo ""

# Step 1: Set secrets
echo "📝 Step 1: Setting RapidAPI secrets..."
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7 RAPIDAPI_HOST=jsearch.p.rapidapi.com

if [ $? -eq 0 ]; then
    echo "✅ Secrets set successfully"
else
    echo "❌ Failed to set secrets"
    exit 1
fi

echo ""

# Step 2: Deploy function
echo "📦 Step 2: Deploying fetch-jobs function..."
supabase functions deploy fetch-jobs

if [ $? -eq 0 ]; then
    echo "✅ Function deployed successfully"
else
    echo "❌ Failed to deploy function"
    exit 1
fi

echo ""
echo "🎉 Deployment complete!"
echo ""
echo "Now test with these commands:"
echo ""
echo "1. Health check:"
echo "   curl -sS \"\$SUPABASE_URL/functions/v1/fetch-jobs/health\" \\"
echo "     -H \"Authorization: Bearer \$SUPABASE_ANON_KEY\" \\"
echo "     -H \"apikey: \$SUPABASE_ANON_KEY\""
echo ""
echo "2. Diagnostics:"
echo "   curl -sS \"\$SUPABASE_URL/functions/v1/fetch-jobs/diagnostics?query=test\" \\"
echo "     -H \"Authorization: Bearer \$SUPABASE_ANON_KEY\" \\"
echo "     -H \"apikey: \$SUPABASE_ANON_KEY\""
echo ""
echo "3. Check logs:"
echo "   supabase functions logs fetch-jobs --include=invocations"
