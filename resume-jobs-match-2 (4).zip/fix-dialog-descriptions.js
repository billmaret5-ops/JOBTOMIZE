#!/usr/bin/env node
const fs = require('fs');
const path = require('path');
const { glob } = require('glob');

// Find all TypeScript/TSX files in src/components
const files = glob.sync('src/components/**/*.{ts,tsx}', {
  ignore: ['**/__tests__/**', '**/ui/**']
});

let filesUpdated = 0;

files.forEach(filePath => {
  let content = fs.readFileSync(filePath, 'utf8');
  let modified = false;

  // Check if file uses DialogContent
  if (!content.includes('DialogContent')) {
    return;
  }

  // Check if DialogDescription is already imported
  const hasDescriptionImport = content.includes('DialogDescription');
  
  // Add DialogDescription to import if missing
  if (!hasDescriptionImport && content.includes("from '@/components/ui/dialog'")) {
    content = content.replace(
      /from '@\/components\/ui\/dialog'/,
      match => {
        const importLine = content.split('\n').find(line => line.includes("from '@/components/ui/dialog'"));
        if (importLine && importLine.includes('DialogTitle') && !importLine.includes('DialogDescription')) {
          return match.replace('DialogTitle', 'DialogTitle, DialogDescription');
        }
        return match;
      }
    );
    modified = true;
  }

  if (!hasDescriptionImport && content.includes("from './ui/dialog'")) {
    content = content.replace(
      /from '\.\/ui\/dialog'/,
      match => {
        const importLine = content.split('\n').find(line => line.includes("from './ui/dialog'"));
        if (importLine && importLine.includes('DialogTitle') && !importLine.includes('DialogDescription')) {
          return match.replace('DialogTitle', 'DialogTitle, DialogDescription');
        }
        return match;
      }
    );
    modified = true;
  }

  // Add DialogDescription after DialogTitle if missing
  const titleRegex = /<DialogTitle[^>]*>[\s\S]*?<\/DialogTitle>/g;
  let matches = content.match(titleRegex);
  
  if (matches) {
    matches.forEach(titleMatch => {
      const afterTitle = content.substring(content.indexOf(titleMatch) + titleMatch.length, content.indexOf(titleMatch) + titleMatch.length + 200);
      
      if (!afterTitle.trim().startsWith('<DialogDescription')) {
        const replacement = titleMatch + '\n          <DialogDescription>\n            View and manage details\n          </DialogDescription>';
        content = content.replace(titleMatch, replacement);
        modified = true;
      }
    });
  }

  if (modified) {
    fs.writeFileSync(filePath, content, 'utf8');
    filesUpdated++;
    console.log(`✓ Updated: ${filePath}`);
  }
});

console.log(`\n✅ Updated ${filesUpdated} files with DialogDescription`);
