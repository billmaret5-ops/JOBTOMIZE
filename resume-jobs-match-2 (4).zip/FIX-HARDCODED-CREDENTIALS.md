# 🔧 FIX: Hardcoded Fallback Credentials Error

## Problem
Your app shows "Using hardcoded fallback credentials (likely invalid)" because the `.env` file is missing or not being read properly.

## ✅ SOLUTION - Follow These Steps:

### Step 1: Create .env File
I've created a `.env` file in your project root with the correct credentials from your screenshot.

### Step 2: Restart Dev Server
```bash
# Stop the current dev server (Ctrl+C)
# Then restart it:
npm run dev
```

### Step 3: Clear Browser Cache
1. Open DevTools (F12)
2. Right-click the refresh button
3. Select "Empty Cache and Hard Reload"

### Step 4: Verify Fix
Go to: https://jobtomize.com/?test-connection

You should now see:
- ✅ "Using environment variables" (green)
- ✅ All connection tests passing

---

## 🔍 Why This Happened

The `supabase.ts` file has fallback credentials:
```typescript
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL || 'fallback-url';
```

When `.env` is missing, it uses the hardcoded fallback, which triggers the warning.

---

## 🚨 If Still Not Working

### Option A: Check .env Location
Make sure `.env` is in the **project root** (same folder as `package.json`), not in `src/`

### Option B: Verify .gitignore
Check that `.env` is in `.gitignore` (it should be ignored for security)

### Option C: Manual Creation
If the file wasn't created, create `.env` manually:

```env
VITE_SUPABASE_URL=https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJnZHZldm1xcmpsa3Fma2l1Y2RoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MzE1MzU5NjksImV4cCI6MjA0NzExMTk2OX0.3_hBYMYLEqLZvjrJlWlNwCEV8_iU_HYdmBuqcfSvjmg
VITE_APP_URL=https://jobtomize.com
NODE_ENV=production
```

---

## 📋 Next Steps After Fix

Once the hardcoded credentials warning is gone, the **Fetch Jobs Edge Function** error should also be resolved, as it was failing due to invalid credentials.

If you still see "HTTP 401: Failed to fetch jobs", check:
1. Edge function is deployed in Supabase Dashboard
2. RAPIDAPI_KEY secret exists in Project Settings → Secrets
3. Function has proper CORS headers
