# ML-Based Anomaly Detection for WebSocket Rate Limiting

## Overview

The ML-based anomaly detection system provides intelligent, adaptive threat detection for WebSocket connections. It learns normal user behavior patterns, identifies unusual activity, detects potential DDoS attacks, and triggers automated responses to protect your infrastructure.

## Key Features

### 1. **Behavioral Learning**
- Establishes user behavior baselines (hourly, daily, weekly)
- Tracks connection patterns, message frequency, and burst behavior
- Adapts to changing usage patterns over time
- Multi-dimensional behavior vector analysis

### 2. **Real-Time Anomaly Detection**
- Sub-50ms inference time for real-time protection
- Token bucket algorithm integration
- Confidence scoring for each detection
- Multiple anomaly types: connection floods, message floods, unusual bursts

### 3. **DDoS Pattern Recognition**
- Pre-configured attack pattern detection
- Distributed attack identification
- Automatic severity classification
- Pattern-based auto-response triggers

### 4. **Automated Response System**
- Immediate temporary bans for critical threats
- Rate limit adjustments based on severity
- Administrator alerts for high-severity events
- Forensic logging for security analysis

### 5. **ML Training Pipeline**
- Initial training from historical data
- Continuous retraining with new patterns
- Incremental learning capabilities
- Model versioning and deployment management

## Architecture

```
User Activity → Feature Extraction → ML Model → Anomaly Score → Response Action
                                          ↓
                                    Baseline Comparison
                                          ↓
                                    Severity Classification
```

## Getting Started

### 1. Access the ML Dashboard

Navigate to the Secure WebSocket Dashboard and select the "ML Detection" tab:

```typescript
import { MLAnomalyDetectionDashboard } from '@/components/MLAnomalyDetectionDashboard';

<MLAnomalyDetectionDashboard />
```

### 2. Monitor Active Model

The dashboard displays:
- Active model version and accuracy
- Recent anomaly detections
- Training job status
- Automated response configuration

### 3. View User Baselines

Check learned behavior patterns:

```typescript
import { UserBehaviorBaselineManager } from '@/components/UserBehaviorBaselineManager';

<UserBehaviorBaselineManager userId={currentUserId} />
```

## Using the ML Service

### Detect Anomalies

```typescript
import { websocketMLAnomalyService } from '@/services/websocketMLAnomalyService';

// Real-time anomaly detection
const features = {
  connections_per_hour: 25,
  messages_per_minute: 150,
  burst_frequency: 5.2
};

const anomaly = await websocketMLAnomalyService.detectAnomaly(userId, features);

if (anomaly) {
  console.log(`Anomaly detected: ${anomaly.anomaly_type}`);
  console.log(`Severity: ${anomaly.severity}`);
  console.log(`Confidence: ${anomaly.confidence_score}`);
}
```

### Get User Baseline

```typescript
const baseline = await websocketMLAnomalyService.getUserBaseline(userId, 'daily');

console.log('Average connections/hour:', baseline.avg_connections_per_hour);
console.log('Average messages/min:', baseline.avg_messages_per_minute);
console.log('Peak usage hours:', baseline.peak_usage_hours);
```

### Start Training Job

```typescript
const jobId = await websocketMLAnomalyService.startTrainingJob(
  'websocket_anomaly_v2',
  'retraining'
);

console.log('Training job started:', jobId);
```

## Custom Hook Usage

```typescript
import { useMLAnomalyDetection } from '@/hooks/useMLAnomalyDetection';

function MyComponent() {
  const {
    activeModel,
    recentAnomalies,
    userBaseline,
    loading,
    detectAnomaly,
    triggerResponse,
    refresh
  } = useMLAnomalyDetection({
    userId: currentUserId,
    autoRefresh: true,
    refreshInterval: 10000
  });

  // Manually detect anomaly
  const handleCheck = async () => {
    const anomaly = await detectAnomaly({
      connections_per_hour: 30,
      messages_per_minute: 200,
      burst_frequency: 8
    });
  };

  return (
    <div>
      <h3>Active Model: {activeModel?.version}</h3>
      <p>Recent Anomalies: {recentAnomalies.length}</p>
    </div>
  );
}
```

## Anomaly Types

### 1. Connection Flood
- **Trigger**: Connections > 5x baseline
- **Severity**: Critical
- **Response**: Immediate 15-minute ban

### 2. Message Flood
- **Trigger**: Messages > 10x baseline
- **Severity**: High
- **Response**: 50% rate limit reduction

### 3. Unusual Burst
- **Trigger**: Burst frequency > 3x baseline
- **Severity**: Medium
- **Response**: Warning notification

### 4. Abnormal Frequency
- **Trigger**: General deviation from baseline
- **Severity**: Low
- **Response**: Log for review

## Automated Response Actions

### Critical Severity
1. Immediate temporary ban (15 minutes)
2. Alert system administrators
3. Log detailed forensics
4. Trigger rate limit reduction

### High Severity
1. Reduce rate limits by 50%
2. Send warning notification
3. Increase monitoring frequency

### Medium Severity
1. Log event for review
2. Send informational alert

### Low Severity
1. Log event only

## Model Training

### Initial Training

```typescript
// Start initial training with historical data
await websocketMLAnomalyService.startTrainingJob(
  'websocket_anomaly_v1',
  'initial_training'
);
```

### Retraining

Models should be retrained periodically (recommended: weekly):

```typescript
// Retrain with recent data
await websocketMLAnomalyService.startTrainingJob(
  'websocket_anomaly_v1',
  'retraining'
);
```

### Incremental Learning

For continuous adaptation:

```typescript
// Incremental learning from new patterns
await websocketMLAnomalyService.startTrainingJob(
  'websocket_anomaly_v1',
  'incremental'
);
```

## Database Schema

### ML Models
```sql
websocket_ml_models
- id, model_name, version
- model_type, status, accuracy
- precision_score, recall_score, f1_score
- features, hyperparameters
- trained_at, deployed_at
```

### User Baselines
```sql
websocket_user_baselines
- id, user_id, baseline_period
- avg_connections_per_hour
- avg_messages_per_minute
- avg_burst_frequency
- peak_usage_hours, typical_channels
- behavior_vector, confidence_score
```

### Anomaly Detections
```sql
websocket_anomaly_detections
- id, user_id, model_id
- anomaly_type, severity
- confidence_score, anomaly_score
- features_analyzed, deviation_metrics
- context, is_false_positive
```

### Automated Responses
```sql
websocket_automated_responses
- id, anomaly_id, action_type
- action_parameters, status
- executed_at, effectiveness_score
```

## Best Practices

### 1. Baseline Establishment
- Allow 7 days for initial baseline learning
- Review baselines weekly for accuracy
- Adjust confidence thresholds as needed

### 2. Model Management
- Deploy new models during low-traffic periods
- Keep 2-3 model versions for rollback
- Monitor model performance metrics

### 3. False Positive Handling
- Review flagged anomalies regularly
- Mark false positives to improve learning
- Adjust severity thresholds based on feedback

### 4. Response Configuration
- Test automated responses in staging first
- Gradually increase response severity
- Monitor effectiveness scores

### 5. Training Schedule
- Initial training: Use 30+ days of data
- Retraining: Weekly or bi-weekly
- Incremental: Daily for high-traffic systems

## Monitoring & Alerts

### Key Metrics to Monitor
- Model accuracy and precision
- Anomaly detection rate
- False positive rate
- Response effectiveness
- Training job success rate

### Alert Configuration
Set up alerts for:
- Critical anomalies detected
- Model accuracy drops below threshold
- Training job failures
- High false positive rates

## Troubleshooting

### High False Positive Rate
**Solution**: 
- Increase baseline learning period
- Adjust anomaly score threshold
- Review and mark false positives

### Model Not Detecting Threats
**Solution**:
- Retrain with recent attack data
- Lower detection threshold
- Add more features to model

### Slow Inference Time
**Solution**:
- Optimize feature extraction
- Use model caching
- Consider simpler model architecture

### Training Job Failures
**Solution**:
- Check data quality and completeness
- Verify sufficient training samples
- Review error logs for specifics

## API Reference

### websocketMLAnomalyService

#### `getActiveModel(): Promise<MLModel | null>`
Returns the currently deployed ML model.

#### `getUserBaseline(userId: string, period?: string): Promise<UserBaseline | null>`
Gets user behavior baseline for specified period.

#### `detectAnomaly(userId: string, features: any): Promise<AnomalyDetection | null>`
Performs real-time anomaly detection.

#### `getRecentAnomalies(limit?: number): Promise<AnomalyDetection[]>`
Returns recent anomaly detections.

#### `triggerAutomatedResponse(anomalyId: string, actionType: string, parameters: any): Promise<void>`
Triggers automated response for detected anomaly.

#### `startTrainingJob(modelName: string, jobType: string): Promise<string>`
Starts a new ML training job.

## Security Considerations

1. **Data Privacy**: User behavior data is anonymized and encrypted
2. **Access Control**: Only admins can view all user baselines
3. **Audit Logging**: All detections and responses are logged
4. **Model Security**: Model artifacts are stored securely
5. **Response Limits**: Automated responses have safety limits

## Performance Impact

- **Inference Time**: < 50ms per request
- **Memory Usage**: ~100MB per active model
- **CPU Impact**: < 5% during normal operation
- **Storage**: ~1GB per million detections

## Future Enhancements

- [ ] Deep learning models (LSTM, Transformer)
- [ ] Multi-model ensemble predictions
- [ ] Federated learning across instances
- [ ] Explainable AI for detection reasoning
- [ ] Automatic hyperparameter tuning
- [ ] Real-time model updates

## Support

For issues or questions:
- Check the troubleshooting section
- Review audit logs for details
- Contact system administrators
- Submit feedback for false positives
