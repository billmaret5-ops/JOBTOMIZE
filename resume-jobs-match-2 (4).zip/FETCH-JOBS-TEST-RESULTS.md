# Fetch Jobs API Test Results

## Test Component Updated

The `FetchJobsDiagnostics` component has been updated to test the new fetch-jobs edge function endpoints.

## How to Test

1. **Navigate to the test page:**
   ```
   http://localhost:5173/jobs-test
   ```

2. **Click "Run Diagnostics"** button

## What Gets Tested

### Test 1: Health Check
- **Endpoint:** `GET /fetch-jobs/health`
- **Expected:** Status 200 with `{ status: "ok" }`
- **Purpose:** Verify function is deployed and responding

### Test 2: Search (GET)
- **Endpoint:** `GET /fetch-jobs/search?query=react%20developer&location=remote`
- **Expected:** Status 200 with `{ jobs: [...], total: number }`
- **Purpose:** Verify real job search is working

### Test 3: Response Structure
- **Checks:** 
  - `jobs` is an array
  - `total` is a number
  - Job count matches response
- **Purpose:** Validate API contract

### Test 4: Job Data Quality
- **Checks:** Each job has required fields:
  - `id`
  - `title`
  - `company`
  - `location`
- **Purpose:** Ensure job data is complete

## Expected Results

### ✅ Success Scenario
```json
{
  "tests": [
    {
      "name": "Health Check",
      "status": "success",
      "statusCode": 200,
      "data": { "status": "ok" }
    },
    {
      "name": "Search (GET)",
      "status": "success",
      "statusCode": 200,
      "jobCount": 10
    },
    {
      "name": "Response Structure",
      "status": "success",
      "hasJobs": true,
      "hasTotal": true
    },
    {
      "name": "Job Data Quality",
      "status": "success",
      "missingFields": []
    }
  ]
}
```

### ❌ Common Errors

**Error: "Failed to fetch"**
- Function not deployed
- CORS issue
- Network connectivity problem

**Error: "RAPIDAPI_KEY not configured"**
- Secret not set in Supabase
- Run: `supabase secrets set RAPIDAPI_KEY=your_key`

**Status: 401 Unauthorized**
- Invalid anon key
- Check `.env` file has correct `VITE_SUPABASE_ANON_KEY`

**Status: 500 Internal Server Error**
- Check Supabase function logs
- Verify RapidAPI key is valid
- Check RapidAPI quota

## Troubleshooting

### View Function Logs
1. Go to Supabase Dashboard
2. Navigate to Edge Functions → fetch-jobs
3. Click "Logs" tab
4. Look for errors or API responses

### Test Manually with curl
```bash
# Health check
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"

# Search
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=react&location=remote" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

## Next Steps

Once all tests pass:
1. ✅ Health check returns 200
2. ✅ Search returns real jobs
3. ✅ Job data is complete
4. → Deploy to production
5. → Update main job search interface
