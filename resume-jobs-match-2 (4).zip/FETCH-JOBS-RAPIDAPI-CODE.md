# Updated fetch-jobs Function Code with RapidAPI

Copy this code to `supabase/functions/fetch-jobs/index.ts`:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  
  // Health check endpoint
  if (url.pathname.endsWith('/health')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST');
    return new Response(JSON.stringify({
      ok: true,
      rapidapi_key_present: !!rapidApiKey,
      rapidapi_host_present: !!rapidApiHost,
      key_length: rapidApiKey ? rapidApiKey.length : 0
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  // Diagnostics endpoint
  if (url.pathname.endsWith('/diagnostics')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';
    const query = url.searchParams.get('query') || 'software engineer';

    if (!rapidApiKey) {
      return new Response(JSON.stringify({
        error: 'RAPIDAPI_KEY not configured',
        instructions: 'Run: supabase secrets set RAPIDAPI_KEY=your_key_here'
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    try {
      const testUrl = `https://${rapidApiHost}/search?query=${encodeURIComponent(query)}&page=1&num_pages=1`;
      const response = await fetch(testUrl, {
        headers: {
          'X-RapidAPI-Key': rapidApiKey,
          'X-RapidAPI-Host': rapidApiHost
        }
      });

      const data = await response.json();
      
      return new Response(JSON.stringify({
        ok: response.ok,
        status: response.status,
        key_configured: true,
        key_first_chars: rapidApiKey.substring(0, 8) + '...',
        host: rapidApiHost,
        test_query: query,
        response_data: data,
        rate_limit_remaining: response.headers.get('x-ratelimit-requests-remaining')
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    } catch (error) {
      return new Response(JSON.stringify({
        error: 'API test failed',
        message: error.message,
        key_configured: true
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
  }

  // Main job search endpoint
  try {
    const { 
      query = 'software engineer', 
      location = '', 
      job_type,
      remote,
      page = 1,
      limit = 20
    } = await req.json();

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';

    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    // Build JSearch API URL
    let searchQuery = query;
    if (location) {
      searchQuery += ` in ${location}`;
    }
    if (remote) {
      searchQuery += ' remote';
    }

    const apiUrl = `https://${rapidApiHost}/search?query=${encodeURIComponent(searchQuery)}&page=${page}&num_pages=1`;

    console.log('Fetching from JSearch API:', { query: searchQuery, page });

    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': rapidApiHost
      }
    });

    if (!response.ok) {
      throw new Error(`JSearch API error: ${response.status} ${response.statusText}`);
    }

    const data = await response.json();
    
    // Transform JSearch response to our JobListing format
    const jobs: JobListing[] = (data.data || []).map((job: any) => ({
      id: job.job_id || `jsearch_${Date.now()}_${Math.random()}`,
      title: job.job_title || 'Unknown Title',
      company: job.employer_name || 'Unknown Company',
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || '',
      salary: job.job_min_salary && job.job_max_salary
        ? `$${job.job_min_salary.toLocaleString()} - $${job.job_max_salary.toLocaleString()}`
        : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'jsearch',
      skills: job.job_required_skills || [],
      company_size: job.employer_company_type,
      remote: job.job_is_remote || false,
      experience_level: job.job_required_experience?.required_experience_in_months 
        ? (job.job_required_experience.required_experience_in_months < 24 ? 'Entry' : 
           job.job_required_experience.required_experience_in_months < 60 ? 'Mid' : 'Senior')
        : undefined
    }));

    // Apply additional filters
    let filteredJobs = jobs;
    if (job_type) {
      filteredJobs = filteredJobs.filter(job => 
        job.type.toLowerCase() === job_type.toLowerCase()
      );
    }

    return new Response(JSON.stringify({
      jobs: filteredJobs,
      total: filteredJobs.length,
      page,
      totalPages: Math.ceil(filteredJobs.length / limit),
      rate_limit_remaining: response.headers.get('x-ratelimit-requests-remaining')
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Deployment Steps

1. **Copy the code above** to `supabase/functions/fetch-jobs/index.ts`

2. **Set secrets:**
```bash
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7 RAPIDAPI_HOST=jsearch.p.rapidapi.com
```

3. **Deploy:**
```bash
supabase functions deploy fetch-jobs
```

4. **Test health:**
```bash
curl "https://your-project.supabase.co/functions/v1/fetch-jobs/health"
```

5. **Test diagnostics:**
```bash
curl "https://your-project.supabase.co/functions/v1/fetch-jobs/diagnostics?query=developer"
```

## What's New

✅ `/health` - Check if RAPIDAPI_KEY is configured
✅ `/diagnostics` - Test actual API connectivity
✅ Real JSearch API integration
✅ Proper error handling
✅ Rate limit tracking
✅ Job data transformation
