# 🔴 FIX: Invalid API Key Error

## Error Message
```
[Login] Error: AuthApiError: Invalid API key
```

## Root Cause
Your `.env` file has **incorrect Supabase credentials**. The `VITE_SUPABASE_ANON_KEY` doesn't match your Supabase project.

---

## ✅ STEP-BY-STEP FIX

### Step 1: Get Your Correct Supabase Keys

1. **Go to Supabase Dashboard**: https://supabase.com/dashboard
2. **Select your project** (the one you're using for Jobtomize)
3. **Click Settings** (⚙️ icon in left sidebar)
4. **Click "API"** in the Settings menu
5. **Copy these TWO values**:
   - **Project URL** (looks like: `https://abcdefghijk.supabase.co`)
   - **anon/public key** (looks like: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...`)

### Step 2: Update Your .env File

1. **Open** `.env` file in your project root
2. **Replace** the values:

```env
VITE_SUPABASE_URL=https://your-actual-project-id.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.your-actual-key-here
```

### Step 3: Restart Dev Server

```bash
# Stop the server (Ctrl+C)
# Then restart:
npm run dev
```

### Step 4: Clear Browser Cache

1. Open **DevTools** (F12)
2. Right-click **Refresh button**
3. Select **"Empty Cache and Hard Reload"**

OR use **Incognito/Private window**

---

## 🔍 Verify It's Fixed

1. Open browser console (F12)
2. Try to login
3. You should see:
   ```
   [Auth] Attempting login...
   [Auth] Login successful
   ```

Instead of the "Invalid API key" error.

---

## 🚨 Common Mistakes

❌ **Using .env.example values** - These are placeholders!
❌ **Wrong project** - Make sure you're using the correct Supabase project
❌ **Service role key** - Use the **anon/public** key, NOT service_role
❌ **Extra spaces** - No spaces around the `=` sign
❌ **Didn't restart** - Must restart dev server after changing .env

---

## ✅ Correct .env Format

```env
VITE_SUPABASE_URL=https://abcdefghijk.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImFiY2RlZmdoaWprIiwicm9sZSI6ImFub24iLCJpYXQiOjE2ODk1NzYwMDAsImV4cCI6MjAwNTE1MjAwMH0.example-signature-here
```

---

## 🎯 Next Steps After Login Works

Once login works, check job search:
- See `REAL-JOBS-SETUP.md` for RapidAPI integration
- Deploy fetch-jobs function with real code
- Test job search functionality

---

**Need more help?** Check `DEBUGGING-GUIDE.md` for comprehensive troubleshooting.
