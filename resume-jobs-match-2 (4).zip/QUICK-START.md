# 🚀 Quick Start Guide - Deploy in 5 Minutes

## Option 1: Deploy to Vercel (Recommended)

### Step 1: Click the Deploy Button
[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fyour-username%2Fyour-repo&env=VITE_SUPABASE_URL,VITE_SUPABASE_ANON_KEY,VITE_OPENAI_API_KEY,VITE_STRIPE_PUBLIC_KEY&envDescription=Required%20API%20keys%20and%20configuration%20for%20the%20application&envLink=https%3A%2F%2Fgithub.com%2Fyour-username%2Fyour-repo%23configuration&project-name=ai-job-search-platform&repository-name=ai-job-search-platform)

### Step 2: Configure Environment Variables
When prompted, enter:
- **VITE_SUPABASE_URL**: Your Supabase project URL
- **VITE_SUPABASE_ANON_KEY**: Your Supabase anon key
- **VITE_OPENAI_API_KEY**: Your OpenAI API key
- **VITE_STRIPE_PUBLIC_KEY**: Your Stripe public key (optional)

### Step 3: Deploy!
Click "Deploy" and wait 2-3 minutes. Done! 🎉

---

## Option 2: Deploy to Netlify

### Step 1: Click the Deploy Button
[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/your-username/your-repo)

### Step 2: Connect Repository
- Authorize Netlify to access your GitHub
- Select the repository

### Step 3: Configure Build Settings
Build settings are pre-configured in `netlify.toml`

### Step 4: Add Environment Variables
In Netlify dashboard, go to Site Settings → Environment Variables:
- `VITE_SUPABASE_URL`
- `VITE_SUPABASE_ANON_KEY`
- `VITE_OPENAI_API_KEY`
- `VITE_STRIPE_PUBLIC_KEY` (optional)

### Step 5: Deploy!
Click "Deploy site" and wait 2-3 minutes. Done! 🎉

---

## 📋 Getting Your API Keys

### Supabase (Required)
1. Go to [supabase.com](https://supabase.com)
2. Create new project (free tier available)
3. Go to Settings → API
4. Copy "Project URL" and "anon public" key

### OpenAI (Required for AI features)
1. Go to [platform.openai.com](https://platform.openai.com)
2. Sign up/login
3. Go to API Keys
4. Create new secret key
5. Copy the key (starts with `sk-`)

### Stripe (Optional - for payments)
1. Go to [stripe.com](https://stripe.com)
2. Sign up for account
3. Go to Developers → API Keys
4. Copy "Publishable key" (starts with `pk_test_` for test mode)

---

## 🔧 Post-Deployment: Supabase Setup

After deploying, set up your database:

### 1. Run Database Migrations
- Go to your Supabase dashboard
- Click "SQL Editor"
- Run migrations from `supabase/migrations/` folder in order

### 2. Enable Realtime
- Go to Database → Replication
- Enable realtime for these tables:
  - `profiles`
  - `jobs`
  - `applications`
  - `email_campaigns`

### 3. Configure Authentication
- Go to Authentication → Providers
- Enable Email provider
- (Optional) Enable OAuth providers (Google, GitHub, etc.)

---

## ✅ Verify Deployment

1. Visit your deployed URL
2. Try signing up for an account
3. Check that the dashboard loads
4. Test job search functionality

---

## 🆘 Troubleshooting

### Build Failed
- Check that all environment variables are set
- Verify Node version is 18+
- Check build logs for specific errors

### App Loads But Features Don't Work
- Verify Supabase URL and key are correct
- Check that database migrations ran successfully
- Ensure Realtime is enabled on required tables

### AI Features Not Working
- Verify OpenAI API key is valid
- Check API key has sufficient credits
- Look for errors in browser console

---

## 📚 Next Steps

- [Full Documentation](./README.md)
- [Database Setup Guide](./README-Database-Setup.md)
- [Deployment Guide](./DEPLOYMENT.md)
- [Configuration Options](./.env.example)
