# Fix Supabase "Invalid API key" Error

## Problem
You're seeing this error:
```
AuthApiError: Invalid API key
Failed to load resource: the server responded with a status of 401
```

This means the Supabase credentials are **incorrect or expired**.

## Solution

### Step 1: Get Your Supabase Credentials

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project (or create a new one)
3. Go to **Settings** → **API**
4. Copy these two values:
   - **Project URL** (e.g., `https://xxxxx.supabase.co`)
   - **anon/public key** (starts with `eyJhbGci...`)

### Step 2: Create .env File

1. In your project root, create a file named `.env`
2. Add your credentials:

```bash
VITE_SUPABASE_URL=https://your-actual-project.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.your-actual-key-here
```

### Step 3: Restart Dev Server

```bash
# Stop the current server (Ctrl+C)
npm run dev
```

### Step 4: Verify Connection

Visit: `http://localhost:8080/?test-connection`

You should see:
- ✅ Connection Status: Connected
- ✅ Database Query: Success

## Why This Happened

The hardcoded credentials in `src/lib/supabase.ts` are:
- From a demo/test project
- Likely expired or restricted
- Not meant for production use

## Need a New Supabase Project?

1. Go to [supabase.com](https://supabase.com)
2. Click "Start your project"
3. Create a new project
4. Wait 2-3 minutes for setup
5. Get your credentials from Settings → API
