# Team Collaboration RLS Setup Guide

## Overview
This guide covers the Row Level Security (RLS) policies for team collaboration features, enabling secure sharing of resumes, job applications, and email campaigns.

## Permission Levels

### 1. **Owner** (Full Control)
- Create, read, update, delete their own resources
- Manage collaboration groups
- Add/remove team members
- Delete shared resources

### 2. **Admin** (Group Management)
- All editor permissions
- Add/remove group members
- Change member roles
- Cannot delete the resource

### 3. **Editor** (Read + Write)
- View shared resources
- Edit shared resources
- Add comments/notes
- Cannot delete resources
- Cannot manage group members

### 4. **Viewer** (Read-Only)
- View shared resources
- View comments/notes
- Cannot edit or delete
- Cannot manage members

## How It Works

### Sharing Flow
1. **Owner creates resource** (resume, application, campaign)
2. **Owner creates collaboration group** for that resource
3. **Owner invites team members** with specific roles
4. **Members accept invitation** (status: pending → active)
5. **Members access resource** based on their role

### Database Structure
```
collaboration_groups
├── id (UUID)
├── owner_id (UUID) → profiles.id
├── resource_type ('resume', 'job_application', 'email_campaign')
├── resource_id (UUID) → resumes.id, job_applications.id, etc.
└── name (TEXT)

collaboration_group_members
├── id (UUID)
├── group_id (UUID) → collaboration_groups.id
├── user_id (UUID) → profiles.id
├── role ('viewer', 'editor', 'admin')
└── status ('pending', 'active', 'declined')
```

## Usage Examples

### 1. Share a Resume (Read-Only)
```typescript
// Create collaboration group
const { data: group } = await supabase
  .from('collaboration_groups')
  .insert({
    owner_id: currentUserId,
    resource_type: 'resume',
    resource_id: resumeId,
    name: 'Resume Review Team'
  })
  .select()
  .single();

// Add viewer
await supabase
  .from('collaboration_group_members')
  .insert({
    group_id: group.id,
    user_id: teammateId,
    role: 'viewer',
    status: 'pending'
  });
```

### 2. Share Job Application (Edit Access)
```typescript
// Create group and add editor
const { data: group } = await supabase
  .from('collaboration_groups')
  .insert({
    owner_id: currentUserId,
    resource_type: 'job_application',
    resource_id: applicationId,
    name: 'Application Team'
  })
  .select()
  .single();

await supabase
  .from('collaboration_group_members')
  .insert({
    group_id: group.id,
    user_id: teammateId,
    role: 'editor',
    status: 'active'
  });
```

### 3. Share Email Campaign (Admin Access)
```typescript
// Add admin who can manage team
await supabase
  .from('collaboration_group_members')
  .insert({
    group_id: existingGroupId,
    user_id: teamLeadId,
    role: 'admin',
    status: 'active'
  });
```

### 4. Query Shared Resources
```typescript
// Get all resumes user has access to (owned + shared)
const { data: resumes } = await supabase
  .from('resumes')
  .select('*')
  .order('updated_at', { ascending: false });
// RLS automatically filters based on ownership + shared access

// Get collaboration details
const { data: collabs } = await supabase
  .from('collaboration_groups')
  .select(`
    *,
    members:collaboration_group_members(
      user_id,
      role,
      status,
      profile:profiles(email, full_name)
    )
  `)
  .eq('resource_type', 'resume')
  .eq('resource_id', resumeId);
```

## Security Features

### ✅ Implemented Protections
- **Owner-only deletion**: Only resource owner can delete
- **Role-based editing**: Editors can modify, viewers cannot
- **Invite system**: Pending invitations must be accepted
- **Automatic filtering**: RLS ensures users only see authorized data
- **Admin controls**: Group admins can manage members
- **Audit trail**: All changes tracked with timestamps

### 🔒 Key Security Rules
1. Users cannot see resources they don't own or aren't shared with
2. Viewers cannot edit shared resources
3. Only owners can delete resources
4. Only owners/admins can manage group membership
5. Inactive members lose all access immediately

## Testing RLS Policies

### Test as Owner
```sql
-- Set user context
SELECT set_config('request.jwt.claims', 
  '{"sub": "owner-user-id"}', true);

-- Should see own resources
SELECT * FROM resumes;

-- Should be able to delete
DELETE FROM resumes WHERE id = 'resume-id';
```

### Test as Editor
```sql
-- Set user context
SELECT set_config('request.jwt.claims', 
  '{"sub": "editor-user-id"}', true);

-- Should see shared resources
SELECT * FROM resumes;

-- Should be able to update
UPDATE resumes SET title = 'New Title' WHERE id = 'shared-resume-id';

-- Should NOT be able to delete
DELETE FROM resumes WHERE id = 'shared-resume-id'; -- Fails
```

### Test as Viewer
```sql
-- Set user context
SELECT set_config('request.jwt.claims', 
  '{"sub": "viewer-user-id"}', true);

-- Should see shared resources
SELECT * FROM resumes WHERE id = 'shared-resume-id';

-- Should NOT be able to update
UPDATE resumes SET title = 'Hack' WHERE id = 'shared-resume-id'; -- Fails

-- Should NOT be able to delete
DELETE FROM resumes WHERE id = 'shared-resume-id'; -- Fails
```

## Monitoring & Debugging

### Check User's Access Level
```sql
SELECT 
  cg.resource_type,
  cg.resource_id,
  cgm.role,
  cgm.status,
  cg.name as group_name
FROM collaboration_group_members cgm
JOIN collaboration_groups cg ON cgm.group_id = cg.id
WHERE cgm.user_id = 'user-id'
AND cgm.status = 'active';
```

### View All Shared Resources
```sql
SELECT 
  r.id,
  r.title,
  r.user_id as owner_id,
  cg.name as shared_group,
  COUNT(cgm.id) as member_count
FROM resumes r
JOIN collaboration_groups cg ON cg.resource_id = r.id
JOIN collaboration_group_members cgm ON cgm.group_id = cg.id
WHERE cg.resource_type = 'resume'
GROUP BY r.id, r.title, r.user_id, cg.name;
```

### Audit Access Attempts
```sql
-- Enable logging in postgresql.conf
ALTER DATABASE postgres SET log_statement = 'all';

-- Check logs for denied access
SELECT * FROM pg_stat_statements 
WHERE query LIKE '%resumes%'
ORDER BY calls DESC;
```

## Migration Instructions

1. **Run the migration**:
   ```bash
   # In Supabase Dashboard → SQL Editor
   # Copy and run: supabase/migrations/create_team_collaboration_rls_policies.sql
   ```

2. **Verify policies are active**:
   ```sql
   SELECT schemaname, tablename, policyname 
   FROM pg_policies 
   WHERE tablename IN ('resumes', 'job_applications', 'email_campaigns');
   ```

3. **Test with different users**:
   - Create test users
   - Share resources between them
   - Verify permissions work correctly

## Common Issues

### Issue: User can't see shared resource
**Solution**: Check collaboration_group_members status is 'active'
```sql
UPDATE collaboration_group_members 
SET status = 'active' 
WHERE user_id = 'user-id' AND status = 'pending';
```

### Issue: Editor can't update
**Solution**: Verify role is set correctly
```sql
UPDATE collaboration_group_members 
SET role = 'editor' 
WHERE user_id = 'user-id' AND group_id = 'group-id';
```

### Issue: Performance slow with many shares
**Solution**: Indexes are created automatically, but verify:
```sql
-- Check indexes exist
SELECT * FROM pg_indexes 
WHERE tablename = 'collaboration_group_members';
```

## Best Practices

1. **Always use groups**: Don't try to share directly
2. **Start with viewer**: Upgrade to editor only when needed
3. **Limit admins**: Only trusted team leads should be admins
4. **Clean up inactive**: Remove declined/inactive members regularly
5. **Audit regularly**: Review who has access to sensitive resources
6. **Use meaningful names**: Name groups clearly (e.g., "Q4 Campaign Team")

## Next Steps

- Implement UI for sharing resources
- Add email notifications for invitations
- Create activity logs for shared resources
- Add expiring access (time-limited shares)
- Implement share links with tokens
