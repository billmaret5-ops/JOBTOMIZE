# Deploy fetch-jobs with JSearch API Integration

## Updated Function Code

Replace your `supabase/functions/fetch-jobs/index.ts` with this code:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JSearchJob {
  job_id: string;
  employer_name: string;
  job_title: string;
  job_description: string;
  job_city?: string;
  job_state?: string;
  job_country?: string;
  job_apply_link: string;
  job_employment_type?: string;
  job_posted_at_datetime_utc?: string;
  job_salary_currency?: string;
  job_min_salary?: number;
  job_max_salary?: number;
  job_is_remote?: boolean;
  job_required_skills?: string[];
  employer_company_type?: string;
}

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

const transformJSearchToJobListing = (job: JSearchJob): JobListing => {
  const location = [job.job_city, job.job_state, job.job_country]
    .filter(Boolean)
    .join(', ') || 'Location not specified';

  let salary = undefined;
  if (job.job_min_salary && job.job_max_salary) {
    const currency = job.job_salary_currency || 'USD';
    salary = `${currency} ${job.job_min_salary.toLocaleString()} - ${job.job_max_salary.toLocaleString()}`;
  }

  return {
    id: job.job_id,
    title: job.job_title,
    company: job.employer_name,
    location,
    description: job.job_description || 'No description available',
    salary,
    type: job.job_employment_type || 'Full-time',
    posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
    apply_url: job.job_apply_link,
    source: 'JSearch',
    skills: job.job_required_skills || [],
    company_size: job.employer_company_type,
    remote: job.job_is_remote || false,
    experience_level: undefined
  };
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  
  if (url.pathname.endsWith('/fetch-jobs') && req.method === 'GET' && !url.search) {
    return new Response(JSON.stringify({ status: 'ok' }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    let query = 'software engineer';
    let location = '';
    let remote = undefined;
    let page = 1;

    if (req.method === 'GET') {
      query = url.searchParams.get('query') || query;
      location = url.searchParams.get('location') || location;
      const remoteParam = url.searchParams.get('remote');
      remote = remoteParam ? remoteParam === 'true' : undefined;
      page = parseInt(url.searchParams.get('page') || '1');
    } else if (req.method === 'POST') {
      const body = await req.json();
      query = body.query || query;
      location = body.location || location;
      remote = body.remote;
      page = body.page || page;
    }

    const jsearchUrl = new URL('https://jsearch.p.rapidapi.com/search');
    jsearchUrl.searchParams.set('query', query);
    if (location) jsearchUrl.searchParams.set('location', location);
    if (remote !== undefined) jsearchUrl.searchParams.set('remote_jobs_only', String(remote));
    jsearchUrl.searchParams.set('page', String(page));
    jsearchUrl.searchParams.set('num_pages', '1');

    const response = await fetch(jsearchUrl.toString(), {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    const jobs: JobListing[] = (data.data || []).map(transformJSearchToJobListing);

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      totalPages: 1
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Deployment Steps

1. **Set your RapidAPI key:**
```bash
supabase secrets set RAPIDAPI_KEY=your_actual_rapidapi_key_here
```

2. **Deploy the function:**
```bash
supabase functions deploy fetch-jobs
```

3. **Test the endpoint:**
```bash
# Test with curl
curl 'https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs?query=software%20engineer&location=remote'

# Or with your frontend code
const res = await fetch(`${base}/fetch-jobs?query=${encodeURIComponent('software engineer')}&location=remote`)
const { jobs } = await res.json()
```

## What Changed

✅ Replaced mock data with real JSearch API integration
✅ Added RapidAPI authentication headers
✅ Transforms JSearch response to match your JobListing interface
✅ Supports both GET and POST requests
✅ Handles query, location, remote, and page parameters
✅ Proper error handling and CORS headers

## API Routes

- **GET** `/fetch-jobs?query=...&location=...&remote=true&page=1`
- **POST** `/fetch-jobs` with JSON body `{ query, location, remote, page }`
- **Healthcheck** `GET /fetch-jobs` returns `{ status: "ok" }`

Your frontend code will work without changes! 🚀
