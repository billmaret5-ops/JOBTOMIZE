# 🔧 Famous.AI Supabase Setup Guide

## ⚠️ CURRENT ISSUE
Your Supabase API key is **INVALID or EXPIRED**. You need to update your credentials.

## 📋 Quick Fix Steps

### Step 1: Get Your Supabase Credentials

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. **Sign in** or **Create a new project** if you don't have one
3. Select your project (or create one named "jobtomize")
4. Click **Settings** (gear icon) → **API**
5. Copy these two values:
   - **Project URL** (looks like: `https://xxxxx.supabase.co`)
   - **anon public key** (starts with `eyJhbGci...`)

### Step 2: Update Environment Variables in Famous.AI

Since you're on Famous.AI servers, you need to set environment variables:

1. In Famous.AI interface, look for **Environment Variables** or **Settings**
2. Add these two variables:
   ```
   VITE_SUPABASE_URL=https://your-project.supabase.co
   VITE_SUPABASE_ANON_KEY=eyJhbGci...your-actual-key
   ```
3. **Save** and the app will automatically rebuild

### Step 3: Verify Connection

1. Visit: `https://jobtomize.com/?test-connection`
2. Click **Retest** button
3. Should show ✅ green checkmarks

## 🎯 Alternative: Update Hardcoded Values

If Famous.AI doesn't support environment variables, reply with:
**"Here are my Supabase credentials: URL and KEY"**

And I'll update the code directly with your credentials.

## 📝 What You Need

Reply with this format:
```
SUPABASE_URL: https://xxxxx.supabase.co
SUPABASE_KEY: eyJhbGci...
```
