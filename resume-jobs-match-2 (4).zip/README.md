# 🚀 AI-Powered Job Search & Email Campaign Platform

A comprehensive full-stack application combining intelligent job search, application tracking, AI-powered resume building, and advanced email campaign management.

## 🎉 Quick Deploy

Deploy this application to your preferred hosting platform with one click:

[![Deploy with Vercel](https://vercel.com/button)](https://vercel.com/new/clone?repository-url=https%3A%2F%2Fgithub.com%2Fyour-username%2Fyour-repo&env=VITE_SUPABASE_URL,VITE_SUPABASE_ANON_KEY,VITE_OPENAI_API_KEY,VITE_STRIPE_PUBLIC_KEY&envDescription=Required%20API%20keys%20and%20configuration%20for%20the%20application&envLink=https%3A%2F%2Fgithub.com%2Fyour-username%2Fyour-repo%23configuration&project-name=ai-job-search-platform&repository-name=ai-job-search-platform)

[![Deploy to Netlify](https://www.netlify.com/img/deploy/button.svg)](https://app.netlify.com/start/deploy?repository=https://github.com/your-username/your-repo)

### 📋 What You'll Need

Before deploying, have these ready:
- **Supabase Account** (free tier available) - [Sign up here](https://supabase.com)
- **OpenAI API Key** (for AI features) - [Get key here](https://platform.openai.com/api-keys)
- **Stripe Account** (optional, for payments) - [Sign up here](https://stripe.com)

### 🔧 Post-Deployment Setup

1. **Supabase Configuration**
   - Create a new project at [supabase.com](https://supabase.com)
   - Copy your project URL and anon key
   - Run migrations from `supabase/migrations/` in SQL Editor
   - Enable Realtime on tables: `profiles`, `jobs`, `applications`, `email_campaigns`

2. **Environment Variables**
   - Add your Supabase URL and anon key
   - Add OpenAI API key (required for AI job matching)
   - Add Stripe public key (optional, for subscription features)
   - See [Configuration](#️-configuration) section for complete list

3. **Deploy Edge Functions** (Optional for advanced features)
   ```bash
   supabase functions deploy
   ```


## ✨ Key Features

### 🎯 Job Search & Application Tracking
- **AI Job Matching** - Intelligent job recommendations based on skills and preferences
- **Application Tracker** - Comprehensive pipeline management with status automation
- **Interview Preparation** - AI-powered mock interviews with video analysis
- **Resume Builder** - Drag-and-drop resume editor with ATS optimization
- **One-Click Apply** - Automated job applications across multiple platforms

### 📧 Email Campaign Management
- **Visual Email Builder** - Drag-and-drop WYSIWYG editor with live preview
- **A/B Testing** - Advanced split testing with Bayesian optimization
- **Email Warmup** - Automated domain reputation building
- **Deliverability Monitoring** - Real-time tracking and spam score analysis
- **Template Library** - 100+ professional templates with analytics

### 🤖 AI-Powered Features
- **Resume Optimization** - ATS keyword matching and suggestions
- **Cover Letter Generator** - Personalized cover letters for each application
- **Interview Coach** - Voice analysis and body language feedback
- **Email Personalization** - Dynamic content based on recipient behavior
- **Predictive Analytics** - ML-powered insights and recommendations

### 👥 Collaboration & Real-Time
- **Live Resume Editing** - Multi-user collaborative editing with conflict resolution
- **Team Workspaces** - Shared campaigns and application tracking
- **Real-Time Analytics** - Live dashboards with WebSocket streaming
- **Video Conferencing** - Built-in interview practice sessions

## 🛠️ Tech Stack

- **Frontend**: React 18 + TypeScript + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Backend**: Supabase (PostgreSQL + Auth + Storage + Realtime)
- **AI/ML**: OpenAI GPT-4, Custom ML models
- **Payments**: Stripe
- **Email**: SendGrid, Mailgun, Postmark, AWS SES
- **State Management**: React Context + Custom Hooks
- **Real-Time**: WebSockets + Supabase Realtime

## 📦 Installation

### Prerequisites
- Node.js 18+ and npm/yarn/pnpm
- Supabase account
- OpenAI API key (for AI features)
- Stripe account (for payments)

### Setup Steps

1. **Clone the repository**
```bash
git clone <repository-url>
cd <project-directory>
```

2. **Install dependencies**
```bash
npm install
```

3. **Configure environment variables**
```bash
cp .env.example .env
```
Edit `.env` and add your API keys (see Configuration section below)

4. **Set up Supabase**
```bash
# Run all migrations
npm run db:migrate
```

5. **Start development server**
```bash
npm run dev
```

Visit `http://localhost:5173`

## ⚙️ Configuration

### Required Environment Variables

See `.env.example` for all variables. Minimum required:

```env
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_anon_key
VITE_OPENAI_API_KEY=your_openai_key (for AI features)
VITE_STRIPE_PUBLIC_KEY=your_stripe_key (for payments)
```

### Database Setup

1. Create a Supabase project at https://supabase.com
2. Run migrations in order from `supabase/migrations/`
3. Enable Realtime for required tables
4. Configure RLS policies (included in migrations)

## 🚀 Deployment

### Vercel (Recommended)
```bash
npm run build
vercel --prod
```

### Netlify
```bash
npm run build
netlify deploy --prod
```

### Environment Variables
Add all `.env` variables to your hosting platform's environment settings.

## 📚 Project Structure

```
src/
├── components/        # React components
│   ├── ui/           # shadcn/ui components
│   ├── auth/         # Authentication components
│   ├── analytics/    # Analytics dashboards
│   └── ...
├── hooks/            # Custom React hooks
├── lib/              # Utility functions & services
├── services/         # API services & business logic
├── contexts/         # React contexts
├── pages/            # Page components
└── types/            # TypeScript types

supabase/
├── functions/        # Edge functions
└── migrations/       # Database migrations

server/               # Express backend (optional)
```

## 🧪 Testing

```bash
# Run tests
npm test

# Run tests with coverage
npm run test:coverage

# E2E tests
npm run test:e2e
```

## 📖 Documentation

- [Database Setup](./README-Database-Setup.md)
- [API Documentation](./docs/api.md)
- [Component Library](./docs/components.md)

## 🔒 Security

- All API keys stored in environment variables
- Row Level Security (RLS) enabled on all tables
- JWT-based authentication
- CSRF protection
- Input validation and sanitization

## 🤝 Contributing

1. Fork the repository
2. Create feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit changes (`git commit -m 'Add AmazingFeature'`)
4. Push to branch (`git push origin feature/AmazingFeature`)
5. Open Pull Request

## 📄 License

MIT License - see LICENSE file for details

## 🆘 Support

- Documentation: [Link to docs]
- Issues: [GitHub Issues]
- Email: support@yourapp.com

## 🎯 Roadmap

- [ ] Mobile app (React Native)
- [ ] Chrome extension for one-click apply
- [ ] Advanced ML models for job matching
- [ ] Integration with more job boards
- [ ] White-label solution for enterprises
