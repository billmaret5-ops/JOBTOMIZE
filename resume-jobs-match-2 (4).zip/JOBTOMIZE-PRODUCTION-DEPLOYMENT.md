# Jobtomize.com Production Deployment Guide

## Complete Domain Configuration & Production Setup

### 1. DNS Configuration

#### A. Vercel DNS Settings (Recommended)
```
Type    Name    Value                           TTL
A       @       76.76.21.21                     Auto
CNAME   www     cname.vercel-dns.com           Auto
```

#### B. Alternative DNS (Cloudflare/Other)
```
Type    Name    Value                           TTL
A       @       76.76.21.21                     300
CNAME   www     jobtomize.vercel.app           300
```

#### C. Email DNS Records (for SendGrid/Mailgun)
```
Type    Name                    Value                               TTL
TXT     @                       v=spf1 include:sendgrid.net ~all   300
CNAME   em123                   u123456.wl.sendgrid.net            300
CNAME   s1._domainkey          s1.domainkey.u123456.wl.sendgrid.net  300
CNAME   s2._domainkey          s2.domainkey.u123456.wl.sendgrid.net  300
```

### 2. Vercel Domain Setup

#### Step 1: Add Domain in Vercel Dashboard
```bash
1. Go to Vercel Dashboard → Your Project → Settings → Domains
2. Add "jobtomize.com"
3. Add "www.jobtomize.com"
4. Vercel will provide DNS records to configure
```

#### Step 2: Configure Domain Settings
```json
{
  "domains": ["jobtomize.com", "www.jobtomize.com"],
  "redirects": [
    {
      "source": "www.jobtomize.com",
      "destination": "https://jobtomize.com",
      "permanent": true
    }
  ]
}
```

### 3. SSL Certificate Setup

#### Automatic SSL (Vercel - Recommended)
- Vercel automatically provisions SSL certificates via Let's Encrypt
- Certificates auto-renew every 90 days
- No manual configuration needed

#### Manual SSL Configuration (if needed)
```bash
# Generate SSL certificate
openssl req -x509 -newkey rsa:4096 -keyout key.pem -out cert.pem -days 365

# Upload to Vercel (if custom cert needed)
vercel certs add jobtomize.com cert.pem key.pem
```

### 4. Environment Variables - Production

#### Required Production Variables
```env
# Supabase Configuration
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key-here
SUPABASE_SERVICE_ROLE_KEY=your-service-role-key

# Domain Configuration
VITE_APP_URL=https://jobtomize.com
VITE_API_URL=https://jobtomize.com/api

# Email Service (SendGrid)
SENDGRID_API_KEY=SG.xxxxxxxxxxxxx
SENDGRID_FROM_EMAIL=noreply@jobtomize.com
SENDGRID_FROM_NAME=Jobtomize

# Stripe Payment
VITE_STRIPE_PUBLIC_KEY=pk_live_xxxxxxxxxxxxx
STRIPE_SECRET_KEY=sk_live_xxxxxxxxxxxxx
STRIPE_WEBHOOK_SECRET=whsec_xxxxxxxxxxxxx

# OAuth Providers
GOOGLE_CLIENT_ID=xxxxxxxxxxxxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=xxxxxxxxxxxxx
LINKEDIN_CLIENT_ID=xxxxxxxxxxxxx
LINKEDIN_CLIENT_SECRET=xxxxxxxxxxxxx

# AI Services
OPENAI_API_KEY=sk-xxxxxxxxxxxxx
ANTHROPIC_API_KEY=sk-ant-xxxxxxxxxxxxx

# Security
JWT_SECRET=your-secure-random-string-min-32-chars
SESSION_SECRET=your-secure-session-secret

# Analytics
GOOGLE_ANALYTICS_ID=G-XXXXXXXXXX
SENTRY_DSN=https://xxxxxxxxxxxxx@sentry.io/xxxxxxxxxxxxx
```

#### Setting Variables in Vercel
```bash
# Via CLI
vercel env add VITE_SUPABASE_URL production
vercel env add VITE_STRIPE_PUBLIC_KEY production

# Via Dashboard
1. Go to Project Settings → Environment Variables
2. Add each variable with "Production" scope
3. Redeploy after adding variables
```

### 5. Supabase Production Configuration

#### Update Supabase URL Configuration
```sql
-- In Supabase Dashboard → Authentication → URL Configuration
Site URL: https://jobtomize.com
Redirect URLs: 
  - https://jobtomize.com/auth/callback
  - https://jobtomize.com/oauth/callback
```

#### CORS Configuration
```sql
-- In Supabase Dashboard → API Settings
CORS Origins:
  - https://jobtomize.com
  - https://www.jobtomize.com
```

### 6. OAuth Redirect URIs

#### Google OAuth Console
```
Authorized JavaScript origins:
  - https://jobtomize.com

Authorized redirect URIs:
  - https://jobtomize.com/auth/callback
  - https://jobtomize.com/oauth/google/callback
```

#### LinkedIn Developer Portal
```
Redirect URLs:
  - https://jobtomize.com/oauth/linkedin/callback
```

### 7. Deployment Commands

#### Initial Production Deployment
```bash
# Build and deploy to production
npm run build
vercel --prod

# Or using Vercel CLI with custom domain
vercel --prod --name jobtomize
```

#### Continuous Deployment (GitHub Integration)
```yaml
# .github/workflows/production-deploy.yml
name: Production Deploy
on:
  push:
    branches: [main]
jobs:
  deploy:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - uses: actions/setup-node@v3
      - run: npm ci
      - run: npm run build
      - uses: amondnet/vercel-action@v20
        with:
          vercel-token: ${{ secrets.VERCEL_TOKEN }}
          vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
          vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
          vercel-args: '--prod'
```

### 8. Post-Deployment Verification

#### Checklist
- [ ] Domain resolves to https://jobtomize.com
- [ ] SSL certificate is valid (check padlock icon)
- [ ] www redirects to non-www (or vice versa)
- [ ] Authentication works (Google/LinkedIn OAuth)
- [ ] Email sending works (test signup/verification)
- [ ] Payment processing works (test Stripe integration)
- [ ] All API endpoints respond correctly
- [ ] Database connections work
- [ ] Real-time features function properly

#### Testing Commands
```bash
# Test DNS resolution
nslookup jobtomize.com

# Test SSL certificate
openssl s_client -connect jobtomize.com:443 -servername jobtomize.com

# Test HTTP to HTTPS redirect
curl -I http://jobtomize.com

# Test API endpoints
curl https://jobtomize.com/api/health
```

### 9. Monitoring & Alerts

#### Setup Monitoring
```bash
# Vercel Analytics (built-in)
- Automatically enabled for production

# Sentry Error Tracking
- Configure SENTRY_DSN in environment variables
- Errors automatically reported

# Uptime Monitoring (UptimeRobot)
- Monitor: https://jobtomize.com
- Alert: email/SMS on downtime
```

### 10. Security Headers

#### Configure in vercel.json
```json
{
  "headers": [
    {
      "source": "/(.*)",
      "headers": [
        {
          "key": "X-Content-Type-Options",
          "value": "nosniff"
        },
        {
          "key": "X-Frame-Options",
          "value": "DENY"
        },
        {
          "key": "X-XSS-Protection",
          "value": "1; mode=block"
        },
        {
          "key": "Strict-Transport-Security",
          "value": "max-age=31536000; includeSubDomains"
        }
      ]
    }
  ]
}
```

### 11. Backup & Disaster Recovery

#### Database Backups
```bash
# Supabase automatic backups (enabled by default)
# Manual backup command
supabase db dump -f backup.sql

# Restore command
supabase db reset --db-url "postgresql://..."
```

#### Code Backups
```bash
# GitHub repository serves as code backup
# Tag production releases
git tag -a v1.0.0 -m "Production release v1.0.0"
git push origin v1.0.0
```

### 12. Performance Optimization

#### Enable Caching
```json
{
  "headers": [
    {
      "source": "/static/(.*)",
      "headers": [
        {
          "key": "Cache-Control",
          "value": "public, max-age=31536000, immutable"
        }
      ]
    }
  ]
}
```

#### CDN Configuration
- Vercel automatically uses global CDN
- Static assets cached at edge locations
- No additional configuration needed

---

## Quick Start Checklist

1. ✅ Configure DNS records at domain registrar
2. ✅ Add domain in Vercel dashboard
3. ✅ Wait for SSL certificate provisioning (5-10 minutes)
4. ✅ Set all production environment variables
5. ✅ Update Supabase URL configuration
6. ✅ Configure OAuth redirect URIs
7. ✅ Deploy to production: `vercel --prod`
8. ✅ Test all functionality
9. ✅ Setup monitoring and alerts
10. ✅ Document and celebrate! 🎉

## Support Resources

- Vercel Docs: https://vercel.com/docs
- Supabase Docs: https://supabase.com/docs
- DNS Checker: https://dnschecker.org
- SSL Checker: https://www.ssllabs.com/ssltest/
