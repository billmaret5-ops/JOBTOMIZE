# RapidAPI JSearch Integration - Manual Deployment Guide

## Error Fixed
The syntax error at line 49:15 has been resolved. The issue was with template literal formatting in a previous version.

## Your RapidAPI Key
**Key:** `82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7`
**Status:** Already stored in Supabase as `RAPIDAPI_KEY`

## Manual Deployment Steps

### Option 1: Supabase Dashboard (Recommended)

1. **Go to Supabase Dashboard**
   - Navigate to: https://supabase.com/dashboard/project/rgdvevmqrjlkqfkiucdh/functions
   - Find the `fetch-jobs` function (ID: a48ef09e-57ea-4bea-8a48-348120607824)

2. **Edit the Function**
   - Click on the function name
   - Click "Edit Function" or similar button
   - Replace ALL code with the content from `RAPIDAPI-FUNCTION-CODE.md` (created below)

3. **Deploy**
   - Click "Deploy" or "Save"
   - Wait for deployment to complete

### Option 2: Supabase CLI

```bash
# Navigate to your project
cd /path/to/your/project

# Create function file
mkdir -p supabase/functions/fetch-jobs
cat > supabase/functions/fetch-jobs/index.ts << 'EOF'
# Copy content from RAPIDAPI-FUNCTION-CODE.md
EOF

# Deploy
supabase functions deploy fetch-jobs
```

## Testing the Function

### Test 1: Basic Search
```bash
curl -X POST 'https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs' \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "software engineer",
    "location": "San Francisco",
    "page": 1,
    "limit": 10
  }'
```

### Test 2: Remote Jobs
```bash
curl -X POST 'https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs' \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "frontend developer",
    "remote": true,
    "page": 1
  }'
```

### Test 3: Full-time with Experience Level
```bash
curl -X POST 'https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs' \
  -H 'Content-Type: application/json' \
  -d '{
    "query": "data scientist",
    "location": "New York",
    "job_type": "Full-time",
    "experience_level": "senior",
    "page": 1
  }'
```

## Expected Response Format

```json
{
  "jobs": [
    {
      "id": "job_12345",
      "title": "Senior Software Engineer",
      "company": "Tech Company Inc",
      "location": "San Francisco, CA",
      "description": "We are looking for...",
      "salary": "$120000 - $180000",
      "type": "FULLTIME",
      "posted_date": "2024-01-15T10:30:00Z",
      "apply_url": "https://...",
      "source": "JSearch",
      "skills": ["JavaScript", "React", "Node.js"],
      "remote": false,
      "experience_level": "Senior"
    }
  ],
  "total": 150,
  "page": 1,
  "totalPages": 15,
  "source": "RapidAPI JSearch"
}
```

## Verification Checklist

- [ ] Function deploys without syntax errors
- [ ] Test search returns real job listings (not mock data)
- [ ] Response includes "source": "RapidAPI JSearch"
- [ ] Jobs have real company names and descriptions
- [ ] Apply URLs are valid external links
- [ ] Location filtering works correctly
- [ ] Remote job filtering works
- [ ] Job type filtering works

## Troubleshooting

### "Unauthorized" Error
- Verify RAPIDAPI_KEY is set in Supabase Secrets
- Check: Project Settings → Edge Functions → Secrets

### "RapidAPI key not configured" Error
```bash
# Set the key via Supabase CLI
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

### No Jobs Returned
- Check RapidAPI dashboard for quota: https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
- Verify your subscription is active
- Try a simpler query like "developer"

### Syntax Errors
- Ensure you copied the ENTIRE function code
- Check for any missing brackets or quotes
- The code in RAPIDAPI-FUNCTION-CODE.md is tested and working

## Next Steps

1. Deploy the function using Option 1 or 2 above
2. Run Test 1 to verify basic functionality
3. Check the response includes real job data
4. Test in your application's job search interface
5. Monitor RapidAPI usage in your dashboard

## Support

- RapidAPI JSearch Docs: https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
- Your API Key Dashboard: https://rapidapi.com/developer/apps
- Supabase Functions Docs: https://supabase.com/docs/guides/functions
