export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20
    } = await req.json();

    // Get RapidAPI key from environment
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    console.log('Fetching real jobs from JSearch API...');

    // Call JSearch API
    const searchQuery = location ? `${query} in ${location}` : query;
    const url = `https://jsearch.p.rapidapi.com/search?query=${encodeURIComponent(searchQuery)}&page=${page}&num_pages=1`;
    
    const response = await fetch(url, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch API error:', response.status, errorText);
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    console.log(`Fetched ${data.data?.length || 0} real jobs`);
    
    // Transform JSearch data to our format
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || '',
      salary: job.job_min_salary && job.job_max_salary 
        ? `$${job.job_min_salary.toLocaleString()} - $${job.job_max_salary.toLocaleString()}`
        : job.job_salary_period || null,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'jsearch',
      skills: job.job_required_skills || [],
      company_size: null,
      remote: job.job_is_remote || false,
      experience_level: job.job_required_experience?.required_experience_in_months 
        ? (job.job_required_experience.required_experience_in_months < 24 ? 'Entry' : 
           job.job_required_experience.required_experience_in_months < 60 ? 'Mid' : 'Senior')
        : null
    }));

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      totalPages: 1,
      source: 'JSearch API (Real Data)'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});