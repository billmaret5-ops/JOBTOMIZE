# 🔧 FIX RAPIDAPI KEY - SECRET NAME IS WRONG

## ❌ THE PROBLEM
You have `RAPID_API` in Supabase secrets, but the function looks for `RAPIDAPI_KEY` (no underscore).

## ✅ THE SOLUTION - 3 STEPS

### Step 1: Set the CORRECT Secret Name
```bash
# Remove the wrong one (optional)
supabase secrets unset RAPID_API

# Set the CORRECT one (no underscore, add _KEY at end)
supabase secrets set RAPIDAPI_KEY="your_actual_rapidapi_key_here"
```

**Get your RapidAPI key from:** https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch

### Step 2: Deploy Updated Function
```bash
# Deploy with the updated CORS for jobtomize.com
supabase functions deploy fetch-jobs
```

### Step 3: Test It
```bash
# Test health (should show rapidapi_key_present: true)
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health"

# Test actual search
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=developer&location=remote" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

## 📋 Updated Function Code

Copy this to `supabase/functions/fetch-jobs/index.ts`:

```typescript
const allowedOrigins = new Set([
  'https://jobtomize.com',
  'https://www.jobtomize.com',
  'http://localhost:3000',
  'http://localhost:5173'
]);

function getOrigin(req: Request): string {
  const origin = req.headers.get('Origin') || '';
  return allowedOrigins.has(origin) ? origin : 'https://jobtomize.com';
}

const corsHeaders = {
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
};

Deno.serve(async (req) => {
  const origin = getOrigin(req);
  
  if (req.method === 'OPTIONS') {
    return new Response('ok', { 
      headers: { ...corsHeaders, 'Access-Control-Allow-Origin': origin }
    });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;
  const jsonHeaders = {
    ...corsHeaders,
    'Access-Control-Allow-Origin': origin,
    'Content-Type': 'application/json'
  };

  // Health check
  if (pathname.includes('/health')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    return new Response(JSON.stringify({
      ok: true,
      rapidapi_key_present: !!rapidApiKey,
      timestamp: new Date().toISOString()
    }), { headers: jsonHeaders });
  }

  try {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      return new Response(JSON.stringify({
        error: 'RAPIDAPI_KEY not set. Run: supabase secrets set RAPIDAPI_KEY=your_key'
      }), { status: 500, headers: jsonHeaders });
    }

    let query = 'software engineer';
    let location = '';
    let page = 1;

    // GET /search
    if (pathname.includes('/search') && req.method === 'GET') {
      query = url.searchParams.get('query') || query;
      location = url.searchParams.get('location') || '';
      page = parseInt(url.searchParams.get('page') || '1');
    } 
    // POST
    else if (req.method === 'POST') {
      const body = await req.json();
      query = body.query || query;
      location = body.location || '';
      page = body.page || 1;
    }

    let searchQuery = query;
    if (location) searchQuery += ` in ${location}`;

    const apiUrl = `https://jsearch.p.rapidapi.com/search?query=${encodeURIComponent(searchQuery)}&page=${page}`;
    
    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      return new Response(JSON.stringify({
        error: 'RapidAPI request failed',
        status: response.status,
        details: errorText
      }), { status: response.status, headers: jsonHeaders });
    }

    const data = await response.json();
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: `${job.job_city}, ${job.job_state}`,
      description: job.job_description,
      salary: job.job_salary,
      type: job.job_employment_type,
      posted_date: job.job_posted_at_datetime_utc,
      apply_url: job.job_apply_link,
      source: 'jsearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote
    }));

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page
    }), { headers: jsonHeaders });

  } catch (error) {
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), { status: 500, headers: jsonHeaders });
  }
});
```

## 🎯 Why This Fixes It

1. **Correct Secret Name**: `RAPIDAPI_KEY` (not `RAPID_API`)
2. **Proper CORS**: Allows jobtomize.com, www.jobtomize.com, localhost
3. **Both Methods**: Supports GET and POST
4. **Auth Headers**: Frontend already sends correct headers

## ✅ Verification Checklist

After deploying, verify:
- [ ] `supabase secrets list` shows `RAPIDAPI_KEY`
- [ ] Health endpoint returns `rapidapi_key_present: true`
- [ ] Search returns actual jobs from RapidAPI
- [ ] No CORS errors in browser console
- [ ] Jobs display on jobtomize.com

## 🚨 Common Mistakes

❌ `RAPID_API` - Wrong (has underscore in middle)
❌ `RAPIDAPI` - Wrong (missing _KEY)
✅ `RAPIDAPI_KEY` - Correct!
