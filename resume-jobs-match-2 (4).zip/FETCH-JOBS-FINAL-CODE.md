# FINAL fetch-jobs Function Code - COPY THIS EXACTLY

**CRITICAL: Your secret is named "Jsearch" not "RAPIDAPI_KEY"**

Copy this ENTIRE code into your Supabase fetch-jobs function editor:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20,
      job_type,
      remote,
      experience_level
    } = await req.json();

    // Get API key from "Jsearch" secret
    const rapidApiKey = Deno.env.get('Jsearch');
    
    if (!rapidApiKey) {
      console.error('Jsearch secret not found');
      throw new Error('API key not configured');
    }

    console.log('API Key found:', rapidApiKey.substring(0, 10) + '...');

    const searchQuery = location ? query + ' in ' + location : query;
    
    let employmentTypes = '';
    if (job_type === 'Full-time') employmentTypes = 'FULLTIME';
    else if (job_type === 'Part-time') employmentTypes = 'PARTTIME';
    else if (job_type === 'Contract') employmentTypes = 'CONTRACTOR';
    else if (job_type === 'Internship') employmentTypes = 'INTERN';

    const apiUrl = new URL('https://jsearch.p.rapidapi.com/search');
    apiUrl.searchParams.append('query', searchQuery);
    apiUrl.searchParams.append('page', page.toString());
    apiUrl.searchParams.append('num_pages', '1');
    
    if (remote) {
      apiUrl.searchParams.append('remote_jobs_only', 'true');
    }
    
    if (employmentTypes) {
      apiUrl.searchParams.append('employment_types', employmentTypes);
    }

    console.log('Calling JSearch API:', apiUrl.toString());

    const response = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch error:', response.status, errorText);
      throw new Error('JSearch API returned ' + response.status);
    }

    const data = await response.json();
    console.log('Jobs found:', data.data?.length || 0);
    
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id || 'job_' + Date.now(),
      title: job.job_title || 'Position',
      company: job.employer_name || 'Company',
      location: job.job_city ? job.job_city + ', ' + job.job_state : job.job_country || 'Remote',
      description: job.job_description || 'No description',
      salary: job.job_salary || undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || '#',
      source: 'JSearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false
    }));

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page,
      totalPages: Math.ceil((data.total || jobs.length) / limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: error.message,
      details: 'Check function logs for details'
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Deployment Steps:
1. Go to: https://supabase.com/dashboard/project/rgdvevmqrjlkqfkiucdh/functions/fetch-jobs
2. Click "Edit function"
3. Delete ALL existing code
4. Copy/paste the code above
5. Click "Deploy"
6. Wait for success message

## Testing:
After deployment, test with this cURL:
```bash
curl -X POST 'https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs' \
  -H 'Authorization: Bearer YOUR_ANON_KEY' \
  -H 'Content-Type: application/json' \
  -d '{"query":"software engineer","location":"New York"}'
```
