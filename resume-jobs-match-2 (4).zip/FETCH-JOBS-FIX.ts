export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const path = url.pathname;

  // Health check endpoint
  if (req.method === 'GET' && path.endsWith('/health')) {
    return new Response(JSON.stringify({ 
      status: 'ok', 
      timestamp: new Date().toISOString(),
      version: '53'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  // Get RapidAPI key
  const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
  
  if (!rapidApiKey) {
    console.error('RAPIDAPI_KEY not configured');
    return new Response(JSON.stringify({ 
      error: 'RapidAPI key not configured. Please set RAPIDAPI_KEY secret.' 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    let query = 'software engineer';
    let location = '';
    let page = 1;
    let remote_jobs_only = false;

    // Handle GET /search with query params
    if (req.method === 'GET' && path.endsWith('/search')) {
      query = url.searchParams.get('query') || 'software engineer';
      location = url.searchParams.get('location') || '';
      page = parseInt(url.searchParams.get('page') || '1');
      remote_jobs_only = url.searchParams.get('remote') === 'true';
    }
    // Handle POST with JSON body
    else if (req.method === 'POST') {
      const body = await req.json();
      query = body.query || 'software engineer';
      location = body.location || '';
      page = body.page || 1;
      remote_jobs_only = body.remote || false;
    }
    // Unknown route
    else {
      return new Response(JSON.stringify({ 
        error: 'Not found. Use GET /health, GET /search?query=..., or POST with JSON body.' 
      }), {
        status: 404,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    // Build JSearch API URL
    const jsearchUrl = new URL('https://jsearch.p.rapidapi.com/search');
    jsearchUrl.searchParams.set('query', query);
    if (location) jsearchUrl.searchParams.set('location', location);
    jsearchUrl.searchParams.set('page', page.toString());
    jsearchUrl.searchParams.set('num_pages', '1');
    if (remote_jobs_only) jsearchUrl.searchParams.set('remote_jobs_only', 'true');
    jsearchUrl.searchParams.set('employment_types', 'FULLTIME,PARTTIME,CONTRACTOR');

    console.log('Calling JSearch API:', jsearchUrl.toString());

    // Call RapidAPI JSearch
    const response = await fetch(jsearchUrl.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch API error:', response.status, errorText);
      return new Response(JSON.stringify({ 
        error: 'JSearch API request failed',
        status: response.status,
        details: errorText
      }), {
        status: response.status,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }

    const data = await response.json();

    // Map JSearch response to our format
    const jobs: JobListing[] = Array.isArray(data?.data) ? data.data.map((job: any) => ({
      id: job.job_id || `jsearch_${Date.now()}_${Math.random()}`,
      title: job.job_title || 'Untitled',
      company: job.employer_name || 'Unknown Company',
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || 'No description available',
      salary: job.job_salary || job.job_min_salary || job.job_max_salary 
        ? `$${job.job_min_salary || 'N/A'} - $${job.job_max_salary || 'N/A'}` 
        : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'jsearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false,
      experience_level: job.job_experience_in_place_of_education ? 'Senior' : 'Mid'
    })) : [];

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      query,
      location
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Fetch jobs error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message,
      stack: error.stack
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
