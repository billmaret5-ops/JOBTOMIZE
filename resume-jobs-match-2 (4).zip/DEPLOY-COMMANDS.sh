#!/bin/bash
# Quick Deploy Commands for fetch-jobs Function

echo "================================================"
echo "🚀 DEPLOY IMPROVED FETCH-JOBS FUNCTION"
echo "================================================"
echo ""

echo "Step 1: Create directory..."
mkdir -p supabase/functions/fetch-jobs
echo "✅ Directory created"
echo ""

echo "Step 2: Copy the code from FETCH-JOBS-IMPROVED-CODE.ts"
echo "to supabase/functions/fetch-jobs/index.ts"
echo ""
echo "Run this command:"
echo "cp FETCH-JOBS-IMPROVED-CODE.ts supabase/functions/fetch-jobs/index.ts"
echo ""
read -p "Press Enter after copying the file..."
echo ""

echo "Step 3: Deploy the function..."
supabase functions deploy fetch-jobs --no-verify-jwt
echo ""

echo "Step 4: Set RAPIDAPI_KEY secret (if not already set)..."
echo "Run: supabase secrets set RAPIDAPI_KEY=your_key_here"
echo ""
read -p "Press Enter after setting the secret..."
echo ""

echo "Step 5: Test the function..."
echo ""
echo "Get your Supabase project URL from the dashboard"
read -p "Enter your project ref (e.g., rgdvevmqrjlkqfkiucdh): " PROJECT_REF
echo ""

BASE_URL="https://${PROJECT_REF}.supabase.co/functions/v1/fetch-jobs"

echo "Testing health endpoint..."
curl "${BASE_URL}/health"
echo ""
echo ""

echo "Testing search endpoint..."
curl "${BASE_URL}/search?query=developer&location=remote&limit=5"
echo ""
echo ""

echo "================================================"
echo "✅ DEPLOYMENT COMPLETE!"
echo "================================================"
echo ""
echo "Your function is now live at:"
echo "${BASE_URL}"
echo ""
echo "Endpoints:"
echo "  - Health: ${BASE_URL}/health"
echo "  - Search: ${BASE_URL}/search?query=...&location=..."
echo ""
