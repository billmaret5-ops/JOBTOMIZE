# Email Analytics Database Setup

## Overview
This document provides comprehensive instructions for setting up the Supabase database schema for the real-time email analytics system.

## Database Schema

### Tables Created
1. **user_profiles** - Enhanced user profile information
2. **email_templates** - Email template storage
3. **email_template_analytics** - Aggregated analytics data
4. **email_interactions** - Individual interaction events
5. **analytics_events** - Real-time event streaming

### Key Features
- **Real-time triggers** for automatic analytics calculation
- **Row Level Security (RLS)** for data protection
- **Performance indexes** for fast queries
- **Stored procedures** for complex calculations
- **Sample data** for testing

## Setup Instructions

### 1. Run Migration Files
Execute the SQL files in the following order:

```sql
-- 1. Create main schema
\i supabase/migrations/create_email_analytics_schema.sql

-- 2. Add performance indexes
\i supabase/migrations/create_analytics_indexes.sql

-- 3. Create stored procedures
\i supabase/migrations/create_analytics_functions.sql

-- 4. Set up triggers
\i supabase/migrations/create_analytics_triggers.sql

-- 5. Configure RLS policies
\i supabase/migrations/create_rls_policies.sql

-- 6. Insert sample data
\i supabase/migrations/insert_sample_data.sql
```

### 2. Verify Installation
```sql
-- Check tables exist
SELECT table_name FROM information_schema.tables 
WHERE table_schema = 'public' 
AND table_name LIKE '%email%' OR table_name LIKE '%analytics%';

-- Check sample data
SELECT COUNT(*) FROM email_template_analytics;
SELECT COUNT(*) FROM email_interactions;
```

## Database Functions

### calculate_template_analytics(template_uuid UUID)
Calculates and updates analytics for a specific template:
- Aggregates interaction counts
- Calculates rates (open, click, conversion, bounce)
- Updates analytics table

### handle_analytics_update()
Trigger function that:
- Recalculates analytics on new interactions
- Creates real-time events for streaming
- Maintains data consistency

## Performance Optimizations

### Indexes
- Primary key indexes on all tables
- Foreign key indexes for joins
- Composite indexes for common queries
- GIN indexes for JSONB columns

### Query Patterns
```sql
-- Get template analytics
SELECT * FROM email_template_analytics 
WHERE user_id = $1 AND template_id = $2;

-- Get recent interactions
SELECT * FROM email_interactions 
WHERE template_id = $1 
ORDER BY timestamp DESC LIMIT 100;

-- Real-time events
SELECT * FROM analytics_events 
WHERE user_id = $1 
ORDER BY created_at DESC;
```

## Security

### Row Level Security (RLS)
- Users can only access their own data
- Admin users have elevated permissions
- Service role has full access for system operations

### Data Protection
- All sensitive data is protected by RLS
- Audit trail through analytics_events
- Automatic cleanup of old events

## Real-time Features

### WebSocket Integration
The database is configured for real-time streaming:
- Triggers create events on data changes
- Events are streamed via Supabase Realtime
- Client applications receive instant updates

### Event Types
- `interaction_sent` - Email sent
- `interaction_delivered` - Email delivered
- `interaction_opened` - Email opened
- `interaction_clicked` - Link clicked
- `interaction_converted` - Conversion tracked

## Sample Data

The system includes sample data for testing:
- 3 user profiles (admin, pro user, free user)
- 4 email templates (welcome, newsletter, marketing, transactional)
- Realistic interaction data over the past 7 days
- Pre-calculated analytics

## Maintenance

### Regular Tasks
```sql
-- Clean up old events (run daily)
DELETE FROM analytics_events 
WHERE created_at < NOW() - INTERVAL '30 days';

-- Recalculate analytics (if needed)
SELECT calculate_template_analytics(id) 
FROM email_templates;
```

### Monitoring
```sql
-- Check system health
SELECT 
    table_name,
    pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) as size
FROM pg_tables 
WHERE schemaname = 'public';

-- Monitor real-time events
SELECT event_type, COUNT(*) 
FROM analytics_events 
WHERE created_at > NOW() - INTERVAL '1 hour'
GROUP BY event_type;
```

## Troubleshooting

### Common Issues
1. **RLS blocking queries** - Ensure user is authenticated
2. **Missing triggers** - Re-run trigger creation scripts
3. **Performance issues** - Check index usage with EXPLAIN

### Debug Queries
```sql
-- Check RLS policies
SELECT * FROM pg_policies WHERE tablename LIKE '%email%';

-- Verify triggers
SELECT * FROM pg_trigger WHERE tgname LIKE '%analytics%';

-- Test function
SELECT calculate_template_analytics('your-template-id');
```