# ✅ FETCH-JOBS ROUTING FIX

## Problem
Your edge function has RapidAPI integration but **missing route handlers**:
- Frontend calls: `GET /health` and `POST /search`  
- Your function only handles: `POST /` (root)

## Solution: Add Route Handling

Replace `supabase/functions/fetch-jobs/index.ts` with this:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const path = url.pathname;

  // Health check: GET /health
  if (path.endsWith('/health') && req.method === 'GET') {
    return new Response(JSON.stringify({ 
      ok: true, 
      timestamp: new Date().toISOString() 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  try {
    let params: any = {};

    // GET /search with query params
    if (path.endsWith('/search') && req.method === 'GET') {
      params = {
        query: url.searchParams.get('query') || 'software engineer',
        location: url.searchParams.get('location') || '',
        page: parseInt(url.searchParams.get('page') || '1'),
        limit: parseInt(url.searchParams.get('limit') || '20'),
        job_type: url.searchParams.get('employment_types'),
        remote: url.searchParams.get('remote') === 'true'
      };
    } 
    // POST with JSON body (both /search and root)
    else if (req.method === 'POST') {
      params = await req.json();
      params = {
        query: params.query || 'software engineer',
        location: params.location || '',
        page: params.page || 1,
        limit: params.limit || 20,
        job_type: params.employment_types || params.job_type,
        remote: params.remote
      };
    }

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';

    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    const searchParams = new URLSearchParams({
      query: `${params.query} ${params.location}`.trim(),
      page: params.page.toString(),
      num_pages: '1'
    });

    if (params.remote) searchParams.append('remote_jobs_only', 'true');
    if (params.job_type) searchParams.append('employment_types', params.job_type.toUpperCase());

    const apiUrl = `https://${rapidApiHost}/search?${searchParams.toString()}`;

    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': rapidApiHost
      }
    });

    if (!response.ok) {
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: `${job.job_city || ''}, ${job.job_state || ''}`.trim(),
      description: job.job_description,
      salary: job.job_min_salary ? `$${job.job_min_salary} - $${job.job_max_salary}` : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc,
      apply_url: job.job_apply_link,
      source: 'JSearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote
    }));

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page: params.page,
      totalPages: Math.ceil((data.total || jobs.length) / params.limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Deploy

```bash
supabase functions deploy fetch-jobs
```

## What Changed
✅ Added `GET /health` endpoint  
✅ Added `GET /search` with query params  
✅ Added `POST /search` with JSON body  
✅ Kept `POST /` for backward compatibility  
✅ All routes use RapidAPI (no mock data)
