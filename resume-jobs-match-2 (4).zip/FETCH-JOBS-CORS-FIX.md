# Fetch Jobs CORS Fix

## Problem Identified
The fetch-jobs function is missing CORS headers, causing the error:
**"Error: Failed to send a request to the Edge Function"**

The OPTIONS preflight request succeeds (200 OK), but the actual GET/POST requests fail because the response doesn't include `Access-Control-Allow-Origin` header.

## Solution

### Step 1: Update the fetch-jobs Function

Replace the entire content of your `supabase/functions/fetch-jobs/index.ts` with this corrected code:

```typescript
// Supabase Edge Function: fetch-jobs
// Purpose: Search for jobs via RapidAPI provider and return normalized results

interface SearchBody {
  query?: string
  location?: string
  remote?: boolean
  page?: number
}

type NormalizedJob = {
  id: string
  title: string | null
  company: string | null
  location: string | null
  via: string | null
  url: string | null
  type: string | null
  published_at: string | null
  salary: string | null
  remote: boolean | null
}

const RAPIDAPI_HOST = 'jsearch.p.rapidapi.com'

// ✅ CORS headers - THIS WAS MISSING!
const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
  'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
}

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      ...corsHeaders, // ✅ Include CORS headers in all responses
    },
  })
}

function normalizeJobs(payload: any): NormalizedJob[] {
  const results: any[] = payload?.data || payload?.jobs || []
  return results.map((item) => {
    const id = String(item.job_id ?? crypto.randomUUID())
    const title = item.job_title ?? item.title ?? null
    const company = item.employer_name ?? item.company_name ?? item.company ?? null
    const location = item.job_city || item.job_country || item.job_state || item.job_location || item.location || null
    const via = item.job_publisher ?? item.publisher ?? null
    const url = item.job_apply_link ?? item.apply_link ?? item.url ?? null
    const type = item.job_employment_type ?? item.type ?? null
    const published_at = item.job_posted_at_datetime_utc ?? item.created_at ?? item.posted_at ?? null
    const salary = item.job_min_salary && item.job_max_salary
      ? `${item.job_min_salary}-${item.job_max_salary} ${item.job_salary_currency || ''}`.trim()
      : (item.salary ?? null)
    const remote = item.job_is_remote ?? item.remote ?? null

    return { id, title, company, location, via, url, type, published_at, salary, remote }
  })
}

async function doSearch(params: { query: string; location?: string; remote?: boolean; page?: number }) {
  const apiKey = Deno.env.get('RAPIDAPI_KEY')
  if (!apiKey) {
    return {
      error: 'Missing RAPIDAPI_KEY secret. Set it with: supabase secrets set RAPIDAPI_KEY=your_key',
      status: 500,
    }
  }

  const query = params.query?.trim()
  if (!query) {
    return { error: 'Missing required parameter: query', status: 400 }
  }

  const searchParams = new URLSearchParams()
  searchParams.set('query', query)
  if (params.location) searchParams.set('location', params.location)
  if (typeof params.remote === 'boolean') searchParams.set('remote', String(params.remote))
  if (params.page) searchParams.set('page', String(params.page))

  const url = `https://${RAPIDAPI_HOST}/search?${searchParams.toString()}`

  try {
    const res = await fetch(url, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': apiKey,
        'X-RapidAPI-Host': RAPIDAPI_HOST,
      },
    })

    if (!res.ok) {
      const text = await res.text().catch(() => '')
      return { error: `RapidAPI error ${res.status}`, details: text.slice(0, 500), status: res.status }
    }

    const payload = await res.json().catch(() => ({}))
    const jobs = normalizeJobs(payload)
    return { jobs, raw: payload, status: 200 }
  } catch (error) {
    return { error: 'Failed to fetch from RapidAPI', details: String(error), status: 500 }
  }
}

Deno.serve(async (req: Request) => {
  // ✅ Handle CORS preflight - THIS WAS MISSING!
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  const url = new URL(req.url)
  
  try {
    // GET /fetch-jobs/search or POST /fetch-jobs/search
    if (url.pathname.includes('/search')) {
      if (req.method === 'GET') {
        const query = url.searchParams.get('query') ?? ''
        const location = url.searchParams.get('location') ?? undefined
        const remoteParam = url.searchParams.get('remote')
        const remote = remoteParam === null ? undefined : /^(1|true|yes)$/i.test(remoteParam)
        const pageParam = url.searchParams.get('page')
        const page = pageParam ? Number(pageParam) : undefined

        const result = await doSearch({ query, location, remote, page })
        if ('error' in result) return json({ error: result.error, details: result['details'] }, result.status)
        return json({ jobs: result.jobs, count: result.jobs.length })
      }

      if (req.method === 'POST') {
        let body: SearchBody = {}
        try { body = await req.json() } catch (_) {}
        const { query = '', location, remote, page } = body
        const result = await doSearch({ query, location, remote, page })
        if ('error' in result) return json({ error: result.error, details: result['details'] }, result.status)
        return json({ jobs: result.jobs, count: result.jobs.length })
      }
    }

    // Health check
    return json({ status: 'ok', message: 'fetch-jobs function is running' })
  } catch (error) {
    return json({ error: String(error) }, 500)
  }
})
```

### Step 2: Deploy the Updated Function

```bash
# Navigate to your project directory
cd your-project-directory

# Deploy the function
supabase functions deploy fetch-jobs

# Verify the RAPIDAPI_KEY is set
supabase secrets list

# If not set, add it:
supabase secrets set RAPIDAPI_KEY=your_rapidapi_key_here
```

### Step 3: Test the Fix

After deployment, refresh your app and click "Run Diagnostics" again. The error should be resolved.

## What Was Fixed

1. **Added CORS headers** to all responses
2. **Added OPTIONS handler** for CORS preflight requests
3. **Improved error handling** with try-catch blocks
4. **Better error messages** for debugging

## Expected Result

After this fix:
- ✅ OPTIONS requests return 200 with CORS headers
- ✅ GET/POST requests work from the frontend
- ✅ Job search returns real results from RapidAPI
- ✅ No more "Failed to send a request" errors
