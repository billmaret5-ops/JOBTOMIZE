# Fix Fetch Jobs 500 Errors - Deploy Instructions

## Root Cause
The current `fetch-jobs` function (v52) only handles POST requests with JSON body. When called with GET requests to `/health` or `/search`, it tries to parse JSON from a GET request, causing a 500 error.

## The Fix
The corrected code in `FETCH-JOBS-FIX.ts` adds:
1. ✅ GET /health endpoint
2. ✅ GET /search?query=...&location=... endpoint  
3. ✅ POST / with JSON body (existing)
4. ✅ Proper RapidAPI JSearch integration using RAPIDAPI_KEY secret
5. ✅ Safe error handling with JSON responses
6. ✅ 404 for unknown routes

## Deploy Steps

### 1. Verify RAPIDAPI_KEY Secret Exists
```bash
supabase secrets list
```
You should see `RAPIDAPI_KEY` in the list. If not, set it:
```bash
supabase secrets set RAPIDAPI_KEY="your_rapidapi_key_here"
```

### 2. Update the Function
Copy the code from `FETCH-JOBS-FIX.ts` and deploy:

**Option A: Via Supabase CLI**
```bash
# Copy the fixed code to your functions directory
cp FETCH-JOBS-FIX.ts supabase/functions/fetch-jobs/index.ts

# Deploy
supabase functions deploy fetch-jobs
```

**Option B: Via Supabase Dashboard**
1. Go to https://supabase.com/dashboard
2. Select your project
3. Go to Edge Functions → fetch-jobs
4. Click "Edit Function"
5. Replace the entire code with contents of `FETCH-JOBS-FIX.ts`
6. Click "Deploy"

### 3. Test the Endpoints

**Health Check:**
```bash
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

**Search (GET):**
```bash
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=react&location=remote" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

**Search (POST):**
```bash
curl -X POST "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query":"react","location":"remote"}'
```

## What Changed

### Before (v52 - BROKEN):
- ❌ Only POST with JSON body
- ❌ No /health endpoint
- ❌ No /search endpoint
- ❌ GET requests caused 500 errors
- ❌ Used mock data only

### After (v53 - FIXED):
- ✅ GET /health returns status
- ✅ GET /search?query=... works
- ✅ POST / with JSON body works
- ✅ Real RapidAPI JSearch integration
- ✅ Proper error handling
- ✅ 404 for unknown routes

## Expected Results

All three test commands above should return 200 OK with JSON responses.

If you still see errors:
1. Check the response body for error details
2. Verify RAPIDAPI_KEY is set correctly
3. Check function logs: `supabase functions logs fetch-jobs`
