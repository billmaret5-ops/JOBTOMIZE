# Deploy Job Alerts Edge Function

## Overview
This guide explains how to deploy the job-alerts-processor edge function that sends email notifications for job matches.

## Edge Function Code

Create a file at `supabase/functions/job-alerts-processor/index.ts` with the following content:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const resendApiKey = Deno.env.get('RESEND_API_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const now = new Date();
    const nowISO = now.toISOString();

    // Fetch active alerts
    const { data: alerts, error: alertsError } = await supabase
      .from('job_alerts')
      .select(`*, profiles:user_id (email, full_name)`)
      .eq('is_active', true);

    if (alertsError) throw alertsError;

    let processedCount = 0;
    let sentCount = 0;

    for (const alert of alerts || []) {
      try {
        const shouldProcess = checkAlertFrequency(alert, now);
        if (!shouldProcess) continue;

        processedCount++;

        // Build job query
        let jobQuery = supabase.from('jobs').select('*').order('created_at', { ascending: false }).limit(10);

        if (alert.job_title) jobQuery = jobQuery.ilike('title', `%${alert.job_title}%`);
        if (alert.location) jobQuery = jobQuery.ilike('location', `%${alert.location}%`);
        if (alert.employment_type) jobQuery = jobQuery.eq('employment_type', alert.employment_type);
        if (alert.min_salary) jobQuery = jobQuery.gte('salary_min', alert.min_salary);
        if (alert.max_salary) jobQuery = jobQuery.lte('salary_max', alert.max_salary);

        if (alert.last_sent_at) {
          jobQuery = jobQuery.gt('created_at', alert.last_sent_at);
        } else {
          const yesterday = new Date(now.getTime() - 24 * 60 * 60 * 1000);
          jobQuery = jobQuery.gt('created_at', yesterday.toISOString());
        }

        const { data: matchingJobs } = await jobQuery;

        if (matchingJobs && matchingJobs.length > 0) {
          const emailSent = await sendJobAlertEmail(alert, matchingJobs, resendApiKey);

          if (emailSent) {
            sentCount++;
            await supabase.from('job_alerts').update({ last_sent_at: nowISO, updated_at: nowISO }).eq('id', alert.id);
          }
        }
      } catch (error) {
        console.error(`Error processing alert ${alert.id}:`, error);
      }
    }

    return new Response(JSON.stringify({ success: true, processed: processedCount, sent: sentCount, timestamp: nowISO }), 
      { headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), 
      { status: 500, headers: { 'Content-Type': 'application/json', ...corsHeaders } });
  }
});

function checkAlertFrequency(alert: any, now: Date): boolean {
  if (!alert.last_sent_at) return true;
  const lastSent = new Date(alert.last_sent_at);
  const hoursSinceLastSent = (now.getTime() - lastSent.getTime()) / (1000 * 60 * 60);
  switch (alert.frequency) {
    case 'instant': return hoursSinceLastSent >= 1;
    case 'daily': return hoursSinceLastSent >= 24;
    case 'weekly': return hoursSinceLastSent >= 168;
    default: return false;
  }
}

async function sendJobAlertEmail(alert: any, jobs: any[], apiKey: string): Promise<boolean> {
  try {
    const userEmail = alert.profiles?.email;
    const userName = alert.profiles?.full_name || 'Job Seeker';
    if (!userEmail) return false;

    const jobsHtml = jobs.map(job => `
      <div style="border: 1px solid #e5e7eb; border-radius: 8px; padding: 16px; margin-bottom: 16px;">
        <h3 style="margin: 0 0 8px 0;">${job.title}</h3>
        <p style="margin: 0 0 8px 0;">${job.company}</p>
        <p style="margin: 0 0 8px 0;">📍 ${job.location || 'Remote'}</p>
        ${job.salary_min ? `<p style="margin: 0;">💰 $${job.salary_min.toLocaleString()}+</p>` : ''}
      </div>
    `).join('');

    const response = await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: { 'Authorization': `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        from: 'Job Alerts <alerts@yourdomain.com>',
        to: [userEmail],
        subject: `🔔 ${jobs.length} New Job${jobs.length > 1 ? 's' : ''} Matching "${alert.name}"`,
        html: `<h1>New Job Matches!</h1><p>Hi ${userName},</p>${jobsHtml}`
      })
    });

    return response.ok;
  } catch (error) {
    console.error('Error sending email:', error);
    return false;
  }
}
```

## Deployment Steps

1. **Deploy the function:**
   ```bash
   supabase functions deploy job-alerts-processor
   ```

2. **Run the migration to set up pg_cron:**
   ```bash
   supabase db push
   ```

3. **Test manually:**
   ```bash
   supabase functions invoke job-alerts-processor
   ```

## How It Works

- **Scheduled Execution**: Runs every hour via pg_cron
- **Frequency Respect**: Checks `last_sent_at` to honor instant/daily/weekly settings
- **Email Delivery**: Uses Resend API to send formatted HTML emails
- **Duplicate Prevention**: Updates `last_sent_at` after successful email send
- **Error Handling**: Continues processing other alerts if one fails

## Testing

Use the manual trigger service in your app:
```typescript
import { jobAlertsProcessorService } from '@/services/jobAlertsProcessorService';

// Trigger processing
await jobAlertsProcessorService.triggerProcessing();

// Get stats
const stats = await jobAlertsProcessorService.getProcessingStats();
```
