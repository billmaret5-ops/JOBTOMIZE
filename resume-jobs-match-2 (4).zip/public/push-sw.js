// Enhanced Push Notification Service Worker
self.addEventListener('push', (event) => {
  if (!event.data) return;

  const data = event.data.json();
  const options = {
    body: data.body,
    icon: data.icon || '/placeholder.svg',
    badge: data.badge || '/placeholder.svg',
    image: data.image,
    data: data.data || {},
    tag: data.tag || 'default',
    requireInteraction: data.requireInteraction || false,
    silent: data.silent || false,
    actions: data.actions || [],
    timestamp: Date.now()
  };

  // Add default actions for email campaigns
  if (data.type && data.type.includes('campaign')) {
    options.actions = [
      { action: 'view_campaign', title: '👁️ View Campaign', icon: '/placeholder.svg' },
      { action: 'view_analytics', title: '📊 Analytics', icon: '/placeholder.svg' },
      { action: 'dismiss', title: '❌ Dismiss', icon: '/placeholder.svg' },
      ...options.actions
    ];
  }

  event.waitUntil(
    self.registration.showNotification(data.title || 'Email Marketing', options)
  );
});

// Handle notification clicks and actions
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  const action = event.action;
  const data = event.notification.data;

  if (action === 'dismiss') {
    return;
  }

  event.waitUntil(
    clients.matchAll({ type: 'window', includeUncontrolled: true })
      .then((clientList) => {
        // Try to focus existing window
        for (const client of clientList) {
          if (client.url.includes(self.registration.scope) && 'focus' in client) {
            client.focus();
            client.postMessage({
              type: 'NOTIFICATION_ACTION',
              action: action,
              notificationId: data.notificationId,
              data: data
            });
            return;
          }
        }

        // Open new window if no existing window found
        const url = getUrlForAction(action, data);
        return clients.openWindow(url).then((client) => {
          if (client) {
            client.postMessage({
              type: 'NOTIFICATION_ACTION',
              action: action,
              notificationId: data.notificationId,
              data: data
            });
          }
        });
      })
  );
});

// Handle notification close
self.addEventListener('notificationclose', (event) => {
  const data = event.notification.data;
  
  // Track notification dismissal
  if (data.notificationId) {
    fetch('/api/notifications/track', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        notificationId: data.notificationId,
        action: 'dismissed'
      })
    }).catch(console.error);
  }
});

function getUrlForAction(action, data) {
  const baseUrl = self.registration.scope;
  
  switch (action) {
    case 'view_campaign':
      return `${baseUrl}email-marketing?campaign=${data.campaignId}`;
    case 'view_analytics':
      return `${baseUrl}email-marketing?tab=analytics&campaign=${data.campaignId}`;
    case 'pause_campaign':
      return `${baseUrl}email-marketing?action=pause&campaign=${data.campaignId}`;
    case 'view_templates':
      return `${baseUrl}email-templates`;
    case 'view_automation':
      return `${baseUrl}email-automation`;
    default:
      return `${baseUrl}email-marketing`;
  }
}

// Background sync for failed notifications
self.addEventListener('sync', (event) => {
  if (event.tag === 'notification-retry') {
    event.waitUntil(retryFailedNotifications());
  }
});

async function retryFailedNotifications() {
  try {
    const response = await fetch('/api/notifications/retry', {
      method: 'POST'
    });
    
    if (response.ok) {
      console.log('Failed notifications retried successfully');
    }
  } catch (error) {
    console.error('Failed to retry notifications:', error);
  }
}

// Handle push subscription changes
self.addEventListener('pushsubscriptionchange', (event) => {
  event.waitUntil(
    self.registration.pushManager.subscribe({
      userVisibleOnly: true,
      applicationServerKey: 'YOUR_VAPID_PUBLIC_KEY'
    }).then((subscription) => {
      return fetch('/api/push-subscription', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          subscription: subscription,
          action: 'update'
        })
      });
    })
  );
});

// Periodic background sync for scheduled notifications
self.addEventListener('periodicsync', (event) => {
  if (event.tag === 'scheduled-notifications') {
    event.waitUntil(checkScheduledNotifications());
  }
});

async function checkScheduledNotifications() {
  try {
    const response = await fetch('/api/notifications/scheduled', {
      method: 'GET'
    });
    
    if (response.ok) {
      const notifications = await response.json();
      
      notifications.forEach(notification => {
        self.registration.showNotification(notification.title, {
          body: notification.body,
          icon: '/placeholder.svg',
          data: notification.data,
          actions: notification.actions || []
        });
      });
    }
  } catch (error) {
    console.error('Failed to check scheduled notifications:', error);
  }
}