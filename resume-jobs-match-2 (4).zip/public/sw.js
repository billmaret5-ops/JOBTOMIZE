const CACHE_NAME = 'job-search-pwa-v1';
const urlsToCache = [
  '/',
  '/static/js/bundle.js',
  '/static/css/main.css',
  '/manifest.json',
  '/icon-192x192.png',
  '/icon-512x512.png'
];

// Data priority levels
const PRIORITY_CRITICAL = 1; // Job applications, interview notes
const PRIORITY_HIGH = 2; // Resume edits, saved jobs
const PRIORITY_MEDIUM = 3; // Search history, preferences
const PRIORITY_LOW = 4; // Analytics, usage stats

// Connection speed thresholds (Mbps)
const CONNECTION_SLOW = 0.5;
const CONNECTION_FAST = 5;

// Retry configuration
const MAX_RETRIES = 5;
const BASE_DELAY = 1000; // 1 second

// Install event - cache resources
self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then((cache) => cache.addAll(urlsToCache))
      .then(() => self.skipWaiting())
  );
});

// Activate event - clean up old caches
self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((cacheNames) => {
      return Promise.all(
        cacheNames.map((cacheName) => {
          if (cacheName !== CACHE_NAME) {
            return caches.delete(cacheName);
          }
        })
      );
    }).then(() => self.clients.claim())
  );
});

// Fetch event - serve from cache, fallback to network
self.addEventListener('fetch', (event) => {
  event.respondWith(
    caches.match(event.request)
      .then((response) => {
        return response || fetch(event.request);
      })
  );
});

// Push event - handle push notifications with priority-based processing
self.addEventListener('push', (event) => {
  let data = {};
  
  if (event.data) {
    try {
      data = event.data.json();
    } catch (e) {
      data = { title: 'New Notification', body: event.data.text() };
    }
  }

  const options = {
    body: data.body || 'You have a new notification',
    icon: data.icon || '/placeholder.svg',
    badge: data.badge || '/placeholder.svg',
    data: data.data || {},
    actions: data.actions || [
      { action: 'view', title: 'View' },
      { action: 'dismiss', title: 'Dismiss' }
    ],
    requireInteraction: data.priority === 'urgent',
    silent: data.priority === 'low',
    tag: data.type || 'general',
    renotify: data.priority === 'urgent'
  };

  event.waitUntil(
    self.registration.showNotification(data.title || 'Job Alert', options)
  );
});

// Notification click event with action handling
self.addEventListener('notificationclick', (event) => {
  event.notification.close();

  if (event.action === 'view') {
    // Open the app and navigate to relevant page based on notification type
    const urlToOpen = getUrlForNotificationType(event.notification.data?.type);
    event.waitUntil(
      clients.matchAll({ type: 'window', includeUncontrolled: true })
        .then((clientList) => {
          // Check if app is already open
          for (const client of clientList) {
            if (client.url.includes(self.location.origin) && 'focus' in client) {
              client.focus();
              client.postMessage({
                type: 'NOTIFICATION_CLICKED',
                data: event.notification.data
              });
              return;
            }
          }
          // Open new window if app not open
          if (clients.openWindow) {
            return clients.openWindow(urlToOpen);
          }
        })
    );
  } else if (event.action === 'dismiss') {
    // Just close the notification (already done above)
    return;
  } else {
    // Default click behavior - open app
    event.waitUntil(
      clients.matchAll({ type: 'window' })
        .then((clientList) => {
          if (clientList.length > 0) {
            return clientList[0].focus();
          }
          if (clients.openWindow) {
            return clients.openWindow('/');
          }
        })
    );
  }
});

function getUrlForNotificationType(type) {
  switch (type) {
    case 'job_match':
      return '/jobs';
    case 'application_update':
      return '/applications';
    case 'interview_reminder':
      return '/interviews';
    case 'sync_complete':
      return '/dashboard';
    default:
      return '/';
  }
}
self.addEventListener('sync', (event) => {
  if (event.tag.startsWith('priority-sync-')) {
    const priority = parseInt(event.tag.split('-')[2]);
    event.waitUntil(processPrioritySync(priority));
  } else if (event.tag === 'background-sync-jobs') {
    event.waitUntil(syncJobs());
  } else if (event.tag === 'background-sync-applications') {
    event.waitUntil(syncApplications());
  }
});

async function processPrioritySync(priority) {
  try {
    const connection = getConnectionInfo();
    const batchSize = getBatchSize(connection);
    
    const syncQueue = await getSyncQueue(priority);
    const batches = chunkArray(syncQueue, batchSize);
    
    for (let i = 0; i < batches.length; i++) {
      const batch = batches[i];
      await processBatch(batch, priority);
      
      // Add delay between batches for slow connections
      if (connection.speed < CONNECTION_FAST) {
        await delay(500);
      }
    }
    
    notifyClients('PRIORITY_SYNC_COMPLETE', { priority });
  } catch (error) {
    console.error('Priority sync failed:', error);
    await scheduleRetry(priority, error);
  }
}

async function processBatch(items, priority) {
  const results = await Promise.allSettled(
    items.map(item => syncItem(item, priority))
  );
  
  const failed = results
    .map((result, index) => ({ result, item: items[index] }))
    .filter(({ result }) => result.status === 'rejected')
    .map(({ item }) => item);
    
  if (failed.length > 0) {
    await requeueFailedItems(failed, priority);
  }
}

async function syncItem(item, priority) {
  const maxRetries = getMaxRetries(priority);
  let attempt = 0;
  
  while (attempt < maxRetries) {
    try {
      const response = await fetch(item.endpoint, {
        method: item.method || 'POST',
        headers: {
          'Content-Type': 'application/json',
          ...item.headers
        },
        body: JSON.stringify(item.data)
      });
      
      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }
      
      await markItemSynced(item.id);
      return await response.json();
    } catch (error) {
      attempt++;
      if (attempt < maxRetries) {
        const delay = calculateBackoffDelay(attempt);
        await new Promise(resolve => setTimeout(resolve, delay));
      } else {
        throw error;
      }
    }
  }
}

function calculateBackoffDelay(attempt) {
  return BASE_DELAY * Math.pow(2, attempt - 1) + Math.random() * 1000;
}

function getConnectionInfo() {
  if ('connection' in navigator) {
    const conn = navigator.connection;
    return {
      speed: conn.downlink || 1,
      effectiveType: conn.effectiveType || '4g',
      saveData: conn.saveData || false
    };
  }
  return { speed: 1, effectiveType: '4g', saveData: false };
}

function getBatchSize(connection) {
  if (connection.saveData) return 1;
  if (connection.speed < CONNECTION_SLOW) return 2;
  if (connection.speed < CONNECTION_FAST) return 5;
  return 10;
}

function getMaxRetries(priority) {
  switch (priority) {
    case PRIORITY_CRITICAL: return MAX_RETRIES;
    case PRIORITY_HIGH: return 3;
    case PRIORITY_MEDIUM: return 2;
    case PRIORITY_LOW: return 1;
    default: return 2;
  }
}

async function getSyncQueue(priority) {
  const clients = await self.clients.matchAll();
  if (clients.length === 0) return [];
  
  return new Promise((resolve) => {
    const messageHandler = (event) => {
      if (event.data.type === 'SYNC_QUEUE_RESPONSE') {
        self.removeEventListener('message', messageHandler);
        resolve(event.data.payload || []);
      }
    };
    
    self.addEventListener('message', messageHandler);
    clients[0].postMessage({ 
      type: 'GET_SYNC_QUEUE', 
      priority 
    });
    
    setTimeout(() => {
      self.removeEventListener('message', messageHandler);
      resolve([]);
    }, 5000);
  });
}

async function markItemSynced(itemId) {
  const clients = await self.clients.matchAll();
  clients.forEach(client => {
    client.postMessage({
      type: 'ITEM_SYNCED',
      payload: { itemId }
    });
  });
}

async function requeueFailedItems(items, priority) {
  const clients = await self.clients.matchAll();
  clients.forEach(client => {
    client.postMessage({
      type: 'REQUEUE_ITEMS',
      payload: { items, priority }
    });
  });
}

async function scheduleRetry(priority, error) {
  const clients = await self.clients.matchAll();
  clients.forEach(client => {
    client.postMessage({
      type: 'SCHEDULE_RETRY',
      payload: { priority, error: error.message }
    });
  });
}

function notifyClients(type, payload) {
  self.clients.matchAll().then(clients => {
    clients.forEach(client => {
      client.postMessage({ type, payload });
    });
  });
}

function chunkArray(array, size) {
  const chunks = [];
  for (let i = 0; i < array.length; i += size) {
    chunks.push(array.slice(i, i + size));
  }
  return chunks;
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

// Legacy sync functions for compatibility
async function syncJobs() {
  try {
    const response = await fetch('/api/jobs');
    const jobs = await response.json();
    
    const cache = await caches.open(CACHE_NAME);
    await cache.put('/api/jobs', new Response(JSON.stringify(jobs)));
    
    notifyClients('JOBS_SYNCED', jobs);
  } catch (error) {
    console.error('Background sync failed:', error);
  }
}

async function syncApplications() {
  try {
    const clients = await self.clients.matchAll();
    
    if (clients.length > 0) {
      const queuedApps = await new Promise((resolve) => {
        const messageHandler = (event) => {
          if (event.data.type === 'QUEUED_APPLICATIONS_RESPONSE') {
            self.removeEventListener('message', messageHandler);
            resolve(event.data.payload);
          }
        };
        self.addEventListener('message', messageHandler);
        clients[0].postMessage({ type: 'GET_QUEUED_APPLICATIONS' });
      });

      const syncedIds = [];
      
      for (const app of queuedApps) {
        try {
          const response = await fetch('/api/applications', {
            method: 'POST',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify({
              jobId: app.jobId,
              ...app.formData
            })
          });
          
          if (response.ok) {
            syncedIds.push(app.jobId);
          }
        } catch (error) {
          console.error('Failed to sync application:', app.jobId, error);
        }
      }
      
      notifyClients('APPLICATIONS_SYNCED', { syncedIds });
    }
  } catch (error) {
    console.error('Application sync failed:', error);
  }
}