# ✅ RapidAPI Key Setup & Testing Guide

## 🎯 Your RapidAPI Key is Already in Supabase!
**Key:** `82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7`
**Status:** ✅ Stored as `RAPIDAPI_KEY` in Supabase Secrets

---

## 🚀 Step 1: Update fetch-jobs Edge Function (5 minutes)

### Option A: Via Supabase Dashboard (Recommended)

1. **Go to:** https://supabase.com/dashboard/project/YOUR_PROJECT/functions
2. **Find:** `fetch-jobs` function in the list
3. **Click:** The function name to open the editor
4. **Replace ALL code** with the code from `FETCH-JOBS-RAPIDAPI-UPDATE.md`
5. **Click:** "Deploy" button (top right)
6. **Wait:** For "Deployed successfully" message

### Option B: Via Supabase CLI

```bash
# Make sure you're in the project directory
cd /path/to/jobtomize

# Deploy the function
supabase functions deploy fetch-jobs

# Verify the secret is set
supabase secrets list
# Should show: RAPIDAPI_KEY
```

---

## 🧪 Step 2: Test the Function

### Test in Supabase Dashboard

1. Go to: **Edge Functions** → **fetch-jobs** → **Invoke** tab
2. Paste this test payload:

```json
{
  "query": "software engineer",
  "location": "San Francisco",
  "page": 1,
  "limit": 10
}
```

3. Click **Invoke**
4. You should see real job listings from JSearch API!

### Expected Response:
```json
{
  "jobs": [
    {
      "id": "abc123",
      "title": "Senior Software Engineer",
      "company": "Google",
      "location": "San Francisco, CA",
      "description": "...",
      "salary": "$150,000 - $200,000",
      "type": "Full-time",
      "apply_url": "https://...",
      "source": "JSearch"
    }
  ],
  "total": 10,
  "page": 1
}
```

---

## 🔍 Step 3: Test in Your App

1. **Open your app:** https://your-app-url.com
2. **Go to:** Job Search page
3. **Search for:** "software engineer" in "San Francisco"
4. **You should see:** Real job listings from JSearch!

### Troubleshooting

**If you see "Failed to fetch jobs":**
- Check browser console (F12) for errors
- Verify RAPIDAPI_KEY is set in Supabase secrets
- Make sure fetch-jobs function is deployed

**If you see mock/fake data:**
- The function wasn't updated correctly
- Re-deploy using the code from FETCH-JOBS-RAPIDAPI-UPDATE.md

---

## 📊 What Changed

### Before (Mock Data):
```typescript
const mockJobs = ['Fake Job 1', 'Fake Job 2'];
return mockJobs;
```

### After (Real API):
```typescript
const response = await fetch('https://jsearch.p.rapidapi.com/search', {
  headers: { 'X-RapidAPI-Key': Deno.env.get('RAPIDAPI_KEY') }
});
return response.json();
```

---

## ✅ Verification Checklist

- [ ] RAPIDAPI_KEY is set in Supabase (already done ✅)
- [ ] fetch-jobs function updated with new code
- [ ] Function deployed successfully
- [ ] Test in Supabase dashboard returns real jobs
- [ ] App shows real job listings (not mock data)

---

## 🎉 Success Indicators

You'll know it's working when:
1. Job listings have real company names (Google, Microsoft, etc.)
2. Apply URLs lead to real job boards
3. Descriptions are detailed and specific
4. Locations are accurate
5. Salaries are realistic

---

## 📝 Next Steps

Once real jobs are loading:
1. Test the AI job matching feature
2. Try different search queries
3. Test filters (remote, salary, job type)
4. Save jobs to favorites
5. Apply to real positions!
