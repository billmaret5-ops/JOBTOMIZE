# 🔍 Debugging Guide - Jobtomize Platform

## How to Debug Issues

### 1. Open Browser Console
- **Chrome**: Press `F12` or `Ctrl+Shift+J` (Windows) / `Cmd+Option+J` (Mac)
- **Firefox**: Press `F12` or `Ctrl+Shift+K` (Windows) / `Cmd+Option+K` (Mac)
- Look for messages starting with `[Auth]`, `[JobAPI]`, or `[Login]`

### 2. Common Issues & Solutions

#### ❌ Can't Log In
**Check Console For:**
- `[Login] Attempting login for: your@email.com`
- `[Login] Error:` - Shows the actual error

**Common Errors:**
- "Invalid login credentials" → Wrong email/password
- "Email not confirmed" → Check your email for verification link
- "Network error" → Check internet connection

**Fix Steps:**
1. Clear browser cache and cookies
2. Try incognito/private mode
3. Check if email is verified in Supabase Dashboard
4. Verify VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env

#### ❌ Session Not Persisting (Doesn't Remember User)
**Check Console For:**
- `[Auth] Initializing...`
- `[Auth] Initial session: your@email.com`

**If you see "null" instead of email:**
1. Check localStorage: `localStorage.getItem('jobtomize-auth')`
2. Try different browser
3. Disable browser extensions
4. Check if cookies are enabled

#### ❌ Job Search Not Working
**Check Console For:**
- `[JobAPI] Fetching jobs with params:`
- `[JobAPI] Response:` - Shows what the API returned
- `[JobAPI] Success: X jobs found`

**Common Errors:**
- "Failed to fetch jobs" → fetch-jobs function issue
- "No jobs in response" → API returned empty
- "Network error" → Supabase connection issue

**Fix Steps:**
1. Verify fetch-jobs function is deployed in Supabase
2. Check RAPIDAPI_KEY is set in Supabase secrets
3. Test function directly in Supabase dashboard
4. Check browser network tab for failed requests

### 3. Test Each Feature

#### Test Login:
```
1. Open console
2. Click "Sign In"
3. Enter credentials
4. Watch for [Login] messages
5. Should see: [Login] Success! Closing modal...
```

#### Test Job Search:
```
1. Open console
2. Log in
3. Click "Search" tab
4. Enter job title
5. Click "Search Jobs"
6. Watch for [JobAPI] messages
7. Should see: [JobAPI] Success: 20 jobs found
```

### 4. Report Issues

When reporting issues, include:
1. Browser and version
2. All console messages (copy/paste)
3. Steps to reproduce
4. Screenshots if possible

### 5. Quick Fixes

**Clear Everything:**
```javascript
// Run in console
localStorage.clear();
sessionStorage.clear();
location.reload();
```

**Check Auth Status:**
```javascript
// Run in console
localStorage.getItem('jobtomize-auth')
```

**Test Supabase Connection:**
```javascript
// Run in console
fetch('https://rgdvevmqrjlkqfkiucdh.supabase.co/rest/v1/')
  .then(r => console.log('Connected:', r.ok))
```
