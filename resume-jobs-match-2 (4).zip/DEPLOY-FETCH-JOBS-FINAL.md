# Deploy Updated Fetch-Jobs Edge Function - FINAL

## ⚠️ CRITICAL: Manual Deployment Required

The edge function cannot be deployed automatically. You MUST deploy it manually using Supabase CLI.

## 📋 Updated Function Code

The updated code is in `FETCH-JOBS-UPDATED-CODE.ts` with:
- ✅ Comprehensive logging of all headers
- ✅ GET /health endpoint for testing
- ✅ GET /search endpoint with query params
- ✅ POST endpoint with JSON body
- ✅ Proper CORS headers

## 🚀 Manual Deployment Steps

### Step 1: Create Function File
```bash
# Navigate to your project
cd /path/to/your/project

# Create functions directory if it doesn't exist
mkdir -p supabase/functions/fetch-jobs

# Copy the updated code
cp FETCH-JOBS-UPDATED-CODE.ts supabase/functions/fetch-jobs/index.ts
```

### Step 2: Deploy WITHOUT JWT Verification (Testing)
```bash
supabase functions deploy fetch-jobs --no-verify-jwt
```

### Step 3: Test the Deployment
```bash
# Test health endpoint
curl https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health

# Test GET search
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=developer&location=remote"

# Test POST search
curl -X POST https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs \
  -H "Content-Type: application/json" \
  -d '{"query":"developer","location":"remote"}'
```

### Step 4: Check Logs
```bash
supabase functions logs fetch-jobs --tail
```

## 🔍 What to Look For in Logs

The updated function logs:
1. **Method**: GET or POST
2. **URL**: Full request URL
3. **Headers**: All incoming headers (authorization, apikey, etc.)
4. **Body**: POST request body (if applicable)

Example log output:
```
=== FETCH-JOBS REQUEST ===
Method: POST
URL: https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs
Headers: {
  "authorization": "Bearer eyJhbGc...",
  "apikey": "eyJhbGc...",
  "content-type": "application/json"
}
POST body: { query: 'developer', location: 'remote' }
```

## ✅ Success Indicators

After deployment, you should see:
- ✅ Health endpoint returns 200 OK
- ✅ GET search returns job listings
- ✅ POST search returns filtered results
- ✅ Logs show all headers being received
- ✅ NO 401 errors

## 🔧 If Still Getting 401 Errors

### Option A: Deploy with JWT Disabled
```bash
supabase functions deploy fetch-jobs --no-verify-jwt
```

### Option B: Check JWT Configuration
```bash
# View function details
supabase functions list

# Check if verify_jwt is enabled
# If enabled, ensure frontend sends proper headers
```

### Option C: Update Frontend Headers
Make sure your frontend sends BOTH headers:
```typescript
const { data, error } = await supabase.functions.invoke('fetch-jobs', {
  body: { query, location },
  headers: {
    Authorization: `Bearer ${session.access_token}`,
    apikey: supabase.supabaseKey
  }
});
```

## 📝 Next Steps After Deployment

1. **Test in Browser**: Open your app and search for jobs
2. **Check Network Tab**: Verify headers are sent correctly
3. **Check Logs**: Monitor for any errors
4. **Verify Response**: Ensure jobs are returned

## 🆘 Still Having Issues?

If 401 errors persist after deployment:

1. **Check Supabase Dashboard**:
   - Go to Edge Functions
   - Find `fetch-jobs`
   - Check "verify_jwt" setting
   - Disable if needed for testing

2. **Verify Auth Token**:
   ```typescript
   const { data: { session } } = await supabase.auth.getSession();
   console.log('Session:', session);
   console.log('Token:', session?.access_token);
   ```

3. **Test Without Auth**:
   ```bash
   curl -X POST https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs \
     -H "Content-Type: application/json" \
     -d '{"query":"test"}'
   ```

## 🎯 Expected Behavior After Fix

- Frontend calls work without 401 errors
- Jobs load successfully
- Logs show proper headers
- Search functionality works
- Filters apply correctly

Deploy now and test!
