# Deploy Job Alerts System - Quick Start

## Prerequisites
- Supabase project set up
- RapidAPI account with JSearch API access
- Resend account for email delivery

## Step 1: Set Environment Variables

Add to your `.env` file:
```env
VITE_RAPIDAPI_KEY=your_rapidapi_key_here
```

## Step 2: Set Supabase Secrets

```bash
# Set Resend API key
supabase secrets set RESEND_API_KEY=your_resend_api_key

# Set RapidAPI key
supabase secrets set RAPIDAPI_KEY=your_rapidapi_key
```

## Step 3: Deploy Edge Function

Create the edge function file at `supabase/functions/job-alerts-processor/index.ts`:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { createClient } = await import('https://esm.sh/@supabase/supabase-js@2');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const resendApiKey = Deno.env.get('RESEND_API_KEY');
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    const supabase = createClient(supabaseUrl, supabaseServiceKey);
    const now = new Date();

    const { data: alerts } = await supabase
      .from('job_alerts')
      .select('*, profiles:user_id (email, full_name)')
      .eq('is_active', true);

    let processed = 0, sent = 0;

    for (const alert of alerts || []) {
      if (!shouldProcess(alert, now)) continue;
      processed++;

      const jobs = await fetchJobs(alert, rapidApiKey);
      if (jobs?.length > 0) {
        if (await sendEmail(alert, jobs, resendApiKey)) {
          sent++;
          await supabase.from('job_alerts')
            .update({ last_sent_at: now.toISOString() })
            .eq('id', alert.id);
        }
      }
    }

    return new Response(JSON.stringify({ success: true, processed, sent }), 
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), 
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } });
  }
});

function shouldProcess(alert: any, now: Date): boolean {
  if (!alert.last_sent_at) return true;
  const hours = (now.getTime() - new Date(alert.last_sent_at).getTime()) / 3600000;
  return (alert.frequency === 'instant' && hours >= 1) ||
         (alert.frequency === 'daily' && hours >= 24) ||
         (alert.frequency === 'weekly' && hours >= 168);
}

async function fetchJobs(alert: any, key: string) {
  if (!key) return [];
  const params = new URLSearchParams({
    query: alert.job_title || 'software',
    ...(alert.location && { location: alert.location }),
    num_pages: '1'
  });
  const res = await fetch(`https://jsearch.p.rapidapi.com/search?${params}`, {
    headers: { 'X-RapidAPI-Key': key, 'X-RapidAPI-Host': 'jsearch.p.rapidapi.com' }
  });
  return res.ok ? (await res.json()).data?.slice(0, 10) : [];
}

async function sendEmail(alert: any, jobs: any[], key: string) {
  if (!key || !alert.profiles?.email) return false;
  const html = `<h1>New Jobs for "${alert.name}"</h1>` + 
    jobs.map(j => `<div style="border:1px solid #ddd;padding:16px;margin:8px 0">
      <h3>${j.job_title}</h3><p>${j.employer_name}</p>
      <a href="${j.job_apply_link}">Apply</a></div>`).join('');
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { 'Authorization': `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from: 'Job Alerts <alerts@jobtomize.com>',
      to: [alert.profiles.email],
      subject: `${jobs.length} New Jobs: ${alert.name}`,
      html
    })
  });
  return res.ok;
}
```

Deploy:
```bash
supabase functions deploy job-alerts-processor --no-verify-jwt
```

## Step 4: Run Database Migrations

```bash
supabase db push
```

This creates:
- `job_alerts` table
- RLS policies
- Cron job (runs hourly)

## Step 5: Test

### Test in App
1. Navigate to `/job-alerts`
2. Create a test alert
3. Set frequency to "instant"
4. Wait for next hour or manually trigger

### Manual Trigger
```bash
supabase functions invoke job-alerts-processor
```

### Check Logs
```bash
supabase functions logs job-alerts-processor --tail
```

## Verification Checklist

- [ ] Environment variables set
- [ ] Supabase secrets configured
- [ ] Edge function deployed
- [ ] Database migrations applied
- [ ] Test alert created
- [ ] Email received

## Troubleshooting

**No emails?**
- Check Resend API key
- Verify user email in profiles table
- Check edge function logs

**No jobs found?**
- Verify RapidAPI key
- Check API quota
- Broaden search criteria

**Cron not running?**
- Check pg_cron is enabled
- Verify cron schedule in DB
- Check Supabase project logs

## Next Steps

1. Create your first job alert at `/job-alerts`
2. Monitor edge function logs
3. Adjust alert criteria as needed
4. Share with users!
