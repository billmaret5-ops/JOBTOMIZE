# Add RapidAPI Key to Supabase - FINAL STEP

## You're Almost There! 🎉

The fetch-jobs edge function is deployed and the frontend is updated. You just need to add the RapidAPI key.

## Option 1: Via Supabase Dashboard (RECOMMENDED)

1. Go to: https://supabase.com/dashboard/project/YOUR_PROJECT/settings/functions
2. Scroll to "Edge Function Secrets"
3. Click "Add Secret"
4. Name: `RAPIDAPI_KEY`
5. Value: Your RapidAPI key from https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
6. Click "Save"

## Option 2: Via Supabase CLI

```bash
# Set the secret
supabase secrets set RAPIDAPI_KEY=your_actual_rapidapi_key_here

# Verify it was set
supabase secrets list
```

## Get Your RapidAPI Key

1. Go to: https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
2. Click "Subscribe to Test"
3. Choose a plan (Free tier available with 2,500 requests/month)
4. Copy your API key from the "X-RapidAPI-Key" header

## Test It Works

Once you add the key, test the job search:

1. Sign in to your app
2. Go to the "Search" tab
3. Search for "software engineer" in "San Francisco"
4. You should see REAL jobs from RapidAPI!

## What Happens Now?

✅ Frontend calls Supabase edge function
✅ Edge function uses your RapidAPI key (secure!)
✅ Real jobs are fetched and displayed
✅ Results are cached for performance
✅ CORS is handled properly

## Troubleshooting

If you still get errors after adding the key:

1. Wait 30 seconds for the secret to propagate
2. Check the Edge Function logs in Supabase Dashboard
3. Make sure the key is exactly: `RAPIDAPI_KEY` (case-sensitive)
4. Verify your RapidAPI subscription is active
