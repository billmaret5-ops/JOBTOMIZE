# Fix fetch-jobs Function - Complete Guide

## Current Problem
The deployed `fetch-jobs` function is using **mock data** instead of real RapidAPI integration.

## Quick Fix (5 minutes)

### Step 1: Verify Your RapidAPI Key
```bash
# Check if RAPIDAPI_KEY is set in Supabase
supabase secrets list

# If not listed, set it:
supabase secrets set RAPIDAPI_KEY=your_actual_key_here
```

### Step 2: Create the Working Function File

Create file: `supabase/functions/fetch-jobs/index.ts`

```typescript
interface SearchBody {
  query?: string
  location?: string
  remote?: boolean
  page?: number
}

type NormalizedJob = {
  id: string
  title: string | null
  company: string | null
  location: string | null
  via: string | null
  url: string | null
  type: string | null
  published_at: string | null
  salary: string | null
  remote: boolean | null
}

const RAPIDAPI_HOST = 'jsearch.p.rapidapi.com'

function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'Content-Type': 'application/json',
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    },
  })
}

function normalizeJobs(payload: any): NormalizedJob[] {
  const results: any[] = payload?.data || payload?.jobs || []
  return results.map((item) => {
    const id = String(item.job_id ?? crypto.randomUUID())
    const title = item.job_title ?? item.title ?? null
    const company = item.employer_name ?? item.company_name ?? item.company ?? null
    const location = item.job_city || item.job_country || item.job_state || item.job_location || item.location || null
    const via = item.job_publisher ?? item.publisher ?? null
    const url = item.job_apply_link ?? item.apply_link ?? item.url ?? null
    const type = item.job_employment_type ?? item.type ?? null
    const published_at = item.job_posted_at_datetime_utc ?? item.created_at ?? item.posted_at ?? null
    const salary = item.job_min_salary && item.job_max_salary
      ? `${item.job_min_salary}-${item.job_max_salary} ${item.job_salary_currency || ''}`.trim()
      : (item.salary ?? null)
    const remote = item.job_is_remote ?? item.remote ?? null
    return { id, title, company, location, via, url, type, published_at, salary, remote }
  })
}

async function doSearch(params: { query: string; location?: string; remote?: boolean; page?: number }) {
  const apiKey = Deno.env.get('RAPIDAPI_KEY')
  if (!apiKey) {
    return { error: 'Missing RAPIDAPI_KEY secret', status: 500 }
  }

  const query = params.query?.trim()
  if (!query) {
    return { error: 'Missing required parameter: query', status: 400 }
  }

  const searchParams = new URLSearchParams()
  searchParams.set('query', query)
  if (params.location) searchParams.set('location', params.location)
  if (typeof params.remote === 'boolean') searchParams.set('remote_jobs_only', String(params.remote))
  if (params.page) searchParams.set('page', String(params.page))

  const url = `https://${RAPIDAPI_HOST}/search?${searchParams.toString()}`

  const res = await fetch(url, {
    method: 'GET',
    headers: {
      'X-RapidAPI-Key': apiKey,
      'X-RapidAPI-Host': RAPIDAPI_HOST,
    },
  })

  if (!res.ok) {
    const text = await res.text().catch(() => '')
    return { error: `API error ${res.status}`, details: text.slice(0, 500), status: res.status }
  }

  const payload = await res.json().catch(() => ({}))
  const jobs = normalizeJobs(payload)
  return { jobs, status: 200 }
}

Deno.serve(async (req: Request) => {
  const url = new URL(req.url)
  if (req.method === 'OPTIONS') return json({ ok: true })

  try {
    if (req.method === 'GET') {
      const query = url.searchParams.get('query') ?? ''
      const location = url.searchParams.get('location') ?? undefined
      const remoteParam = url.searchParams.get('remote')
      const remote = remoteParam ? /^(1|true|yes)$/i.test(remoteParam) : undefined
      const page = url.searchParams.get('page') ? Number(url.searchParams.get('page')) : undefined
      const result = await doSearch({ query, location, remote, page })
      if ('error' in result) return json({ error: result.error, details: result['details'] }, result.status)
      return json({ jobs: result.jobs, count: result.jobs.length })
    }

    if (req.method === 'POST') {
      let body: SearchBody = {}
      try { body = await req.json() } catch (_) {}
      const { query = '', location, remote, page } = body
      const result = await doSearch({ query, location, remote, page })
      if ('error' in result) return json({ error: result.error, details: result['details'] }, result.status)
      return json({ jobs: result.jobs, count: result.jobs.length })
    }

    return json({ error: 'Method not allowed' }, 405)
  } catch (error) {
    return json({ error: 'Internal server error', details: String(error) }, 500)
  }
})
```

### Step 3: Deploy
```bash
supabase functions deploy fetch-jobs
```

### Step 4: Test
```bash
curl -X POST https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs \
  -H "Content-Type: application/json" \
  -d '{"query":"software engineer","location":"San Francisco"}'
```

You should see real job results from JSearch API!

## What Changed
- ❌ OLD: Mock data generator
- ✅ NEW: Real RapidAPI JSearch integration
- ✅ Reads RAPIDAPI_KEY from environment
- ✅ Normalizes job data properly
- ✅ Better error handling

## Troubleshooting

**"Missing RAPIDAPI_KEY secret"**
- Run: `supabase secrets set RAPIDAPI_KEY=your_key`

**"API error 403"**
- Your RapidAPI key is invalid or expired
- Check your RapidAPI dashboard

**"No jobs found"**
- Try broader search terms
- Check RapidAPI quota/limits

## Frontend is Already Fixed
The frontend code in `jobApiService.ts` and `JobSearchPlatform.tsx` is already correct and will work once you deploy this function.
