# Database Cleanup Analysis

## Summary
- **Total Tables**: 130+ tables
- **Actively Used**: ~35 tables
- **Unused/Rarely Used**: ~95 tables
- **Recommended for Deletion**: 90+ tables

## Tables Actively Used in Frontend

### Core Application Tables (KEEP)
1. `profiles` - User profiles
2. `user_profiles` - Extended user data
3. `user_roles` - Role-based access control
4. `job_applications` - Job application tracking
5. `jobs` - Job listings
6. `saved_jobs` - User saved jobs
7. `job_alerts` - Job alert preferences
8. `application_templates` - Application form templates
9. `application_reminders` - Application deadline reminders
10. `application_automation_rules` - Auto-status updates

### Resume & Templates (KEEP)
11. `resumes` - User resumes (storage bucket)
12. `resume_templates` - Resume template library
13. `ai_generated_resumes` - AI-generated resumes
14. `resume_versions` - Resume version history
15. `resume_email_integrations` - Email integration data

### Collaboration (KEEP)
16. `collaboration_sessions` - Real-time collaboration
17. `collaboration_groups` - Team collaboration
18. `collaboration_messages` - Group messages
19. `job_notes` - Collaborative job notes

### Company Research (KEEP)
20. `company_research` - Saved company research

### Analytics & Monitoring (KEEP)
21. `audit_logs` - System audit trail
22. `audit_configurations` - Audit settings

### Beta & Access Control (KEEP)
23. `beta_access` - Beta program access
24. `beta_invites` - Beta invitation codes
25. `beta_waitlist` - Beta waitlist entries

### Backup & Storage (KEEP)
26. `backup_monitoring` - Backup health monitoring
27. `backup_alert_config` - Backup alert settings
28. `retention_policies` - Data retention policies
29. `backup_retry_log` - Backup retry tracking

### Testing & Optimization (KEEP)
30. `ab_tests` - A/B test configurations
31. `test_variants` - A/B test variants

### Alerts & Incidents (KEEP)
32. `alert_routing_rules` - Alert routing config
33. `incidents` - Incident tracking

### Bulk Operations (KEEP)
34. `bulk_application_batches` - Bulk application tracking

### Compliance (KEEP)
35. `compliance_reports` - Compliance reporting

### Storage Buckets (KEEP)
- `resumes` - Resume file storage
- `tenant-assets` - Avatar & asset storage
- `audio-recordings` - Interview recording storage

## Tables to DELETE (90+ tables)

### Email Marketing System (NOT USED - 30+ tables)
- email_templates
- email_tracking
- email_analytics
- email_campaigns
- email_campaigns_analytics
- email_automation_workflows
- email_deliverability_metrics
- email_warmup_campaigns
- email_ab_tests
- email_campaign_schedules
- real_time_email_events
- email_template_blocks
- email_template_categories
- email_provider_configs
- email_campaign_analytics
- email_heatmap_interactions
- email_heatmap_campaigns
- email_engagement_sessions
- email_webhook_events
- email_notification_settings
- email_campaign_performance
- email_engagement_heatmaps
- email_heatmap_data
- campaign_recipients
- campaign_analytics
- email_delivery_logs
- email_verification_metrics
- email_deliverability_alerts
- follow_up_sequences
- follow_up_sequence_templates
- personalized_email_templates
- template_components
- contact_lists
- contacts

### ML/AI Infrastructure (OVER-ENGINEERED - 20+ tables)
- model_registry
- model_validation_rules
- model_monitoring_metrics
- mlops_pipelines
- ml_pipelines
- model_comparisons
- model_performance_metrics
- model_data_drift
- ml_send_time_training_data
- ml_send_time_models
- send_time_optimization_history
- ml_pipeline_runs
- data_sources
- integration_providers
- integration_sync_jobs
- alert_analytics_summary
- ai_usage_logs
- ai_collaboration_sessions

### Video/Interview Features (NOT CORE - 15+ tables)
- interview_recordings
- interview_analytics
- coaching_sessions
- study_plans
- video_interviews
- video_analysis
- video_storage
- video_shares
- video_collaboration_sessions
- collaboration_session_recordings
- meeting_summaries
- live_transcripts
- recording_metadata
- voice_analysis

### Notification Systems (REDUNDANT - 10+ tables)
- sms_notifications
- sms_preferences
- notifications
- real_time_notifications
- notification_delivery_log
- push_notification_ab_tests
- ab_test_events

### Advanced Features (UNUSED - 15+ tables)
- search_history
- parsed_resumes
- optimized_resumes
- interview_questions
- for (invalid table name)
- skills
- coding_challenges
- practice_sessions
- offline_sync_queue
- email_verifications
- user_behavior_tracking
- funnel_definitions
- funnel_alert_conditions
- real_time_metrics
- subscription_plans
- webhook_events
- tenants
- job_search_preferences
- application_analytics
- resume_template_sections
- usage_alert_rules
- usage_history
- system_settings
- export_jobs
- two_factor_policies
- two_factor_ab_tests
- two_factor_auth
- biometric_credentials
- oauth_providers
- password_reset_tokens
- imported_templates
- recipient_behavior_patterns

## Recommended Action Plan

1. **Phase 1: Delete Email Marketing System** (30+ tables)
   - Not a core job search feature
   - Adds significant complexity
   - Can be re-added if needed later

2. **Phase 2: Delete ML Infrastructure** (20+ tables)
   - Over-engineered for current needs
   - Simple AI calls don't need this complexity

3. **Phase 3: Delete Video/Interview Features** (15+ tables)
   - Not core to job application tracking
   - Can use external tools

4. **Phase 4: Delete Unused Features** (25+ tables)
   - Features that were planned but not implemented
   - Redundant notification systems

## Benefits of Cleanup

- **Reduced Complexity**: 130+ tables → 35 tables (73% reduction)
- **Better Performance**: Fewer tables = faster queries
- **Easier Maintenance**: Less schema to manage
- **Lower Costs**: Reduced storage and backup needs
- **Clearer Architecture**: Focus on core features
