import { test, expect } from '@playwright/test';

test.describe('Authentication Flow', () => {
  test('should sign up new user', async ({ page }) => {
    await page.goto('/');
    
    await page.click('text=Sign Up');
    await page.fill('input[name="email"]', 'newuser@example.com');
    await page.fill('input[name="password"]', 'SecurePass123!');
    await page.fill('input[name="confirmPassword"]', 'SecurePass123!');
    await page.click('button:has-text("Create Account")');
    
    await expect(page).toHaveURL(/\/dashboard/);
    await expect(page.locator('text=Welcome')).toBeVisible();
  });

  test('should sign in existing user', async ({ page }) => {
    await page.goto('/');
    
    await page.click('text=Sign In');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button:has-text("Sign In")');
    
    await expect(page).toHaveURL(/\/dashboard/);
  });

  test('should handle invalid credentials', async ({ page }) => {
    await page.goto('/');
    
    await page.click('text=Sign In');
    await page.fill('input[name="email"]', 'wrong@example.com');
    await page.fill('input[name="password"]', 'wrongpass');
    await page.click('button:has-text("Sign In")');
    
    await expect(page.locator('text=Invalid credentials')).toBeVisible();
  });

  test('should reset password', async ({ page }) => {
    await page.goto('/');
    
    await page.click('text=Forgot Password');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.click('button:has-text("Send Reset Link")');
    
    await expect(page.locator('text=Check your email')).toBeVisible();
  });

  test('should sign out', async ({ page }) => {
    await page.goto('/dashboard');
    
    await page.click('button:has-text("Sign Out")');
    
    await expect(page).toHaveURL('/');
  });
});
