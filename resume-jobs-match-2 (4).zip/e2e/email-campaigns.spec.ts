import { test, expect } from '@playwright/test';

test.describe('Email Campaign Workflow', () => {
  test.beforeEach(async ({ page }) => {
    await page.goto('/');
    await page.click('text=Sign In');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button:has-text("Sign In")');
  });

  test('should create email campaign', async ({ page }) => {
    await page.goto('/email-campaigns');
    
    await page.click('button:has-text("New Campaign")');
    await page.fill('input[name="campaignName"]', 'Follow-up Campaign');
    await page.fill('input[name="subject"]', 'Following up on my application');
    await page.click('button:has-text("Select Template")');
    await page.click('.template-card:first-child');
    await page.click('button:has-text("Create Campaign")');
    
    await expect(page.locator('text=Campaign created')).toBeVisible();
  });

  test('should build email template', async ({ page }) => {
    await page.goto('/email-templates');
    
    await page.click('button:has-text("Create Template")');
    await page.fill('input[name="templateName"]', 'Job Application');
    
    // Drag and drop components
    await page.dragAndDrop('.component-library >> text=Header', '.email-canvas');
    await page.dragAndDrop('.component-library >> text=Text', '.email-canvas');
    
    await page.click('button:has-text("Save Template")');
    
    await expect(page.locator('text=Template saved')).toBeVisible();
  });

  test('should send test email', async ({ page }) => {
    await page.goto('/email-campaigns');
    
    await page.locator('.campaign-card').first().click();
    await page.click('button:has-text("Send Test")');
    await page.fill('input[name="testEmail"]', 'test@example.com');
    await page.click('button:has-text("Send")');
    
    await expect(page.locator('text=Test email sent')).toBeVisible();
  });

  test('should view campaign analytics', async ({ page }) => {
    await page.goto('/email-campaigns');
    
    await page.locator('.campaign-card').first().click();
    await page.click('text=Analytics');
    
    await expect(page.locator('text=Open Rate')).toBeVisible();
    await expect(page.locator('text=Click Rate')).toBeVisible();
  });
});
