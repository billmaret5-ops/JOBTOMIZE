import { test, expect } from '@playwright/test';

test.describe('Job Search Workflow', () => {
  test.beforeEach(async ({ page }) => {
    // Sign in before each test
    await page.goto('/');
    await page.click('text=Sign In');
    await page.fill('input[name="email"]', 'test@example.com');
    await page.fill('input[name="password"]', 'password123');
    await page.click('button:has-text("Sign In")');
    await expect(page).toHaveURL(/\/dashboard/);
  });

  test('should search for jobs', async ({ page }) => {
    await page.goto('/jobs');
    
    await page.fill('input[placeholder*="Search"]', 'Software Engineer');
    await page.click('button:has-text("Search")');
    
    await expect(page.locator('.job-card')).toHaveCount(10, { timeout: 5000 });
    await expect(page.locator('text=Software Engineer')).toBeVisible();
  });

  test('should filter jobs by location', async ({ page }) => {
    await page.goto('/jobs');
    
    await page.click('button:has-text("Filters")');
    await page.fill('input[name="location"]', 'Remote');
    await page.click('button:has-text("Apply Filters")');
    
    await expect(page.locator('text=Remote')).toBeVisible();
  });

  test('should save job', async ({ page }) => {
    await page.goto('/jobs');
    
    await page.locator('.job-card').first().hover();
    await page.click('button[aria-label="Save job"]');
    
    await expect(page.locator('text=Job saved')).toBeVisible();
    
    await page.goto('/saved-jobs');
    await expect(page.locator('.job-card')).toHaveCount(1, { timeout: 3000 });
  });

  test('should apply to job', async ({ page }) => {
    await page.goto('/jobs');
    
    await page.locator('.job-card').first().click();
    await page.click('button:has-text("Apply Now")');
    
    await page.fill('textarea[name="coverLetter"]', 'I am interested in this position...');
    await page.click('button:has-text("Submit Application")');
    
    await expect(page.locator('text=Application submitted')).toBeVisible();
  });
});
