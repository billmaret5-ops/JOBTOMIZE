# Database Signup Error Fix

## Problem
Users are getting "Database error saving new user" when trying to sign up. This is a 500 error from Supabase authentication.

## Root Cause
The database trigger that creates user profiles after signup is either:
1. Not working correctly
2. Pointing to the wrong table
3. Being blocked by RLS policies
4. Has conflicting trigger definitions

## Solution

### Step 1: Run the Migration
Execute the migration file to fix the trigger:

```bash
# Using Supabase CLI
supabase db push

# Or manually run the SQL file
# Go to Supabase Dashboard > SQL Editor
# Copy and paste the contents of: supabase/migrations/fix_database_signup_error.sql
```

### Step 2: Verify the Fix

1. **Check the trigger exists:**
```sql
SELECT * FROM pg_trigger WHERE tgname = 'on_auth_user_created';
```

2. **Check the function exists:**
```sql
SELECT proname, prosrc 
FROM pg_proc 
WHERE proname = 'handle_new_user';
```

3. **Test signup:**
   - Try creating a new user account
   - Check if profile is created in profiles table

### Step 3: Manual Fix (If Migration Fails)

If the migration doesn't work, run these commands in Supabase SQL Editor:

```sql
-- 1. Drop existing trigger
DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;

-- 2. Create the function
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
SECURITY DEFINER
SET search_path = public
LANGUAGE plpgsql
AS $$
BEGIN
  INSERT INTO public.profiles (
    id,
    email,
    full_name,
    created_at,
    updated_at
  )
  VALUES (
    NEW.id,
    NEW.email,
    COALESCE(NEW.raw_user_meta_data->>'full_name', NEW.email),
    NOW(),
    NOW()
  )
  ON CONFLICT (id) DO NOTHING;
  
  RETURN NEW;
EXCEPTION
  WHEN OTHERS THEN
    RAISE WARNING 'Error creating profile: %', SQLERRM;
    RETURN NEW;
END;
$$;

-- 3. Create the trigger
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW
  EXECUTE FUNCTION public.handle_new_user();

-- 4. Fix RLS policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Enable insert during signup" ON public.profiles;
CREATE POLICY "Enable insert during signup"
  ON public.profiles FOR INSERT
  WITH CHECK (true);
```

### Step 4: Verify Tables

Check which profile tables exist:

```sql
SELECT table_name 
FROM information_schema.tables 
WHERE table_schema = 'public' 
  AND table_name IN ('profiles', 'user_profiles');
```

## Common Issues

### Issue 1: Column Mismatch
**Error:** `column "xyz" does not exist`

**Fix:** Check your profiles table structure:
```sql
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'profiles' 
  AND table_schema = 'public';
```

Update the trigger function to match your actual columns.

### Issue 2: RLS Policy Blocking
**Error:** `new row violates row-level security policy`

**Fix:** Temporarily disable RLS to test:
```sql
ALTER TABLE public.profiles DISABLE ROW LEVEL SECURITY;
-- Test signup
-- Then re-enable with proper policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
```

### Issue 3: Multiple Triggers
**Error:** Conflicting trigger definitions

**Fix:** Remove all triggers and recreate:
```sql
SELECT tgname FROM pg_trigger 
WHERE tgrelid = 'auth.users'::regclass;

-- Drop each one
DROP TRIGGER trigger_name ON auth.users;
```

## Testing

After applying the fix:

1. **Clear browser cache and cookies**
2. **Try signing up with a new email**
3. **Check Supabase logs:**
   - Go to Dashboard > Logs
   - Look for any errors during signup

4. **Verify profile creation:**
```sql
SELECT id, email, created_at 
FROM public.profiles 
ORDER BY created_at DESC 
LIMIT 5;
```

## Prevention

To prevent this in the future:

1. **Always test auth flow** after database changes
2. **Use migrations** instead of manual SQL
3. **Monitor Supabase logs** for auth errors
4. **Keep trigger functions simple** and well-tested

## Additional Resources

- [Supabase Auth Triggers](https://supabase.com/docs/guides/auth/managing-user-data)
- [Row Level Security](https://supabase.com/docs/guides/auth/row-level-security)
- [Database Functions](https://supabase.com/docs/guides/database/functions)
