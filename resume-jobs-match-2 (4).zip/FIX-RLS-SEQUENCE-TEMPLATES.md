# Fix RLS on sequence_step_templates Table

## Issue
Table `public.sequence_step_templates` has RLS disabled, exposing data publicly.

## Solution Created
✅ Migration file: `supabase/migrations/enable_rls_sequence_step_templates.sql`

## How to Apply

### Option 1: Via Supabase Dashboard (Recommended)
1. Go to https://supabase.com/dashboard/project/YOUR_PROJECT/editor
2. Click **SQL Editor** in left sidebar
3. Click **New Query**
4. Copy the contents of `supabase/migrations/enable_rls_sequence_step_templates.sql`
5. Paste into the SQL editor
6. Click **Run** button

### Option 2: Via Supabase CLI
```bash
# Make sure you're logged in
supabase login

# Link to your project (if not already linked)
supabase link --project-ref YOUR_PROJECT_REF

# Apply the migration
supabase db push
```

### Option 3: Manual SQL Execution
Run this SQL in your Supabase SQL Editor:

```sql
-- Enable RLS
ALTER TABLE public.sequence_step_templates ENABLE ROW LEVEL SECURITY;

-- User policies
CREATE POLICY "Users can view their own sequence step templates"
ON public.sequence_step_templates FOR SELECT
USING (auth.uid() = user_id);

CREATE POLICY "Users can insert their own sequence step templates"
ON public.sequence_step_templates FOR INSERT
WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update their own sequence step templates"
ON public.sequence_step_templates FOR UPDATE
USING (auth.uid() = user_id);

CREATE POLICY "Users can delete their own sequence step templates"
ON public.sequence_step_templates FOR DELETE
USING (auth.uid() = user_id);

-- Admin override
CREATE POLICY "Admins can manage all sequence step templates"
ON public.sequence_step_templates FOR ALL
USING (
  EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_roles.user_id = auth.uid()
    AND user_roles.role = 'admin'
  )
);
```

## Verify RLS is Enabled
After applying, run this query to verify:

```sql
SELECT schemaname, tablename, rowsecurity 
FROM pg_tables 
WHERE tablename = 'sequence_step_templates';
```

Should return `rowsecurity = true`

## What This Does
- ✅ Enables Row Level Security on the table
- ✅ Users can only access their own templates (via `user_id`)
- ✅ Admins can access all templates
- ✅ Prevents unauthorized data access
- ✅ Follows security best practices

## Note
This migration file has already been created in your project. You just need to apply it to your Supabase database using one of the methods above.
