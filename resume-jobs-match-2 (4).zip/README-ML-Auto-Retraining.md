# ML Auto-Retraining System

## Overview

The ML Auto-Retraining System provides intelligent, automated model retraining capabilities with drift detection, performance monitoring, and automatic rollback functionality to ensure optimal circuit breaker performance.

## Features

### 1. Automatic Retraining Scheduler
- **Schedule Types**: Daily, weekly, monthly, on-drift, on-degradation
- **Configurable Thresholds**: Set accuracy and drift thresholds
- **Manual Triggers**: Force retraining on-demand
- **Next Training Prediction**: Know when next training will occur

### 2. Drift Detection
- **Statistical Drift Analysis**: KS-test, PSI, and distribution shifts
- **Feature-Level Drift**: Track drift for individual features
- **Threshold Monitoring**: Automatic alerts when drift exceeds limits
- **Data Distribution Tracking**: Monitor mean shifts and variance changes

### 3. Model Performance Comparison
- **Side-by-Side Metrics**: Compare current vs new model performance
- **Multiple Metrics**: Accuracy, precision, recall, F1-score
- **Performance Delta**: Calculate improvement/degradation percentage
- **Automatic Recommendations**: Deploy, rollback, or monitor suggestions

### 4. Automatic Rollback
- **Performance-Based**: Rollback if new model performs worse
- **One-Click Rollback**: Manual rollback option
- **Rollback History**: Track all rollback events
- **Safe Deployment**: Test before production deployment

### 5. Performance Alerts
- **Real-Time Monitoring**: Track model performance continuously
- **Severity Levels**: Low, medium, high, critical alerts
- **Alert Acknowledgment**: Track who acknowledged alerts
- **Threshold Violations**: Alert when metrics drop below thresholds

## Database Schema

### ml_retraining_schedules
```sql
- id: UUID (primary key)
- model_type: VARCHAR(100)
- schedule_type: ENUM (daily, weekly, monthly, on_drift, on_degradation)
- schedule_config: JSONB
- accuracy_threshold: DECIMAL(5,4)
- drift_threshold: DECIMAL(5,4)
- enabled: BOOLEAN
- last_training_at: TIMESTAMPTZ
- next_training_at: TIMESTAMPTZ
```

### ml_drift_metrics
```sql
- id: UUID (primary key)
- model_id: UUID (foreign key)
- metric_type: VARCHAR(50)
- drift_score: DECIMAL(5,4)
- feature_drifts: JSONB
- data_distribution: JSONB
- threshold_exceeded: BOOLEAN
- detected_at: TIMESTAMPTZ
```

### ml_model_performance_comparisons
```sql
- id: UUID (primary key)
- current_model_id: UUID (foreign key)
- new_model_id: UUID (foreign key)
- comparison_type: VARCHAR(50)
- current_metrics: JSONB
- new_metrics: JSONB
- performance_delta: DECIMAL(5,4)
- recommendation: ENUM (deploy, rollback, monitor)
- deployed: BOOLEAN
- rolled_back: BOOLEAN
```

### ml_retraining_jobs
```sql
- id: UUID (primary key)
- schedule_id: UUID (foreign key)
- trigger_type: VARCHAR(50)
- trigger_reason: TEXT
- status: ENUM (pending, running, completed, failed, rolled_back)
- old_model_id: UUID
- new_model_id: UUID
- training_metrics: JSONB
- error_message: TEXT
- started_at: TIMESTAMPTZ
- completed_at: TIMESTAMPTZ
```

### ml_performance_alerts
```sql
- id: UUID (primary key)
- model_id: UUID (foreign key)
- alert_type: VARCHAR(50)
- severity: ENUM (low, medium, high, critical)
- metric_name: VARCHAR(100)
- current_value: DECIMAL(10,4)
- threshold_value: DECIMAL(10,4)
- message: TEXT
- acknowledged: BOOLEAN
- acknowledged_by: UUID
- acknowledged_at: TIMESTAMPTZ
```

## API Usage

### Create Retraining Schedule
```typescript
import { mlAutoRetrainingService } from '@/services/mlAutoRetrainingService';

const schedule = await mlAutoRetrainingService.createSchedule({
  model_type: 'circuit_breaker_threshold',
  schedule_type: 'daily',
  schedule_config: { hour: 2, minute: 0 },
  accuracy_threshold: 0.85,
  drift_threshold: 0.15,
  enabled: true
});
```

### Detect Drift
```typescript
const driftMetrics = await mlAutoRetrainingService.detectDrift(modelId);

if (driftMetrics.threshold_exceeded) {
  console.log('Drift threshold exceeded!');
  console.log('Drift score:', driftMetrics.drift_score);
  console.log('Feature drifts:', driftMetrics.feature_drifts);
}
```

### Compare Models
```typescript
const comparison = await mlAutoRetrainingService.compareModels(
  currentModelId,
  newModelId
);

console.log('Performance delta:', comparison.performance_delta);
console.log('Recommendation:', comparison.recommendation);

if (comparison.recommendation === 'deploy') {
  await mlAutoRetrainingService.deployModel(comparison.id);
} else if (comparison.recommendation === 'rollback') {
  await mlAutoRetrainingService.rollbackModel(comparison.id);
}
```

### Trigger Manual Retraining
```typescript
const job = await mlAutoRetrainingService.triggerRetraining(
  scheduleId,
  'manual',
  'Performance degradation detected'
);

console.log('Retraining job started:', job.id);
```

### Handle Performance Alerts
```typescript
const alerts = await mlAutoRetrainingService.getAlerts(false); // unacknowledged only

for (const alert of alerts) {
  if (alert.severity === 'critical') {
    console.log('Critical alert:', alert.message);
    await mlAutoRetrainingService.acknowledgeAlert(alert.id, userId);
  }
}
```

## Dashboard Features

### Retraining Schedules Section
- View all configured schedules
- Enable/disable schedules
- See last training time and next scheduled training
- Trigger manual retraining

### Drift Detection Section
- Real-time drift scores
- Feature-level drift breakdown
- Threshold exceeded indicators
- Historical drift trends

### Model Comparisons Section
- Performance delta visualization
- Current vs new model metrics
- Deploy/rollback controls
- Deployment status tracking

### Recent Jobs Section
- Job status tracking (pending, running, completed, failed)
- Training metrics display
- Error message visibility
- Job history

### Active Alerts Section
- Severity-based color coding
- Alert details and thresholds
- One-click acknowledgment
- Alert history

## Best Practices

### 1. Schedule Configuration
- Use daily schedules for high-traffic systems
- Set accuracy threshold based on baseline performance
- Configure drift threshold based on data stability
- Enable multiple trigger types for comprehensive coverage

### 2. Drift Monitoring
- Monitor drift scores regularly
- Investigate feature-level drift patterns
- Set appropriate thresholds (typically 0.10-0.20)
- Track data distribution changes

### 3. Model Deployment
- Always review performance comparisons before deployment
- Test new models in staging first
- Monitor deployed models closely for 24-48 hours
- Keep rollback option ready

### 4. Alert Management
- Acknowledge alerts promptly
- Investigate critical alerts immediately
- Track alert patterns for proactive improvements
- Set up notification channels (email, Slack, etc.)

### 5. Performance Optimization
- Retrain during low-traffic periods
- Use incremental learning when possible
- Monitor training resource usage
- Archive old models regularly

## Troubleshooting

### High Drift Scores
- **Cause**: Data distribution changes, seasonal patterns
- **Solution**: Increase training frequency, adjust thresholds
- **Prevention**: Monitor data sources, implement data validation

### Failed Retraining Jobs
- **Cause**: Insufficient data, resource constraints, data quality issues
- **Solution**: Check error messages, validate data, increase resources
- **Prevention**: Implement data quality checks, monitor data pipelines

### Performance Degradation
- **Cause**: Concept drift, data quality issues, model overfitting
- **Solution**: Rollback to previous model, retrain with more data
- **Prevention**: Regular monitoring, diverse training data

### False Alerts
- **Cause**: Threshold too sensitive, temporary fluctuations
- **Solution**: Adjust thresholds, implement alert aggregation
- **Prevention**: Use statistical significance testing, longer evaluation windows

## Integration Examples

### With Circuit Breaker System
```typescript
// Automatically adjust circuit breaker thresholds based on retraining
const handleRetrainingComplete = async (jobId: string) => {
  const job = await mlAutoRetrainingService.getRetrainingJobs();
  const completedJob = job.find(j => j.id === jobId);
  
  if (completedJob?.status === 'completed' && completedJob.new_model_id) {
    const comparison = await mlAutoRetrainingService.compareModels(
      completedJob.old_model_id,
      completedJob.new_model_id
    );
    
    if (comparison.recommendation === 'deploy') {
      // Update circuit breaker with new thresholds
      await circuitBreakerService.updateThresholds(
        comparison.new_metrics
      );
    }
  }
};
```

### With Monitoring System
```typescript
// Send alerts to monitoring system
const monitorAlerts = async () => {
  const alerts = await mlAutoRetrainingService.getAlerts(false);
  
  for (const alert of alerts) {
    if (alert.severity === 'critical') {
      await sendToMonitoring({
        type: 'ml_performance_alert',
        severity: alert.severity,
        message: alert.message,
        model_id: alert.model_id
      });
    }
  }
};
```

## Performance Metrics

- **Drift Detection Latency**: < 100ms
- **Model Comparison Time**: < 500ms
- **Retraining Job Startup**: < 2 seconds
- **Alert Processing**: < 50ms
- **Dashboard Load Time**: < 1 second

## Security Considerations

- All retraining operations require authentication
- Model artifacts stored securely
- Audit logs for all deployments and rollbacks
- Role-based access control for manual triggers
- Encrypted model storage

## Future Enhancements

- [ ] A/B testing for model deployments
- [ ] Multi-model ensemble support
- [ ] Advanced drift detection algorithms
- [ ] Automated hyperparameter tuning
- [ ] Integration with MLflow/Kubeflow
- [ ] Real-time model serving
- [ ] Federated learning support
- [ ] Model explainability integration
