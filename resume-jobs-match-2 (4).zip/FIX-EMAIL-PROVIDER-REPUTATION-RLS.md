# Fix: email_provider_reputation RLS Issues

## Problem Summary
The `email_provider_reputation` table has RLS policies defined but **RLS is not enabled** on the table. This causes a security vulnerability where the policies are not being enforced.

**Lint Issue Details:**
- **Title:** Policy Exists RLS Disabled
- **Entity:** public.email_provider_reputation
- **Issue:** Table has RLS policies but RLS is not enabled
- **Existing Policy:** "Users can view their own provider reputation"

---

## Solution Applied

### 1. ✅ Enable RLS on the Table
```sql
ALTER TABLE public.email_provider_reputation ENABLE ROW LEVEL SECURITY;
```

### 2. ✅ Create Performance Index on user_id
```sql
CREATE INDEX idx_email_provider_reputation_user_id 
ON public.email_provider_reputation(user_id);
```
**Benefits:**
- Faster queries filtering by user_id
- Improved RLS policy performance
- Better JOIN performance with auth.users

### 3. ✅ Grant SELECT Permission to Authenticated Role
```sql
GRANT SELECT ON public.email_provider_reputation TO authenticated;
GRANT INSERT ON public.email_provider_reputation TO authenticated;
GRANT UPDATE ON public.email_provider_reputation TO authenticated;
GRANT DELETE ON public.email_provider_reputation TO authenticated;
```

### 4. ✅ Column Name Confirmed: `user_id`
The column name is **`user_id`** (type: `uuid`, references `auth.users`).

---

## How to Apply the Fix

### Option 1: Run Migration File (Recommended)
```bash
# Navigate to your project directory
cd /path/to/your/project

# Run the migration using Supabase CLI
supabase db push

# Or apply specific migration
supabase migration up
```

### Option 2: Run SQL Directly in Supabase Dashboard
1. Go to Supabase Dashboard → SQL Editor
2. Copy the contents of `supabase/migrations/fix_email_provider_reputation_rls.sql`
3. Paste and run the SQL
4. Verify success

### Option 3: Manual Steps in Dashboard
1. **Enable RLS:**
   - Go to Table Editor → email_provider_reputation
   - Click "Enable RLS" button

2. **Create Index:**
   - Go to SQL Editor
   - Run: `CREATE INDEX idx_email_provider_reputation_user_id ON public.email_provider_reputation(user_id);`

3. **Grant Permissions:**
   - Go to SQL Editor
   - Run the GRANT statements from the migration file

---

## Verification Steps

After applying the fix, verify:

```sql
-- 1. Check RLS is enabled
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename = 'email_provider_reputation';
-- Should return: rowsecurity = true

-- 2. Check index exists
SELECT indexname, indexdef 
FROM pg_indexes 
WHERE tablename = 'email_provider_reputation';
-- Should show: idx_email_provider_reputation_user_id

-- 3. Check policies exist
SELECT policyname, cmd, qual 
FROM pg_policies 
WHERE tablename = 'email_provider_reputation';
-- Should show 4 policies (SELECT, INSERT, UPDATE, DELETE)

-- 4. Check permissions
SELECT grantee, privilege_type 
FROM information_schema.table_privileges 
WHERE table_name = 'email_provider_reputation' 
AND grantee = 'authenticated';
-- Should show SELECT, INSERT, UPDATE, DELETE
```

---

## What This Fixes

### Before (Insecure):
- ❌ RLS policies defined but not enforced
- ❌ All authenticated users could access all rows
- ❌ Security vulnerability
- ❌ Slow queries without index

### After (Secure):
- ✅ RLS enabled and policies enforced
- ✅ Users can only access their own data
- ✅ Security vulnerability resolved
- ✅ Optimized queries with index
- ✅ Proper permissions granted

---

## Additional RLS Issues?

If you have **900+ RLS issues**, you likely need to apply similar fixes to other tables. Here's a template:

```sql
-- Template for fixing RLS on any table
ALTER TABLE public.{table_name} ENABLE ROW LEVEL SECURITY;

CREATE INDEX idx_{table_name}_user_id ON public.{table_name}(user_id);

GRANT SELECT, INSERT, UPDATE, DELETE ON public.{table_name} TO authenticated;

CREATE POLICY "Users can manage their own {table_name}"
ON public.{table_name}
FOR ALL
TO authenticated
USING (auth.uid() = user_id)
WITH CHECK (auth.uid() = user_id);
```

### Bulk Fix Script
To fix multiple tables at once, see: `ENABLE-RLS-ALL-TABLES.sql`

---

## Troubleshooting

### Issue: "column user_id does not exist"
**Solution:** The column might be named differently. Check with:
```sql
SELECT column_name, data_type 
FROM information_schema.columns 
WHERE table_name = 'email_provider_reputation';
```
Then update the migration file with the correct column name.

### Issue: "permission denied"
**Solution:** Run as database owner or with sufficient privileges:
```sql
-- Grant yourself permissions first
GRANT ALL ON public.email_provider_reputation TO postgres;
```

### Issue: Policies still not working
**Solution:** Check if user_id is properly set:
```sql
-- Test query (should only return your rows)
SELECT * FROM email_provider_reputation WHERE user_id = auth.uid();
```

---

## Summary

✅ **RLS Enabled** on email_provider_reputation  
✅ **Index Created** on user_id for performance  
✅ **Permissions Granted** to authenticated role  
✅ **Column Confirmed** as user_id (uuid)  
✅ **Policies Recreated** for SELECT, INSERT, UPDATE, DELETE  

The table is now secure and optimized!
