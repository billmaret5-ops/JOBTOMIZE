-- =====================================================
-- ENABLE RLS ON ALL TABLES - SECURITY CRITICAL
-- =====================================================
-- Run this in Supabase Dashboard → SQL Editor
-- This enables Row Level Security on all tables

-- Core User Tables
ALTER TABLE IF EXISTS profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS resumes ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS job_alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS saved_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS saved_searches ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS search_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS user_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS user_profiles ENABLE ROW LEVEL SECURITY;

-- Resume & Application Tables
ALTER TABLE IF EXISTS parsed_resumes ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS optimized_resumes ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS application_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS resume_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS resume_template_sections ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS company_research ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS job_notes ENABLE ROW LEVEL SECURITY;

-- Interview Tables
ALTER TABLE IF EXISTS interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS interview_recordings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS interview_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS coaching_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS study_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS video_interviews ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS video_analysis ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS video_storage ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS video_shares ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS practice_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS interview_questions ENABLE ROW LEVEL SECURITY;

-- Skills & Assessment Tables
ALTER TABLE IF EXISTS skills ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS coding_challenges ENABLE ROW LEVEL SECURITY;

-- Notification Tables
ALTER TABLE IF EXISTS notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS real_time_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS notification_delivery_log ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS sms_notifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS sms_preferences ENABLE ROW LEVEL SECURITY;

-- Email Campaign Tables
ALTER TABLE IF EXISTS email_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_tracking ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_campaigns_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_verifications ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_automation_workflows ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_deliverability_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_warmup_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_ab_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_campaign_schedules ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS real_time_email_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_template_blocks ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_heatmap_interactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_heatmap_campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_engagement_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_webhook_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_delivery_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_notification_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_campaign_performance ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_engagement_heatmaps ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_heatmap_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_verification_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_deliverability_alerts ENABLE ROW LEVEL SECURITY;

-- Contact & Campaign Management
ALTER TABLE IF EXISTS contacts ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS contact_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS campaign_recipients ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS campaign_analytics ENABLE ROW LEVEL SECURITY;

-- A/B Testing Tables
ALTER TABLE IF EXISTS ab_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ab_test_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS push_notification_ab_tests ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS two_factor_ab_tests ENABLE ROW LEVEL SECURITY;

-- Collaboration Tables
ALTER TABLE IF EXISTS collaboration_groups ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS collaboration_group_members ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS collaboration_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS resume_collaboration_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ai_collaboration_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS video_collaboration_sessions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS collaboration_session_recordings ENABLE ROW LEVEL SECURITY;

-- Sync & Offline Tables
ALTER TABLE IF EXISTS offline_sync_queue ENABLE ROW LEVEL SECURITY;

-- Analytics & Monitoring Tables
ALTER TABLE IF EXISTS application_analytics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS job_search_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS usage_alert_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS usage_history ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ai_usage_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS real_time_metrics ENABLE ROW LEVEL SECURITY;

-- ML & Model Tables
ALTER TABLE IF EXISTS model_registry ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS model_validation_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS model_monitoring_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS model_comparisons ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS model_performance_metrics ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS model_data_drift ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ml_pipelines ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ml_pipeline_runs ENABLE ROW LEVEL SECURITY;

-- Integration Tables
ALTER TABLE IF EXISTS data_sources ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS mlops_pipelines ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS integration_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS integration_sync_jobs ENABLE ROW LEVEL SECURITY;

-- System Tables
ALTER TABLE IF EXISTS alert_analytics_summary ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS system_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS export_jobs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS audit_logs ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS audit_configurations ENABLE ROW LEVEL SECURITY;

-- Authentication Tables
ALTER TABLE IF EXISTS two_factor_auth ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS two_factor_policies ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS biometric_credentials ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS oauth_providers ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS password_reset_tokens ENABLE ROW LEVEL SECURITY;

-- Billing & Subscription Tables
ALTER TABLE IF EXISTS subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS webhook_events ENABLE ROW LEVEL SECURITY;

-- Tenant Tables
ALTER TABLE IF EXISTS tenants ENABLE ROW LEVEL SECURITY;

-- Template & Content Tables
ALTER TABLE IF EXISTS imported_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS template_components ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_template_categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS email_provider_configs ENABLE ROW LEVEL SECURITY;

-- Meeting & Recording Tables
ALTER TABLE IF EXISTS meeting_summaries ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS live_transcripts ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS recording_metadata ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS voice_analysis ENABLE ROW LEVEL SECURITY;

-- Follow-up & Sequence Tables
ALTER TABLE IF EXISTS follow_up_sequences ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS follow_up_sequence_templates ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS recipient_behavior_patterns ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ml_send_time_training_data ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS ml_send_time_models ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS send_time_optimization_history ENABLE ROW LEVEL SECURITY;

-- Funnel Tables
ALTER TABLE IF EXISTS funnel_definitions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS funnel_alert_conditions ENABLE ROW LEVEL SECURITY;
ALTER TABLE IF EXISTS user_behavior_tracking ENABLE ROW LEVEL SECURITY;

-- Personalization Tables
ALTER TABLE IF EXISTS personalized_email_templates ENABLE ROW LEVEL SECURITY;

-- Jobs Table (Public Read)
ALTER TABLE IF EXISTS jobs ENABLE ROW LEVEL SECURITY;

-- =====================================================
-- CREATE BASIC POLICIES
-- =====================================================

-- Helper function for admin check
CREATE OR REPLACE FUNCTION is_admin()
RETURNS BOOLEAN AS $$
BEGIN
  RETURN EXISTS (
    SELECT 1 FROM user_roles 
    WHERE user_id = auth.uid() 
    AND role IN ('admin', 'super_admin')
  );
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Profiles: Users manage their own
DROP POLICY IF EXISTS "Users manage own profile" ON profiles;
CREATE POLICY "Users manage own profile" ON profiles
  FOR ALL USING (auth.uid() = id);

-- Resumes: Users manage their own
DROP POLICY IF EXISTS "Users manage own resumes" ON resumes;
CREATE POLICY "Users manage own resumes" ON resumes
  FOR ALL USING (auth.uid() = user_id);

-- Job Applications: Users manage their own
DROP POLICY IF EXISTS "Users manage own applications" ON job_applications;
CREATE POLICY "Users manage own applications" ON job_applications
  FOR ALL USING (auth.uid() = user_id);

-- Job Alerts: Users manage their own
DROP POLICY IF EXISTS "Users manage own alerts" ON job_alerts;
CREATE POLICY "Users manage own alerts" ON job_alerts
  FOR ALL USING (auth.uid() = user_id);

-- Jobs: Public read, admin write
DROP POLICY IF EXISTS "Public can view jobs" ON jobs;
CREATE POLICY "Public can view jobs" ON jobs
  FOR SELECT USING (true);

DROP POLICY IF EXISTS "Admins manage jobs" ON jobs;
CREATE POLICY "Admins manage jobs" ON jobs
  FOR ALL USING (is_admin());

-- Saved Jobs: Users manage their own
DROP POLICY IF EXISTS "Users manage saved jobs" ON saved_jobs;
CREATE POLICY "Users manage saved jobs" ON saved_jobs
  FOR ALL USING (auth.uid() = user_id);

-- User Preferences: Users manage their own
DROP POLICY IF EXISTS "Users manage preferences" ON user_preferences;
CREATE POLICY "Users manage preferences" ON user_preferences
  FOR ALL USING (auth.uid() = user_id);

-- Notifications: Users see their own
DROP POLICY IF EXISTS "Users see own notifications" ON notifications;
CREATE POLICY "Users see own notifications" ON notifications
  FOR ALL USING (auth.uid() = user_id);

-- Email Templates: Users manage their own
DROP POLICY IF EXISTS "Users manage email templates" ON email_templates;
CREATE POLICY "Users manage email templates" ON email_templates
  FOR ALL USING (auth.uid() = user_id);

-- Contacts: Users manage their own
DROP POLICY IF EXISTS "Users manage contacts" ON contacts;
CREATE POLICY "Users manage contacts" ON contacts
  FOR ALL USING (auth.uid() = user_id);

-- Email Campaigns: Users manage their own
DROP POLICY IF EXISTS "Users manage campaigns" ON email_campaigns;
CREATE POLICY "Users manage campaigns" ON email_campaigns
  FOR ALL USING (auth.uid() = user_id);

-- Admin full access to audit logs
DROP POLICY IF EXISTS "Admins view audit logs" ON audit_logs;
CREATE POLICY "Admins view audit logs" ON audit_logs
  FOR SELECT USING (is_admin());

-- System settings: Admin only
DROP POLICY IF EXISTS "Admins manage settings" ON system_settings;
CREATE POLICY "Admins manage settings" ON system_settings
  FOR ALL USING (is_admin());

-- =====================================================
-- DONE! All tables now have RLS enabled
-- =====================================================
-- Next: Review and customize policies per your needs
-- Some tables may need more specific policies