# Jobtomize Platform Setup Guide

## Making the Platform Work - Complete Integration Guide

This guide shows you how to connect all platform features to work with real data.

---

## 1. Job Search Integration

### Option A: RapidAPI JSearch (Recommended - Free Tier Available)
```bash
# 1. Sign up at https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
# 2. Get your API key
# 3. Add to Supabase Edge Function Environment Variables:
RAPIDAPI_KEY=your_rapidapi_key_here
```

### Option B: Direct API Integrations
- **Indeed API**: https://indeed.com/publisher
- **LinkedIn Jobs API**: https://developer.linkedin.com/
- **Adzuna API**: https://developer.adzuna.com/

### Deploy Job Fetching Function
```bash
# The edge function code is ready at: supabase/functions/fetch-jobs/index.ts
# Deploy it with:
supabase functions deploy fetch-jobs --no-verify-jwt

# Set environment variable:
supabase secrets set RAPIDAPI_KEY=your_key_here
```

---

## 2. AI Services Setup (Resume/Cover Letter Optimization)

### OpenAI Setup (Recommended)
```bash
# 1. Get API key from https://platform.openai.com/api-keys
# 2. Add to your .env file:
VITE_OPENAI_API_KEY=sk-...

# 3. Insert AI configuration into database:
```

```sql
INSERT INTO ai_configurations (provider, api_key, model, max_tokens, temperature, is_active)
VALUES ('openai', 'sk-your-key-here', 'gpt-4', 4000, 0.7, true);
```

### Alternative: Anthropic Claude
```sql
INSERT INTO ai_configurations (provider, api_key, model, max_tokens, temperature, is_active)
VALUES ('anthropic', 'sk-ant-...', 'claude-3-sonnet-20240229', 4000, 0.7, true);
```

### Initialize AI Service
```typescript
// In your app initialization (main.tsx or App.tsx):
import { aiService } from '@/lib/aiService';

aiService.initialize().catch(console.error);
```

---

## 3. Application Tracking Database Setup

### Create Required Tables
```sql
-- Applications table
CREATE TABLE IF NOT EXISTS job_applications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL,
  job_title TEXT NOT NULL,
  company TEXT NOT NULL,
  status TEXT DEFAULT 'applied',
  applied_date TIMESTAMP DEFAULT NOW(),
  notes TEXT,
  resume_version TEXT,
  cover_letter TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Saved jobs table
CREATE TABLE IF NOT EXISTS saved_jobs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE,
  job_id TEXT NOT NULL,
  saved_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(user_id, job_id)
);

-- Enable RLS
ALTER TABLE job_applications ENABLE ROW LEVEL SECURITY;
ALTER TABLE saved_jobs ENABLE ROW LEVEL SECURITY;

-- RLS Policies
CREATE POLICY "Users can view own applications"
  ON job_applications FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own applications"
  ON job_applications FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own applications"
  ON job_applications FOR UPDATE
  USING (auth.uid() = user_id);
```

---

## 4. Usage Limits & Beta System Setup

### Create Beta Tables
```sql
-- Beta invites
CREATE TABLE IF NOT EXISTS beta_invites (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  code TEXT UNIQUE NOT NULL,
  email TEXT,
  max_uses INTEGER DEFAULT 1,
  current_uses INTEGER DEFAULT 0,
  expires_at TIMESTAMP,
  created_by UUID REFERENCES auth.users(id),
  created_at TIMESTAMP DEFAULT NOW()
);

-- Waitlist
CREATE TABLE IF NOT EXISTS waitlist (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  email TEXT UNIQUE NOT NULL,
  name TEXT,
  company TEXT,
  role TEXT,
  reason TEXT,
  status TEXT DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Usage limits
CREATE TABLE IF NOT EXISTS user_usage_limits (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE UNIQUE,
  resumes_created INTEGER DEFAULT 0,
  resumes_limit INTEGER DEFAULT 10,
  applications_submitted INTEGER DEFAULT 0,
  applications_limit INTEGER DEFAULT 50,
  ai_requests_made INTEGER DEFAULT 0,
  ai_requests_limit INTEGER DEFAULT 100,
  email_campaigns_sent INTEGER DEFAULT 0,
  email_campaigns_limit INTEGER DEFAULT 10,
  storage_used_mb DECIMAL DEFAULT 0,
  storage_limit_mb DECIMAL DEFAULT 500,
  reset_date TIMESTAMP DEFAULT NOW() + INTERVAL '30 days'
);

-- User feedback
CREATE TABLE IF NOT EXISTS user_feedback (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id),
  type TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  status TEXT DEFAULT 'new',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Support tickets
CREATE TABLE IF NOT EXISTS support_tickets (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES auth.users(id),
  subject TEXT NOT NULL,
  category TEXT NOT NULL,
  priority TEXT DEFAULT 'normal',
  status TEXT DEFAULT 'open',
  created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 5. Testing the Platform

### Test Job Search
```typescript
import { jobApiService } from '@/services/jobApiService';

const results = await jobApiService.searchJobs({
  query: 'software engineer',
  location: 'San Francisco',
  remote: true
});

console.log('Found jobs:', results.jobs.length);
```

### Test AI Resume Optimization
```typescript
import { aiService } from '@/lib/aiService';

await aiService.initialize();

const analysis = await aiService.optimizeForATS(
  'Your resume content here',
  'Job description here'
);

console.log('ATS Score:', analysis.data.overallScore);
```

### Test Application Tracking
```typescript
import { supabase } from '@/lib/supabase';

const { data, error } = await supabase
  .from('job_applications')
  .insert({
    job_id: 'job-123',
    job_title: 'Software Engineer',
    company: 'Tech Corp',
    status: 'applied'
  });

console.log('Application saved:', data);
```

---

## 6. Quick Start Checklist

- [ ] Set up RapidAPI account and get JSearch API key
- [ ] Deploy fetch-jobs edge function
- [ ] Get OpenAI or Anthropic API key
- [ ] Insert AI configuration into database
- [ ] Run database migration for application tracking
- [ ] Run database migration for beta system
- [ ] Test job search functionality
- [ ] Test AI resume optimization
- [ ] Test application tracking
- [ ] Configure usage limits for beta users

---

## 7. Environment Variables Summary

```bash
# .env file
VITE_SUPABASE_URL=your_supabase_url
VITE_SUPABASE_ANON_KEY=your_supabase_key
VITE_OPENAI_API_KEY=sk-your-openai-key

# Supabase Edge Function Secrets
supabase secrets set RAPIDAPI_KEY=your_rapidapi_key
```

---

## Support

For issues or questions, check:
- Job Search: Verify RAPIDAPI_KEY is set correctly
- AI Services: Check ai_configurations table has active config
- Database: Ensure all migrations have run successfully
- RLS: Verify user is authenticated before accessing data
