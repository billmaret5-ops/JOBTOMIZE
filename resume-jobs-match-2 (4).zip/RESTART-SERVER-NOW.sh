#!/bin/bash

echo "🛑 Stopping any running dev servers..."
pkill -f "vite" 2>/dev/null || true
pkill -f "npm run dev" 2>/dev/null || true

echo "🧹 Clearing cache..."
rm -rf node_modules/.vite
rm -rf dist

echo "✅ Starting fresh dev server..."
npm run dev

echo "🚀 Dev server should now be running!"
echo "📍 Check http://localhost:5173"
