# Deployment Instructions

## I Cannot Deploy Edge Functions Directly

I don't have permission to deploy Supabase edge functions from my environment. You need to deploy this through **Famous.ai support** or your **deployment dashboard**.

## What Needs to Be Deployed

**Function Name:** `fetch-jobs`

**Function Code:**
```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { query, location, page = 1 } = await req.json();

    const rapidApiKey = 'f4ab66a1d0msh340d0a1e1bc7e3ap18e0a0jsn16e3c73c3a4a';
    
    const url = new URL('https://jsearch.p.rapidapi.com/search');
    url.searchParams.append('query', `${query} in ${location}`);
    url.searchParams.append('page', page.toString());
    url.searchParams.append('num_pages', '1');

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    const data = await response.json();

    return new Response(JSON.stringify(data), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
```

## How to Deploy

**Option 1: Contact Famous.ai Support**
- Send them this file
- Ask them to update the `fetch-jobs` edge function

**Option 2: Use Famous.ai Dashboard**
- Look for "Edge Functions" or "Supabase Functions" section
- Find `fetch-jobs` function
- Replace the code with the above

## After Deployment

Test at: `https://your-app-url.com/verify-jsearch`
