# Security Setup Instructions

## 1. Enable Row Level Security (RLS)

### Quick Method (Recommended)
1. Go to **Supabase Dashboard** → **SQL Editor**
2. Copy the entire contents of `ENABLE-RLS-ALL-TABLES.sql`
3. Paste and click **Run**
4. Wait for completion (may take 30-60 seconds)

### Verify RLS is Enabled
```sql
SELECT tablename 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename NOT IN (
  SELECT tablename 
  FROM pg_tables t
  JOIN pg_class c ON c.relname = t.tablename
  WHERE c.relrowsecurity = true
);
```
This should return **no rows** (meaning all tables have RLS enabled).

## 2. Enable Leaked Password Protection

### Steps:
1. Go to **Supabase Dashboard** → **Authentication** → **Policies**
2. Find **"Leaked Password Protection"**
3. Toggle it **ON**
4. Save changes

### What This Does:
- Checks passwords against HaveIBeenPwned.org (600M+ breached passwords)
- Blocks signup/password changes with compromised passwords
- Uses k-anonymity API (secure, no password sent to third party)
- Zero performance impact

### Error Users Will See:
```
"Password has been found in a data breach. Please use a different password."
```

## 3. Additional Security Recommendations

### Enable Email Confirmations
**Dashboard** → **Authentication** → **Email** → Enable "Confirm email"

### Set Password Requirements
**Dashboard** → **Authentication** → **Policies**
- Minimum length: 8+ characters
- Require uppercase, lowercase, numbers

### Enable MFA (Two-Factor Authentication)
**Dashboard** → **Authentication** → **MFA** → Enable

### Review API Keys
**Dashboard** → **Settings** → **API**
- Keep `anon` key in frontend (safe)
- NEVER expose `service_role` key in frontend
- Use Edge Functions for sensitive operations

## 4. Testing RLS

### Test User Access
```sql
-- As authenticated user
SELECT * FROM resumes; -- Should only see own resumes

-- As anonymous
SELECT * FROM resumes; -- Should see nothing
```

### Test Admin Access
```sql
-- First, make yourself admin
INSERT INTO user_roles (user_id, role)
VALUES (auth.uid(), 'admin');

-- Now test admin access
SELECT * FROM jobs; -- Should see all jobs
```

## 5. Troubleshooting

### "No rows returned" after enabling RLS
**Cause:** No policies exist for that table
**Fix:** Add policies in `ENABLE-RLS-ALL-TABLES.sql` or create custom ones

### "Unauthorized" errors
**Cause:** User doesn't have permission
**Fix:** Check policies match your auth.uid() or user_id column

### Need custom policies?
```sql
-- Example: Share resumes with team
CREATE POLICY "Team can view shared resumes" ON resumes
  FOR SELECT USING (
    shared_with_team = true 
    OR user_id = auth.uid()
  );
```

## 6. Monitoring

### Check RLS Status
```sql
SELECT 
  schemaname,
  tablename,
  rowsecurity as rls_enabled
FROM pg_tables 
WHERE schemaname = 'public'
ORDER BY tablename;
```

### View Active Policies
```sql
SELECT 
  schemaname,
  tablename,
  policyname,
  permissive,
  roles,
  cmd,
  qual
FROM pg_policies
WHERE schemaname = 'public'
ORDER BY tablename, policyname;
```

## ✅ Security Checklist

- [ ] RLS enabled on all tables
- [ ] Policies created for user data
- [ ] Leaked password protection enabled
- [ ] Email confirmation enabled
- [ ] MFA available for users
- [ ] API keys secured
- [ ] Service role key never in frontend
- [ ] Tested user access restrictions
- [ ] Tested admin access
- [ ] Monitoring queries saved

---

**Need Help?**
- Supabase Docs: https://supabase.com/docs/guides/auth/row-level-security
- Security Guide: https://supabase.com/docs/guides/auth/security