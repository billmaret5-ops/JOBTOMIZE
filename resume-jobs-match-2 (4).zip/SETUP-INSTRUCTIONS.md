# 🚀 Platform Setup Instructions

## Your platform is 95% ready! Here's what needs to be done:

### ✅ What's Already Working:
- Authentication (sign up/login)
- User dashboard
- All UI components
- Frontend is fully functional

### ⚠️ What Needs Setup (5 minutes):

## Step 1: Deploy fetch-jobs Edge Function

**Go to Supabase Dashboard:**
1. Visit: https://supabase.com/dashboard/project/YOUR_PROJECT_ID/functions
2. Click "Create a new function"
3. Name it: `fetch-jobs`
4. Paste this code:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') return new Response('ok', { headers: corsHeaders });

  try {
    const { query = 'software engineer', location = '', page = 1 } = await req.json();
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) throw new Error('RapidAPI key not configured');

    const apiUrl = new URL('https://jsearch.p.rapidapi.com/search');
    apiUrl.searchParams.append('query', location ? query + ' in ' + location : query);
    apiUrl.searchParams.append('page', page.toString());

    const response = await fetch(apiUrl.toString(), {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    const data = await response.json();
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: job.job_city + ', ' + job.job_state,
      description: job.job_description,
      salary: job.job_salary,
      type: job.job_employment_type,
      posted_date: job.job_posted_at_datetime_utc,
      apply_url: job.job_apply_link,
      source: 'JSearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote
    }));

    return new Response(JSON.stringify({ jobs, total: data.total }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

5. Click "Deploy"
6. Done!

## Step 2: Test Everything

1. Sign in to your platform
2. Go to Dashboard → Diagnostics tab
3. Click "Run Tests"
4. All tests should pass ✅

## That's It!

Your platform is now fully functional with:
- Real job search via RapidAPI
- AI job matching
- Resume builder
- Cover letter generator
- Interview prep
- Application tracking

## Support

If tests fail, check:
- RAPIDAPI_KEY is set in Supabase secrets
- fetch-jobs function is deployed
- Browser console for errors (F12)
