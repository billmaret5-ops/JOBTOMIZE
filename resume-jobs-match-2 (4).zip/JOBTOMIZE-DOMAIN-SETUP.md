# 🚀 Jobtomize.com Domain Setup Guide

## Quick Setup Checklist

- [ ] Choose deployment platform (Vercel or Netlify)
- [ ] Deploy app to platform
- [ ] Add DNS records at domain registrar
- [ ] Verify domain in platform
- [ ] Wait for SSL certificate (auto-generated)
- [ ] Test https://jobtomize.com

---

## Option 1: Vercel Setup (Recommended)

### Step 1: Deploy to Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel --prod

# Note the deployment URL (e.g., jobtomize-xyz.vercel.app)
```

### Step 2: Add Domain in Vercel Dashboard
1. Go to https://vercel.com/dashboard
2. Select your project
3. Go to **Settings** → **Domains**
4. Add domain: `jobtomize.com`
5. Add domain: `www.jobtomize.com`

### Step 3: Configure DNS Records

Go to your domain registrar (GoDaddy, Namecheap, Cloudflare, etc.) and add:

#### For Root Domain (jobtomize.com):
```
Type: A
Name: @
Value: 76.76.21.21
TTL: 3600
```

#### For WWW Subdomain:
```
Type: CNAME
Name: www
Value: cname.vercel-dns.com
TTL: 3600
```

### Step 4: Verify Setup
```bash
# Check DNS propagation
dig jobtomize.com
dig www.jobtomize.com

# Should show:
# jobtomize.com → 76.76.21.21
# www.jobtomize.com → cname.vercel-dns.com
```

---

## Option 2: Netlify Setup

### Step 1: Deploy to Netlify
```bash
# Install Netlify CLI
npm i -g netlify-cli

# Deploy
netlify deploy --prod

# Note the site name (e.g., jobtomize-abc123.netlify.app)
```

### Step 2: Add Domain in Netlify Dashboard
1. Go to https://app.netlify.com
2. Select your site
3. Go to **Domain settings**
4. Click **Add custom domain**
5. Enter: `jobtomize.com`
6. Click **Verify** and **Add domain**

### Step 3: Configure DNS Records

#### Option A: Use Netlify DNS (Easiest)
1. In Netlify, click **Set up Netlify DNS**
2. Update nameservers at your registrar to:
   ```
   dns1.p01.nsone.net
   dns2.p01.nsone.net
   dns3.p01.nsone.net
   dns4.p01.nsone.net
   ```
3. Netlify handles everything automatically

#### Option B: External DNS
Add these records at your registrar:

```
Type: A
Name: @
Value: 75.2.60.5
TTL: 3600
```

```
Type: CNAME
Name: www
Value: [your-site-name].netlify.app
TTL: 3600
```

---

## SSL Certificate (Automatic)

Both Vercel and Netlify automatically provision SSL certificates:

✅ **Free** Let's Encrypt certificates  
✅ **Auto-renewal** every 90 days  
✅ **Wildcard support** (*.jobtomize.com)  
✅ **HTTP/2 and TLS 1.3** enabled  
✅ **A+ SSL rating** on SSL Labs  

**Wait time:** 5-15 minutes after DNS propagation

---

## Verification Steps

### 1. Check DNS Propagation
```bash
# Check globally
https://www.whatsmydns.net/#A/jobtomize.com

# Check locally
nslookup jobtomize.com
ping jobtomize.com
```

### 2. Test Domain Access
```bash
# Should redirect to HTTPS
curl -I http://jobtomize.com

# Should return 200 OK
curl -I https://jobtomize.com
```

### 3. Verify SSL Certificate
```bash
# Check certificate details
openssl s_client -connect jobtomize.com:443 -servername jobtomize.com

# Or visit in browser and check padlock icon
```

---

## Common Issues & Solutions

### DNS Not Propagating
- **Wait time:** 5 minutes to 48 hours (usually < 1 hour)
- **Clear cache:** `sudo dscacheutil -flushcache` (Mac) or `ipconfig /flushdns` (Windows)
- **Check TTL:** Lower TTL = faster updates

### SSL Certificate Pending
- Ensure DNS is fully propagated first
- Check domain verification in platform dashboard
- Wait 15-30 minutes after DNS propagation
- Contact platform support if > 1 hour

### WWW Not Working
- Ensure CNAME record for `www` is correct
- Check if registrar requires separate A record
- Verify redirect settings in platform dashboard

### Domain Shows "Not Found"
- Verify domain is added in platform dashboard
- Check DNS records are correct (no typos)
- Ensure project is deployed to production

---

## Post-Setup Checklist

- [ ] https://jobtomize.com loads correctly
- [ ] https://www.jobtomize.com loads correctly
- [ ] http:// redirects to https://
- [ ] SSL certificate shows valid (green padlock)
- [ ] All pages and features work
- [ ] Environment variables are set
- [ ] Analytics/monitoring configured

---

## Recommended Next Steps

1. **Set up monitoring:** Add Vercel Analytics or Netlify Analytics
2. **Configure redirects:** Set www → non-www or vice versa
3. **Add email:** Set up MX records for support@jobtomize.com
4. **Enable caching:** Configure CDN cache headers
5. **Set up staging:** Create staging.jobtomize.com for testing

---

## Support Resources

- **Vercel Docs:** https://vercel.com/docs/concepts/projects/domains
- **Netlify Docs:** https://docs.netlify.com/domains-https/custom-domains/
- **DNS Checker:** https://www.whatsmydns.net
- **SSL Test:** https://www.ssllabs.com/ssltest/

---

## Quick Command Reference

```bash
# Deploy to Vercel
vercel --prod

# Deploy to Netlify
netlify deploy --prod

# Check DNS
dig jobtomize.com
nslookup jobtomize.com

# Test SSL
curl -I https://jobtomize.com
openssl s_client -connect jobtomize.com:443

# Check propagation
https://www.whatsmydns.net/#A/jobtomize.com
```

🎉 **Your Jobtomize.com domain will be live in minutes!**
