# 🧪 TEST YOUR DEPLOYMENT

I cannot directly test API endpoints, but here's what YOU can do:

## ✅ Quick Browser Test

**Open these URLs in your browser:**

1. **Health Check:**
```
https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health
```
Expected: `{"ok":true,"rapidapi_key_present":true,"timestamp":"..."}`

2. **Diagnostics:**
```
https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/diagnostics
```
Expected: `{"upstream_ok":true,"status":200,...}`

## 🔍 What to Look For

### ✅ SUCCESS Signs:
- Health returns `"ok": true`
- Diagnostics returns `"upstream_ok": true`
- No 404 errors

### ❌ FAILURE Signs:
- 404 = Function not deployed
- 500 = Missing RAPIDAPI_KEY
- CORS error = Routing issue

## 📱 Test in Your App

Go to your live site and try searching for jobs. Check browser console (F12) for errors.

## 🚨 If It Fails

Run: `supabase functions list`

Should show `fetch-jobs` in the list.

If not listed, redeploy:
```bash
supabase functions deploy fetch-jobs
```
