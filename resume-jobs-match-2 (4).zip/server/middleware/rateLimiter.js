import { RateLimiterRedis } from 'rate-limiter-flexible';
import { redis } from '../config/redis.js';

// Rate limiter for WebSocket connections
export const connectionLimiter = new RateLimiterRedis({
  storeClient: redis,
  keyPrefix: 'rl_conn',
  points: 10, // 10 connections
  duration: 60, // per 60 seconds
  blockDuration: 300 // Block for 5 minutes if exceeded
});

// Rate limiter for WebSocket messages
export const messageLimiter = new RateLimiterRedis({
  storeClient: redis,
  keyPrefix: 'rl_msg',
  points: 100, // 100 messages
  duration: 60, // per 60 seconds
  blockDuration: 60 // Block for 1 minute if exceeded
});

// Rate limiter for operations (edits)
export const operationLimiter = new RateLimiterRedis({
  storeClient: redis,
  keyPrefix: 'rl_op',
  points: 200, // 200 operations
  duration: 60, // per 60 seconds
  blockDuration: 30
});

// Middleware to check connection rate limit
export async function checkConnectionRateLimit(userId, ip) {
  try {
    await connectionLimiter.consume(userId || ip);
    return { allowed: true };
  } catch (error) {
    if (error.remainingPoints !== undefined) {
      return {
        allowed: false,
        retryAfter: Math.ceil(error.msBeforeNext / 1000),
        message: 'Too many connection attempts'
      };
    }
    throw error;
  }
}

// Middleware to check message rate limit
export async function checkMessageRateLimit(userId) {
  try {
    await messageLimiter.consume(userId);
    return { allowed: true };
  } catch (error) {
    if (error.remainingPoints !== undefined) {
      return {
        allowed: false,
        retryAfter: Math.ceil(error.msBeforeNext / 1000),
        message: 'Too many messages sent'
      };
    }
    throw error;
  }
}

// Middleware to check operation rate limit
export async function checkOperationRateLimit(userId) {
  try {
    await operationLimiter.consume(userId);
    return { allowed: true };
  } catch (error) {
    if (error.remainingPoints !== undefined) {
      return {
        allowed: false,
        retryAfter: Math.ceil(error.msBeforeNext / 1000),
        message: 'Too many edit operations'
      };
    }
    throw error;
  }
}
