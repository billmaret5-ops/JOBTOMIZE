import jwt from 'jsonwebtoken';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_ANON_KEY
);

// Validate WebSocket authentication
export async function validateWebSocketAuth(ws, request) {
  try {
    // Extract token from query params or headers
    const url = new URL(request.url, `http://${request.headers.host}`);
    const token = url.searchParams.get('token') || 
                  request.headers.authorization?.replace('Bearer ', '');

    if (!token) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Authentication required'
      }));
      ws.close(1008, 'Authentication required');
      return false;
    }

    // Verify JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      // Try Supabase JWT verification
      const { data: { user }, error } = await supabase.auth.getUser(token);
      
      if (error || !user) {
        throw new Error('Invalid token');
      }
      
      decoded = {
        id: user.id,
        email: user.email,
        role: user.role
      };
    }

    // Attach user info to WebSocket
    ws.user = {
      id: decoded.id || decoded.sub,
      email: decoded.email,
      role: decoded.role || 'user'
    };

    return true;

  } catch (error) {
    console.error('Authentication error:', error);
    ws.send(JSON.stringify({
      type: 'error',
      message: 'Authentication failed: ' + error.message
    }));
    ws.close(1008, 'Authentication failed');
    return false;
  }
}

// Validate REST API authentication
export async function validateRestAuth(req, res, next) {
  try {
    const token = req.headers.authorization?.replace('Bearer ', '');

    if (!token) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    // Verify JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (jwtError) {
      // Try Supabase JWT verification
      const { data: { user }, error } = await supabase.auth.getUser(token);
      
      if (error || !user) {
        throw new Error('Invalid token');
      }
      
      decoded = {
        id: user.id,
        email: user.email,
        role: user.role
      };
    }

    req.user = {
      id: decoded.id || decoded.sub,
      email: decoded.email,
      role: decoded.role || 'user'
    };

    next();

  } catch (error) {
    console.error('Authentication error:', error);
    res.status(401).json({ error: 'Authentication failed' });
  }
}

// Check if user has required role
export function requireRole(role) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ error: 'Authentication required' });
    }

    if (req.user.role !== role && req.user.role !== 'admin') {
      return res.status(403).json({ error: 'Insufficient permissions' });
    }

    next();
  };
}
