import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

// Initialize Supabase client
export const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY || process.env.SUPABASE_ANON_KEY
);

// Database helper functions
export const db = {
  // Get user by ID
  async getUserById(userId) {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('id', userId)
      .single();
    
    if (error) throw error;
    return data;
  },

  // Get room permissions
  async getRoomPermissions(roomId, userId) {
    const { data, error } = await supabase
      .from('collaboration_sessions')
      .select('*')
      .eq('id', roomId)
      .eq('user_id', userId)
      .single();
    
    if (error && error.code !== 'PGRST116') throw error;
    return data;
  },

  // Store collaboration session
  async createCollaborationSession(roomId, userId, documentType, documentId) {
    const { data, error } = await supabase
      .from('collaboration_sessions')
      .insert({
        id: roomId,
        user_id: userId,
        document_type: documentType,
        document_id: documentId,
        started_at: new Date().toISOString()
      })
      .select()
      .single();
    
    if (error) throw error;
    return data;
  },

  // Update session activity
  async updateSessionActivity(roomId, userId) {
    const { error } = await supabase
      .from('collaboration_sessions')
      .update({ 
        last_activity: new Date().toISOString() 
      })
      .eq('id', roomId)
      .eq('user_id', userId);
    
    if (error) throw error;
  },

  // End collaboration session
  async endCollaborationSession(roomId, userId) {
    const { error } = await supabase
      .from('collaboration_sessions')
      .update({ 
        ended_at: new Date().toISOString() 
      })
      .eq('id', roomId)
      .eq('user_id', userId);
    
    if (error) throw error;
  },

  // Store operation
  async storeOperation(roomId, userId, operation) {
    const { error } = await supabase
      .from('collaboration_operations')
      .insert({
        session_id: roomId,
        user_id: userId,
        operation_type: operation.type,
        operation_data: operation,
        created_at: new Date().toISOString()
      });
    
    if (error) throw error;
  },

  // Get recent operations
  async getRecentOperations(roomId, limit = 100) {
    const { data, error } = await supabase
      .from('collaboration_operations')
      .select('*')
      .eq('session_id', roomId)
      .order('created_at', { ascending: false })
      .limit(limit);
    
    if (error) throw error;
    return data;
  }
};

export default supabase;
