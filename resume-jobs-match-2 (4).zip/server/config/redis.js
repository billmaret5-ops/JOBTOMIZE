import Redis from 'ioredis';
import dotenv from 'dotenv';

dotenv.config();

// Redis configuration
const redisConfig = {
  host: process.env.REDIS_HOST || 'localhost',
  port: parseInt(process.env.REDIS_PORT) || 6379,
  password: process.env.REDIS_PASSWORD || undefined,
  retryStrategy: (times) => {
    const delay = Math.min(times * 50, 2000);
    return delay;
  },
  maxRetriesPerRequest: 3,
  enableReadyCheck: true,
  lazyConnect: false
};

// Main Redis client
export const redis = new Redis(redisConfig);

// Pub/Sub clients (separate connections required)
export const publisher = new Redis(redisConfig);
export const subscriber = new Redis(redisConfig);

// Redis event handlers
redis.on('connect', () => {
  console.log('✓ Redis client connected');
});

redis.on('error', (err) => {
  console.error('Redis client error:', err);
});

publisher.on('connect', () => {
  console.log('✓ Redis publisher connected');
});

subscriber.on('connect', () => {
  console.log('✓ Redis subscriber connected');
});

// Redis key prefixes
export const KEYS = {
  ROOM: (roomId) => `room:${roomId}`,
  PRESENCE: (roomId) => `presence:${roomId}`,
  CURSOR: (roomId, userId) => `cursor:${roomId}:${userId}`,
  OPERATION: (roomId) => `operations:${roomId}`,
  RATE_LIMIT: (userId) => `rate_limit:${userId}`,
  SESSION: (sessionId) => `session:${sessionId}`
};

// Redis helper functions
export const redisHelpers = {
  // Store room data
  async setRoomData(roomId, data, ttl = 86400) {
    await redis.setex(KEYS.ROOM(roomId), ttl, JSON.stringify(data));
  },

  // Get room data
  async getRoomData(roomId) {
    const data = await redis.get(KEYS.ROOM(roomId));
    return data ? JSON.parse(data) : null;
  },

  // Add user to room presence
  async addUserToRoom(roomId, userId, userData) {
    await redis.hset(KEYS.PRESENCE(roomId), userId, JSON.stringify({
      ...userData,
      joinedAt: Date.now()
    }));
  },

  // Remove user from room
  async removeUserFromRoom(roomId, userId) {
    await redis.hdel(KEYS.PRESENCE(roomId), userId);
  },

  // Get all users in room
  async getRoomUsers(roomId) {
    const users = await redis.hgetall(KEYS.PRESENCE(roomId));
    return Object.entries(users).map(([userId, data]) => ({
      userId,
      ...JSON.parse(data)
    }));
  },

  // Store cursor position
  async updateCursor(roomId, userId, position) {
    await redis.setex(
      KEYS.CURSOR(roomId, userId),
      60,
      JSON.stringify(position)
    );
  },

  // Store operation
  async storeOperation(roomId, operation) {
    await redis.lpush(KEYS.OPERATION(roomId), JSON.stringify(operation));
    await redis.ltrim(KEYS.OPERATION(roomId), 0, 999);
  },

  // Get operations
  async getOperations(roomId, limit = 100) {
    const ops = await redis.lrange(KEYS.OPERATION(roomId), 0, limit - 1);
    return ops.map(op => JSON.parse(op));
  }
};

export default redis;
