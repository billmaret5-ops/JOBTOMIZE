import { analyticsQueries, supabase } from '../config/database.js';
import { v4 as uuidv4 } from 'uuid';

export class AnalyticsService {
  constructor() {
    this.subscribers = new Map();
    this.metricsCache = new Map();
    this.startRealtimeUpdates();
  }

  // Subscribe client to real-time updates
  subscribe(ws, filters = {}) {
    const subscriptionId = uuidv4();
    this.subscribers.set(subscriptionId, { ws, filters, lastUpdate: Date.now() });
    
    ws.subscriptionId = subscriptionId;
    ws.send(JSON.stringify({
      type: 'subscription_confirmed',
      subscriptionId
    }));

    return subscriptionId;
  }

  // Unsubscribe client
  unsubscribe(subscriptionId) {
    this.subscribers.delete(subscriptionId);
  }

  // Start real-time database updates
  startRealtimeUpdates() {
    // Listen to email_interactions table
    supabase
      .channel('email_interactions')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'email_interactions'
      }, (payload) => {
        this.handleInteractionUpdate(payload);
      })
      .subscribe();

    // Listen to template_analytics table
    supabase
      .channel('template_analytics')
      .on('postgres_changes', {
        event: '*',
        schema: 'public',
        table: 'email_template_analytics'
      }, (payload) => {
        this.handleAnalyticsUpdate(payload);
      })
      .subscribe();

    // Periodic metrics update
    setInterval(() => {
      this.broadcastMetricsUpdate();
    }, 5000);
  }

  // Handle interaction updates (opens, clicks, etc.)
  async handleInteractionUpdate(payload) {
    const interaction = payload.new || payload.old;
    
    // Update cached metrics
    await this.updateMetricsCache(interaction.template_id);
    
    // Broadcast to subscribers
    this.broadcast({
      type: 'interaction_update',
      data: {
        templateId: interaction.template_id,
        interactionType: interaction.interaction_type,
        timestamp: interaction.created_at,
        payload: payload
      }
    });
  }

  // Handle analytics updates
  async handleAnalyticsUpdate(payload) {
    const analytics = payload.new || payload.old;
    
    this.broadcast({
      type: 'analytics_update',
      data: {
        templateId: analytics.template_id,
        metrics: analytics,
        timestamp: new Date().toISOString()
      }
    });
  }

  // Update metrics cache
  async updateMetricsCache(templateId) {
    try {
      const stats = await analyticsQueries.getTemplateStats(templateId);
      this.metricsCache.set(templateId, {
        ...stats,
        lastUpdated: Date.now()
      });
    } catch (error) {
      console.error('Error updating metrics cache:', error);
    }
  }

  // Broadcast metrics update
  async broadcastMetricsUpdate() {
    try {
      const realtimeMetrics = await analyticsQueries.getRealtimeMetrics();
      
      this.broadcast({
        type: 'metrics_update',
        data: {
          metrics: realtimeMetrics,
          timestamp: new Date().toISOString(),
          cached: Object.fromEntries(this.metricsCache)
        }
      });
    } catch (error) {
      console.error('Error broadcasting metrics:', error);
    }
  }

  // Broadcast message to all subscribers
  broadcast(message, filter = null) {
    this.subscribers.forEach((subscriber, subscriptionId) => {
      const { ws, filters } = subscriber;
      
      if (ws.readyState === ws.OPEN) {
        // Apply filters if specified
        if (filter && !filter(filters)) {
          return;
        }
        
        ws.send(JSON.stringify(message));
      } else {
        // Clean up closed connections
        this.subscribers.delete(subscriptionId);
      }
    });
  }

  // Get current metrics for a template
  async getTemplateMetrics(templateId) {
    if (this.metricsCache.has(templateId)) {
      const cached = this.metricsCache.get(templateId);
      if (Date.now() - cached.lastUpdated < 30000) { // 30 seconds cache
        return cached;
      }
    }
    
    await this.updateMetricsCache(templateId);
    return this.metricsCache.get(templateId);
  }
}