const { S3Client, PutObjectCommand, GetObjectCommand, ListObjectsV2Command, DeleteObjectCommand } = require('@aws-sdk/client-s3');
const crypto = require('crypto');
const zlib = require('zlib');
const { promisify } = require('util');
const gzip = promisify(zlib.gzip);
const gunzip = promisify(zlib.gunzip);

class BackupService {
  constructor() {
    this.s3Client = new S3Client({
      region: process.env.AWS_REGION || 'us-east-1',
      credentials: {
        accessKeyId: process.env.AWS_ACCESS_KEY_ID,
        secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY
      }
    });
    this.bucket = process.env.AWS_BACKUP_BUCKET;
    this.encryptionKey = process.env.BACKUP_ENCRYPTION_KEY;
  }

  encrypt(data) {
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv('aes-256-gcm', Buffer.from(this.encryptionKey, 'hex'), iv);
    let encrypted = cipher.update(JSON.stringify(data), 'utf8', 'hex');
    encrypted += cipher.final('hex');
    const authTag = cipher.getAuthTag();
    return { encrypted, iv: iv.toString('hex'), authTag: authTag.toString('hex') };
  }

  decrypt(encryptedData, iv, authTag) {
    const decipher = crypto.createDecipheriv('aes-256-gcm', Buffer.from(this.encryptionKey, 'hex'), Buffer.from(iv, 'hex'));
    decipher.setAuthTag(Buffer.from(authTag, 'hex'));
    let decrypted = decipher.update(encryptedData, 'hex', 'utf8');
    decrypted += decipher.final('utf8');
    return JSON.parse(decrypted);
  }

  async createBackup(supabase, jobConfig) {
    const backupData = { tables: {}, metadata: { timestamp: new Date().toISOString(), jobId: jobConfig.id } };
    
    const tablesToBackup = jobConfig.tables_to_backup || await this.getAllTables(supabase);
    
    for (const table of tablesToBackup) {
      try {
        const { data, error } = await supabase.from(table).select('*');
        if (!error && data) {
          backupData.tables[table] = data;
        }
      } catch (err) {
        console.error(`Error backing up table ${table}:`, err);
      }
    }

    const compressed = await gzip(JSON.stringify(backupData));
    
    let finalData = compressed;
    let encryptionMetadata = null;
    
    if (jobConfig.encryption_enabled) {
      const { encrypted, iv, authTag } = this.encrypt(compressed);
      finalData = Buffer.from(encrypted, 'hex');
      encryptionMetadata = { iv, authTag, algorithm: 'aes-256-gcm' };
    }

    const fileName = `backup-${jobConfig.id}-${Date.now()}.dat`;
    const filePath = `backups/${new Date().toISOString().split('T')[0]}/${fileName}`;

    await this.s3Client.send(new PutObjectCommand({
      Bucket: this.bucket,
      Key: filePath,
      Body: finalData,
      Metadata: encryptionMetadata || {}
    }));

    return { filePath, fileSize: finalData.length, rowCount: Object.values(backupData.tables).reduce((sum, t) => sum + t.length, 0), encryptionMetadata };
  }

  async restoreBackup(supabase, backupPath, encryptionMetadata, tablesToRestore) {
    const command = new GetObjectCommand({ Bucket: this.bucket, Key: backupPath });
    const response = await this.s3Client.send(command);
    
    let data = await this.streamToBuffer(response.Body);
    
    if (encryptionMetadata) {
      data = Buffer.from(this.decrypt(data.toString('hex'), encryptionMetadata.iv, encryptionMetadata.authTag));
    }

    const decompressed = await gunzip(data);
    const backupData = JSON.parse(decompressed.toString());

    let restoredRows = 0;
    const tables = tablesToRestore || Object.keys(backupData.tables);

    for (const table of tables) {
      if (backupData.tables[table]) {
        const { error } = await supabase.from(table).upsert(backupData.tables[table]);
        if (!error) restoredRows += backupData.tables[table].length;
      }
    }

    return { restoredRows, tables };
  }

  async streamToBuffer(stream) {
    return new Promise((resolve, reject) => {
      const chunks = [];
      stream.on('data', chunk => chunks.push(chunk));
      stream.on('end', () => resolve(Buffer.concat(chunks)));
      stream.on('error', reject);
    });
  }

  async getAllTables(supabase) {
    return ['profiles', 'resumes', 'job_applications', 'jobs', 'saved_jobs', 'interviews'];
  }

  async applyRetentionPolicy(policy) {
    const command = new ListObjectsV2Command({ Bucket: this.bucket, Prefix: 'backups/' });
    const response = await this.s3Client.send(command);
    
    const now = new Date();
    const toDelete = [];

    for (const obj of response.Contents || []) {
      const age = Math.floor((now - obj.LastModified) / (1000 * 60 * 60 * 24));
      if (age > policy.keep_daily) toDelete.push(obj.Key);
    }

    for (const key of toDelete) {
      await this.s3Client.send(new DeleteObjectCommand({ Bucket: this.bucket, Key: key }));
    }

    return toDelete.length;
  }
}

module.exports = new BackupService();
