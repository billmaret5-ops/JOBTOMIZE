import { v4 as uuidv4 } from 'uuid';
import { publisher, subscriber, redisHelpers } from '../config/redis.js';

export class CollaborationService {
  constructor() {
    this.rooms = new Map();
    this.userConnections = new Map();
    this.setupRedisSubscriptions();
  }

  // Setup Redis pub/sub for multi-server scaling
  setupRedisSubscriptions() {
    subscriber.on('message', (channel, message) => {
      const [type, roomId] = channel.split(':');
      const data = JSON.parse(message);

      switch (type) {
        case 'operation':
          this.broadcastToRoom(roomId, data, data.userId);
          break;
        case 'cursor':
          this.broadcastToRoom(roomId, data, data.userId);
          break;
        case 'presence':
          this.broadcastToRoom(roomId, data);
          break;
        case 'comment':
          this.broadcastToRoom(roomId, data, data.userId);
          break;
      }
    });
  }

  // Join a room
  async joinRoom(ws, roomId, userId, userData) {
    // Create room if doesn't exist
    if (!this.rooms.has(roomId)) {
      this.rooms.set(roomId, new Set());
      await subscriber.subscribe(`operation:${roomId}`);
      await subscriber.subscribe(`cursor:${roomId}`);
      await subscriber.subscribe(`presence:${roomId}`);
      await subscriber.subscribe(`comment:${roomId}`);
    }

    // Add user to room
    this.rooms.get(roomId).add(ws);
    ws.roomId = roomId;
    ws.userId = userId;

    // Track user connection
    if (!this.userConnections.has(userId)) {
      this.userConnections.set(userId, new Set());
    }
    this.userConnections.get(userId).add(ws);

    // Store in Redis
    await redisHelpers.addUserToRoom(roomId, userId, userData);

    // Get current room state
    const users = await redisHelpers.getRoomUsers(roomId);
    const operations = await redisHelpers.getOperations(roomId, 50);

    // Notify others
    await this.publishPresence(roomId, {
      type: 'user_joined',
      userId,
      userData,
      timestamp: Date.now()
    });

    return { users, operations };
  }

  // Leave a room
  async leaveRoom(ws) {
    const { roomId, userId } = ws;
    if (!roomId) return;

    // Remove from room
    const room = this.rooms.get(roomId);
    if (room) {
      room.delete(ws);
      if (room.size === 0) {
        this.rooms.delete(roomId);
        await subscriber.unsubscribe(`operation:${roomId}`);
        await subscriber.unsubscribe(`cursor:${roomId}`);
        await subscriber.unsubscribe(`presence:${roomId}`);
        await subscriber.unsubscribe(`comment:${roomId}`);
      }
    }

    // Remove user connection
    const userConns = this.userConnections.get(userId);
    if (userConns) {
      userConns.delete(ws);
      if (userConns.size === 0) {
        this.userConnections.delete(userId);
        await redisHelpers.removeUserFromRoom(roomId, userId);
      }
    }

    // Notify others
    await this.publishPresence(roomId, {
      type: 'user_left',
      userId,
      timestamp: Date.now()
    });
  }

  // Broadcast operation
  async broadcastOperation(roomId, userId, operation) {
    const message = {
      type: 'operation',
      userId,
      operation,
      timestamp: Date.now()
    };

    // Store in Redis
    await redisHelpers.storeOperation(roomId, operation);

    // Publish to Redis (for multi-server)
    await publisher.publish(`operation:${roomId}`, JSON.stringify(message));
  }

  // Broadcast cursor position
  async broadcastCursor(roomId, userId, position) {
    const message = {
      type: 'cursor',
      userId,
      position,
      timestamp: Date.now()
    };

    // Store in Redis
    await redisHelpers.updateCursor(roomId, userId, position);

    // Publish to Redis
    await publisher.publish(`cursor:${roomId}`, JSON.stringify(message));
  }

  // Broadcast comment
  async broadcastComment(roomId, userId, comment) {
    const message = {
      type: 'comment',
      userId,
      comment: {
        id: uuidv4(),
        ...comment,
        timestamp: Date.now()
      }
    };

    // Publish to Redis
    await publisher.publish(`comment:${roomId}`, JSON.stringify(message));
  }

  // Publish presence update
  async publishPresence(roomId, data) {
    await publisher.publish(`presence:${roomId}`, JSON.stringify(data));
  }

  // Broadcast to room (local connections only)
  broadcastToRoom(roomId, message, excludeUserId = null) {
    const room = this.rooms.get(roomId);
    if (!room) return;

    const messageStr = JSON.stringify(message);
    room.forEach(ws => {
      if (ws.readyState === 1 && ws.userId !== excludeUserId) {
        ws.send(messageStr);
      }
    });
  }

  // Get room statistics
  async getRoomStats(roomId) {
    const users = await redisHelpers.getRoomUsers(roomId);
    const operations = await redisHelpers.getOperations(roomId, 1);
    
    return {
      roomId,
      userCount: users.length,
      users: users.map(u => ({ userId: u.userId, name: u.name })),
      lastActivity: operations[0]?.timestamp || null
    };
  }

  // Get all active rooms
  getActiveRooms() {
    return Array.from(this.rooms.keys()).map(roomId => ({
      roomId,
      connections: this.rooms.get(roomId).size
    }));
  }
}
