# Real-Time Collaboration WebSocket Server

Enterprise-grade WebSocket server for real-time collaborative editing with Redis scaling, rate limiting, and operational transformation support.

## Features

- **WebSocket Server**: Real-time bidirectional communication
- **Room-Based Sessions**: Isolated collaboration spaces
- **Redis Scaling**: Multi-server support with pub/sub
- **Rate Limiting**: Protection against abuse
- **Authentication**: JWT-based WebSocket auth
- **Operation Broadcasting**: Real-time edit synchronization
- **Cursor Tracking**: Live cursor positions
- **Presence Management**: Online user tracking
- **Comment System**: Real-time comments and suggestions

## Architecture

```
┌─────────────┐     ┌─────────────┐     ┌─────────────┐
│   Client 1  │────▶│   Server 1  │────▶│    Redis    │
└─────────────┘     └─────────────┘     └─────────────┘
                           │                    │
┌─────────────┐            │                    │
│   Client 2  │────────────┘                    │
└─────────────┘                                 │
                                                │
┌─────────────┐     ┌─────────────┐            │
│   Client 3  │────▶│   Server 2  │────────────┘
└─────────────┘     └─────────────┘
```

## Installation

```bash
cd server
npm install
```

## Configuration

Create `.env` file:

```env
PORT=8080
JWT_SECRET=your-jwt-secret
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-supabase-key
REDIS_HOST=localhost
REDIS_PORT=6379
REDIS_PASSWORD=optional-password
```

## Running the Server

Development:
```bash
npm run dev
```

Production:
```bash
npm start
```

## WebSocket Protocol

### Connection

```javascript
const ws = new WebSocket('ws://localhost:8080/collaborate', {
  headers: {
    'Authorization': 'Bearer YOUR_JWT_TOKEN'
  }
});
```

### Messages

#### Join Room
```json
{
  "type": "join_room",
  "roomId": "resume-123",
  "userData": {
    "name": "John Doe",
    "avatar": "https://...",
    "color": "#3B82F6"
  }
}
```

#### Send Operation
```json
{
  "type": "operation",
  "operation": {
    "type": "insert",
    "position": 10,
    "content": "Hello",
    "version": 5
  }
}
```

#### Update Cursor
```json
{
  "type": "cursor",
  "position": {
    "line": 5,
    "column": 10,
    "x": 250,
    "y": 120
  }
}
```

#### Add Comment
```json
{
  "type": "comment",
  "comment": {
    "text": "Great point!",
    "position": 150,
    "resolved": false
  }
}
```

## Rate Limits

- **Connections**: 10 per minute per user
- **Messages**: 100 per minute per user
- **Operations**: 200 per minute per user

## API Endpoints

### Health Check
```
GET /health
```

Response:
```json
{
  "status": "healthy",
  "connections": 42,
  "rooms": 5,
  "uptime": 3600
}
```

### Active Rooms
```
GET /api/rooms
```

### Room Statistics
```
GET /api/rooms/:roomId/stats
```

## Redis Keys

- `room:{roomId}` - Room data
- `presence:{roomId}` - Active users
- `cursor:{roomId}:{userId}` - Cursor positions
- `operations:{roomId}` - Operation history
- `rate_limit:{userId}` - Rate limit counters

## Scaling

The server uses Redis pub/sub for horizontal scaling:

1. Start multiple server instances
2. All connect to same Redis instance
3. Operations broadcast via Redis channels
4. Clients connect to any server instance

## Monitoring

Monitor server health:
```bash
curl http://localhost:8080/health
```

View active rooms:
```bash
curl http://localhost:8080/api/rooms
```

## Security

- JWT authentication required
- Rate limiting on all operations
- Input validation with Joi
- WebSocket origin validation
- Automatic connection cleanup

## Performance

- Compression enabled
- Heartbeat every 30 seconds
- Automatic reconnection handling
- Operation history limited to 1000 items
- Cursor TTL of 60 seconds

## Troubleshooting

### Connection Issues
- Check JWT token validity
- Verify WebSocket URL
- Check rate limits

### Redis Issues
- Verify Redis connection
- Check Redis memory
- Monitor pub/sub channels

### Performance Issues
- Monitor connection count
- Check operation rate
- Review Redis metrics

## Production Deployment

1. Set environment variables
2. Configure Redis cluster
3. Use process manager (PM2)
4. Enable SSL/TLS
5. Configure load balancer
6. Set up monitoring

Example PM2 config:
```javascript
module.exports = {
  apps: [{
    name: 'collaboration-server',
    script: 'server.js',
    instances: 4,
    exec_mode: 'cluster',
    env: {
      NODE_ENV: 'production',
      PORT: 8080
    }
  }]
};
```
