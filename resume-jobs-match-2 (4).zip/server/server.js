import express from 'express';
import { WebSocketServer } from 'ws';
import cors from 'cors';
import http from 'http';
import compression from 'compression';
import { validateWebSocketAuth } from './middleware/auth.js';
import { CollaborationService } from './services/collaborationService.js';
import { 
  checkConnectionRateLimit, 
  checkMessageRateLimit,
  checkOperationRateLimit 
} from './middleware/rateLimiter.js';
import Joi from 'joi';

const app = express();
const server = http.createServer(app);
const PORT = process.env.PORT || 8080;

// Initialize collaboration service
const collaborationService = new CollaborationService();

// Middleware
app.use(cors());
app.use(compression());
app.use(express.json());

// WebSocket server for collaboration
const wss = new WebSocketServer({ 
  server,
  path: '/collaborate'
});

// Message validation schemas
const messageSchemas = {
  join_room: Joi.object({
    type: Joi.string().valid('join_room').required(),
    roomId: Joi.string().required(),
    userData: Joi.object({
      name: Joi.string().required(),
      avatar: Joi.string().optional(),
      color: Joi.string().optional()
    }).required()
  }),

  operation: Joi.object({
    type: Joi.string().valid('operation').required(),
    operation: Joi.object({
      type: Joi.string().required(),
      position: Joi.number().required(),
      content: Joi.any().optional(),
      version: Joi.number().required()
    }).required()
  }),

  cursor: Joi.object({
    type: Joi.string().valid('cursor').required(),
    position: Joi.object({
      line: Joi.number().required(),
      column: Joi.number().required(),
      x: Joi.number().optional(),
      y: Joi.number().optional()
    }).required()
  }),

  comment: Joi.object({
    type: Joi.string().valid('comment').required(),
    comment: Joi.object({
      text: Joi.string().required(),
      position: Joi.number().optional(),
      resolved: Joi.boolean().optional()
    }).required()
  })
};

// WebSocket connection handler
wss.on('connection', async (ws, request) => {
  const clientIp = request.socket.remoteAddress;
  console.log('New collaboration connection attempt from', clientIp);
  
  // Authenticate connection
  const isAuthenticated = await validateWebSocketAuth(ws, request);
  if (!isAuthenticated) {
    return;
  }

  const userId = ws.user.id;

  // Check connection rate limit
  const rateLimitResult = await checkConnectionRateLimit(userId, clientIp);
  if (!rateLimitResult.allowed) {
    ws.send(JSON.stringify({
      type: 'error',
      message: rateLimitResult.message,
      retryAfter: rateLimitResult.retryAfter
    }));
    ws.close(1008, 'Rate limit exceeded');
    return;
  }

  console.log(`User ${ws.user.email} connected to collaboration server`);
  
  // Send welcome message
  ws.send(JSON.stringify({
    type: 'connected',
    message: 'Connected to collaboration server',
    userId: ws.user.id,
    email: ws.user.email
  }));

  // Handle messages
  ws.on('message', async (data) => {
    try {
      // Check message rate limit
      const msgRateLimit = await checkMessageRateLimit(userId);
      if (!msgRateLimit.allowed) {
        ws.send(JSON.stringify({
          type: 'error',
          message: msgRateLimit.message
        }));
        return;
      }

      const message = JSON.parse(data.toString());
      await handleCollaborationMessage(ws, message);
    } catch (error) {
      ws.send(JSON.stringify({
        type: 'error',
        message: 'Invalid message: ' + error.message
      }));
    }
  });

  // Handle connection close
  ws.on('close', async () => {
    await collaborationService.leaveRoom(ws);
    console.log(`User ${ws.user?.email} disconnected`);
  });

  // Handle errors
  ws.on('error', (error) => {
    console.error('WebSocket error:', error);
  });

  // Send heartbeat every 30 seconds
  const heartbeat = setInterval(() => {
    if (ws.readyState === 1) {
      ws.ping();
    } else {
      clearInterval(heartbeat);
    }
  }, 30000);

  ws.on('pong', () => {
    ws.isAlive = true;
  });
});

// Handle collaboration messages
async function handleCollaborationMessage(ws, message) {
  const { type } = message;
  const userId = ws.user.id;
  
  try {
    switch (type) {
      case 'join_room': {
        const { error } = messageSchemas.join_room.validate(message);
        if (error) throw new Error(error.details[0].message);
        
        const { roomId, userData } = message;
        const roomState = await collaborationService.joinRoom(
          ws, 
          roomId, 
          userId, 
          { ...userData, email: ws.user.email }
        );
        
        ws.send(JSON.stringify({
          type: 'room_joined',
          roomId,
          ...roomState
        }));
        break;
      }

      case 'operation': {
        const { error } = messageSchemas.operation.validate(message);
        if (error) throw new Error(error.details[0].message);

        // Check operation rate limit
        const opRateLimit = await checkOperationRateLimit(userId);
        if (!opRateLimit.allowed) {
          ws.send(JSON.stringify({
            type: 'error',
            message: opRateLimit.message
          }));
          return;
        }
        
        if (!ws.roomId) throw new Error('Not in a room');
        
        await collaborationService.broadcastOperation(
          ws.roomId,
          userId,
          message.operation
        );
        break;
      }

      case 'cursor': {
        const { error } = messageSchemas.cursor.validate(message);
        if (error) throw new Error(error.details[0].message);
        
        if (!ws.roomId) throw new Error('Not in a room');
        
        await collaborationService.broadcastCursor(
          ws.roomId,
          userId,
          message.position
        );
        break;
      }

      case 'comment': {
        const { error } = messageSchemas.comment.validate(message);
        if (error) throw new Error(error.details[0].message);
        
        if (!ws.roomId) throw new Error('Not in a room');
        
        await collaborationService.broadcastComment(
          ws.roomId,
          userId,
          message.comment
        );
        break;
      }

      case 'ping':
        ws.send(JSON.stringify({ type: 'pong' }));
        break;

      default:
        throw new Error(`Unknown message type: ${type}`);
    }
  } catch (error) {
    ws.send(JSON.stringify({
      type: 'error',
      message: error.message
    }));
  }
}

// REST API endpoints
app.get('/health', (req, res) => {
  res.json({ 
    status: 'healthy', 
    connections: wss.clients.size,
    rooms: collaborationService.getActiveRooms().length,
    uptime: process.uptime()
  });
});

app.get('/api/rooms', (req, res) => {
  res.json({
    rooms: collaborationService.getActiveRooms()
  });
});

app.get('/api/rooms/:roomId/stats', async (req, res) => {
  try {
    const stats = await collaborationService.getRoomStats(req.params.roomId);
    res.json(stats);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Error handling
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).json({ error: 'Something went wrong!' });
});

// Start server
server.listen(PORT, () => {
  console.log(`Collaboration WebSocket server running on port ${PORT}`);
  console.log(`WebSocket endpoint: ws://localhost:${PORT}/collaborate`);
  console.log(`Health check: http://localhost:${PORT}/health`);
});

// Graceful shutdown
process.on('SIGTERM', () => {
  console.log('Shutting down server...');
  server.close(() => {
    process.exit(0);
  });
});
