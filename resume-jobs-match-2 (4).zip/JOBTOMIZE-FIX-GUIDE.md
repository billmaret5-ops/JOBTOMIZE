# Jobtomize Critical Fixes Guide

## Issues Identified

### 1. Job Matching Not Working
**Root Cause**: The `ai-job-matching` edge function is using the deprecated direct OpenAI API instead of the API Gateway.

### 2. Resume Builder/Parser Not Working
**Root Cause**: The `parse-resume` edge function is using the deprecated direct OpenAI API instead of the API Gateway.

---

## Fix Instructions

### Fix 1: Update ai-job-matching Function

1. Go to Supabase Dashboard → Edge Functions → `ai-job-matching`
2. Replace the function code with the corrected version below:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { userProfile, jobs, resumeText, preferences } = await req.json();
    const gatewayApiKey = Deno.env.get("GATEWAY_API_KEY");

    if (!gatewayApiKey) {
      throw new Error("API Gateway key not configured");
    }

    const matchedJobs = [];

    for (const job of jobs) {
      const prompt = `Analyze job match between user and job posting.

USER: Skills: ${userProfile?.skills?.join(', ') || 'Not specified'}, Experience: ${userProfile?.experience_level || 'Not specified'}, Location: ${userProfile?.location || 'Not specified'}

JOB: ${job.title} at ${job.company}, Location: ${job.location}, Type: ${job.type}, Requirements: ${job.requirements}

Return ONLY JSON: {"matchScore": 0-100, "skillsMatch": 0-100, "careerFit": 0-100, "locationFit": 0-100, "salaryFit": 0-100, "strengths": ["str1","str2"], "gaps": ["gap1"], "recommendations": ["rec1"], "reasoning": "text"}`;

      const response = await fetch('https://ai.gateway.fastrouter.io/api/v1/chat/completions', {
        method: 'POST',
        headers: {
          'X-API-Key': gatewayApiKey,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          model: 'google/gemini-2.5-flash',
          messages: [{ role: 'user', content: prompt }],
          temperature: 0.2
        })
      });

      const aiResult = await response.json();
      let matchData;

      try {
        const content = aiResult.choices[0].message.content.trim();
        const jsonMatch = content.match(/\{[\s\S]*\}/);
        matchData = JSON.parse(jsonMatch ? jsonMatch[0] : content);
      } catch {
        matchData = {
          matchScore: 65, skillsMatch: 60, careerFit: 65,
          locationFit: 70, salaryFit: 70,
          strengths: ["Experience alignment"], gaps: ["Complete profile"],
          recommendations: ["Update skills"], reasoning: "Basic analysis"
        };
      }

      matchedJobs.push({
        ...job,
        matchScore: Math.max(0, Math.min(100, matchData.matchScore)),
        skillsMatch: matchData.skillsMatch || 50,
        careerFit: matchData.careerFit || 50,
        locationFit: matchData.locationFit || 50,
        salaryFit: matchData.salaryFit || 50,
        strengths: matchData.strengths || [],
        gaps: matchData.gaps || [],
        recommendations: matchData.recommendations || [],
        reasoning: matchData.reasoning || "Match completed"
      });
    }

    matchedJobs.sort((a, b) => b.matchScore - a.matchScore);

    return new Response(JSON.stringify({ 
      matchedJobs,
      totalAnalyzed: jobs.length,
      avgMatchScore: matchedJobs.reduce((sum, job) => sum + job.matchScore, 0) / matchedJobs.length
    }), {
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });

  } catch (error) {
    return new Response(JSON.stringify({ 
      error: error.message, matchedJobs: [], totalAnalyzed: 0 
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });
  }
});
```

3. Click "Deploy" to save changes

---

### Fix 2: Update parse-resume Function

1. Go to Supabase Dashboard → Edge Functions → `parse-resume`
2. Replace with:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { text, filename } = await req.json();
    const gatewayApiKey = Deno.env.get("GATEWAY_API_KEY");

    if (!gatewayApiKey) {
      throw new Error("API Gateway key not configured");
    }

    const prompt = `Extract structured data from this resume. Return ONLY valid JSON:
{
  "personalInfo": {"name": "", "email": "", "phone": "", "location": ""},
  "summary": "",
  "skills": {
    "technical": [{"name": "", "proficiency": "beginner|intermediate|advanced|expert"}],
    "soft": [{"name": "", "proficiency": ""}]
  },
  "experience": [{"title": "", "company": "", "startDate": "", "endDate": "", "description": "", "achievements": []}],
  "education": [{"degree": "", "school": "", "year": ""}],
  "experienceYears": 0,
  "seniorityLevel": "entry|junior|mid|senior|lead",
  "atsScore": 0-100
}

Resume: ${text}`;

    const response = await fetch('https://ai.gateway.fastrouter.io/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'X-API-Key': gatewayApiKey,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.3
      })
    });

    const result = await response.json();
    const content = result.choices[0].message.content.trim();
    const jsonMatch = content.match(/\{[\s\S]*\}/);
    const parsedData = JSON.parse(jsonMatch ? jsonMatch[0] : content);

    return new Response(JSON.stringify({
      success: true,
      data: parsedData,
      filename: filename
    }), {
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });

  } catch (error) {
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });
  }
});
```

3. Click "Deploy"

---

## Verification Steps

### Test Job Matching:
1. Log into jobtomize.com
2. Upload a resume or fill out your profile
3. Search for jobs
4. Verify match scores appear on job cards
5. Check that match details show when clicking jobs

### Test Resume Parser:
1. Go to Resume Builder section
2. Upload a PDF/DOCX resume
3. Verify it extracts: name, email, skills, experience, education
4. Check that parsed data populates the builder fields

---

## Additional Debugging

### Check Environment Variables:
```bash
# In Supabase Dashboard → Settings → Edge Functions → Secrets
# Verify GATEWAY_API_KEY is set
```

### View Function Logs:
```bash
# In Supabase Dashboard → Edge Functions → Select function → Logs tab
# Look for errors related to API calls
```

### Test Functions Directly:
```bash
curl -X POST https://YOUR-PROJECT.supabase.co/functions/v1/ai-job-matching \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"userProfile":{"skills":["JavaScript"]}, "jobs":[{"title":"Developer","company":"Test","location":"Remote"}]}'
```

---

## Common Issues

### "API Gateway key not configured"
- Go to Supabase → Settings → Edge Functions → Secrets
- Add `GATEWAY_API_KEY` with your API gateway key

### "Unauthorized" errors
- Check that GATEWAY_API_KEY is valid
- Verify the key has permissions for AI services

### Still not working?
1. Check browser console for errors (F12)
2. Check Supabase function logs
3. Verify user is logged in (job matching requires auth)
4. Clear browser cache and try again

---

## Quick CLI Fix (Alternative)

If you have Supabase CLI installed:

```bash
# Update ai-job-matching
supabase functions deploy ai-job-matching

# Update parse-resume  
supabase functions deploy parse-resume
```

Make sure the function files in your local `supabase/functions/` directory have the corrected code above.
