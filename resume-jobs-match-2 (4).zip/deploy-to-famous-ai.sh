#!/bin/bash

# 🚀 Jobtomize.com - Famous.ai Deployment Script
# This script builds your app and prepares it for upload

echo "🚀 Starting Jobtomize.com build for Famous.ai deployment..."
echo ""

# Step 1: Clean previous build
echo "🧹 Cleaning previous build..."
rm -rf dist/
echo "✅ Clean complete"
echo ""

# Step 2: Install dependencies
echo "📦 Installing dependencies..."
npm install
if [ $? -ne 0 ]; then
    echo "❌ npm install failed"
    exit 1
fi
echo "✅ Dependencies installed"
echo ""

# Step 3: Build production version
echo "🔨 Building production version..."
npm run build
if [ $? -ne 0 ]; then
    echo "❌ Build failed"
    exit 1
fi
echo "✅ Build complete"
echo ""

# Step 4: Verify build output
echo "📋 Verifying build output..."
if [ ! -d "dist" ]; then
    echo "❌ dist/ folder not found"
    exit 1
fi

if [ ! -f "dist/index.html" ]; then
    echo "❌ index.html not found in dist/"
    exit 1
fi

echo "✅ Build verification passed"
echo ""

# Step 5: Show build stats
echo "📊 Build Statistics:"
echo "-------------------"
du -sh dist/
echo ""
echo "Files ready for upload:"
ls -lh dist/
echo ""

# Step 6: Next steps
echo "🎉 BUILD SUCCESSFUL!"
echo ""
echo "📁 Your files are ready in the 'dist/' folder"
echo ""
echo "🔄 NEXT STEPS:"
echo "1. Upload all files from 'dist/' folder to Famous.ai"
echo "2. Use FTP/SFTP to connect to your Famous.ai server"
echo "3. Upload to 'public_html' or 'www' directory"
echo "4. Configure DNS to point to Famous.ai"
echo "5. Enable SSL certificate in Famous.ai dashboard"
echo ""
echo "📖 See FAMOUS-AI-DEPLOYMENT-STEPS.md for detailed instructions"
echo ""
echo "✅ Ready to deploy to jobtomize.com!"
