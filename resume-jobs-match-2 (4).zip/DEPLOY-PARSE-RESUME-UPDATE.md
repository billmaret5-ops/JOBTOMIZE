# Update parse-resume Function to Use API Gateway

## Quick Fix - Update Edge Function

The `parse-resume` function needs to be updated to use the API Gateway instead of direct OpenAI API.

### Step 1: Go to Supabase Dashboard

1. Open https://supabase.com/dashboard
2. Select your project
3. Go to **Edge Functions** in the left sidebar
4. Find and click on **parse-resume** function

### Step 2: Replace the Function Code

Replace the entire function code with this:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { text, filename, userId } = await req.json();
    const gatewayApiKey = Deno.env.get("GATEWAY_API_KEY");

    if (!gatewayApiKey) {
      throw new Error("API Gateway key not configured");
    }

    const prompt = `Analyze this resume comprehensively and extract detailed structured information. Return ONLY valid JSON with this exact structure:
    {
      "personalInfo": {"name": "", "email": "", "phone": "", "location": "", "linkedin": "", "portfolio": ""},
      "summary": "",
      "skills": {
        "technical": [{"name": "", "category": "", "proficiency": ""}],
        "soft": [{"name": "", "proficiency": ""}],
        "languages": [{"name": "", "proficiency": ""}],
        "certifications": [{"name": "", "issuer": "", "year": ""}]
      },
      "experience": [{"title": "", "company": "", "startDate": "", "endDate": "", "description": "", "achievements": [], "technologies": []}],
      "education": [{"degree": "", "school": "", "year": "", "gpa": "", "relevant_courses": []}],
      "projects": [{"name": "", "description": "", "technologies": [], "url": ""}],
      "experienceYears": 0,
      "seniorityLevel": "",
      "preferredRoles": [],
      "industryExperience": [],
      "atsScore": 0,
      "optimizationSuggestions": [],
      "skillGaps": {"missing": [], "needsImprovement": []},
      "strengthsAnalysis": [],
      "improvementAreas": []
    }

    Resume text: ${text}`;

    const response = await fetch('https://ai.gateway.fastrouter.io/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': gatewayApiKey
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.3,
      }),
    });

    const result = await response.json();
    const content = result.choices[0].message.content;
    const parsedData = JSON.parse(content);

    return new Response(JSON.stringify({
      success: true,
      data: parsedData,
      filename: filename
    }), {
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });

  } catch (error) {
    return new Response(JSON.stringify({
      success: false,
      error: error.message
    }), {
      status: 500,
      headers: { "Content-Type": "application/json", ...corsHeaders }
    });
  }
});
```

### Step 3: Deploy

Click **Deploy** button in the Supabase dashboard.

## What Changed?

✅ **Before**: Used `OPENAI_API_KEY` and direct OpenAI API
✅ **After**: Uses `GATEWAY_API_KEY` and API Gateway with Gemini

## Benefits

- ✅ Uses your existing GATEWAY_API_KEY (no new API keys needed)
- ✅ Faster and cheaper with Gemini Flash
- ✅ More reliable with API Gateway
- ✅ Better rate limiting and error handling

## Test It

After deploying, test by uploading a resume in the Resume Management page!
