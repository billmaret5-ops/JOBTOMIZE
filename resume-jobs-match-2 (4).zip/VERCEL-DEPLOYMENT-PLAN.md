# 🚀 VERCEL DEPLOYMENT PLAN - COMPLETE FUNCTIONALITY

## ✅ YOU'RE RIGHT ABOUT ENV VARS!

### Environment Variable Strategy:

**Frontend (Vercel) - Uses VITE_ prefix:**
```bash
VITE_SUPABASE_URL=https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGci...
VITE_RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

**Supabase Edge Functions - Uses Secrets (NO VITE_ prefix):**
```bash
RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

**Why Different?**
- Frontend: Vite requires `VITE_` prefix to expose vars to browser
- Edge Functions: Run on Supabase servers, use Supabase secrets (no VITE_)

---

## 📊 CURRENT FUNCTIONALITY STATUS

### ✅ WORKING FEATURES:
1. **Auth System** - ProductionAuthContext with Supabase
2. **Landing Page** - JobSearchLandingPage for non-authenticated
3. **Authenticated Dashboard** - AuthenticatedLayout for logged-in users
4. **Diagnostics Mode** - `/?diagnostics` for testing
5. **PWA Features** - Offline indicator, install prompt, update notifications
6. **Error Monitoring** - ApiErrorBanner catches auth/API errors

### ⚠️ NEEDS VERIFICATION:
1. **Job Search** - Depends on RAPIDAPI_KEY in Supabase secrets
2. **Edge Function** - fetch-jobs must be deployed with secret
3. **Real-time Features** - WebSocket connections to Supabase

---

## 🔧 PRE-DEPLOYMENT CHECKLIST

### 1. Verify Supabase Edge Function Secret
```bash
# Check if RAPIDAPI_KEY is set
supabase secrets list

# If not set, add it:
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

### 2. Test Locally First
```bash
# Create .env file
cat > .env << EOF
VITE_SUPABASE_URL=https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
VITE_RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
EOF

# Test build
npm run build
npm run preview
```

### 3. Test Job Search
Visit: `http://localhost:4173/?diagnostics`
- Check "Edge Function Tester"
- Check "Fetch Jobs Diagnostics"
- Verify jobs load

---

## 🚀 VERCEL DEPLOYMENT STEPS

### Step 1: Install Vercel CLI
```bash
npm i -g vercel
```

### Step 2: Deploy
```bash
vercel --prod
```

### Step 3: Add Environment Variables in Vercel Dashboard
1. Go to: https://vercel.com/dashboard
2. Select your project
3. Settings → Environment Variables
4. Add these (Production):

```
VITE_SUPABASE_URL = https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY = eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InJnZHZldm1xcmpsa3Fma2l1Y2RoIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTgyODg1NDMsImV4cCI6MjA3Mzg2NDU0M30.u0xOI5v_7kGFOzl3KCv7Oe9gxHfCXSJZGXiOLlcfMbY
VITE_RAPIDAPI_KEY = 82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

### Step 4: Redeploy
```bash
vercel --prod
```

### Step 5: Test Production
Visit: `https://your-app.vercel.app/?diagnostics`

---

## 🔍 FUNCTIONALITY TEST PLAN

### Test 1: Landing Page (Not Logged In)
- [ ] Visit homepage
- [ ] See hero section with job search
- [ ] Search for "software engineer"
- [ ] Jobs should load from JSearch API
- [ ] Click "Apply" opens job link

### Test 2: Authentication
- [ ] Click "Sign Up"
- [ ] Create account
- [ ] Verify email (check inbox)
- [ ] Login works
- [ ] Dashboard loads

### Test 3: Authenticated Features
- [ ] Job search works when logged in
- [ ] Can save jobs
- [ ] Application tracking works
- [ ] Profile settings accessible

### Test 4: PWA Features
- [ ] Offline indicator shows when offline
- [ ] Install prompt appears (mobile/desktop)
- [ ] App works offline (cached pages)

### Test 5: Error Handling
- [ ] Invalid credentials show error
- [ ] API errors show banner
- [ ] Network errors handled gracefully

---

## 🐛 KNOWN ISSUES TO FIX

### Issue 1: Job Search May Fail
**Symptom:** No jobs load, console shows 401 error
**Fix:** Ensure RAPIDAPI_KEY is set in Supabase secrets
```bash
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7
```

### Issue 2: Mixed Content Warnings
**Symptom:** Console shows "Mixed Content" errors
**Fix:** Vercel auto-handles HTTPS, but check:
- All API calls use `https://`
- WebSocket uses `wss://`
- No `http://` in production

### Issue 3: Auth Redirect Issues
**Symptom:** After login, stuck on loading
**Fix:** Add Vercel domain to Supabase Auth URLs:
1. Supabase Dashboard → Authentication → URL Configuration
2. Add: `https://your-app.vercel.app`

---

## 📈 POST-DEPLOYMENT MONITORING

### Check These After Deploy:
1. **Vercel Logs** - Real-time function logs
2. **Supabase Logs** - Edge function execution
3. **Browser Console** - Frontend errors
4. **Network Tab** - API call success/failure

### Quick Health Check URLs:
```
https://your-app.vercel.app/
https://your-app.vercel.app/?diagnostics
https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health
```

---

## 🎯 PRIORITY FIXES (If Needed)

### Priority 1: Job Search Not Working
1. Verify RAPIDAPI_KEY in Supabase
2. Test edge function directly
3. Check Supabase logs

### Priority 2: Auth Issues
1. Add Vercel domain to Supabase
2. Check CORS settings
3. Verify anon key

### Priority 3: Performance
1. Enable Vercel Edge Network
2. Configure caching headers
3. Optimize images

---

## ✨ VERCEL ADVANTAGES

1. **Auto SSL** - HTTPS + auto-renewal
2. **Global CDN** - Fast worldwide
3. **Zero Config** - Works out of box
4. **Preview Deploys** - Test before prod
5. **Analytics** - Built-in monitoring
6. **Free Tier** - 100GB bandwidth/month

---

## 🚨 EMERGENCY ROLLBACK

If deployment breaks:
```bash
# Rollback to previous version
vercel rollback
```

Or in Vercel Dashboard:
Deployments → Previous → Promote to Production

---

## 📞 NEXT STEPS

1. ✅ Verify RAPIDAPI_KEY in Supabase
2. ✅ Test locally with `npm run build && npm run preview`
3. ✅ Deploy to Vercel
4. ✅ Add env vars in Vercel dashboard
5. ✅ Test with `/?diagnostics`
6. ✅ Fix any issues
7. ✅ Add custom domain (optional)

**Ready to deploy?** Start with Step 1 above! 🚀
