# WebSocket Rate Limit Analytics System

## Overview

The Rate Limit Analytics System provides comprehensive insights into WebSocket rate limiting patterns, user behavior, and predictive alerts to optimize threshold configurations and prevent abuse.

## Features

### 1. **Historical Violation Trends**
- Track violation patterns over time (30-day history)
- Visualize trends by violation type (connection_limit, message_rate, burst_limit)
- Identify peak violation periods
- Line charts showing daily violation counts

### 2. **User Behavior Patterns**
- Average messages per minute per user
- Peak usage hours and days
- Violation rate calculations
- Risk scoring (0-100)
- Last activity tracking

### 3. **Peak Usage Times Heatmap**
- 24-hour x 7-day heatmap visualization
- Identify high-traffic periods
- Optimize resource allocation
- Plan maintenance windows

### 4. **Top Violators List**
- Ranked list of users by violation count
- Violation type breakdown
- Current status (active/banned)
- Last violation timestamp

### 5. **Predictive Alerts**
- Real-time monitoring of users approaching limits
- Severity classification (low/medium/high)
- Estimated time to limit breach
- Percentage usage tracking
- Proactive intervention opportunities

### 6. **Threshold Recommendations**
- AI-powered threshold optimization
- Confidence scoring for recommendations
- Impact analysis
- Reason explanations
- Current vs. recommended values

## Architecture

### Database Tables

#### `rate_limit_analytics`
Aggregated violation data by date, hour, user, and type:
```sql
- id: UUID
- date: DATE
- hour: INTEGER (0-23)
- user_id: UUID
- violation_type: TEXT
- violation_count: INTEGER
- total_messages: INTEGER
- avg_messages_per_minute: DECIMAL
- peak_usage_time: TIMESTAMP
```

#### `user_behavior_patterns`
User-specific behavior metrics:
```sql
- id: UUID
- user_id: UUID (unique)
- avg_messages_per_minute: DECIMAL
- peak_hour: INTEGER (0-23)
- peak_day: INTEGER (0-6)
- violation_rate: DECIMAL
- total_messages: INTEGER
- total_violations: INTEGER
- last_active: TIMESTAMP
- risk_score: DECIMAL (0-100)
```

#### `rate_limit_threshold_recommendations`
System-generated optimization recommendations:
```sql
- id: UUID
- metric: TEXT
- current_value: INTEGER
- recommended_value: INTEGER
- reason: TEXT
- impact: TEXT
- confidence: DECIMAL (0-1)
- status: TEXT (pending/applied/rejected)
- applied_at: TIMESTAMP
```

#### `rate_limit_predictive_alerts`
Proactive alerts for users approaching limits:
```sql
- id: UUID
- user_id: UUID
- current_usage: DECIMAL
- limit_value: INTEGER
- percentage_used: DECIMAL
- estimated_time_to_limit: INTEGER (minutes)
- severity: TEXT (low/medium/high)
- alert_sent: BOOLEAN
- resolved: BOOLEAN
```

## Usage

### Accessing the Dashboard

1. Navigate to the Secure WebSocket Dashboard
2. Click on the "Analytics" tab
3. View comprehensive analytics across 5 sub-tabs:
   - **Violation Trends**: Historical charts
   - **Peak Usage**: Heatmap visualization
   - **Top Violators**: Ranked list
   - **Predictive Alerts**: Proactive warnings
   - **Recommendations**: Threshold optimization

### Understanding Metrics

#### Violation Rate
```
Violation Rate = (Total Violations / Total Messages) × 100
```

#### Risk Score
```
Risk Score = min(Violation Rate, 100)
```
- 0-30: Low risk (green)
- 31-70: Medium risk (yellow)
- 71-100: High risk (red)

#### Predictive Alert Severity
- **Low**: 50-70% of limit used
- **Medium**: 70-90% of limit used
- **High**: 90%+ of limit used

### API Integration

#### Fetch Violation Trends
```typescript
import { rateLimitAnalyticsService } from '@/services/rateLimitAnalyticsService';

const trends = await rateLimitAnalyticsService.getViolationTrends(30);
```

#### Get User Behavior Patterns
```typescript
const patterns = await rateLimitAnalyticsService.getUserBehaviorPatterns();
```

#### Retrieve Predictive Alerts
```typescript
const alerts = await rateLimitAnalyticsService.getPredictiveAlerts();
```

#### Get Threshold Recommendations
```typescript
const recommendations = await rateLimitAnalyticsService.getThresholdRecommendations();
```

### Using the Hook

```typescript
import { useRateLimitAnalytics } from '@/hooks/useRateLimitAnalytics';

function MyComponent() {
  const {
    violationTrends,
    behaviorPatterns,
    peakUsageData,
    topViolators,
    recommendations,
    predictiveAlerts,
    loading,
    error,
    refresh
  } = useRateLimitAnalytics(30000); // Refresh every 30 seconds

  // Use the data...
}
```

## Optimization Recommendations

### When to Adjust Thresholds

1. **High Average Usage (>80%)**
   - Increase message rate limit by 50%
   - Expected impact: 40% reduction in violations

2. **Frequent Burst Violations**
   - Double burst capacity
   - Better handling of traffic spikes

3. **Consistent Peak Hour Violations**
   - Implement time-based rate limits
   - Higher limits during peak hours

4. **Low Violation Rate (<5%)**
   - Consider reducing limits to optimize resources
   - Maintain quality of service

## Monitoring Best Practices

### 1. Regular Review
- Check analytics dashboard daily
- Review weekly trends
- Monthly threshold optimization

### 2. Alert Response
- Investigate high-severity alerts immediately
- Contact users approaching limits proactively
- Document recurring patterns

### 3. Threshold Tuning
- Apply recommendations with >85% confidence
- A/B test threshold changes
- Monitor impact for 7 days before finalizing

### 4. User Communication
- Notify users before applying bans
- Provide usage statistics
- Offer upgrade paths for legitimate high-volume users

## Performance Considerations

### Data Aggregation
- Analytics data aggregates hourly
- Run `aggregate_rate_limit_analytics()` function via cron
- Recommended: Every hour

```sql
SELECT aggregate_rate_limit_analytics();
```

### Behavior Pattern Updates
- Update patterns daily
- Run `update_user_behavior_patterns()` function

```sql
SELECT update_user_behavior_patterns();
```

### Data Retention
- Keep detailed logs for 90 days
- Archive analytics data after 1 year
- Maintain aggregated summaries indefinitely

## Troubleshooting

### No Data Showing
1. Verify websocket_rate_limit_violations table has data
2. Check RLS policies allow access
3. Run aggregation functions manually
4. Verify user has admin role

### Inaccurate Predictions
1. Ensure sufficient historical data (7+ days)
2. Check for data gaps in analytics table
3. Verify user activity is being tracked
4. Review calculation logic in service

### Slow Dashboard Loading
1. Add indexes to analytics tables
2. Reduce date range for queries
3. Implement data pagination
4. Use caching for frequently accessed data

## Security

### Row-Level Security (RLS)
- Admins can view all analytics
- Users can only view their own data
- Recommendations require admin role
- Audit all threshold changes

### Data Privacy
- Anonymize user IDs in exports
- Aggregate data before sharing
- Comply with data retention policies
- GDPR-compliant data handling

## Integration with Existing Systems

### Alert System Integration
```typescript
// Send alerts when predictive warnings trigger
const alerts = await rateLimitAnalyticsService.getPredictiveAlerts();
alerts.filter(a => a.severity === 'high').forEach(alert => {
  notificationService.send({
    userId: alert.userId,
    message: `You're using ${alert.percentageUsed}% of your rate limit`,
    type: 'warning'
  });
});
```

### Automated Threshold Adjustment
```typescript
// Apply high-confidence recommendations automatically
const recommendations = await rateLimitAnalyticsService.getThresholdRecommendations();
recommendations
  .filter(r => r.confidence > 0.9 && r.status === 'pending')
  .forEach(async rec => {
    await applyThresholdChange(rec);
  });
```

## Future Enhancements

- [ ] Machine learning-based anomaly detection
- [ ] Automated threshold optimization
- [ ] Multi-dimensional behavior clustering
- [ ] Real-time streaming analytics
- [ ] Custom alert rule builder
- [ ] Export to external analytics platforms
- [ ] Mobile app for monitoring
- [ ] Slack/Teams integration for alerts

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review the WebSocket Rate Limiting documentation
3. Contact the development team
4. Submit a GitHub issue

## License

Part of the comprehensive WebSocket security and monitoring system.
