# 🔑 GET YOUR SUPABASE KEYS FOR VERCEL

## 📍 Step 1: Go to Supabase Dashboard

Open: https://supabase.com/dashboard

---

## 📂 Step 2: Select Your Project

Click on your project (the one you've been using)

---

## ⚙️ Step 3: Go to Settings

1. Click the **Settings** icon (gear) in the left sidebar
2. Click **API** in the settings menu

---

## 📋 Step 4: Copy These Values

You'll see two sections:

### **Project URL**
```
https://xxxxxxxxxx.supabase.co
```
Copy this entire URL → This is your `VITE_SUPABASE_URL`

### **Project API keys**
Look for the **anon public** key (NOT the service_role key!)
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZi...
```
Copy this long string → This is your `VITE_SUPABASE_ANON_KEY`

---

## ✅ Step 5: Add to Vercel

1. Go to https://vercel.com/dashboard
2. Click your project
3. Go to **Settings** → **Environment Variables**
4. Click **Add New**

**Add Variable 1:**
- Name: `VITE_SUPABASE_URL`
- Value: (paste your Project URL)
- Environment: Production, Preview, Development (check all 3)
- Click **Save**

**Add Variable 2:**
- Name: `VITE_SUPABASE_ANON_KEY`
- Value: (paste your anon public key)
- Environment: Production, Preview, Development (check all 3)
- Click **Save**

---

## 🔄 Step 6: Redeploy

In your terminal:
```bash
vercel --prod
```

**DONE! Your app can now connect to Supabase!**

---

## ⚠️ IMPORTANT

- **NEVER** use the `service_role` key in frontend code
- **ONLY** use the `anon public` key
- The anon key is safe to expose in your frontend

---

## 🐛 Troubleshooting

**Can't find API settings?**
- Make sure you're logged into Supabase
- Make sure you selected the correct project
- Settings icon is in the left sidebar (looks like a gear)

**Keys not working?**
- Make sure you copied the FULL key (they're very long)
- Make sure no extra spaces before/after
- Make sure you're using anon key, not service_role key

---

## ✅ How to Verify It Works

After redeploying:
1. Visit your Vercel URL
2. Open browser console (F12)
3. Try to sign up or log in
4. If you see errors, send me the console output

**Let's get this working! 🚀**
