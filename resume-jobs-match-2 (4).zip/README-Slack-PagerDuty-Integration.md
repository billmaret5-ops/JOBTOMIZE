# Slack and PagerDuty Integration Guide

Complete guide for setting up real-time alerting with Slack and PagerDuty for ML deployment monitoring.

## Overview

The integration system provides:
- **Slack Integration**: Real-time alerts to Slack channels with formatted messages
- **PagerDuty Integration**: Incident creation and on-call schedule synchronization
- **Test Notifications**: Verify configuration before going live
- **Channel Mapping**: Route alerts by severity to different channels
- **On-Call Sync**: Automatic synchronization of PagerDuty schedules

## Slack Integration Setup

### 1. Create Slack Webhook

1. Go to your Slack workspace settings
2. Navigate to **Apps & Integrations**
3. Search for "Incoming Webhooks" and add to your workspace
4. Click **Add New Webhook to Workspace**
5. Select the default channel for alerts
6. Copy the webhook URL (format: `https://hooks.slack.com/services/...`)

### 2. Configure in Application

```typescript
// Navigate to Integrations tab
// Click on Slack tab
// Enter webhook URL
// Configure channel mappings:
{
  "default": "#alerts",
  "critical": "#critical-alerts",
  "high": "#high-priority",
  "medium": "#monitoring",
  "low": "#info"
}
```

### 3. Test Connection

Click **Send Test Message** to verify the integration. Check your Slack channel for the test notification.

## PagerDuty Integration Setup

### 1. Generate API Key

1. Log in to PagerDuty
2. Go to **Configuration** → **API Access**
3. Click **Create New API Key**
4. Give it a description (e.g., "ML Deployment Monitor")
5. Copy the API key (starts with `u+` or similar)

### 2. Get Integration Key

1. Go to **Services** in PagerDuty
2. Select your service (or create a new one)
3. Go to **Integrations** tab
4. Add a new integration or copy existing integration key
5. Note the Service ID from the URL

### 3. Configure in Application

```typescript
// Navigate to Integrations tab
// Click on PagerDuty tab
// Enter:
// - API Key
// - Integration/Routing Key
// - Service ID
```

### 4. Sync On-Call Schedules

Click **Sync Schedules** to pull current on-call information from PagerDuty.

## Edge Functions (Manual Deployment)

Due to deployment constraints, the edge functions need to be deployed manually to Supabase.

### Slack Integration Function

Create `supabase/functions/slack-integration/index.ts`:

\`\`\`typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, webhookUrl, channel, message, severity, incident } = await req.json();

    if (action === 'send') {
      const color = severity === 'critical' ? '#ff0000' : 
                    severity === 'high' ? '#ff6600' : 
                    severity === 'medium' ? '#ffcc00' : '#00cc00';

      const slackPayload = {
        channel: channel || '#alerts',
        username: 'ML Deployment Monitor',
        icon_emoji: ':robot_face:',
        text: message,
        attachments: [{
          color: color,
          title: incident?.title || 'ML Anomaly Detected',
          fields: [
            { title: 'Severity', value: severity?.toUpperCase(), short: true },
            { title: 'Model', value: incident?.model_name || 'N/A', short: true },
            { title: 'Anomaly Type', value: incident?.anomaly_type || 'N/A', short: true },
            { title: 'Status', value: incident?.status || 'open', short: true },
            { title: 'Description', value: incident?.description || message, short: false }
          ],
          footer: 'ML Deployment System',
          ts: Math.floor(Date.now() / 1000)
        }]
      };

      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(slackPayload)
      });

      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    if (action === 'test') {
      const testPayload = {
        channel: channel || '#alerts',
        text: '🧪 Test notification from ML Deployment System',
        attachments: [{
          color: '#36a64f',
          title: 'Integration Test Successful',
          text: 'Your Slack integration is configured correctly!'
        }]
      };

      await fetch(webhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(testPayload)
      });

      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
\`\`\`

Deploy:
\`\`\`bash
supabase functions deploy slack-integration
\`\`\`

### PagerDuty Integration Function

Create `supabase/functions/pagerduty-integration/index.ts`:

\`\`\`typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, apiKey, incident, routingKey } = await req.json();

    if (action === 'test') {
      const response = await fetch('https://api.pagerduty.com/users', {
        headers: {
          'Authorization': \`Token token=\${apiKey}\`,
          'Accept': 'application/vnd.pagerduty+json;version=2'
        }
      });

      if (!response.ok) throw new Error('Invalid API key');

      return new Response(JSON.stringify({ success: true }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    if (action === 'create_incident') {
      const payload = {
        incident: {
          type: 'incident',
          title: incident.title,
          service: { id: incident.service_id, type: 'service_reference' },
          urgency: incident.severity === 'critical' ? 'high' : 'low',
          body: { type: 'incident_body', details: incident.description }
        }
      };

      const response = await fetch('https://api.pagerduty.com/incidents', {
        method: 'POST',
        headers: {
          'Authorization': \`Token token=\${apiKey}\`,
          'Content-Type': 'application/json',
          'Accept': 'application/vnd.pagerduty+json;version=2',
          'From': incident.from_email
        },
        body: JSON.stringify(payload)
      });

      const data = await response.json();
      return new Response(JSON.stringify({ incident_id: data.incident.id }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }

    if (action === 'sync_schedules') {
      const response = await fetch('https://api.pagerduty.com/oncalls', {
        headers: {
          'Authorization': \`Token token=\${apiKey}\`,
          'Accept': 'application/vnd.pagerduty+json;version=2'
        }
      });

      const data = await response.json();
      const schedules = data.oncalls.map(oncall => ({
        schedule_id: oncall.schedule.id,
        schedule_name: oncall.schedule.summary,
        on_call_users: [{
          id: oncall.user.id,
          name: oncall.user.summary,
          email: oncall.user.email,
          start_time: oncall.start,
          end_time: oncall.end
        }]
      }));

      return new Response(JSON.stringify({ schedules }), {
        headers: { 'Content-Type': 'application/json', ...corsHeaders }
      });
    }
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
\`\`\`

Deploy:
\`\`\`bash
supabase functions deploy pagerduty-integration
\`\`\`

## Usage Examples

### Sending Slack Alerts

```typescript
import { integrationService } from '@/services/integrationService';

await integrationService.sendSlackAlert(
  configId,
  'High error rate detected in production deployment',
  'high',
  {
    title: 'Error Rate Spike',
    model_name: 'recommendation-model-v2',
    anomaly_type: 'error_rate',
    status: 'investigating',
    description: 'Error rate increased to 5.2% (threshold: 2%)'
  }
);
```

### Creating PagerDuty Incidents

```typescript
const incidentId = await integrationService.createPagerDutyIncident(
  configId,
  {
    title: 'Critical: Model Latency Exceeded',
    service_id: 'PXXXXXX',
    severity: 'critical',
    description: 'P95 latency: 2.5s (threshold: 500ms)',
    from_email: 'alerts@company.com'
  }
);
```

## Channel Mapping Strategy

### Recommended Setup

```json
{
  "default": "#ml-alerts",
  "critical": "#critical-incidents",
  "high": "#high-priority-alerts",
  "medium": "#monitoring",
  "low": "#info-feed"
}
```

### Severity Levels

- **Critical**: Immediate action required, page on-call engineer
- **High**: Requires attention within 1 hour
- **Medium**: Monitor and investigate during business hours
- **Low**: Informational, no action required

## Troubleshooting

### Slack Test Fails

1. Verify webhook URL is correct and active
2. Check webhook hasn't been revoked in Slack settings
3. Ensure channel exists and bot has access
4. Try regenerating the webhook

### PagerDuty Test Fails

1. Verify API key is valid and not expired
2. Check API key has correct permissions
3. Ensure service ID is correct
4. Verify account is active

### No Alerts Received

1. Check integration is marked as active
2. Verify alert rules are configured correctly
3. Check integration logs for errors
4. Test with manual alert trigger

## Best Practices

1. **Test Regularly**: Send test notifications weekly to verify connectivity
2. **Rotate Keys**: Update API keys quarterly for security
3. **Monitor Integration Health**: Check logs for failed deliveries
4. **Document Escalation**: Keep on-call schedules up to date
5. **Alert Fatigue**: Use appropriate severity levels to avoid noise

## Integration Logs

View integration logs in the database:

```sql
SELECT * FROM integration_logs 
WHERE integration_config_id = 'your-config-id'
ORDER BY created_at DESC 
LIMIT 50;
```

## Support

For issues with:
- **Slack**: Check Slack API documentation
- **PagerDuty**: Visit PagerDuty developer portal
- **Integration**: Review application logs and test connectivity
