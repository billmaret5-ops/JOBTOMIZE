#!/bin/bash

# RapidAPI Integration Deployment Script
# This script will set secrets and deploy the fetch-jobs function

echo "🚀 Deploying RapidAPI Integration for fetch-jobs"
echo "================================================"
echo ""

# Step 1: Set secrets
echo "📝 Step 1: Setting RapidAPI secrets..."
supabase secrets set \
  RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7 \
  RAPIDAPI_HOST=jsearch.p.rapidapi.com

if [ $? -eq 0 ]; then
  echo "✅ Secrets set successfully"
else
  echo "❌ Failed to set secrets"
  exit 1
fi

echo ""

# Step 2: Deploy function
echo "📦 Step 2: Deploying fetch-jobs function..."
supabase functions deploy fetch-jobs

if [ $? -eq 0 ]; then
  echo "✅ Function deployed successfully"
else
  echo "❌ Failed to deploy function"
  exit 1
fi

echo ""

# Step 3: Get function URL
echo "🔗 Step 3: Getting function URL..."
SUPABASE_URL=$(supabase status | grep "API URL" | awk '{print $3}')
FUNCTION_URL="${SUPABASE_URL}/functions/v1/fetch-jobs"

echo "Function URL: $FUNCTION_URL"
echo ""

# Step 4: Test health endpoint
echo "🏥 Step 4: Testing health endpoint..."
echo "Run this command to test:"
echo ""
echo "curl -sS \"${FUNCTION_URL}/health\" \\"
echo "  -H \"Authorization: Bearer YOUR_ANON_KEY\" \\"
echo "  -H \"apikey: YOUR_ANON_KEY\""
echo ""

# Step 5: Test diagnostics
echo "🔍 Step 5: Testing diagnostics..."
echo "Run this command to test:"
echo ""
echo "curl -sS \"${FUNCTION_URL}/diagnostics?query=software+engineer\" \\"
echo "  -H \"Authorization: Bearer YOUR_ANON_KEY\" \\"
echo "  -H \"apikey: YOUR_ANON_KEY\""
echo ""

echo "✅ Deployment complete!"
echo ""
echo "📚 Next steps:"
echo "1. Replace YOUR_ANON_KEY with your actual Supabase anon key"
echo "2. Run the health check command above"
echo "3. Run the diagnostics command above"
echo "4. Test the main endpoint with a POST request"
echo ""
echo "For more details, see DEPLOY-RAPIDAPI-NOW.md"
