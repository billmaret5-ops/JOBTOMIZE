# Update fetch-jobs Function to Use RapidAPI

## Instructions

1. Go to your Supabase Dashboard
2. Navigate to **Edge Functions** → **fetch-jobs**
3. Replace the entire code with the code below
4. Click **Deploy**

## Updated Code (Copy Everything Below)

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20,
      job_type,
      salary_min,
      salary_max,
      remote
    } = await req.json();

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    // Build JSearch API URL
    const params = new URLSearchParams({
      query: `${query} ${location}`.trim(),
      page: page.toString(),
      num_pages: '1',
      date_posted: 'all'
    });

    if (remote) {
      params.append('remote_jobs_only', 'true');
    }

    if (job_type) {
      params.append('employment_types', job_type.toUpperCase());
    }

    const apiUrl = `https://jsearch.p.rapidapi.com/search?${params.toString()}`;

    // Call JSearch API
    const response = await fetch(apiUrl, {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      throw new Error(`RapidAPI failed: ${response.status}`);
    }

    const data = await response.json();

    // Transform to our format
    const jobs: JobListing[] = (data.data || []).map((job: any) => ({
      id: job.job_id || `job_${Date.now()}_${Math.random()}`,
      title: job.job_title || 'Unknown Title',
      company: job.employer_name || 'Unknown Company',
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || 'No description',
      salary: job.job_min_salary && job.job_max_salary 
        ? `$${job.job_min_salary.toLocaleString()} - $${job.job_max_salary.toLocaleString()}`
        : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'JSearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false,
      experience_level: job.job_required_experience?.required_experience_in_months 
        ? (job.job_required_experience.required_experience_in_months < 24 ? 'Entry' : 
           job.job_required_experience.required_experience_in_months < 60 ? 'Mid' : 'Senior')
        : undefined
    }));

    // Apply salary filters
    let filteredJobs = jobs.filter(job => {
      if (salary_min || salary_max) {
        const salaryMatch = job.salary?.match(/\$(\d+(?:,\d{3})*)\s*-\s*\$(\d+(?:,\d{3})*)/);
        if (salaryMatch) {
          const minSalary = parseInt(salaryMatch[1].replace(/,/g, ''));
          const maxSalary = parseInt(salaryMatch[2].replace(/,/g, ''));
          if (salary_min && maxSalary < salary_min) return false;
          if (salary_max && minSalary > salary_max) return false;
        } else if (salary_min || salary_max) {
          return false;
        }
      }
      return true;
    });

    return new Response(JSON.stringify({
      jobs: filteredJobs,
      total: filteredJobs.length,
      page,
      totalPages: Math.ceil(filteredJobs.length / limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## What Changed

✅ Removed all mock data generation  
✅ Added RapidAPI JSearch integration  
✅ Uses your existing RAPIDAPI_KEY secret  
✅ Transforms JSearch data to match your app format  
✅ Maintains all existing filters (salary, remote, job type)  

## After Deployment

The app will now fetch **real job listings** from JSearch API instead of fake data!
