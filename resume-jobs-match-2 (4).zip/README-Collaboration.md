# Real-Time Collaboration Features

## Overview
Comprehensive real-time collaborative editing system with live cursors, comments, conflict resolution, and activity tracking for resume editing and job application tracking.

## Features

### 1. Real-Time Editing
- **Operational Transformation (OT)**: Handles concurrent edits without conflicts
- **CRDT Engine**: Conflict-free replicated data types for distributed editing
- **Live Synchronization**: Instant updates across all connected users
- **Auto-save**: Automatic saving of changes to prevent data loss

### 2. Live Cursors
- **Position Tracking**: See where other users are typing in real-time
- **User Identification**: Color-coded cursors with user names
- **Selection Highlighting**: View text selections of collaborators
- **Smooth Animations**: Fluid cursor movements for better UX

### 3. User Presence
- **Online Indicators**: See who's currently editing the document
- **User Avatars**: Visual representation of active collaborators
- **Join/Leave Notifications**: Real-time updates when users connect/disconnect
- **Active User Count**: Display total number of online users

### 4. Comments & Suggestions
- **Inline Comments**: Add comments at specific positions in the document
- **Comment Threads**: Reply to comments for discussions
- **Resolve Comments**: Mark comments as resolved when addressed
- **Real-time Updates**: See new comments instantly

### 5. Activity Feed
- **Change Tracking**: Log all edits, comments, and user actions
- **User Attribution**: See who made each change
- **Timestamp**: Track when changes occurred
- **Activity Types**: Edit, comment, join, leave events

### 6. Conflict Resolution
- **Automatic Detection**: Identify conflicting changes
- **Resolution Strategies**: Choose local, remote, or merge
- **Manual Resolution**: UI for resolving complex conflicts
- **Conflict History**: Track resolved conflicts

## Architecture

### WebSocket Service
```typescript
import { wsService } from './services/webSocketService';

// Connect to WebSocket server
wsService.connect('ws://localhost:3000', token);

// Listen for events
wsService.on('operation', handleOperation);
wsService.on('cursor', handleCursor);

// Send events
wsService.send('operation', operation);
```

### Operational Transformation
```typescript
import { OperationalTransform } from './lib/operationalTransform';

// Transform operations
const transformed = OperationalTransform.transform(op1, op2);

// Apply operation to text
const newText = OperationalTransform.apply(text, operation);
```

### CRDT Engine
```typescript
import { CRDTEngine } from './lib/crdtEngine';

const crdt = new CRDTEngine(userId);

// Insert character
crdt.insert(position, 'a');

// Delete character
crdt.delete(position);

// Get current text
const text = crdt.getText();
```

## Usage

### Collaborative Resume Editor
```tsx
import { CollaborativeResumeEditor } from './components/CollaborativeResumeEditor';

<CollaborativeResumeEditor
  resumeId="resume-123"
  userId="user-456"
  initialContent="My resume content..."
/>
```

### Collaborative Application Tracker
```tsx
import { CollaborativeApplicationTracker } from './components/CollaborativeApplicationTracker';

<CollaborativeApplicationTracker
  userId="user-456"
  applications={applications}
/>
```

### React Hook
```tsx
import { useRealTimeCollaboration } from './hooks/useRealTimeCollaboration';

const {
  users,
  cursors,
  comments,
  activities,
  isConnected,
  sendOperation,
  updateCursor,
  addComment
} = useRealTimeCollaboration(documentId, userId);
```

## Database Schema

### Tables
- `collaboration_sessions`: Document editing sessions
- `collaboration_participants`: Active users in sessions
- `collaboration_operations`: Edit operations log
- `collaboration_comments`: Comments and suggestions
- `collaboration_activities`: Activity feed events

## WebSocket Events

### Client → Server
- `join-document`: Join editing session
- `operation`: Send edit operation
- `cursor`: Update cursor position
- `comment`: Add new comment

### Server → Client
- `operation`: Receive remote operation
- `cursor`: Receive cursor update
- `user-join`: User joined session
- `user-leave`: User left session
- `comment`: Receive new comment

## Conflict Resolution

### Strategies
1. **Keep Local**: Use your changes
2. **Keep Remote**: Use their changes
3. **Merge Both**: Combine both changes
4. **Manual**: Choose specific parts

### Example
```tsx
import { ConflictResolutionModal } from './components/ConflictResolutionModal';

<ConflictResolutionModal
  conflict={conflict}
  isOpen={showModal}
  onClose={() => setShowModal(false)}
  onResolve={(strategy) => resolveConflict(strategy)}
/>
```

## Best Practices

1. **Connection Management**: Handle reconnection gracefully
2. **Conflict Prevention**: Use OT/CRDT for automatic resolution
3. **Performance**: Debounce cursor updates (100ms)
4. **User Experience**: Show connection status clearly
5. **Data Persistence**: Save to database regularly
6. **Error Handling**: Gracefully handle WebSocket errors

## Security

- **Authentication**: Token-based WebSocket authentication
- **Authorization**: RLS policies on collaboration tables
- **Rate Limiting**: Prevent operation flooding
- **Validation**: Validate all incoming operations

## Performance Optimization

1. **Debouncing**: Cursor updates every 100ms
2. **Batching**: Combine multiple operations
3. **Compression**: Compress large operations
4. **Cleanup**: Remove old activity logs (keep last 50)

## Testing

```typescript
// Mock WebSocket for testing
const mockWs = {
  send: jest.fn(),
  on: jest.fn(),
  connect: jest.fn()
};
```

## Troubleshooting

### Connection Issues
- Check WebSocket URL configuration
- Verify authentication token
- Check network connectivity

### Sync Problems
- Clear local cache
- Refresh the page
- Check server logs

### Performance Issues
- Reduce cursor update frequency
- Limit activity feed size
- Optimize operation batching

## WebSocket Server Setup

### Installation

```bash
cd server
npm install
```

### Configuration

Create `server/.env` file:
```env
PORT=8080
JWT_SECRET=your-jwt-secret
SUPABASE_URL=your-supabase-url
SUPABASE_ANON_KEY=your-supabase-key
REDIS_HOST=localhost
REDIS_PORT=6379
```

### Running the Server

Development:
```bash
npm run dev
```

Production:
```bash
npm start
```

### Docker Deployment

```bash
# Start all services (Redis + 2 WebSocket servers + Nginx)
docker-compose up -d

# View logs
docker-compose logs -f

# Stop services
docker-compose down
```

### Server Features

- **Room-Based Sessions**: Isolated collaboration spaces
- **Redis Pub/Sub**: Multi-server scaling support
- **Rate Limiting**: Protection against abuse
- **Authentication**: JWT-based WebSocket auth
- **Health Monitoring**: `/health` endpoint
- **Load Balancing**: Nginx for distributing connections

### WebSocket Protocol

Connect to server:
```javascript
const ws = new WebSocket('ws://localhost:8080/collaborate?token=YOUR_JWT');

// Join a room
ws.send(JSON.stringify({
  type: 'join_room',
  roomId: 'resume-123',
  userData: {
    name: 'John Doe',
    avatar: 'https://...',
    color: '#3B82F6'
  }
}));

// Send operation
ws.send(JSON.stringify({
  type: 'operation',
  operation: {
    type: 'insert',
    position: 10,
    content: 'Hello',
    version: 5
  }
}));
```

### Rate Limits

- **Connections**: 10 per minute per user
- **Messages**: 100 per minute per user  
- **Operations**: 200 per minute per user

### Monitoring

```bash
# Health check
curl http://localhost:8080/health

# Active rooms
curl http://localhost:8080/api/rooms

# Room statistics
curl http://localhost:8080/api/rooms/resume-123/stats
```

## Client Integration

### Update WebSocket URL

In `src/services/webSocketService.ts`, update the WebSocket URL:

```typescript
const WS_URL = process.env.VITE_WS_URL || 'ws://localhost:8080/collaborate';
```

Add to `.env`:
```env
VITE_WS_URL=ws://localhost:8080/collaborate
```

### Production Deployment

For production, use secure WebSocket:
```env
VITE_WS_URL=wss://your-domain.com/collaborate
```
