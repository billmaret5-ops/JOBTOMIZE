# How to Restart Your Dev Server

## I Cannot Control Running Processes
Unfortunately, I (Famous AI) cannot directly stop or restart npm processes. I can only read/write files.

## What You Need to Do:

### Option 1: If You Have Terminal Access
1. Find the terminal window running `npm run dev`
2. Press **Ctrl+C** to stop it
3. Run `npm run dev` again to restart

### Option 2: If Using a Cloud IDE (Replit, CodeSandbox, etc.)
1. Look for a "Stop" or "Restart" button in the IDE interface
2. Click it to restart the dev server

### Option 3: Close and Reopen Your Browser
1. Close all browser tabs with your app
2. Close the terminal/IDE completely
3. Reopen and run `npm run dev` again

## Fix Your API Key Error:
The "Invalid API key" error means your `.env` file needs correct Supabase credentials:

1. Go to: https://supabase.com/dashboard
2. Select your project
3. Go to Settings → API
4. Copy your Project URL and anon/public key
5. Create/update `.env` file in your project root with:
```
VITE_SUPABASE_URL=your-project-url-here
VITE_SUPABASE_ANON_KEY=your-anon-key-here
```
6. Save the file
7. Restart the dev server

The server MUST be restarted after changing .env files!
