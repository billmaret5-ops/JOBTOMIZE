# Live Job Search Integration Guide

## Overview
This application now integrates with the **JSearch API** via RapidAPI to fetch real job postings from multiple sources including Indeed, LinkedIn, Glassdoor, and more.

## Features Implemented

### 1. Real Job API Integration
- **JSearch API** integration via RapidAPI
- Fetches live job postings from major job boards
- Caching mechanism to reduce API calls
- Error handling and fallback support

### 2. Advanced Search Filters
- **Location-based search** with radius filtering
- **Salary range** filtering ($0 - $200k+)
- **Experience level** filtering (Entry, 1-3 years, 3+ years)
- **Employment type** (Full-time, Part-time, Contract, Intern)
- **Date posted** filters (Today, Last 3 days, Week, Month)
- **Remote jobs** toggle

### 3. Pagination
- Navigate through multiple pages of results
- Shows current page and total results
- Smooth page transitions
- Maintains filter state across pages

### 4. Real-Time Updates
- Optional real-time job sync
- Notifications for new matching jobs
- Auto-refresh capability
- Toast notifications for updates

## Setup Instructions

### Step 1: Get RapidAPI Key
1. Go to [JSearch API on RapidAPI](https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch)
2. Sign up for a free account
3. Subscribe to the JSearch API (free tier available)
4. Copy your API key

### Step 2: Configure Environment Variables
1. Copy `.env.example` to `.env`
2. Add your RapidAPI key:
```env
VITE_RAPIDAPI_KEY=your_rapidapi_key_here
```

### Step 3: Access the Live Job Search
Navigate to `/live-jobs` in your browser to access the new live job search platform.

## API Endpoints

### JSearch API
- **Base URL**: `https://jsearch.p.rapidapi.com`
- **Endpoint**: `/search`
- **Method**: GET
- **Rate Limits**: Depends on your RapidAPI subscription

### Supported Parameters
- `query` - Job title or keywords (required)
- `location` - City, state, or country
- `page` - Page number for pagination
- `date_posted` - Filter by posting date
- `remote_jobs_only` - Boolean for remote jobs
- `employment_types` - Comma-separated list
- `job_requirements` - Experience level requirements
- `radius` - Search radius in miles

## Components Created

### 1. `jSearchApiService.ts`
Service layer for JSearch API integration with caching and error handling.

### 2. `AdvancedJobFilters.tsx`
Comprehensive filter component with:
- Date posted selector
- Remote jobs toggle
- Employment type checkboxes
- Experience level dropdown
- Salary range slider
- Search radius slider

### 3. `JobPagination.tsx`
Pagination component with:
- Previous/Next navigation
- Page number buttons
- Total results display
- Responsive design

### 4. `RealTimeJobSync.tsx`
Real-time update component with:
- Enable/disable toggle
- New job notifications
- Last check timestamp
- Quick load new jobs button

### 5. `EnhancedJobSearchPlatform.tsx`
Main search platform integrating all features:
- Search bar with location
- Filter sidebar
- Job cards with apply links
- Pagination controls
- Real-time sync

## Usage Examples

### Basic Search
```typescript
const result = await jSearchApiService.searchJobs({
  query: 'software engineer',
  location: 'San Francisco, CA',
  page: 1
});
```

### Advanced Search with Filters
```typescript
const result = await jSearchApiService.searchJobs({
  query: 'frontend developer',
  location: 'New York, NY',
  page: 1,
  date_posted: 'week',
  remote_jobs_only: true,
  employment_types: 'FULLTIME,CONTRACTOR',
  job_requirements: 'under_3_years_experience',
  radius: 25
});
```

## Testing

1. **Without API Key**: The app will show an error message prompting you to add your API key
2. **With API Key**: Real job results will be fetched and displayed
3. **Filters**: Test each filter to ensure results update correctly
4. **Pagination**: Navigate through pages to verify data persistence

## Rate Limiting

The free tier of JSearch API includes:
- 100 requests per month
- Caching reduces duplicate requests
- Consider upgrading for production use

## Future Enhancements

- [ ] Job detail modal/page
- [ ] Save favorite jobs to database
- [ ] Email job alerts
- [ ] Application tracking
- [ ] Resume matching scores
- [ ] Company reviews integration
- [ ] Salary insights and trends

## Troubleshooting

### "API request failed" error
- Check your RapidAPI key is correct
- Verify you're subscribed to JSearch API
- Check your API quota hasn't been exceeded

### No results showing
- Try broader search terms
- Remove or adjust filters
- Check location spelling
- Verify API key is set in .env

### Slow loading
- Results are cached for 10 minutes
- First search may be slower
- Consider implementing loading states

## Support

For issues or questions:
1. Check the RapidAPI dashboard for API status
2. Review browser console for error messages
3. Verify environment variables are loaded correctly
