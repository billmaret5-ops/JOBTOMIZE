# 🚀 Deploy RapidAPI Integration NOW

## Step 1: Set the API Keys (REQUIRED)

```bash
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7 RAPIDAPI_HOST=jsearch.p.rapidapi.com
```

## Step 2: Deploy the Updated Function

The function code has been updated in the repository. Deploy it:

```bash
supabase functions deploy fetch-jobs
```

## Step 3: Verify Health Check

```bash
curl -sS "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

**Expected Response:**
```json
{
  "ok": true,
  "rapidapi_key_present": true,
  "rapidapi_host_present": true,
  "key_length": 50
}
```

## Step 4: Test Diagnostics

```bash
curl -sS "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/diagnostics?query=software+engineer" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY"
```

## Step 5: Test Real Job Search

```bash
curl -X POST "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs" \
  -H "Authorization: Bearer YOUR_ANON_KEY" \
  -H "apikey: YOUR_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query": "software engineer", "location": "San Francisco", "page": 1}'
```

## ✅ Success Indicators

- Health check shows `rapidapi_key_present: true`
- Diagnostics returns real job data from JSearch
- Main endpoint returns jobs with `source: "jsearch"`
- Rate limit header shows remaining requests

## 🔧 Troubleshooting

**If health check fails:**
- Verify secrets were set: `supabase secrets list`
- Redeploy: `supabase functions deploy fetch-jobs`

**If diagnostics fails:**
- Check the error message in the response
- Verify RapidAPI key is valid at https://rapidapi.com
- Check rate limits on your RapidAPI dashboard

**If jobs endpoint returns errors:**
- Check function logs: `supabase functions logs fetch-jobs`
- Verify the query parameters are correct
- Test with diagnostics first

## 📝 What Changed

✅ Added RAPIDAPI_KEY environment variable support
✅ Added /health endpoint to verify configuration
✅ Added /diagnostics endpoint to test API connectivity
✅ Integrated JSearch API for real job data
✅ Transformed JSearch response to JobListing format
✅ Added rate limit tracking
✅ Maintained backward compatibility with existing code

## 🎯 Next Steps

After deployment works:
1. Update frontend to use real job data
2. Add error handling for rate limits
3. Implement caching to reduce API calls
4. Add more JSearch endpoints (job details, salary estimates)
