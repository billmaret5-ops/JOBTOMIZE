# 🔐 Authentication Test Instructions

## ✅ Setup Complete!

Your `.env` file has been created with:
- ✓ Supabase URL configured
- ✓ Supabase ANON key configured  
- ✓ OpenAI API key configured

## 🧪 How to Test Authentication

### Step 1: Start the Development Server
```bash
npm run dev
```

### Step 2: Open the Auth Test Page
Navigate to: **http://localhost:5173/?auth-test**

### Step 3: Test the Authentication Flow

The test page will show:

1. **Connection Status** - Verifies Supabase is connected
2. **Test Credentials Form** - Pre-filled with test email/password
3. **Action Buttons**:
   - **Create Test Account** - Signs up a new user
   - **Sign In** - Logs in with the test credentials
   - **Sign Out** - Logs out the current user

### Step 4: What to Test

#### Test Sign Up:
1. Click "Create Test Account"
2. You should see: "Sign up successful! User: test@example.com"
3. Check Supabase Dashboard → Authentication → Users to verify

#### Test Sign In:
1. Click "Sign In"
2. You should see: "Sign in successful! User: test@example.com"
3. The page will show "Logged in as: test@example.com"

#### Test Sign Out:
1. Click "Sign Out"
2. You should see: "Signed out successfully"
3. The login buttons will reappear

## 🎯 Expected Results

✅ **Success Indicators:**
- Green checkmark next to "Supabase connection established"
- Successful sign up creates user in Supabase
- Successful sign in shows user email
- Sign out clears the session

❌ **Error Indicators:**
- Red X icon with error message
- Check console for detailed errors
- Verify .env file has correct credentials

## 🔧 Troubleshooting

If you see errors:

1. **"Invalid API key"**
   - Verify VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in .env
   - Restart dev server: `npm run dev`

2. **"Connection failed"**
   - Check Supabase project is active
   - Verify internet connection
   - Check Supabase dashboard for service status

3. **"User already exists"**
   - Change the test email in the form
   - Or use "Sign In" instead

## 📊 View in Supabase Dashboard

After creating test accounts:
1. Go to https://supabase.com/dashboard
2. Select your project
3. Navigate to **Authentication** → **Users**
4. You'll see your test users listed

## 🚀 Next Steps

Once authentication is working:
- Return to main app: Click "Exit to Main App" button
- Or navigate to: http://localhost:5173/
- The main app will now have working sign up/login!

## 📝 Notes

- Test credentials can be changed in the form
- Each sign up creates a new user in Supabase
- User profiles are automatically created via database triggers
- Email verification is optional for testing
