# 🔒 Secure RapidAPI Deployment Guide

## ✅ You're Right - Security First!

Thank you for catching that security issue. The RapidAPI key should NEVER be in plaintext in any script files.

## 🚀 Deployment Steps

### Step 1: Set Secrets Locally (YOU DO THIS)

```bash
# Option A: Direct command (secrets won't show in history if you prefix with space)
 supabase secrets set RAPIDAPI_KEY="your-key-here" RAPIDAPI_HOST="jsearch.p.rapidapi.com"

# Option B: Use env file (recommended)
echo "RAPIDAPI_KEY=your-key-here" > .env.rapidapi
echo "RAPIDAPI_HOST=jsearch.p.rapidapi.com" >> .env.rapidapi
supabase secrets set --env-file .env.rapidapi
rm .env.rapidapi  # Delete after setting
```

### Step 2: I Deploy Function Code (I DO THIS)

I will now deploy ONLY the Edge Function code with no secrets embedded.

### Step 3: Verify Deployment

```bash
# Test health endpoint
curl -sS "$SUPABASE_URL/functions/v1/fetch-jobs/health" \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY"

# Expected: {"ok":true,"rapidapi_key_present":true}
```

## 🎯 Confirm to Proceed

Reply with "DEPLOY FUNCTION CODE" and I'll deploy only the Edge Function.
