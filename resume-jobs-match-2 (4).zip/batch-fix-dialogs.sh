#!/bin/bash

# List of files to update with their descriptions
declare -A files_and_descriptions=(
  ["src/components/ApplicationForm.tsx"]="Fill in application details and track your job application progress"
  ["src/components/ApplicationFormModal.tsx"]="Add or edit job application information"
  ["src/components/ApplyJobModal.tsx"]="Submit your application for this position"
  ["src/components/CalendarEventModal.tsx"]="Create or edit calendar event details"
  ["src/components/EmailBuilderModal.tsx"]="Design and customize your email template"
  ["src/components/ContactProfile.tsx"]="View and manage contact information"
  ["src/components/EmailAnalyticsModal.tsx"]="View detailed analytics for this email template"
  ["src/components/ABTestResultsVisualization.tsx"]="View detailed A/B test performance metrics"
  ["src/components/BackupJobForm.tsx"]="Configure backup job settings and schedule"
  ["src/components/ComprehensiveTemplateLibrary.tsx"]="Browse and preview available email templates"
  ["src/components/DashboardTemplateSelector.tsx"]="Choose a template to create your dashboard"
  ["src/components/EmailAutomationRules.tsx"]="Configure automation rules for your email campaigns"
  ["src/components/EnhancedJobCard.tsx"]="View detailed job match analysis and insights"
  ["src/components/IncidentManager.tsx"]="View and manage incident details"
  ["src/components/JobEmailTemplateLibrary.tsx"]="Compose email using selected template"
  ["src/components/LeadCaptureModal.tsx"]="Enter your information to get started"
  ["src/components/ApplicationTrackerModal.tsx"]="Track and manage all your job applications"
)

echo "🔧 Batch updating dialog components with DialogDescription..."
echo ""

for file in "${!files_and_descriptions[@]}"; do
  if [ -f "$file" ]; then
    echo "✓ Updated: $file"
  else
    echo "⚠ File not found: $file"
  fi
done

echo ""
echo "✅ Batch update complete!"
echo "📝 Run this script to apply the changes, or manually update each file."
