# JSearch API Integration - Complete Implementation Guide

## Status: Ready to Deploy ✅

The RAPIDAPI_KEY has been added to Supabase secrets. Now we need to update the `fetch-jobs` edge function.

## Updated Edge Function Code

Replace the entire content of `supabase/functions/fetch-jobs/index.ts` with:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

interface JSearchJob {
  job_id: string;
  job_title: string;
  employer_name: string;
  job_city?: string;
  job_state?: string;
  job_country?: string;
  job_description: string;
  job_min_salary?: number;
  job_max_salary?: number;
  job_employment_type?: string;
  job_posted_at_datetime_utc?: string;
  job_apply_link: string;
  job_required_skills?: string[];
  employer_company_type?: string;
  job_is_remote?: boolean;
  job_required_experience?: {
    required_experience_in_months?: number;
  };
}

const transformJSearchJob = (job: JSearchJob): JobListing => {
  const location = [job.job_city, job.job_state, job.job_country]
    .filter(Boolean)
    .join(', ') || 'Not specified';

  let salary = undefined;
  if (job.job_min_salary && job.job_max_salary) {
    salary = `$${job.job_min_salary.toLocaleString()} - $${job.job_max_salary.toLocaleString()}`;
  } else if (job.job_min_salary) {
    salary = `From $${job.job_min_salary.toLocaleString()}`;
  } else if (job.job_max_salary) {
    salary = `Up to $${job.job_max_salary.toLocaleString()}`;
  }

  const experienceMonths = job.job_required_experience?.required_experience_in_months || 0;
  let experience_level = 'Entry';
  if (experienceMonths >= 60) experience_level = 'Senior';
  else if (experienceMonths >= 24) experience_level = 'Mid';

  return {
    id: job.job_id,
    title: job.job_title,
    company: job.employer_name,
    location,
    description: job.job_description || 'No description available',
    salary,
    type: job.job_employment_type || 'Full-time',
    posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
    apply_url: job.job_apply_link,
    source: 'jsearch',
    skills: job.job_required_skills || [],
    company_size: job.employer_company_type,
    remote: job.job_is_remote || false,
    experience_level
  };
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured');
    }

    const { 
      query = 'software engineer', 
      location = '', 
      job_type,
      remote,
      page = 1,
      limit = 20
    } = await req.json();

    const searchQuery = location ? `${query} in ${location}` : query;
    const apiUrl = new URL('https://jsearch.p.rapidapi.com/search');
    apiUrl.searchParams.append('query', searchQuery);
    apiUrl.searchParams.append('page', page.toString());
    apiUrl.searchParams.append('num_pages', '1');
    
    if (remote) {
      apiUrl.searchParams.append('remote_jobs_only', 'true');
    }
    
    if (job_type) {
      apiUrl.searchParams.append('employment_types', job_type.toUpperCase());
    }

    const response = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      throw new Error(`JSearch API returned ${response.status}`);
    }

    const data = await response.json();
    const jobs = data.data.map(transformJSearchJob);
    const paginatedJobs = jobs.slice(0, limit);

    return new Response(JSON.stringify({
      jobs: paginatedJobs,
      total: jobs.length,
      page,
      totalPages: Math.ceil(jobs.length / limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Deploy Command

```bash
supabase functions deploy fetch-jobs
```

## What Changed

1. ✅ Removed all mock data generation
2. ✅ Added JSearch API integration with RapidAPI authentication
3. ✅ Proper request headers (X-RapidAPI-Key, X-RapidAPI-Host)
4. ✅ Response transformation to match JobListing interface
5. ✅ Support for query, location, job_type, remote filters
6. ✅ Pagination support
7. ✅ Error handling with detailed logging

## Testing

Test the function:
```bash
curl -X POST https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs \
  -H "Content-Type: application/json" \
  -d '{"query": "software engineer", "location": "San Francisco"}'
```

## Next Steps

1. Deploy the updated function
2. Test with real queries
3. Monitor API usage and rate limits
4. Update frontend if needed
