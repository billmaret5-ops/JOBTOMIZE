# Circuit Breaker Pattern for Webhook Retry System

## Overview

The Circuit Breaker pattern prevents cascading failures by automatically disabling failing webhook endpoints after a threshold is reached. It implements three states (closed, open, half-open) with automatic recovery testing and health score calculation.

## Features

- **Automatic Failure Detection**: Monitors consecutive failures and opens circuit when threshold is reached
- **Three-State Pattern**: Closed (normal), Open (blocked), Half-Open (testing recovery)
- **Health Score Calculation**: Real-time health metrics based on success/failure rates
- **Automatic Recovery Testing**: Periodic attempts to restore failed endpoints
- **Comprehensive Monitoring**: Dashboard showing circuit states, failure thresholds, and statistics
- **Manual Controls**: Override circuit states for testing and maintenance

## Circuit States

### Closed (Normal Operation)
- All requests pass through normally
- Failures are tracked but don't block requests
- Transitions to Open when failure threshold is reached

### Open (Circuit Tripped)
- Requests are blocked to prevent cascading failures
- Protects downstream systems from overload
- Waits for timeout duration before attempting recovery
- Transitions to Half-Open for recovery testing

### Half-Open (Recovery Testing)
- Limited number of test requests allowed
- Success threshold determines if circuit closes
- Single failure reopens the circuit
- Provides controlled recovery path

## Database Schema

### circuit_breakers
```sql
- id: UUID (primary key)
- endpoint_url: TEXT (unique)
- endpoint_type: TEXT (slack, pagerduty, webhook, email, sms)
- state: TEXT (closed, open, half_open)
- failure_count: INTEGER
- success_count: INTEGER
- consecutive_failures: INTEGER
- consecutive_successes: INTEGER
- failure_threshold: INTEGER (default: 5)
- success_threshold: INTEGER (default: 2)
- timeout_duration: INTERVAL (default: 60 seconds)
- health_score: DECIMAL (0-100)
- next_recovery_test_at: TIMESTAMPTZ
```

### circuit_breaker_events
```sql
- id: UUID (primary key)
- circuit_breaker_id: UUID (foreign key)
- event_type: TEXT (state_change, failure, success, recovery_test)
- previous_state: TEXT
- new_state: TEXT
- error_message: TEXT
- response_time_ms: INTEGER
```

### circuit_breaker_statistics
```sql
- circuit_breaker_id: UUID (foreign key)
- date: DATE
- hour: INTEGER
- total_requests: INTEGER
- successful_requests: INTEGER
- failed_requests: INTEGER
- blocked_requests: INTEGER
- avg_response_time_ms: DECIMAL
```

## Configuration

### Default Thresholds
- **Failure Threshold**: 5 consecutive failures
- **Success Threshold**: 2 consecutive successes (in half-open state)
- **Timeout Duration**: 60 seconds
- **Half-Open Max Calls**: 3 test requests

### Customization
```typescript
await circuitBreakerService.getOrCreateCircuitBreaker(
  'https://hooks.slack.com/services/...',
  'slack',
  {
    failure_threshold: 10,
    success_threshold: 3,
    timeout_duration: '120 seconds',
    half_open_max_calls: 5
  }
);
```

## Usage

### Recording Request Results
```typescript
import { circuitBreakerService } from '@/services/circuitBreakerService';

// Get or create circuit breaker
const breaker = await circuitBreakerService.getOrCreateCircuitBreaker(
  webhookUrl,
  'slack'
);

// Record successful request
await circuitBreakerService.recordRequest(
  breaker.id,
  true,  // success
  250    // response time in ms
);

// Record failed request
await circuitBreakerService.recordRequest(
  breaker.id,
  false,  // failure
  undefined,
  'Connection timeout'
);
```

### Manual Circuit Control
```typescript
// Manually open circuit (for maintenance)
await circuitBreakerService.openCircuit(breakerId);

// Manually close circuit (after fixing issues)
await circuitBreakerService.closeCircuit(breakerId);

// Reset circuit (clear all counters)
await circuitBreakerService.resetCircuit(breakerId);
```

### Integration with Webhook Retry System
```typescript
import { webhookRetryService } from '@/services/webhookRetryService';
import { circuitBreakerService } from '@/services/circuitBreakerService';

async function sendWebhook(url: string, payload: any) {
  const breaker = await circuitBreakerService.getOrCreateCircuitBreaker(
    url,
    'webhook'
  );

  try {
    // Circuit breaker will throw if open
    const response = await fetch(url, {
      method: 'POST',
      body: JSON.stringify(payload)
    });

    await circuitBreakerService.recordRequest(
      breaker.id,
      response.ok,
      Date.now() - startTime
    );

    if (!response.ok) {
      // Queue for retry
      await webhookRetryService.queueRetry(url, payload);
    }
  } catch (error) {
    await circuitBreakerService.recordRequest(
      breaker.id,
      false,
      undefined,
      error.message
    );
    throw error;
  }
}
```

## Health Score Calculation

Health score is calculated based on:
- **Success Rate** (70% weight): Percentage of successful requests
- **Response Time** (15% weight): Average response time
- **Consecutive Failures** (15% weight): Recent failure patterns

```typescript
// Health score ranges:
// 90-100: Excellent
// 70-89: Good
// 50-69: Degraded
// 0-49: Poor
```

## Dashboard Features

### Real-Time Monitoring
- Circuit state indicators (green/yellow/red)
- Health score with color-coded badges
- Failure counts vs thresholds
- Last success/failure timestamps

### Statistics
- Total circuits by state
- Success/failure rates over time
- Response time trends
- Blocked request counts

### Manual Actions
- Open/close circuit buttons
- Reset circuit counters
- Test recovery manually
- View event history

## Best Practices

### 1. Set Appropriate Thresholds
```typescript
// For critical endpoints (lower tolerance)
failure_threshold: 3
timeout_duration: '30 seconds'

// For less critical endpoints (higher tolerance)
failure_threshold: 10
timeout_duration: '300 seconds'
```

### 2. Monitor Health Scores
- Set up alerts for health scores below 70
- Investigate patterns in circuit breaker events
- Review blocked request counts regularly

### 3. Recovery Strategy
- Use longer timeout durations for known unstable endpoints
- Increase success threshold for critical systems
- Monitor half-open state transitions

### 4. Integration Testing
```typescript
// Test circuit breaker behavior
const breaker = await circuitBreakerService.getOrCreateCircuitBreaker(
  testUrl,
  'webhook',
  { failure_threshold: 2 }
);

// Simulate failures
for (let i = 0; i < 2; i++) {
  await circuitBreakerService.recordRequest(breaker.id, false);
}

// Verify circuit is open
const updated = await circuitBreakerService.getCircuitBreaker(breaker.id);
assert(updated.state === 'open');
```

## Troubleshooting

### Circuit Won't Close
- Check if success threshold is too high
- Verify endpoint is actually responding successfully
- Review recovery test results in events log

### Too Many False Positives
- Increase failure threshold
- Extend timeout duration
- Review error patterns in events

### Circuit Opens Too Quickly
- Increase failure threshold
- Check for network issues
- Review endpoint response times

## Performance Considerations

- Circuit breaker checks add minimal latency (<5ms)
- Health score calculation runs asynchronously
- Statistics are aggregated hourly for efficiency
- Event logs are indexed for fast queries

## Monitoring Queries

### Get Circuit Status
```sql
SELECT 
  endpoint_url,
  state,
  health_score,
  consecutive_failures,
  failure_threshold
FROM circuit_breakers
WHERE state = 'open';
```

### Recent State Changes
```sql
SELECT 
  cb.endpoint_url,
  cbe.event_type,
  cbe.previous_state,
  cbe.new_state,
  cbe.created_at
FROM circuit_breaker_events cbe
JOIN circuit_breakers cb ON cb.id = cbe.circuit_breaker_id
WHERE cbe.event_type = 'state_change'
ORDER BY cbe.created_at DESC
LIMIT 20;
```

### Health Score Trends
```sql
SELECT 
  date,
  AVG(health_score) as avg_health,
  COUNT(*) as circuit_count
FROM circuit_breaker_health_history
WHERE recorded_at > NOW() - INTERVAL '7 days'
GROUP BY date
ORDER BY date;
```

## Future Enhancements

- Adaptive thresholds based on historical patterns
- Circuit breaker groups for related endpoints
- Automatic threshold tuning with ML
- Integration with alerting systems
- Circuit breaker policies per endpoint type
