# Fix Login Issues - RLS Policy Problem

## Problem
Users cannot log in because the `user_profiles` table has Row Level Security (RLS) enabled but profiles are not being auto-created on signup, causing authentication to fail silently.

## Solution

### Step 1: Run SQL Migration
1. Go to your Supabase Dashboard
2. Navigate to **SQL Editor**
3. Open the file: `supabase/migrations/fix_user_profiles_rls.sql`
4. Copy and paste the entire contents
5. Click **Run**

This will:
- Fix RLS policies on `user_profiles` table
- Add a trigger to auto-create profiles on signup
- Backfill profiles for existing users

### Step 2: Verify the Fix
After running the migration, test:

1. **Check if profiles exist:**
```sql
SELECT COUNT(*) FROM user_profiles;
```

2. **Check RLS policies:**
```sql
SELECT * FROM pg_policies WHERE tablename = 'user_profiles';
```

3. **Test login** - Try logging in again

### Step 3: Manual Profile Creation (if needed)
If you still can't log in, manually create your profile:

```sql
INSERT INTO user_profiles (user_id, email, full_name, role, subscription_tier)
SELECT 
  id,
  email,
  COALESCE(raw_user_meta_data->>'full_name', 'User'),
  'user',
  'free'
FROM auth.users
WHERE email = 'your-email@example.com'
ON CONFLICT (email) DO NOTHING;
```

## Root Cause
The app has TWO user profile tables:
1. `profiles` - Original table (uses `id` as PK)
2. `user_profiles` - Analytics table (uses `user_id` as FK)

The code queries `user_profiles` but the auto-creation trigger was only set up for `profiles`, causing new users to have no profile record and RLS to block access.

## Prevention
The migration adds a trigger that automatically creates a `user_profiles` entry whenever a new user signs up.