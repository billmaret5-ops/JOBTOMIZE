# AI Resume Generator - Deployment Guide

## Overview
AI-powered resume generation system using API Gateway with Google Gemini 2.5 Flash for professional content creation.

## Edge Function Deployment

### Function: `ai-resume-generator`

The edge function code is ready but needs manual deployment due to authentication issues.

**Function Location:** `supabase/functions/ai-resume-generator/index.ts`

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { action, data } = await req.json();
    const gatewayApiKey = Deno.env.get("GATEWAY_API_KEY");
    
    if (!gatewayApiKey) {
      throw new Error("API Gateway key not configured");
    }

    let prompt = '';
    
    switch (action) {
      case 'generate_bullet_points':
        prompt = `Generate 3-5 professional resume bullet points for this role:
Job Title: ${data.jobTitle}
Company: ${data.company || 'N/A'}
Responsibilities: ${data.description}
Tone: ${data.tone || 'professional'}

Use strong action verbs and quantify achievements where possible. Format as array of strings.`;
        break;
        
      case 'improve_writing':
        prompt = `Improve this resume content with better writing style:
Original: ${data.text}
Tone: ${data.tone || 'professional'}

Make it more impactful, concise, and achievement-focused. Return only the improved text.`;
        break;
        
      case 'suggest_action_verbs':
        prompt = `Suggest 10 powerful action verbs for this context:
Job Title: ${data.jobTitle}
Industry: ${data.industry || 'general'}
Current text: ${data.text}

Return as comma-separated list.`;
        break;
        
      case 'tailor_to_job':
        prompt = `Tailor this resume content to match the job description:
Resume Content: ${data.resumeContent}
Job Description: ${data.jobDescription}
Tone: ${data.tone || 'professional'}

Highlight relevant skills and experiences. Return improved content.`;
        break;
        
      case 'generate_summary':
        prompt = `Generate a professional resume summary:
Job Title: ${data.targetRole}
Years of Experience: ${data.yearsExperience}
Key Skills: ${data.skills}
Tone: ${data.tone || 'professional'}

Create a compelling 3-4 sentence summary.`;
        break;
        
      case 'enhance_experience':
        prompt = `Enhance this experience description:
${data.description}
Tone: ${data.tone || 'professional'}

Make it more impactful with specific achievements and metrics. Return enhanced description.`;
        break;
        
      default:
        throw new Error('Invalid action');
    }

    const response = await fetch('https://ai.gateway.fastrouter.io/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': gatewayApiKey
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'user', content: prompt }],
        temperature: 0.7
      })
    });

    const aiData = await response.json();
    const content = aiData.choices?.[0]?.message?.content || '';
    
    return new Response(JSON.stringify({ success: true, content }), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  } catch (error) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
```

### Manual Deployment Steps

1. **Create the function directory:**
```bash
mkdir -p supabase/functions/ai-resume-generator
```

2. **Create the function file:**
```bash
# Copy the code above into:
supabase/functions/ai-resume-generator/index.ts
```

3. **Deploy using Supabase CLI:**
```bash
supabase functions deploy ai-resume-generator
```

4. **Verify GATEWAY_API_KEY is set:**
```bash
supabase secrets list
```

## Features Implemented

### 1. AI Resume Builder (`AIResumeBuilder.tsx`)
- Generate professional bullet points
- Improve writing style
- Suggest action verbs
- Tailor content to job descriptions
- Tone adjustment (professional, creative, technical)

### 2. AI Cover Letter Generator (`AICoverLetterGenerator.tsx`)
- Job description analysis
- Personalized cover letter generation
- Tone customization
- Copy and download functionality

### 3. AI Resume Optimizer (`AIResumeOptimizer.tsx`)
- ATS score calculation
- Keyword analysis
- Improvement suggestions
- Strength and weakness identification

### 4. Integration with Resume Builder
- New "AI Assistant" tab in Interactive Resume Builder
- Seamless content generation workflow
- Real-time preview updates

## AI Service Utility

**File:** `src/lib/aiService.ts`

Provides centralized AI content generation with type-safe options:

```typescript
import { generateAIContent } from '@/lib/aiService';

// Example usage
const content = await generateAIContent({
  action: 'generate_bullet_points',
  data: {
    jobTitle: 'Software Engineer',
    description: 'Developed web applications',
    tone: 'professional'
  }
});
```

## Supported Actions

1. **generate_bullet_points** - Create professional resume bullets
2. **improve_writing** - Enhance existing content
3. **suggest_action_verbs** - Recommend powerful verbs
4. **tailor_to_job** - Customize for specific job descriptions
5. **generate_summary** - Create professional summaries
6. **enhance_experience** - Improve experience descriptions

## Tone Options

- **professional** - Traditional, formal business language
- **creative** - Engaging, dynamic, innovative language
- **technical** - Precise, detailed, technical terminology

## Testing

1. Navigate to `/resume-builder`
2. Click "AI Assistant" tab
3. Fill in job details and current content
4. Select desired tone
5. Click generation buttons
6. Review and apply generated content

## Error Handling

The system includes comprehensive error handling:
- API Gateway connection errors
- Invalid action types
- Missing required data
- Rate limiting
- Network failures

## Cost Optimization

Using Google Gemini 2.5 Flash model:
- Fast response times
- Cost-effective pricing
- High-quality output
- Balanced performance

## Next Steps

1. Deploy the edge function manually
2. Test all AI generation features
3. Monitor usage and costs
4. Gather user feedback
5. Fine-tune prompts based on results

## Troubleshooting

**Issue:** "API Gateway key not configured"
- Verify GATEWAY_API_KEY secret is set in Supabase

**Issue:** "Unauthorized" error during deployment
- Check Supabase CLI authentication
- Verify project permissions

**Issue:** Slow response times
- Check API Gateway status
- Consider caching frequently used content

## Support

For issues or questions:
1. Check Supabase function logs
2. Verify API Gateway connectivity
3. Review error messages in browser console
4. Test with different tone/action combinations
