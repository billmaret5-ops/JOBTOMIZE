# Real-Time Performance Monitoring System

## Overview

Enterprise-grade real-time performance monitoring system with WebSocket streaming, animated charts, threshold alerts, and historical comparison for ML model deployments.

## Features

### Real-Time Metrics Streaming
- **WebSocket Connection**: Live metrics updated every second
- **Auto-Reconnection**: Automatic reconnection with exponential backoff
- **Multi-Stage Tracking**: Monitor production, canary, and staging simultaneously
- **Low Latency**: Sub-second metric delivery

### Animated Visualizations
- **Streaming Charts**: Smooth animated charts with 750ms transitions
- **Stage Comparison**: Side-by-side performance across deployment stages
- **Historical Overlays**: Compare current metrics with historical baselines
- **Responsive Design**: Adapts to different screen sizes

### Alert System
- **Threshold Monitoring**: Configurable warning and critical thresholds
- **Real-Time Notifications**: Instant alerts for violations
- **Severity Levels**: Warning and critical alert classifications
- **Alert History**: Track all alerts with timestamps

### Performance Metrics
- **Latency**: Average, P95, and P99 latency measurements
- **Error Rate**: Real-time error tracking with percentage calculations
- **Throughput**: Requests per second across all stages
- **Traffic Distribution**: Live traffic splitting percentages
- **Active Connections**: Current WebSocket connection count

## Usage

### Basic Setup

```typescript
import { RealTimeDataDashboard } from '@/components/RealTimeDataDashboard';

function MyComponent() {
  return <RealTimeDataDashboard deploymentId="deploy_123" />;
}
```

### Using the Hook

```typescript
import { useRealTimeData } from '@/hooks/useRealTimeData';

function MyComponent() {
  const { 
    metrics, 
    alerts, 
    isConnected,
    getLatestMetrics,
    getAverageMetric 
  } = useRealTimeData('deploy_123');

  const latestLatency = getLatestMetrics()?.avgLatency;
  const avgErrorRate = getAverageMetric('errorRate');

  return (
    <div>
      <p>Connected: {isConnected ? 'Yes' : 'No'}</p>
      <p>Latest Latency: {latestLatency}ms</p>
      <p>Avg Error Rate: {avgErrorRate}%</p>
    </div>
  );
}
```

### Custom Streaming Service

```typescript
import { deploymentMetricsStreamingService } from '@/services/deploymentMetricsStreamingService';

// Connect to deployment
deploymentMetricsStreamingService.connect('deploy_123');

// Subscribe to metrics
const unsubscribe = deploymentMetricsStreamingService.onMetrics((metric) => {
  console.log('New metric:', metric);
});

// Subscribe to alerts
const unsubAlerts = deploymentMetricsStreamingService.onAlert((alert) => {
  console.log('Alert:', alert);
});

// Cleanup
unsubscribe();
unsubAlerts();
deploymentMetricsStreamingService.disconnect();
```

## Components

### RealTimeDataDashboard
Main dashboard with streaming charts and metrics cards.

**Props:**
- `deploymentId`: string - Deployment to monitor

### StreamingChart
Animated chart component for time-series data.

**Props:**
- `data`: Array of { timestamp, value, stage }
- `title`: string
- `yAxisLabel`: string
- `maxDataPoints`: number (default: 60)
- `thresholds`: { warning?, critical? }

### RealTimeMetricsCards
Summary cards showing key metrics.

**Props:**
- `metrics`: DeploymentMetrics[]

## Metrics Structure

```typescript
interface DeploymentMetrics {
  deploymentId: string;
  timestamp: Date;
  stage: 'production' | 'canary' | 'staging';
  trafficPercentage: number;
  requestCount: number;
  errorCount: number;
  errorRate: number;
  avgLatency: number;
  p95Latency: number;
  p99Latency: number;
  throughput: number;
  activeConnections: number;
}
```

## Alert Configuration

Alerts are triggered when metrics exceed thresholds:

```typescript
// Default thresholds
const thresholds = {
  latency: {
    warning: 200,  // ms
    critical: 500  // ms
  },
  errorRate: {
    warning: 1,    // %
    critical: 5    // %
  },
  throughput: {
    warning: 100,  // req/s
    critical: 50   // req/s
  }
};
```

## Best Practices

### 1. Connection Management
```typescript
// Always cleanup on unmount
useEffect(() => {
  const service = deploymentMetricsStreamingService;
  service.connect(deploymentId);
  
  return () => service.disconnect();
}, [deploymentId]);
```

### 2. Data Retention
```typescript
// Keep limited data in memory
setMetrics(prev => [...prev.slice(-300), newMetric]); // 5 min at 1 sec
```

### 3. Performance Optimization
```typescript
// Use memo for expensive calculations
const avgMetrics = useMemo(() => 
  calculateAverages(metrics), 
  [metrics]
);
```

### 4. Error Handling
```typescript
try {
  const data = await deploymentMetricsStreamingService.getHistoricalMetrics(id);
} catch (error) {
  console.error('Failed to load metrics:', error);
  // Show user-friendly error
}
```

## Troubleshooting

### WebSocket Not Connecting

**Issue**: Connection fails or disconnects frequently

**Solutions**:
1. Check Supabase URL configuration
2. Verify network connectivity
3. Check browser console for errors
4. Ensure deployment ID is valid

### Missing Metrics

**Issue**: No data appearing in charts

**Solutions**:
1. Verify deployment is active
2. Check if metrics are being generated
3. Inspect WebSocket messages in dev tools
4. Ensure subscription is successful

### High Memory Usage

**Issue**: Browser memory increases over time

**Solutions**:
1. Reduce `maxDataPoints` in StreamingChart
2. Implement data cleanup in useEffect
3. Limit metrics array size
4. Clear old alerts periodically

### Slow Chart Rendering

**Issue**: Charts lag or stutter

**Solutions**:
1. Reduce animation duration
2. Decrease data points displayed
3. Use React.memo for components
4. Optimize re-render triggers

## Integration Examples

### With Model Deployment

```typescript
function DeploymentMonitor({ deployment }) {
  return (
    <div>
      <ModelDeploymentPipeline deployment={deployment} />
      <RealTimeDataDashboard deploymentId={deployment.id} />
    </div>
  );
}
```

### With Alert Actions

```typescript
const { alerts } = useRealTimeData(deploymentId);

useEffect(() => {
  const criticalAlerts = alerts.filter(a => a.severity === 'critical');
  
  if (criticalAlerts.length > 0) {
    // Trigger rollback
    triggerAutomaticRollback(deploymentId);
  }
}, [alerts]);
```

### With Historical Comparison

```typescript
function ComparisonView({ deploymentId }) {
  const { metrics, historicalData } = useRealTimeData(deploymentId);
  
  return (
    <StreamingChart
      data={[...historicalData, ...metrics]}
      title="Current vs Historical"
      yAxisLabel="Latency (ms)"
    />
  );
}
```

## API Reference

### deploymentMetricsStreamingService

#### Methods

- `connect(deploymentId: string): void`
- `disconnect(): void`
- `onMetrics(callback: (metrics: DeploymentMetrics) => void): () => void`
- `onAlert(callback: (alert: MetricsAlert) => void): () => void`
- `getHistoricalMetrics(deploymentId: string, minutes: number): Promise<any[]>`

### useRealTimeData Hook

#### Parameters
- `deploymentId`: string
- `enabled`: boolean (default: true)

#### Returns
- `metrics`: DeploymentMetrics[]
- `alerts`: MetricsAlert[]
- `isConnected`: boolean
- `historicalData`: any[]
- `getLatestMetrics(): DeploymentMetrics | undefined`
- `getMetricsByStage(stage: string): DeploymentMetrics[]`
- `getAverageMetric(metricName: string): number`
- `refresh(): Promise<void>`

## Performance Considerations

- **Memory**: Limits metrics to last 300 data points (5 minutes)
- **Network**: WebSocket reduces overhead vs polling
- **Rendering**: Smooth animations without blocking UI
- **CPU**: Efficient chart updates with minimal recalculation

## Future Enhancements

- [ ] Custom metric aggregations
- [ ] Metric export to CSV/JSON
- [ ] Advanced filtering and search
- [ ] Metric correlation analysis
- [ ] Predictive alerting with ML
- [ ] Multi-deployment comparison
- [ ] Custom dashboard layouts
- [ ] Metric annotations and notes
