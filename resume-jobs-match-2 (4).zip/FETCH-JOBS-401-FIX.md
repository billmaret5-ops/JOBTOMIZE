# Fetch Jobs 401 Error Fix Guide

## Problem
The fetch-jobs edge function is returning 401 Unauthorized errors even with proper Authorization and apikey headers.

## Root Cause
The edge function has `verify_jwt: true` enabled in Supabase, but the function code doesn't properly handle GET requests or log authentication details.

## Solution

### Step 1: Update Edge Function Code

The current function only handles POST requests. It needs to support:
- GET /health (health check)
- GET /search?query=...&location=... (search via query params)
- POST with JSON body (existing functionality)

### Step 2: Deploy Updated Function

Use the Supabase CLI or dashboard to deploy this updated code:

```typescript
// See FETCH-JOBS-UPDATED-CODE.ts for the full implementation
```

### Step 3: Verify JWT Configuration

In Supabase Dashboard:
1. Go to Edge Functions → fetch-jobs
2. Check "Enforce JWT verification" setting
3. Options:
   - **Recommended**: Keep JWT verification ON (more secure)
   - **For testing**: Temporarily disable to verify the function works

### Step 4: Test with Proper Headers

Both headers are required when JWT verification is enabled:

```bash
# Test health endpoint
curl -H "Authorization: Bearer YOUR_ANON_KEY" \
     -H "apikey: YOUR_ANON_KEY" \
     "YOUR_SUPABASE_URL/functions/v1/fetch-jobs/health"

# Test search endpoint (GET)
curl -H "Authorization: Bearer YOUR_ANON_KEY" \
     -H "apikey: YOUR_ANON_KEY" \
     "YOUR_SUPABASE_URL/functions/v1/fetch-jobs/search?query=react&location=remote"

# Test search endpoint (POST)
curl -X POST \
     -H "Authorization: Bearer YOUR_ANON_KEY" \
     -H "apikey: YOUR_ANON_KEY" \
     -H "Content-Type: application/json" \
     -d '{"query":"react","location":"remote"}' \
     "YOUR_SUPABASE_URL/functions/v1/fetch-jobs/search"
```

### Step 5: Check Logs

After deploying, check the Supabase logs to see:
- What headers the function receives
- Any JWT verification errors
- Request/response details

## Quick Fix: Disable JWT Verification Temporarily

If you need to test immediately:

1. Go to Supabase Dashboard → Edge Functions
2. Select fetch-jobs function
3. Settings → Uncheck "Enforce JWT verification"
4. Save and test

This will allow requests without authentication headers while you debug.

## Files Updated

- `src/services/fetchJobsService.ts` - Service with proper auth headers
- `src/components/FetchJobsDiagnostics.tsx` - Diagnostic component
- `src/components/EdgeFunctionTester.tsx` - Simple health check tester
- `FETCH-JOBS-UPDATED-CODE.ts` - Complete edge function code

## Next Steps

1. Deploy the updated edge function code
2. Check Supabase logs for header information
3. Verify JWT verification setting matches your needs
4. Test all three endpoints (health, GET search, POST search)
