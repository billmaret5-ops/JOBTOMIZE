# Real-Time Dashboard WebSocket Streaming

## Overview

This system provides WebSocket-based real-time data streaming for dashboard widgets, enabling automatic updates without page refresh. Perfect for live monitoring of alerts, metrics, and system health.

## Features

- **WebSocket Connection Management**: Automatic connection, reconnection, and error handling
- **Real-Time Metrics**: Live updates for MTTA, MTTR, alert counts, and custom metrics
- **Live Event Stream**: Real-time alert feed with severity indicators
- **Streaming Charts**: Auto-updating line charts with configurable intervals
- **Connection Status Indicator**: Visual feedback for connection state
- **Automatic Reconnection**: Configurable retry logic with exponential backoff

## Components

### Core Components

1. **RealTimeDataDashboard** - Main dashboard with live monitoring tabs
2. **RealTimeConnectionManager** - Connection status indicator with reconnect controls
3. **RealTimeMetricsCards** - Auto-updating metric cards with trend indicators
4. **StreamingChart** - Real-time line charts with rolling data
5. **LiveEventStream** - Live alert feed with auto-scroll

### Hooks

- **useWebSocketStreaming** - WebSocket connection management
- **useRealTimeData** - Real-time data state management

## Usage

### Basic WebSocket Connection

```typescript
import { useWebSocketStreaming } from '@/hooks/useWebSocketStreaming';

const { status, lastMessage, sendMessage, connect, disconnect } = useWebSocketStreaming({
  url: 'ws://localhost:8080/dashboard',
  reconnectInterval: 3000,
  maxReconnectAttempts: 10,
  onMessage: (message) => {
    console.log('Received:', message);
  },
  onConnect: () => console.log('Connected'),
  onDisconnect: () => console.log('Disconnected'),
});
```

### Using Real-Time Data in Widgets

```typescript
import { useRealTimeData } from '@/hooks/useRealTimeData';

const MyWidget = () => {
  const { metrics, alerts, isConnected, lastUpdate } = useRealTimeData();
  
  return (
    <div>
      <p>MTTA: {metrics.mtta?.value}m</p>
      <p>Status: {isConnected ? 'Live' : 'Offline'}</p>
    </div>
  );
};
```

### Connection Status Indicator

```typescript
import { RealTimeConnectionManager } from '@/components/RealTimeConnectionManager';

<RealTimeConnectionManager
  status={status}
  reconnectAttempts={reconnectAttempts}
  onReconnect={connect}
  compact={true}
/>
```

## WebSocket Message Format

### Metric Update
```json
{
  "type": "metric_update",
  "data": {
    "id": "mtta",
    "value": 12.5,
    "change": -2.3,
    "timestamp": "2025-10-25T03:30:00Z"
  }
}
```

### Alert Update
```json
{
  "type": "alert_update",
  "data": {
    "id": "alert-123",
    "severity": "critical",
    "message": "High CPU usage detected",
    "timestamp": "2025-10-25T03:30:00Z",
    "status": "open"
  }
}
```

### Chart Update
```json
{
  "type": "chart_update",
  "data": {
    "id": "alert_volume",
    "labels": ["10:00", "10:01", "10:02"],
    "datasets": [{
      "label": "Alerts",
      "data": [45, 52, 48]
    }]
  }
}
```

## Configuration

### Environment Variables

```env
VITE_WS_URL=ws://localhost:8080/dashboard
```

### Reconnection Settings

```typescript
{
  reconnectInterval: 3000,      // Wait 3s between reconnection attempts
  maxReconnectAttempts: 10,     // Try up to 10 times
}
```

## Integration with Custom Dashboards

The real-time streaming integrates seamlessly with the custom dashboard builder:

1. Navigate to **Dashboards** tab in Backup Dashboard
2. Select **Live Monitoring** tab
3. View real-time metrics, charts, and alerts
4. Connection status shown in header
5. Pause/Resume controls for data streaming

## Performance Considerations

- **Update Intervals**: Default 2-3 seconds for metrics, 5 seconds for alerts
- **Data Retention**: Keeps last 50 alerts, 20 chart data points
- **Memory Management**: Automatic cleanup of old data
- **Connection Pooling**: Single WebSocket connection shared across widgets

## Troubleshooting

### Connection Issues
- Check WebSocket URL in environment variables
- Verify backend WebSocket server is running
- Check browser console for connection errors

### No Data Updates
- Verify connection status indicator shows "Live"
- Check if data streaming is paused
- Inspect WebSocket messages in browser DevTools

### High CPU Usage
- Increase update intervals for charts/metrics
- Reduce number of active widgets
- Enable pause mode when not actively monitoring

## Future Enhancements

- [ ] WebSocket authentication and authorization
- [ ] Compression for large data payloads
- [ ] Binary message format for efficiency
- [ ] Multi-channel subscriptions
- [ ] Historical data replay
- [ ] Custom widget data transformations
