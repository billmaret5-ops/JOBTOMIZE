# APP NOT LOADING - QUICK FIX GUIDE

## IMMEDIATE FIXES (Try these in order)

### 1. HARD REFRESH THE BROWSER
```
Windows/Linux: Ctrl + Shift + R
Mac: Cmd + Shift + R
```

### 2. CLEAR BROWSER CACHE
- Open DevTools (F12)
- Right-click the refresh button
- Select "Empty Cache and Hard Reload"

### 3. RESTART DEV SERVER
```bash
# Stop the server (Ctrl+C)
# Then restart:
npm run dev
```

### 4. CHECK FOR ERRORS
Open browser console (F12) and look for:
- Red error messages
- Import errors
- Component errors

### 5. REBUILD THE APP
```bash
# Clear cache and rebuild
rm -rf node_modules/.vite
npm run dev
```

### 6. FULL CLEAN RESTART
```bash
# Stop server
# Clear all caches
rm -rf node_modules/.vite
rm -rf dist

# Restart
npm run dev
```

## COMMON ISSUES

### Issue: White/Blank Screen
**Solution**: Check browser console for errors

### Issue: "Cannot find module" Error
**Solution**: Restart dev server

### Issue: Infinite Loading
**Solution**: Check network tab for failed requests

### Issue: 404 Errors
**Solution**: Clear cache and hard refresh

## VERIFY APP IS WORKING

1. Open: http://localhost:5173 (or your dev server URL)
2. You should see the Jobtomize landing page
3. Check console for any red errors

## STILL NOT WORKING?

Try accessing with query parameter:
```
http://localhost:5173/?diagnostics
```

This will show diagnostic information.
