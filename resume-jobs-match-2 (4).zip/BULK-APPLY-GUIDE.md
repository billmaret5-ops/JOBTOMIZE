# Bulk Apply AI Optimizations Guide

## Overview
The Bulk Apply feature allows you to apply multiple AI-optimized resume sections at once with a single confirmation, streamlining the optimization process.

## Features

### 1. Apply All Suggestions Button
- Located in the Comparison tab
- Opens preview modal with all changes
- Gradient purple-to-blue styling for visibility

### 2. Preview Modal
- Shows all sections with available changes
- Checkboxes to selectively include/exclude sections
- Preview of optimized content for each section
- Visual badges indicating change availability

### 3. Progress Indicator
- Real-time progress bar during bulk operations
- Animated spinner with status text
- Smooth transitions between sections

### 4. Selective Application
- Choose which sections to apply (summary, experience, skills)
- Sections without changes are disabled
- Clear visual feedback on selection state

## Usage Instructions

### Step 1: Analyze Resume
1. Navigate to Resume Management
2. Select the AI Optimizer tab
3. Paste job description
4. Click "Analyze Resume"

### Step 2: Review Suggestions
1. Review analysis results in Overview, Keywords, and Skills Gap tabs
2. Navigate to Comparison tab to see side-by-side changes

### Step 3: Bulk Apply
1. Click "Apply All Suggestions" button (top right of Comparison tab)
2. Review preview modal showing all changes
3. Use checkboxes to select/deselect sections
4. Click "Apply X Section(s)" button

### Step 4: Monitor Progress
1. Watch progress bar as sections are applied
2. Wait for success notification
3. Resume is automatically updated and version saved

## Section Details

### Summary Section
- Shows preview of optimized professional summary
- Indicates if changes are available

### Experience Section
- Shows count of positions to be updated
- All experience entries updated together

### Skills Section
- Shows count of skills to be added/updated
- Merges with existing skills

## Safety Features

### Confirmation Dialog
- Prevents accidental bulk application
- Shows clear preview of all changes
- Cancel option available at any time

### Version Control
- Automatic version snapshot created
- Can revert using version history
- Undo functionality available per section

### Progress Tracking
- Visual progress bar
- Section-by-section application
- Error handling with rollback

## Best Practices

1. **Review Before Applying**
   - Always review suggestions in Overview tab first
   - Check keyword matches and skills gap
   - Verify optimized content in Comparison tab

2. **Selective Application**
   - Uncheck sections you want to keep original
   - Apply summary first to test
   - Review each section individually if unsure

3. **Version Management**
   - Check version history after bulk apply
   - Keep track of applied changes
   - Use undo if needed

4. **Iterative Optimization**
   - Apply changes for one job description
   - Review results
   - Re-analyze for different positions

## Troubleshooting

### Modal Doesn't Open
- Ensure analysis is complete
- Check that optimized content exists
- Refresh page and try again

### Changes Not Applied
- Verify internet connection
- Check browser console for errors
- Ensure you have edit permissions

### Progress Bar Stuck
- Wait for timeout (30 seconds)
- Refresh page
- Check database connection

### Sections Disabled
- Indicates no changes available
- Re-run analysis with different job description
- Check that resume has content in those sections

## Technical Details

### State Management
- `showBulkApplyModal`: Controls modal visibility
- `selectedSections`: Array of sections to apply
- `isApplying`: Loading state during operation
- `progress`: Progress percentage (0-100)

### Database Updates
- Single transaction for all sections
- Automatic version creation
- Resume content updated atomically

### Error Handling
- Try-catch blocks for each operation
- Toast notifications for user feedback
- Rollback on failure

## Tips for Success

1. **Start Small**: Test with one section before bulk applying
2. **Save Versions**: Create manual versions before bulk operations
3. **Review Results**: Check updated resume after application
4. **Iterate**: Apply changes, review, and re-optimize as needed
5. **Use Undo**: Don't hesitate to undo and try again

## Related Features

- **Individual Apply**: Apply single sections from Comparison view
- **Undo Functionality**: Revert individual or bulk changes
- **Version History**: Track all resume changes over time
- **AI Analysis**: Get detailed optimization suggestions

## Support

If you encounter issues:
1. Check browser console for errors
2. Verify Supabase connection
3. Review edge function logs
4. Contact support with error details
