# Complete fetch-jobs Function Code

Copy this ENTIRE code block into your Supabase function editor:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type: string;
  posted_date: string;
  apply_url: string;
  source: string;
  skills: string[];
  company_size?: string;
  remote?: boolean;
  experience_level?: string;
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20,
      job_type,
      remote,
      experience_level
    } = await req.json();

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      throw new Error('RapidAPI key not configured');
    }

    // Build search query
    const searchQuery = location ? query + ' in ' + location : query;
    
    // Map job_type to JSearch employment_types
    let employmentTypes = '';
    if (job_type === 'Full-time') employmentTypes = 'FULLTIME';
    else if (job_type === 'Part-time') employmentTypes = 'PARTTIME';
    else if (job_type === 'Contract') employmentTypes = 'CONTRACTOR';
    else if (job_type === 'Internship') employmentTypes = 'INTERN';

    // Build API URL
    const apiUrl = new URL('https://jsearch.p.rapidapi.com/search');
    apiUrl.searchParams.append('query', searchQuery);
    apiUrl.searchParams.append('page', page.toString());
    apiUrl.searchParams.append('num_pages', '1');
    
    if (remote) {
      apiUrl.searchParams.append('remote_jobs_only', 'true');
    }
    
    if (employmentTypes) {
      apiUrl.searchParams.append('employment_types', employmentTypes);
    }
    
    if (experience_level) {
      apiUrl.searchParams.append('job_requirements', experience_level.toUpperCase());
    }

    console.log('Fetching jobs from JSearch API:', apiUrl.toString());

    const response = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch API error:', response.status, errorText);
      throw new Error('JSearch API error: ' + response.status);
    }

    const data = await response.json();
    
    // Transform JSearch data to our format
    const jobs: JobListing[] = (data.data || []).map((job: any) => {
      const minSal = job.job_min_salary || 'N/A';
      const maxSal = job.job_max_salary || 'N/A';
      const salaryStr = job.job_salary || (minSal + ' - ' + maxSal);
      
      let expLevel = undefined;
      if (job.job_required_experience?.required_experience_in_months) {
        const months = job.job_required_experience.required_experience_in_months;
        if (months < 24) expLevel = 'Entry';
        else if (months < 60) expLevel = 'Mid';
        else expLevel = 'Senior';
      }
      
      return {
        id: job.job_id || 'job_' + Date.now() + '_' + Math.random(),
        title: job.job_title || 'Untitled Position',
        company: job.employer_name || 'Unknown Company',
        location: (job.job_city && job.job_state) ? 
          job.job_city + ', ' + job.job_state : 
          (job.job_country || 'Location not specified'),
        description: job.job_description || 'No description available',
        salary: salaryStr !== 'N/A - N/A' ? salaryStr : undefined,
        type: job.job_employment_type || 'Full-time',
        posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
        apply_url: job.job_apply_link || job.job_google_link || '#',
        source: 'JSearch',
        skills: job.job_required_skills || [],
        company_size: undefined,
        remote: job.job_is_remote || false,
        experience_level: expLevel
      };
    });

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page,
      totalPages: Math.ceil((data.total || jobs.length) / limit),
      source: 'RapidAPI JSearch'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

## Key Changes from Previous Version

1. **Fixed Template Literals** - Replaced template literals with string concatenation to avoid syntax errors
2. **Simplified Conditionals** - Used if/else instead of ternary operators for clarity
3. **Error Handling** - Better error messages and logging
4. **Type Safety** - Proper TypeScript interfaces

## Deployment Instructions

1. Open Supabase Dashboard: https://supabase.com/dashboard/project/rgdvevmqrjlkqfkiucdh/functions
2. Find `fetch-jobs` function
3. Click Edit
4. Select ALL code above (from `export const corsHeaders` to the final `});`)
5. Paste into editor
6. Click Deploy
7. Wait for success message

Your RapidAPI key (82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7) is already configured!
