# 🚀 Deployment Guide

## Quick Deploy (5 Minutes)

### Option 1: Vercel (Recommended)

1. **Install Vercel CLI**
```bash
npm i -g vercel
```

2. **Deploy**
```bash
vercel --prod
```

3. **Add Environment Variables** (in Vercel Dashboard)
- `VITE_SUPABASE_URL` - Your Supabase project URL
- `VITE_SUPABASE_ANON_KEY` - Your Supabase anon key
- `VITE_OPENAI_API_KEY` - OpenAI API key (for ML features)
- `VITE_STRIPE_PUBLIC_KEY` - Stripe public key (optional)

### Option 2: Netlify

1. **Install Netlify CLI**
```bash
npm i -g netlify-cli
```

2. **Deploy**
```bash
netlify deploy --prod
```

## Database Setup (Supabase)

1. **Create Project** at [supabase.com](https://supabase.com)

2. **Run Migrations** (in Supabase SQL Editor)
   - Navigate to SQL Editor
   - Run each file in `supabase/migrations/` in order
   - Key migrations:
     - `create_user_authentication_system.sql`
     - `create_job_matching_retraining_tables.sql`
     - `create_comprehensive_email_campaign_tables.sql`

3. **Enable Realtime** (in Supabase Dashboard)
   - Go to Database → Replication
   - Enable for: `profiles`, `jobs`, `applications`, `job_matching_metrics`

4. **Deploy Edge Functions**
```bash
supabase functions deploy
```

## Environment Variables

### Required (Minimum for Demo)
```env
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key
VITE_OPENAI_API_KEY=sk-...
```

### Optional (Enhanced Features)
```env
VITE_STRIPE_PUBLIC_KEY=pk_test_...
VITE_APP_URL=https://your-app.vercel.app
```

## Demo Mode Setup

For quick demo without full setup:
1. Deploy frontend to Vercel
2. Use Supabase free tier
3. Add OpenAI key for ML job matching
4. Skip email providers (use mock data)
5. Skip Stripe (disable payment features)

## Post-Deployment

1. **Test the app** at your deployment URL
2. **Create test account** via signup
3. **Verify ML retraining** in Job Matching → Auto-Retrain tab
4. **Check realtime features** work properly

## Troubleshooting

- **Build fails**: Check Node version (18+)
- **Supabase errors**: Verify migrations ran successfully
- **ML features broken**: Confirm OpenAI API key is set
- **Realtime not working**: Enable replication in Supabase

## Production Checklist

- [ ] All migrations executed
- [ ] Environment variables set
- [ ] Realtime enabled on tables
- [ ] Edge functions deployed
- [ ] SSL certificate active
- [ ] Custom domain configured (optional)
