# Jobtomize.com SSL/HTTPS Setup Guide (Famous.ai)

## ✅ Automatic SSL Configuration for Famous.ai

### Step 1: Enable SSL on Famous.ai Platform

Famous.ai (Supabase-based) automatically provisions SSL certificates via Let's Encrypt when you add a custom domain.

**Action Required:**
1. Go to Famous.ai dashboard
2. Navigate to Project Settings → Custom Domains
3. Add `jobtomize.com` and `www.jobtomize.com`
4. SSL certificates will be automatically provisioned within 5-10 minutes

### Step 2: DNS Configuration

Add these DNS records at your domain registrar:

```
Type    Name    Value                           TTL
A       @       76.76.21.21                     3600
A       www     76.76.21.21                     3600
CNAME   @       <your-project>.supabase.co      3600
```

### Step 3: Verify SSL Certificate

```bash
# Check SSL certificate
curl -vI https://jobtomize.com

# Verify certificate details
openssl s_client -connect jobtomize.com:443 -servername jobtomize.com
```

## 🔄 Automatic Certificate Renewal

Let's Encrypt certificates are valid for 90 days. Famous.ai handles automatic renewal:

- ✅ Auto-renewal runs every 60 days
- ✅ No manual intervention required
- ✅ Email notifications if renewal fails


## 🛠️ Mixed Content Fixes

Mixed content occurs when HTTPS pages load HTTP resources. Here's how to fix:

### Automatic Fixes Applied:

1. **Content Security Policy** - Upgrades insecure requests automatically
2. **HTTPS Enforcement** - Redirects HTTP to HTTPS in production
3. **API URL Validation** - Ensures all API calls use HTTPS

### Manual Checks:

```bash
# Scan for mixed content issues
grep -r "http://" src/ --exclude-dir=node_modules

# Check for hardcoded HTTP URLs
grep -r "http://api" src/ --exclude-dir=node_modules
```

### Common Mixed Content Sources:

| Resource Type | Fix |
|--------------|-----|
| Images | Use `https://` or protocol-relative URLs |
| Scripts | Load from HTTPS CDN |
| Stylesheets | Use HTTPS URLs |
| API Calls | Update to HTTPS endpoints |
| Fonts | Use HTTPS or self-host |

## ✅ Verification Checklist

### 1. SSL Certificate Status
```bash
# Check certificate
curl -vI https://jobtomize.com 2>&1 | grep -i "SSL\|TLS\|certificate"

# Verify expiration date
echo | openssl s_client -servername jobtomize.com -connect jobtomize.com:443 2>/dev/null | openssl x509 -noout -dates
```

### 2. HTTPS Redirect Test
```bash
# Should redirect to HTTPS
curl -I http://jobtomize.com

# Should return 301 or 302
curl -I http://www.jobtomize.com
```

### 3. Security Headers Test
```bash
# Check security headers
curl -I https://jobtomize.com | grep -i "strict-transport\|content-security\|x-frame"
```

### 4. Mixed Content Test
- Open https://jobtomize.com
- Open browser DevTools (F12)
- Check Console for mixed content warnings
- Check Network tab for HTTP requests

### 5. SSL Labs Test
Visit: https://www.ssllabs.com/ssltest/analyze.html?d=jobtomize.com

**Target Grade: A or A+**

## 🚨 Troubleshooting

### Issue: Certificate Not Provisioning

**Cause:** DNS not propagated or incorrect records

**Fix:**
```bash
# Check DNS propagation
nslookup jobtomize.com
dig jobtomize.com

# Wait 24-48 hours for full propagation
# Contact Famous.ai support if issue persists
```

### Issue: Mixed Content Warnings

**Cause:** HTTP resources on HTTPS page

**Fix:**
1. Check browser console for specific URLs
2. Update hardcoded HTTP URLs to HTTPS
3. Use protocol-relative URLs: `//example.com/resource`

### Issue: HTTPS Not Redirecting

**Cause:** Redirect rules not applied

**Fix:**
1. Verify `_headers` file is in `public/` directory
2. Check Famous.ai dashboard for redirect settings
3. Clear browser cache and test in incognito

### Issue: Certificate Expired

**Cause:** Auto-renewal failed

**Fix:**
1. Check Famous.ai dashboard for renewal errors
2. Verify domain ownership
3. Contact Famous.ai support

## 📧 Support

If issues persist after following this guide:

1. **Famous.ai Support:** support@famous.ai
2. **Check Status:** https://status.famous.ai
3. **Documentation:** https://docs.famous.ai

## 🎉 Success Indicators

✅ Green padlock in browser address bar
✅ Certificate valid for 90 days
✅ All resources load over HTTPS
✅ No mixed content warnings
✅ HSTS header present
✅ SSL Labs grade A or A+
✅ HTTP redirects to HTTPS automatically

---

**Last Updated:** 2025-11-27
**Platform:** Famous.ai (Supabase)
**Domain:** jobtomize.com


### Option 1: Application-Level Redirects (Recommended)

Already configured in `public/.htaccess` and `netlify.toml`

### Option 2: Add Security Headers

Create/update these files for enhanced security:

