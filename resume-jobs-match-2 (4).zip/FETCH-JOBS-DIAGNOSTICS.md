# Fetch-Jobs 401 Error Diagnostics

## Current Situation
- ✅ OPTIONS requests: 204 (working)
- ❌ GET/POST requests: 401 Unauthorized
- ❌ Health check: 401 Unauthorized

## What This Means
The function is receiving requests but rejecting them due to authentication failure.

## Why 401 Happens with verify_jwt: true

### The JWT Verification Process
1. Request arrives at edge function
2. Supabase checks for valid JWT in Authorization header
3. If JWT is missing/invalid → **401 Unauthorized**
4. If JWT is valid → Function code executes

### Common Causes of 401

#### 1. Missing Authorization Header
```bash
# ❌ This will fail
curl "$SUPABASE_URL/functions/v1/fetch-jobs/health"

# ✅ This should work
curl -H "Authorization: Bearer $ANON_KEY" \
     -H "apikey: $ANON_KEY" \
     "$SUPABASE_URL/functions/v1/fetch-jobs/health"
```

#### 2. Wrong Token Format
```bash
# ❌ Missing "Bearer" prefix
Authorization: eyJhbGc...

# ✅ Correct format
Authorization: Bearer eyJhbGc...
```

#### 3. Expired Token
- User session tokens expire
- Anon key should not expire
- Check token at jwt.io

#### 4. Wrong Token
- Using wrong project's anon key
- Using service role key (not recommended for client)

## Diagnostic Steps

### Step 1: Check Function Configuration
```bash
supabase functions list
```
Look for `verify_jwt` column for fetch-jobs function.

### Step 2: Test With Correct Headers
```bash
# Get your keys
export SUPABASE_URL="https://your-project.supabase.co"
export SUPABASE_ANON_KEY="eyJhbGc..."

# Test health endpoint
curl -v \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/health"
```

### Step 3: Check What Function Receives
After deploying the updated function with logging:
```bash
# Make a request
curl -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
     -H "apikey: $SUPABASE_ANON_KEY" \
     "$SUPABASE_URL/functions/v1/fetch-jobs/health"

# Check logs
supabase functions logs fetch-jobs --follow
```

Look for:
```
=== FETCH-JOBS REQUEST ===
Headers: {
  authorization: 'Bearer eyJ...',
  apikey: 'eyJ...'
}
```

### Step 4: Verify Token
```bash
# Decode your anon key
echo $SUPABASE_ANON_KEY | cut -d'.' -f2 | base64 -d 2>/dev/null | jq
```

Check:
- `iss` (issuer) matches your Supabase URL
- `role` is "anon"
- Token hasn't expired

## Solutions

### Solution 1: Disable JWT Verification (Testing)
```bash
supabase functions deploy fetch-jobs --no-verify-jwt
```
**Pros**: Requests work immediately
**Cons**: No authentication (not secure for production)

### Solution 2: Fix Client Headers (Production)
Update all client code to send proper headers:

```typescript
// In fetchJobsService.ts
const headers = {
  'Authorization': `Bearer ${SUPABASE_CONFIG.anonKey}`,
  'apikey': SUPABASE_CONFIG.anonKey,
  'Content-Type': 'application/json'
};
```

### Solution 3: Use Supabase Client (Recommended)
```typescript
// Supabase client handles auth automatically
const { data, error } = await supabase.functions.invoke('fetch-jobs', {
  body: { query: 'react', location: 'remote' }
});
```

## Testing Matrix

### Test 1: No Auth
```bash
curl "$SUPABASE_URL/functions/v1/fetch-jobs/health"
# Expected: 401 if verify_jwt=true, 200 if verify_jwt=false
```

### Test 2: With Anon Key
```bash
curl -H "Authorization: Bearer $ANON_KEY" \
     -H "apikey: $ANON_KEY" \
     "$SUPABASE_URL/functions/v1/fetch-jobs/health"
# Expected: 200 (should always work)
```

### Test 3: With User Token
```typescript
const { data: { session } } = await supabase.auth.getSession();
fetch(`${url}/functions/v1/fetch-jobs/health`, {
  headers: {
    'Authorization': `Bearer ${session.access_token}`,
    'apikey': anonKey
  }
});
// Expected: 200 if user is logged in
```

### Test 4: Via Supabase Client
```typescript
const { data, error } = await supabase.functions.invoke('fetch-jobs', {
  body: { query: 'test' }
});
// Expected: Should always work
```

## Expected Behavior After Fix

### With verify_jwt: false
- All requests work without auth
- Not secure for production
- Good for testing

### With verify_jwt: true
- Requests with valid JWT work
- Requests without JWT get 401
- Secure for production

## Recommended Approach

1. **Deploy with logging** (see DEPLOY-FETCH-JOBS-NOW.md)
2. **Test with proper headers** to confirm function works
3. **Update all client code** to send correct headers
4. **Keep JWT verification enabled** for security

## Client Code Checklist

✅ All fetch calls include Authorization header
✅ All fetch calls include apikey header
✅ Authorization uses "Bearer " prefix
✅ Using correct anon key for project
✅ Handling session expiration for logged-in users

## Still Getting 401?

If you've deployed the updated function and are still getting 401:

1. **Check the logs** - What headers is the function receiving?
2. **Verify the token** - Is it valid? Correct format?
3. **Test with curl** - Does it work outside your app?
4. **Try without JWT** - Does it work with --no-verify-jwt?

The logs will tell you exactly what's wrong!
