# Deploy Interview Reminder System

## Edge Function: send-interview-reminder

Create `supabase/functions/send-interview-reminder/index.ts`:

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2';

serve(async (req) => {
  const { interviewId, type, test } = await req.json();
  const supabase = createClient(
    Deno.env.get('SUPABASE_URL') ?? '',
    Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
  );

  const { data: interview } = await supabase
    .from('interviews').select('*, user:user_id(*)').eq('id', interviewId).single();

  if (type === 'email') {
    await fetch('https://api.resend.com/emails', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('RESEND_API_KEY')}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        from: 'interviews@jobtomize.com',
        to: interview.user.email,
        subject: `Interview Reminder: ${interview.company}`,
        html: `<h2>Upcoming Interview</h2>
               <p>Company: ${interview.company}</p>
               <p>Role: ${interview.role}</p>
               <p>Date: ${interview.scheduled_date} at ${interview.start_time}</p>
               ${interview.meeting_link ? `<p><a href="${interview.meeting_link}">Join Meeting</a></p>` : ''}`
      })
    });
  } else if (type === 'sms') {
    await fetch('https://api.twilio.com/2010-04-01/Accounts/${ACCOUNT_SID}/Messages.json', {
      method: 'POST',
      headers: { 'Authorization': `Basic ${btoa(`${Deno.env.get('TWILIO_ACCOUNT_SID')}:${Deno.env.get('TWILIO_AUTH_TOKEN')}`)}` },
      body: new URLSearchParams({
        To: interview.user.phone,
        From: Deno.env.get('TWILIO_PHONE_NUMBER') || '',
        Body: `Interview Reminder: ${interview.company} - ${interview.role} on ${interview.scheduled_date} at ${interview.start_time}`
      })
    });
  }

  return new Response(JSON.stringify({ success: true }));
});
```

## Cron Schedule (pg_cron)

```sql
-- Run every hour to check for upcoming interviews
SELECT cron.schedule(
  'send-interview-reminders',
  '0 * * * *',
  $$
  SELECT net.http_post(
    url := 'https://your-project.supabase.co/functions/v1/process-interview-reminders',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer ' || current_setting('app.service_role_key') || '"}'::jsonb
  );
  $$
);
```

## Deploy

```bash
supabase functions deploy send-interview-reminder
supabase secrets set RESEND_API_KEY=your_key
supabase secrets set TWILIO_ACCOUNT_SID=your_sid
supabase secrets set TWILIO_AUTH_TOKEN=your_token
supabase secrets set TWILIO_PHONE_NUMBER=+1234567890
```
