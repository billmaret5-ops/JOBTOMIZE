# ✅ JSearch API Integration Setup - FINAL STEPS

## 🎯 Current Status
- ✅ RapidAPI Key configured in Supabase: `82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7`
- ✅ Secret name in Supabase: **"Jsearch"**
- ✅ Frontend service ready to call the function
- ⚠️ **NEED TO DO**: Deploy the fetch-jobs edge function

---

## 📋 STEP 1: Deploy fetch-jobs Function (5 minutes)

### Option A: Via Supabase Dashboard (EASIEST)

1. **Go to Supabase Dashboard**
   - URL: https://supabase.com/dashboard/project/YOUR_PROJECT_ID/functions
   - Click on **Edge Functions** in the left sidebar

2. **Create/Edit fetch-jobs Function**
   - If `fetch-jobs` exists: Click it → Click "Edit"
   - If it doesn't exist: Click "New Function" → Name: `fetch-jobs`

3. **Paste This Complete Code**

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20,
      job_type,
      remote,
      experience_level
    } = await req.json();

    const rapidApiKey = Deno.env.get('Jsearch') || Deno.env.get('RAPIDAPI_KEY');
    
    if (!rapidApiKey) {
      throw new Error('RapidAPI key not configured');
    }

    const searchQuery = location ? query + ' in ' + location : query;
    
    let employmentTypes = '';
    if (job_type === 'Full-time') employmentTypes = 'FULLTIME';
    else if (job_type === 'Part-time') employmentTypes = 'PARTTIME';
    else if (job_type === 'Contract') employmentTypes = 'CONTRACTOR';
    else if (job_type === 'Internship') employmentTypes = 'INTERN';

    const apiUrl = new URL('https://jsearch.p.rapidapi.com/search');
    apiUrl.searchParams.append('query', searchQuery);
    apiUrl.searchParams.append('page', page.toString());
    apiUrl.searchParams.append('num_pages', '1');
    
    if (remote) apiUrl.searchParams.append('remote_jobs_only', 'true');
    if (employmentTypes) apiUrl.searchParams.append('employment_types', employmentTypes);
    if (experience_level) apiUrl.searchParams.append('job_requirements', experience_level.toUpperCase());

    console.log('Fetching from JSearch:', apiUrl.toString());

    const response = await fetch(apiUrl.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('JSearch error:', response.status, errorText);
      throw new Error('JSearch API error: ' + response.status);
    }

    const data = await response.json();
    
    const jobs = (data.data || []).map((job: any) => {
      const minSal = job.job_min_salary || 'N/A';
      const maxSal = job.job_max_salary || 'N/A';
      const salaryStr = job.job_salary || (minSal + ' - ' + maxSal);
      
      let expLevel = undefined;
      if (job.job_required_experience?.required_experience_in_months) {
        const months = job.job_required_experience.required_experience_in_months;
        if (months < 24) expLevel = 'Entry';
        else if (months < 60) expLevel = 'Mid';
        else expLevel = 'Senior';
      }
      
      return {
        id: job.job_id || 'job_' + Date.now() + '_' + Math.random(),
        title: job.job_title || 'Untitled Position',
        company: job.employer_name || 'Unknown Company',
        location: (job.job_city && job.job_state) ? 
          job.job_city + ', ' + job.job_state : 
          (job.job_country || 'Location not specified'),
        description: job.job_description || 'No description available',
        salary: salaryStr !== 'N/A - N/A' ? salaryStr : undefined,
        type: job.job_employment_type || 'Full-time',
        posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
        apply_url: job.job_apply_link || job.job_google_link || '#',
        source: 'JSearch',
        skills: job.job_required_skills || [],
        remote: job.job_is_remote || false,
        experience_level: expLevel
      };
    });

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page,
      totalPages: Math.ceil((data.total || jobs.length) / limit),
      source: 'RapidAPI JSearch'
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

4. **Click "Deploy"** (top right corner)
5. **Wait for "Deployed successfully"** message

---

## 🧪 STEP 2: Test the Integration

### Test in Supabase Dashboard

1. Go to **Edge Functions** → **fetch-jobs** → **Invoke** tab
2. Paste this test JSON:

```json
{
  "query": "software engineer",
  "location": "San Francisco",
  "page": 1,
  "limit": 10
}
```

3. Click **Invoke**
4. You should see real job listings from JSearch!

### Test in Your App

1. Open your app
2. Go to the Job Search page
3. Search for "software engineer" in "San Francisco"
4. You should see real jobs from Indeed, LinkedIn, Glassdoor!

---

## ✅ Verification Checklist

- [ ] fetch-jobs function deployed in Supabase
- [ ] Test in Supabase dashboard returns real jobs
- [ ] App job search shows real listings
- [ ] No console errors in browser (F12)
- [ ] Jobs have real company names and descriptions

---

## 🐛 Troubleshooting

### Error: "RapidAPI key not configured"
- Go to Supabase → Project Settings → Edge Functions → Secrets
- Verify secret named "Jsearch" exists with value: `82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7`

### Error: "Failed to fetch jobs"
- Check browser console (F12) for detailed error
- Verify function is deployed (should show green checkmark)
- Try invoking directly in Supabase dashboard

### No jobs returned
- Check if your search query is too specific
- Try broader search: "software" or "engineer"
- Check JSearch API status on RapidAPI dashboard

---

## 🎉 Success!

Once deployed, your app will fetch REAL job listings from:
- Indeed
- LinkedIn  
- Glassdoor
- ZipRecruiter
- And many more!

All through the JSearch API via RapidAPI.
