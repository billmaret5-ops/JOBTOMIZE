# Deploy Team Collaboration RLS Policies NOW

## Quick Deployment (3 Methods)

### Method 1: Supabase Dashboard (Easiest)
1. Go to your Supabase Dashboard
2. Navigate to **SQL Editor**
3. Click **New Query**
4. Copy the entire contents of `supabase/migrations/create_team_collaboration_rls_policies.sql`
5. Paste into the SQL Editor
6. Click **Run** (or press Cmd/Ctrl + Enter)
7. Wait for "Success. No rows returned" message

### Method 2: Supabase CLI (Recommended)
```bash
# 1. Install Supabase CLI (if not installed)
npm install -g supabase

# 2. Login to Supabase
supabase login

# 3. Link your project
supabase link --project-ref YOUR_PROJECT_REF

# 4. Push the migration
supabase db push

# 5. Verify deployment
supabase db diff
```

### Method 3: Direct SQL Connection
```bash
# Connect to your database
psql "postgresql://postgres:[YOUR-PASSWORD]@db.[YOUR-PROJECT-REF].supabase.co:5432/postgres"

# Run the migration file
\i supabase/migrations/create_team_collaboration_rls_policies.sql
```

## Verification Steps

### 1. Check RLS is Enabled
```sql
SELECT tablename, rowsecurity 
FROM pg_tables 
WHERE schemaname = 'public' 
AND tablename IN ('resumes', 'job_applications', 'email_campaigns');
```

### 2. Verify Policies Exist
```sql
SELECT schemaname, tablename, policyname, permissive, roles, cmd
FROM pg_policies
WHERE tablename IN ('resumes', 'job_applications', 'email_campaigns')
ORDER BY tablename, policyname;
```

### 3. Test Helper Functions
```sql
-- Test is_owner function
SELECT is_owner(auth.uid(), 'some-resource-id');

-- Test has_shared_access function
SELECT has_shared_access(auth.uid(), 'some-resource-id', 'resumes');
```

## Post-Deployment Testing

### Create Test Data
```sql
-- Insert test collaboration group
INSERT INTO collaboration_groups (name, description, created_by)
VALUES ('Test Team', 'Testing collaboration', auth.uid());

-- Add member to group
INSERT INTO collaboration_group_members (group_id, user_id, role)
VALUES ('group-id', 'user-id', 'Editor');

-- Share a resume
INSERT INTO shared_resources (resource_id, resource_type, shared_with_user_id, permission_level, shared_by)
VALUES ('resume-id', 'resumes', 'user-id', 'Editor', auth.uid());
```

### Test Access Control
```typescript
// Test in your app
import { supabase } from './lib/supabase';

// Try to read shared resume
const { data, error } = await supabase
  .from('resumes')
  .select('*')
  .eq('id', 'shared-resume-id')
  .single();

// Try to update with edit permission
const { error: updateError } = await supabase
  .from('resumes')
  .update({ title: 'Updated Title' })
  .eq('id', 'shared-resume-id');
```

## Troubleshooting

### Error: "new row violates row-level security policy"
- User doesn't have permission to access the resource
- Check if resource is shared with the user
- Verify user's role in collaboration group

### Error: "permission denied for table"
- RLS might not be enabled on the table
- Run: `ALTER TABLE table_name ENABLE ROW LEVEL SECURITY;`

### Policies Not Working
1. Check if RLS is enabled: `SELECT * FROM pg_tables WHERE tablename = 'your_table';`
2. Verify policies exist: `SELECT * FROM pg_policies WHERE tablename = 'your_table';`
3. Test helper functions directly in SQL Editor
4. Check user authentication: `SELECT auth.uid();`

## Rollback (If Needed)
```sql
-- Disable RLS on tables
ALTER TABLE resumes DISABLE ROW LEVEL SECURITY;
ALTER TABLE job_applications DISABLE ROW LEVEL SECURITY;
ALTER TABLE email_campaigns DISABLE ROW LEVEL SECURITY;

-- Drop policies
DROP POLICY IF EXISTS "Users can view own resumes" ON resumes;
-- (repeat for all policies)

-- Drop helper functions
DROP FUNCTION IF EXISTS is_owner;
DROP FUNCTION IF EXISTS has_shared_access;
DROP FUNCTION IF EXISTS has_edit_permission;
DROP FUNCTION IF EXISTS is_collaboration_admin;
```

## Support
- Check TEAM-COLLABORATION-RLS-GUIDE.md for usage examples
- Review create_team_collaboration_rls_policies.sql for policy details
- Test with the TypeScript examples provided
