#!/bin/bash

# 🚀 ONE-COMMAND VERCEL DEPLOY
# Run this after installing Vercel CLI: npm install -g vercel

echo "🚀 Deploying to Vercel..."
echo ""
echo "⚠️  IMPORTANT: After first deploy, add these env vars in Vercel dashboard:"
echo "   VITE_SUPABASE_URL"
echo "   VITE_SUPABASE_ANON_KEY"
echo ""
echo "📍 Dashboard: https://vercel.com/dashboard"
echo ""

# Deploy to production
vercel --prod

echo ""
echo "✅ DEPLOYED!"
echo ""
echo "🔑 Now add environment variables:"
echo "   1. Go to https://vercel.com/dashboard"
echo "   2. Click your project → Settings → Environment Variables"
echo "   3. Add VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY"
echo "   4. Run: vercel --prod (again to redeploy with env vars)"
echo ""
