# Admin Access Guide for Jobtomize.com

## Admin Login System

Your admin login system is now fully configured and ready to use!

### Access URLs

- **Admin Login Page**: `https://yourdomain.com/admin-login`
- **Admin Dashboard**: `https://yourdomain.com/admin-dashboard` (protected)
- **Alternative**: `https://yourdomain.com/admin` (redirects to login)

### How to Create Admin Users

#### Option 1: Using Supabase Dashboard (Recommended)

1. Go to your Supabase project dashboard
2. Navigate to **Table Editor** → **user_roles**
3. Click **Insert** → **Insert row**
4. Fill in:
   - `user_id`: The UUID of the user (from auth.users table)
   - `role`: `admin`
   - `created_at`: (auto-filled)
5. Click **Save**

#### Option 2: Using SQL

Run this SQL in your Supabase SQL Editor:

```sql
-- First, create a user account (or use existing user_id)
-- Then assign admin role
INSERT INTO user_roles (user_id, role)
VALUES ('USER_UUID_HERE', 'admin');
```

#### Option 3: Direct Database Insert

```sql
-- Create admin user and assign role in one go
INSERT INTO auth.users (email, encrypted_password, email_confirmed_at)
VALUES ('admin@jobtomize.com', crypt('your_password', gen_salt('bf')), now());

-- Get the user_id and insert role
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin' FROM auth.users WHERE email = 'admin@jobtomize.com';
```

### Admin Features

The admin dashboard provides full access to:

✅ **User Management** - View, edit, and manage all users
✅ **System Analytics** - Platform-wide statistics and metrics
✅ **Database Management** - Direct database access and tools
✅ **System Health** - Monitor server performance and uptime
✅ **Activity Logs** - Track all user and system activities
✅ **Settings** - Configure system-wide settings

### Security Features

- ✅ Protected routes with authentication check
- ✅ Role-based access control (RBAC)
- ✅ Automatic redirect for non-admin users
- ✅ Session management
- ✅ Secure password handling

### Testing Admin Access

1. Create an admin user using one of the methods above
2. Navigate to `/admin-login`
3. Enter admin credentials
4. You'll be automatically redirected to `/admin-dashboard`

### Troubleshooting

**Issue**: "Access denied. Admin privileges required"
- **Solution**: Ensure the user has a record in `user_roles` table with `role = 'admin'`

**Issue**: Login page doesn't redirect
- **Solution**: Check browser console for errors, verify Supabase connection

**Issue**: Can't access admin dashboard
- **Solution**: Clear browser cache and cookies, try logging in again

### Default Admin Credentials

For development/testing, you can create a test admin:

```sql
-- Create test admin (CHANGE PASSWORD IN PRODUCTION!)
INSERT INTO user_roles (user_id, role)
SELECT id, 'admin' FROM auth.users WHERE email = 'admin@jobtomize.com';
```

**⚠️ IMPORTANT**: Always change default passwords in production!

### Production Deployment

1. Ensure `user_roles` table exists in production database
2. Create admin users via Supabase dashboard
3. Test admin login before going live
4. Set up proper RLS policies for security
5. Monitor admin activity logs regularly

---

Your admin system is production-ready! 🎉
