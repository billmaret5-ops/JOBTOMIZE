// IMPROVED fetch-jobs Edge Function Code
// Copy this to: supabase/functions/fetch-jobs/index.ts
// Then deploy with: supabase functions deploy fetch-jobs --no-verify-jwt

// ✅ Whitelisted origins for CORS (add staging/preview URLs here)
const allowedOrigins = new Set([
  'https://jobtomize.com',
  'https://www.jobtomize.com',
  'http://localhost:5173',
  'http://localhost:3000',
  'http://127.0.0.1:5173'
]);

// ✅ Safer CORS origin resolution
function resolveOrigin(req: Request): string {
  const origin = req.headers.get('Origin') || '';
  return allowedOrigins.has(origin) ? origin : 'https://jobtomize.com';
}

function getCorsHeaders(req: Request) {
  return {
    'Access-Control-Allow-Origin': resolveOrigin(req),
    'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
    'Access-Control-Allow-Methods': 'GET, POST, OPTIONS'
  };
}

// ✅ Whitelisted fields for POST body
interface JobSearchParams {
  query?: string;
  location?: string;
  page?: number;
  limit?: number;
  remote?: boolean;
  employment_type?: string;
}

Deno.serve(async (req) => {
  const corsHeaders = getCorsHeaders(req);

  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const pathname = url.pathname;

  // Health check
  if (pathname.includes('/health')) {
    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    return new Response(JSON.stringify({
      ok: true,
      rapidapi_configured: !!rapidApiKey,
      timestamp: new Date().toISOString()
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }

  // ✅ Main search - supports GET and POST
  if (pathname.includes('/search') || req.method === 'POST') {
    try {
      const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
      const rapidApiHost = 'jsearch.p.rapidapi.com';

      if (!rapidApiKey) {
        return new Response(JSON.stringify({
          error: 'API key not configured'
        }), {
          status: 500,
          headers: { ...corsHeaders, 'Content-Type': 'application/json' }
        });
      }

      // ✅ Parse params - whitelist fields from POST body
      let params: JobSearchParams;
      if (req.method === 'GET') {
        params = {
          query: url.searchParams.get('query') || 'software engineer',
          location: url.searchParams.get('location') || '',
          page: parseInt(url.searchParams.get('page') || '1'),
          limit: parseInt(url.searchParams.get('limit') || '20')
        };
      } else {
        const body = await req.json();
        // Only extract whitelisted fields
        params = {
          query: body.query || 'software engineer',
          location: body.location || '',
          page: body.page || 1,
          limit: body.limit || 20,
          remote: body.remote,
          employment_type: body.employment_type
        };
      }

      // Build search query
      let searchQuery = params.query || 'software engineer';
      if (params.location) {
        searchQuery += ` in ${params.location}`;
      }

      const apiUrl = `https://${rapidApiHost}/search?query=${encodeURIComponent(searchQuery)}&page=${params.page}&num_pages=1`;

      // Fetch REAL jobs from RapidAPI
      const response = await fetch(apiUrl, {
        headers: {
          'X-RapidAPI-Key': rapidApiKey,
          'X-RapidAPI-Host': rapidApiHost
        }
      });

      if (!response.ok) {
        throw new Error(`RapidAPI returned ${response.status}`);
      }

      const data = await response.json();
      
      // Transform to our format
      const jobs = (data.data || []).map((job: any) => ({
        id: job.job_id || `job_${Date.now()}_${Math.random()}`,
        title: job.job_title || 'Untitled Position',
        company: job.employer_name || 'Unknown Company',
        location: job.job_city && job.job_state 
          ? `${job.job_city}, ${job.job_state}` 
          : job.job_country || 'Remote',
        description: job.job_description || 'No description',
        salary: job.job_min_salary && job.job_max_salary 
          ? `$${job.job_min_salary}-$${job.job_max_salary}` 
          : undefined,
        type: job.job_employment_type || 'Full-time',
        posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
        apply_url: job.job_apply_link || job.job_google_link || '#',
        source: 'jsearch',
        skills: job.job_required_skills || [],
        remote: job.job_is_remote || false
      }));

      // ✅ Add Cache-Control for GET requests
      const cacheHeaders = req.method === 'GET' 
        ? { 'Cache-Control': 'public, max-age=60, s-maxage=300' }
        : {};

      return new Response(JSON.stringify({
        jobs,
        total: data.total || jobs.length,
        page: params.page,
        totalPages: Math.ceil((data.total || jobs.length) / (params.limit || 20))
      }), {
        headers: { 
          ...corsHeaders, 
          ...cacheHeaders,
          'Content-Type': 'application/json' 
        }
      });

    } catch (error) {
      console.error('Job fetch error:', error);
      return new Response(JSON.stringify({ 
        error: 'Failed to fetch jobs',
        details: error.message 
      }), {
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      });
    }
  }

  return new Response(JSON.stringify({ error: 'Not found' }), {
    status: 404,
    headers: { ...corsHeaders, 'Content-Type': 'application/json' }
  });
});
