# 🌐 No Terminal Setup Guide

## Set RapidAPI Key Without Terminal Access

Since you don't have terminal access, use this browser-based method:

---

## ✅ METHOD 1: Browser-Based Setup (EASIEST)

### Step 1: Get Your RapidAPI Key
1. Go to https://rapidapi.com/letscrape-6bRBa3QguO5/api/jsearch
2. Click "Subscribe to Test"
3. Choose the FREE plan (2,500 requests/month)
4. Copy your API key (starts with something like `abc123...`)

### Step 2: Get Your Supabase Access Token
1. Go to https://supabase.com/dashboard/account/tokens
2. Click **"Generate New Token"**
3. Give it a name like "Set Secrets"
4. Copy the token (starts with `sbp_...`)

### Step 3: Open the Browser Tool
1. **Open the file `SET-RAPIDAPI-KEY-BROWSER.html` in your browser**
2. Paste your Supabase Access Token
3. Paste your RapidAPI Key
4. Click "Set Secret & Deploy"
5. Wait for success message ✅

### Step 4: Test It Works
Click this link to test: https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health

Should return: `{"status":"ok","rapidapi_configured":true}`

---

## 🔄 METHOD 2: Supabase Dashboard (Alternative)

### Try This Dashboard Path:
1. Go to https://supabase.com/dashboard/project/rgdvevmqrjlkqfkiucdh
2. Click **"Project Settings"** (bottom left)
3. Look for **"Edge Functions"** or **"Configuration"**
4. Find **"Secrets"** or **"Environment Variables"**
5. Add: `RAPIDAPI_KEY` = `your_key_here`

**Note:** Some accounts hide this UI - if you don't see it, use Method 1 above.

---

## 🧪 Testing Your Setup

### Test 1: Health Check
```
https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health
```
Expected: `{"status":"ok","rapidapi_configured":true}`

### Test 2: Search Jobs
```
https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/search?query=software%20engineer&location=remote
```
Expected: JSON with real jobs

### Test 3: In Your App
1. Open your job search platform
2. Search for "software engineer"
3. You should see REAL jobs appear!

---

## ❌ Troubleshooting

### "Access token invalid"
- Make sure you copied the FULL token from Supabase
- Token should start with `sbp_`
- Generate a new token if needed

### "RapidAPI key not configured"
- Wait 30 seconds after setting the secret
- The edge function may need time to pick up the new secret
- Try the health check again

### "Rate limit exceeded"
- You've used your free 2,500 requests
- Upgrade your RapidAPI plan or wait until next month

### Still not working?
1. Open browser console (F12)
2. Look for error messages
3. Check the Network tab for failed requests
4. Share the error message for help

---

## 🎉 Success Checklist

- [ ] RapidAPI account created
- [ ] JSearch API subscribed (FREE plan)
- [ ] Supabase access token generated
- [ ] Secret set using browser tool
- [ ] Health check returns `rapidapi_configured: true`
- [ ] Search returns real jobs
- [ ] App shows real job listings

---

## 📞 Need Help?

If you're still stuck, provide:
1. Screenshot of any error messages
2. Response from health check endpoint
3. Browser console errors (F12 → Console tab)

Your platform is 99% ready - just need that API key set! 🚀
