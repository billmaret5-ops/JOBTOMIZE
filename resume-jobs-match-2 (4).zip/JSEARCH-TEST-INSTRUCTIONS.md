# JSearch API Integration Test Instructions

## ✅ You've deployed the fixed code! Now let's verify it works.

### Step 1: Open the Verification Page

Navigate to: **http://localhost:5173/verify-jsearch**

(Or your deployed URL + `/verify-jsearch`)

### Step 2: Run the Test

1. Click the **"Run Full Verification"** button
2. Wait 5-10 seconds for results

### Step 3: Check Results

#### ✅ SUCCESS Indicators:
- Health Check shows: `{ "ok": true, "timestamp": "..." }`
- Integration Status badge shows: **"REAL JOBS"** (green)
- Job listings show real companies (not TechCorp, StartupXYZ)
- Jobs have real URLs to Indeed/LinkedIn/Glassdoor

#### ❌ FAILURE Indicators:
- Integration Status shows: **"MOCK DATA"** (red)
- Companies are: TechCorp, StartupXYZ, InnovateLabs
- Job IDs start with "mock-"
- Error messages appear

### Step 4: Verify Real Data

Check the job listings for:
- Real company names (Google, Microsoft, etc.)
- Actual job URLs that link to job boards
- Real locations (not "Remote" for everything)
- Varied job titles and descriptions

### Alternative Test Routes

If you want to test different endpoints:

1. **Basic Test**: http://localhost:5173/jobs-real-test
2. **Diagnostics**: http://localhost:5173/jobs-test
3. **Live Search**: http://localhost:5173/live-jobs

### Troubleshooting

If you see errors:

1. **Check Supabase Logs**: Go to Supabase Dashboard > Edge Functions > fetch-jobs > Logs
2. **Verify RapidAPI Key**: Make sure it's set in Supabase secrets
3. **Check API Quota**: Verify you haven't exceeded RapidAPI limits

### What to Look For

**Mock Data (BAD):**
```json
{
  "company": "TechCorp",
  "id": "mock-job-1",
  "title": "Senior Software Engineer"
}
```

**Real Data (GOOD):**
```json
{
  "company": "Google",
  "id": "abc123xyz",
  "title": "Software Engineer III",
  "url": "https://www.google.com/careers/...",
  "posted_date": "2 days ago"
}
```

## Next Steps

Once verified:
- The `/live-jobs` page will show real jobs
- Job search throughout the app will use real data
- Job alerts will send actual job listings
