# AI Resume Optimizer - Complete Guide

## Overview
The AI Resume Optimizer is a powerful tool that analyzes resumes against job descriptions and provides actionable optimization suggestions using AI.

## Features

### 1. **ATS Score Calculation**
- Calculates a comprehensive ATS (Applicant Tracking System) compatibility score (0-100%)
- Provides overall feedback on resume quality
- Color-coded scoring (Green: 80+, Yellow: 60-79, Red: <60)

### 2. **Keyword Matching**
- Identifies matched keywords between resume and job description
- Highlights missing important keywords
- Visual badges for easy identification

### 3. **Skills Gap Analysis**
- Compares your skills with job requirements
- Identifies missing skills
- Provides recommendations for skill development

### 4. **Section-by-Section Recommendations**
- **Summary**: Optimization suggestions for professional summary
- **Experience**: Improvements for work experience descriptions
- **Education**: Enhancement tips for education section
- **Skills**: Skills section optimization

### 5. **Side-by-Side Comparison**
- Original vs. Optimized content comparison
- Visual highlighting of changes
- Easy-to-understand before/after view

## How to Use

### Step 1: Select a Resume
1. Go to Resume Management page
2. Navigate to "My Resumes" tab
3. Select the resume you want to optimize

### Step 2: Access AI Optimizer
1. Click on the "AI Optimizer" tab
2. You'll see the optimizer interface

### Step 3: Analyze Resume
1. Paste the job description in the text area
2. Click "Analyze Resume" button
3. Wait for AI analysis (usually 10-30 seconds)

### Step 4: Review Results
Navigate through the tabs:
- **Overview**: See ATS score and section-by-section feedback
- **Keywords**: Review matched and missing keywords
- **Skills Gap**: Analyze skills alignment
- **Comparison**: View original vs. optimized content

## Edge Function Deployment

The AI optimizer requires a Supabase edge function. Here's how to deploy it:

### Manual Deployment

Create a file: `supabase/functions/ai-resume-optimizer/index.ts`

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { resumeContent, jobDescription, resumeData } = await req.json();
    
    const gatewayApiKey = Deno.env.get("GATEWAY_API_KEY");
    if (!gatewayApiKey) {
      throw new Error("API Gateway key not configured");
    }

    const analysisPrompt = \`You are an expert resume optimizer and ATS specialist. Analyze the following resume against the job description and provide detailed optimization suggestions.

RESUME CONTENT:
\${resumeContent}

JOB DESCRIPTION:
\${jobDescription}

Provide a comprehensive analysis in the following JSON format:
{
  "atsScore": <number 0-100>,
  "overallFeedback": "<string>",
  "keywordMatches": {
    "matched": ["<keyword1>", "<keyword2>"],
    "missing": ["<keyword1>", "<keyword2>"]
  },
  "skillsGap": {
    "hasSkills": ["<skill1>", "<skill2>"],
    "missingSkills": ["<skill1>", "<skill2>"],
    "recommendations": ["<recommendation1>", "<recommendation2>"]
  },
  "sectionRecommendations": {
    "summary": {
      "score": <number 0-100>,
      "feedback": "<string>",
      "suggestions": ["<suggestion1>", "<suggestion2>"]
    },
    "experience": {
      "score": <number 0-100>,
      "feedback": "<string>",
      "suggestions": ["<suggestion1>", "<suggestion2>"]
    },
    "education": {
      "score": <number 0-100>,
      "feedback": "<string>",
      "suggestions": ["<suggestion1>", "<suggestion2>"]
    },
    "skills": {
      "score": <number 0-100>,
      "feedback": "<string>",
      "suggestions": ["<suggestion1>", "<suggestion2>"]
    }
  },
  "optimizedContent": {
    "summary": "<optimized summary text>",
    "experience": [{"title": "<title>", "company": "<company>", "description": "<optimized description>"}],
    "skills": ["<skill1>", "<skill2>"]
  }
}\`;

    const response = await fetch('https://ai.gateway.fastrouter.io/api/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'X-API-Key': gatewayApiKey
      },
      body: JSON.stringify({
        model: 'google/gemini-2.5-flash',
        messages: [{ role: 'user', content: analysisPrompt }],
        temperature: 0.7,
        response_format: { type: "json_object" }
      })
    });

    if (!response.ok) {
      throw new Error(\`AI API error: \${response.statusText}\`);
    }

    const data = await response.json();
    const analysisResult = JSON.parse(data.choices[0].message.content);
    
    return new Response(JSON.stringify(analysisResult), {
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  } catch (error) {
    console.error('Resume optimization error:', error);
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', ...corsHeaders }
    });
  }
});
```

### Deploy the Function

```bash
# Deploy to Supabase
supabase functions deploy ai-resume-optimizer
```

## Components Created

1. **AIResumeOptimizerPanel** (`src/components/AIResumeOptimizerPanel.tsx`)
   - Main optimizer interface
   - Handles job description input
   - Displays analysis results in tabs

2. **ResumeComparisonView** (`src/components/ResumeComparisonView.tsx`)
   - Side-by-side comparison component
   - Shows original vs. optimized content
   - Visual highlighting of improvements

## Integration

The optimizer is integrated into the Resume Management page as a new tab:
- Navigate to: Resume Management → AI Optimizer
- Requires a selected resume to function
- Uses the API Gateway for AI analysis

## Tips for Best Results

1. **Complete Job Descriptions**: Paste the full job description for better analysis
2. **Updated Resume**: Ensure your resume is current before optimization
3. **Review All Tabs**: Check all analysis tabs for comprehensive insights
4. **Apply Suggestions**: Use the comparison view to update your resume
5. **Iterate**: Re-analyze after making changes to track improvements

## Troubleshooting

### "Failed to analyze resume"
- Check that the edge function is deployed
- Verify GATEWAY_API_KEY is configured
- Ensure job description is provided

### Low ATS Score
- Add missing keywords from the Keywords tab
- Address skills gaps identified in Skills Gap tab
- Follow section-specific recommendations

### No Optimized Content
- The AI may need more context
- Try with a more detailed job description
- Ensure resume has sufficient content

## Future Enhancements

- One-click apply optimizations
- Save optimization history
- Compare multiple job descriptions
- Export optimization reports
- ATS score tracking over time
