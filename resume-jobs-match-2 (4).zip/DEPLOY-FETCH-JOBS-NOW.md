# Deploy fetch-jobs Edge Function - IMMEDIATE FIX

## 🚨 Current Issue
Getting 401 Unauthorized errors on fetch-jobs function endpoints.

## Root Cause
The function has `verify_jwt: true` enabled but requests aren't properly authenticated.

## Quick Fix Options

### Option 1: Deploy WITHOUT JWT Verification (Testing Only)
```bash
# Navigate to your project
cd supabase/functions/fetch-jobs

# Create index.ts with the updated code from FETCH-JOBS-UPDATED-CODE.ts
# Then deploy without JWT verification
supabase functions deploy fetch-jobs --no-verify-jwt
```

### Option 2: Keep JWT Verification (Recommended for Production)
```bash
# Deploy with JWT verification enabled (default)
supabase functions deploy fetch-jobs
```

## Manual Deployment Steps

### 1. Create/Update Function File
```bash
# Create the function directory if it doesn't exist
mkdir -p supabase/functions/fetch-jobs

# Copy the updated code
cat > supabase/functions/fetch-jobs/index.ts << 'EOF'
[PASTE CONTENT FROM FETCH-JOBS-UPDATED-CODE.ts HERE]
EOF
```

### 2. Deploy the Function
```bash
# Option A: Without JWT verification (for testing)
supabase functions deploy fetch-jobs --no-verify-jwt

# Option B: With JWT verification (production)
supabase functions deploy fetch-jobs
```

### 3. Test the Deployment
```bash
# Set your environment variables
export SUPABASE_URL="your-project-url"
export SUPABASE_ANON_KEY="your-anon-key"

# Test health endpoint
curl -sS \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/health"

# Test search endpoint
curl -sS \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/search?query=react&location=remote"
```

## Understanding JWT Verification

### What's Happening
- `verify_jwt: false` = Function accepts ANY request (no auth required)
- `verify_jwt: true` = Function requires valid Supabase JWT token

### When JWT Verification is Enabled
Requests MUST include:
1. **Authorization header**: `Bearer <valid-jwt-token>`
2. **apikey header**: `<your-anon-key>`

### Getting a Valid JWT Token

#### For Anonymous Requests
Use your anon key as the Bearer token:
```bash
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
apikey: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

#### For Authenticated Users
Get the user's session token:
```typescript
const { data: { session } } = await supabase.auth.getSession();
const token = session?.access_token;

// Use in requests
fetch(`${SUPABASE_URL}/functions/v1/fetch-jobs/search`, {
  headers: {
    'Authorization': `Bearer ${token}`,
    'apikey': SUPABASE_ANON_KEY
  }
});
```

## Checking Current JWT Setting

### Via Supabase Dashboard
1. Go to Edge Functions
2. Find `fetch-jobs` function
3. Check configuration for `verify_jwt` setting

### Via CLI
```bash
supabase functions list
```

## New Function Features

The updated function includes:

### 1. Comprehensive Logging
```typescript
console.log('=== FETCH-JOBS REQUEST ===');
console.log('Method:', req.method);
console.log('URL:', req.url);
console.log('Headers:', Object.fromEntries(req.headers.entries()));
```

### 2. Multiple Endpoints

**Health Check (GET)**
```
GET /functions/v1/fetch-jobs/health
```

**Search with Query Params (GET)**
```
GET /functions/v1/fetch-jobs/search?query=react&location=remote&page=1&limit=20
```

**Search with JSON Body (POST)**
```
POST /functions/v1/fetch-jobs
Body: {
  "query": "react",
  "location": "remote",
  "sources": ["indeed", "linkedin"],
  "page": 1,
  "limit": 20
}
```

### 3. Better Error Messages
All errors now return structured JSON with details.

## Viewing Function Logs

### Via Supabase Dashboard
1. Go to Edge Functions
2. Click on `fetch-jobs`
3. View Logs tab

### Via CLI
```bash
supabase functions logs fetch-jobs --follow
```

## Testing After Deployment

### 1. Test Without Auth (if JWT disabled)
```bash
curl -sS "$SUPABASE_URL/functions/v1/fetch-jobs/health"
```

### 2. Test With Auth (if JWT enabled)
```bash
curl -sS \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  "$SUPABASE_URL/functions/v1/fetch-jobs/health"
```

### 3. Check Logs
Look for the header logging output:
```
=== FETCH-JOBS REQUEST ===
Method: GET
URL: https://...
Headers: { authorization: 'Bearer ...', apikey: '...' }
```

## Troubleshooting 401 Errors

### If Still Getting 401 After Deployment

1. **Verify JWT Setting**
   ```bash
   supabase functions list
   # Check verify_jwt column
   ```

2. **Check Headers in Logs**
   - Look for the logged headers
   - Verify both `authorization` and `apikey` are present
   - Verify token format: `Bearer <token>`

3. **Test Token Validity**
   ```bash
   # Decode your anon key at jwt.io
   # Check expiration and issuer
   ```

4. **Try Without JWT**
   ```bash
   supabase functions deploy fetch-jobs --no-verify-jwt
   ```

## Next Steps

1. Deploy the function using one of the options above
2. Check the logs to see what headers are being received
3. Test the endpoints with proper authentication
4. Report back what you see in the logs

The comprehensive logging will show exactly what headers the function receives, which will help diagnose why authentication is failing.
