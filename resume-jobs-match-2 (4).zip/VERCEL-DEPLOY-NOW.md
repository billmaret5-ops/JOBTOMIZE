# 🚀 DEPLOY TO VERCEL - COPY/PASTE GUIDE

## ✅ YOU'RE READY - Everything is configured!

Your project already has `vercel.json` configured. Just follow these steps:

---

## 📋 STEP 1: Install Vercel CLI

Open your terminal and run:

```bash
npm install -g vercel
```

---

## 🔐 STEP 2: Login to Vercel

```bash
vercel login
```

This will open your browser. Click "Continue with GitHub" (or your method).

---

## 🚀 STEP 3: Deploy

In your project folder, run:

```bash
vercel
```

**Answer the prompts:**
- Set up and deploy? → **YES**
- Which scope? → Select your account
- Link to existing project? → **NO**
- What's your project's name? → **jobtomize** (or whatever you want)
- In which directory is your code? → **./** (press Enter)
- Want to override settings? → **NO**

**It will deploy in 30 seconds!**

---

## 🔑 STEP 4: Add Environment Variables

After first deploy, go to: https://vercel.com/dashboard

1. Click your project
2. Go to **Settings** → **Environment Variables**
3. Add these 2 variables:

```
VITE_SUPABASE_URL = https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY = your-anon-key-here
```

**Where to find these:**
- Go to https://supabase.com/dashboard
- Select your project
- Go to Settings → API
- Copy "Project URL" and "anon public" key

---

## 🔄 STEP 5: Redeploy with Env Vars

```bash
vercel --prod
```

**DONE! Your site is live!**

---

## 🎯 WHAT YOU GET

✅ Live URL: `https://jobtomize.vercel.app`
✅ Auto-deploys on git push
✅ Free SSL certificate
✅ Global CDN
✅ Clear build logs
✅ Easy rollbacks

---

## 🐛 IF BUILD FAILS

Check build logs in Vercel dashboard. Common fixes:

1. **Missing env vars** → Add them in Vercel settings
2. **Build errors** → Check the log, fix locally, redeploy
3. **Supabase connection** → Verify URL and key are correct

---

## 🔗 CUSTOM DOMAIN (Optional)

1. Go to Vercel project settings
2. Click **Domains**
3. Add your domain (e.g., jobtomize.com)
4. Update DNS records (Vercel shows you exactly what to add)

---

## 📊 NEXT STEPS AFTER DEPLOY

1. Visit your live URL
2. Test login/signup
3. Test job search
4. Check browser console for errors
5. Fix ONE thing at a time

---

## 💡 PRO TIP

Every time you push to GitHub, Vercel auto-deploys. You can:
- Deploy branches for testing
- Rollback to previous versions
- See preview URLs before going live

**Your Supabase functions still work separately - fix them later!**

---

## 🆘 NEED HELP?

Run this and send me the output:

```bash
vercel --version
node --version
npm --version
```

**LET'S GET YOU LIVE! 🚀**
