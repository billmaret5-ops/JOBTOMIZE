# 🎯 Famous.ai Deployment - Step-by-Step Instructions

## 📋 What You Need

1. **Famous.ai Account** - Your hosting account credentials
2. **FTP/SFTP Access** - Get from Famous.ai dashboard
3. **Domain Access** - jobtomize.com registrar login
4. **This Codebase** - Already ready to deploy!

---

## 🚀 STEP-BY-STEP DEPLOYMENT

### ✅ STEP 1: Build Your Application (5 minutes)

Open terminal in your project folder:

```bash
# Install dependencies (if not already done)
npm install

# Build production version
npm run build
```

**What this does:**
- Creates optimized production files
- Minifies JavaScript and CSS
- Generates `dist/` folder with all files ready to upload

**Verify build succeeded:**
```bash
ls dist/
# Should see: index.html, assets/, manifest.json, etc.
```

---

### ✅ STEP 2: Get Famous.ai FTP Credentials (2 minutes)

1. Log into Famous.ai dashboard
2. Find **FTP Access** or **File Manager** section
3. Note down:
   - **Host**: `ftp.famous.ai` or IP address
   - **Username**: Your FTP username
   - **Password**: Your FTP password
   - **Port**: Usually 21 (FTP) or 22 (SFTP)
   - **Directory**: Usually `public_html` or `www`

---

### ✅ STEP 3: Upload Files to Famous.ai (10 minutes)

**Option A: Using FileZilla (Recommended for beginners)**

1. Download FileZilla: https://filezilla-project.org/
2. Open FileZilla
3. Enter credentials:
   - Host: `sftp://your-server.famous.ai`
   - Username: [from Step 2]
   - Password: [from Step 2]
   - Port: 22
4. Click **Quickconnect**
5. Navigate to `public_html` or `www` folder (right panel)
6. **DELETE all existing files** in that folder (if any)
7. Navigate to your `dist/` folder (left panel)
8. **Select ALL files** in dist/ folder
9. **Right-click → Upload**
10. Wait for upload to complete (2-5 minutes)

**Option B: Using Command Line (Advanced)**

```bash
# Connect via SFTP
sftp username@your-server.famous.ai

# Navigate to web directory
cd public_html

# Upload all files from dist
put -r dist/*

# Verify upload
ls -la

# Exit
exit
```

---

### ✅ STEP 4: Configure DNS for jobtomize.com (5 minutes)

1. **Get Famous.ai Server IP:**
   - Check Famous.ai dashboard for your server IP
   - Usually shown in "Account Details" or "Server Info"
   - Example: `123.45.67.89`

2. **Log into Domain Registrar** (GoDaddy, Namecheap, etc.)

3. **Update DNS Records:**

   **Delete any existing A records for @ and www**

   **Add these new records:**
   ```
   Type: A
   Name: @
   Value: [Famous.ai IP address]
   TTL: 3600 (or Auto)

   Type: A
   Name: www
   Value: [Famous.ai IP address]
   TTL: 3600 (or Auto)
   ```

4. **Save changes**

**DNS propagation takes 5-60 minutes**

---

### ✅ STEP 5: Enable SSL Certificate (5 minutes)

**In Famous.ai Dashboard:**

1. Go to **SSL/TLS** or **Security** section
2. Select **Let's Encrypt** (free)
3. Enter domain: `jobtomize.com`
4. Add: `www.jobtomize.com`
5. Click **Install Certificate**
6. Wait 5-15 minutes for activation

**OR if Famous.ai has AutoSSL:**
- It should automatically detect your domain and install SSL
- Check after 15 minutes

---

### ✅ STEP 6: Verify Deployment (5 minutes)

**Test these URLs in browser:**

1. ✅ http://jobtomize.com (should redirect to https)
2. ✅ https://jobtomize.com (should load homepage)
3. ✅ https://www.jobtomize.com (should work)
4. ✅ https://jobtomize.com/job-search (should load job search)
5. ✅ https://jobtomize.com/resume-builder (should load resume builder)

**Test functionality:**
- [ ] Click "Sign Up" - modal opens
- [ ] Click "Login" - modal opens
- [ ] Navigate to Job Search
- [ ] Search for jobs (should return results)
- [ ] Click on a job card (should open details)
- [ ] Test all navigation links

---

## 🆘 TROUBLESHOOTING

### Problem: "404 Not Found" on routes

**Solution:**
1. Verify `.htaccess` file is in root directory
2. Check if `mod_rewrite` is enabled on server
3. Contact Famous.ai support: "Please enable mod_rewrite for SPA routing"

### Problem: Blank white page

**Solution:**
1. Open browser console (F12)
2. Check for errors
3. Verify all files uploaded correctly
4. Check file permissions (should be 644 for files, 755 for folders)

### Problem: "Failed to fetch jobs"

**Solution:**
1. This is normal - Supabase edge functions are working
2. Jobs will load after a few seconds
3. Check browser console for specific errors

### Problem: SSL not working

**Solution:**
1. Wait 15-30 minutes after DNS propagation
2. Check DNS is pointing correctly: `nslookup jobtomize.com`
3. Contact Famous.ai support for SSL installation help

### Problem: www not working

**Solution:**
1. Verify you added A record for `www` subdomain
2. Wait for DNS propagation (up to 60 minutes)
3. Clear browser cache

---

## 📞 SUPPORT CONTACTS

**Famous.ai Support:**
- Tell them: "I deployed a React SPA and need mod_rewrite enabled"
- Ask for: "SSL certificate for jobtomize.com"

**What to provide:**
- Domain: jobtomize.com
- Issue: [specific problem]
- Server: [your server name/IP]

---

## ✅ SUCCESS CHECKLIST

- [ ] `npm run build` completed successfully
- [ ] All files uploaded to Famous.ai
- [ ] DNS records updated (A records for @ and www)
- [ ] SSL certificate installed
- [ ] https://jobtomize.com loads
- [ ] All pages accessible
- [ ] Job search works
- [ ] Login/signup works
- [ ] Same as deploypad.app

---

## 🎉 YOU'RE DONE!

Your Jobtomize.com is now live on Famous.ai hosting!

**Next steps:**
1. Test all features thoroughly
2. Share with users
3. Monitor performance in Famous.ai dashboard
4. Set up backups (if available)

---

## 📝 QUICK REFERENCE

**Build command:**
```bash
npm run build
```

**Check DNS:**
```bash
nslookup jobtomize.com
```

**Test SSL:**
```bash
curl -I https://jobtomize.com
```

**Files to upload:**
Everything in `dist/` folder

**Critical file:**
`.htaccess` (for SPA routing)
