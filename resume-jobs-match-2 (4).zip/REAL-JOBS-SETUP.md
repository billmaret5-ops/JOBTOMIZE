# 🎯 Setup Real Job Matching with RapidAPI

## ✅ Prerequisites
- [x] RAPIDAPI_KEY already uploaded to Supabase

## 🚀 Step 1: Create fetch-jobs Edge Function

### Go to Supabase Dashboard
1. Open your project: https://supabase.com/dashboard
2. Navigate to: **Edge Functions** (left sidebar)
3. Click: **Create a new function**
4. Name: `fetch-jobs`
5. Paste the code below:

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { 
      query = 'software engineer',
      location = '',
      job_type,
      remote,
      page = 1,
    } = await req.json()

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY')
    if (!rapidApiKey) {
      throw new Error('RAPIDAPI_KEY not configured')
    }

    // Build search query
    let searchQuery = query
    if (location) searchQuery += ` in ${location}`
    if (remote) searchQuery += ' remote'
    if (job_type) searchQuery += ` ${job_type}`

    // Fetch REAL jobs from Indeed, LinkedIn, Glassdoor via JSearch API
    const url = new URL('https://jsearch.p.rapidapi.com/search')
    url.searchParams.append('query', searchQuery)
    url.searchParams.append('page', page.toString())
    url.searchParams.append('num_pages', '1')
    
    const response = await fetch(url.toString(), {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    })

    if (!response.ok) {
      throw new Error(`API error: ${response.statusText}`)
    }

    const data = await response.json()
    
    // Transform to our format
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id || `job-${Date.now()}-${Math.random()}`,
      title: job.job_title,
      company: job.employer_name,
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || '',
      salary: job.job_min_salary && job.job_max_salary 
        ? `$${job.job_min_salary} - $${job.job_max_salary}` 
        : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || '#',
      source: job.job_publisher?.toLowerCase() || 'indeed',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false,
    }))

    return new Response(
      JSON.stringify({ jobs, total: data.total || jobs.length }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message, jobs: [], total: 0 }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    )
  }
})
```

6. Click **Deploy**

## 🧪 Step 2: Test the Function

In Supabase Dashboard → Edge Functions → fetch-jobs → Test:

```json
{
  "query": "software engineer",
  "location": "San Francisco",
  "page": 1
}
```

Should return real jobs from Indeed, LinkedIn, Glassdoor!

## ✅ That's It!

Your app now fetches REAL jobs and matches candidates with actual opportunities.

### What This Does:
- ✅ Fetches real jobs from Indeed, LinkedIn, Glassdoor
- ✅ Supports location, job type, remote filters
- ✅ Returns actual apply URLs
- ✅ Works with AI matching system
- ✅ Caches results for performance

### Test in Your App:
1. Login to Jobtomize
2. Go to "Search" tab
3. Search for any job title + location
4. See REAL job listings!
