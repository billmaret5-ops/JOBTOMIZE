# FETCH-JOBS RAPIDAPI INTEGRATION FIX

## The Problem
You're absolutely right! The fetch-jobs function is still using MOCK/DEMO data instead of the real RapidAPI JSearch integration, even though you've set the secrets.

## The Solution

### Step 1: Verify Secrets Are Set
```bash
supabase secrets list
```

You should see:
- RAPIDAPI_KEY
- RAPIDAPI_HOST

### Step 2: Update the Function

Create/update `supabase/functions/fetch-jobs/index.ts` with this code:

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1,
      limit = 20,
      job_type,
      remote
    } = await req.json();

    const rapidApiKey = Deno.env.get('RAPIDAPI_KEY');
    const rapidApiHost = Deno.env.get('RAPIDAPI_HOST') || 'jsearch.p.rapidapi.com';


    if (!rapidApiKey || !rapidApiHost) {
      throw new Error('RapidAPI credentials not configured');
    }

    const searchParams = new URLSearchParams({
      query: `${query} ${location}`.trim(),
      page: page.toString(),
      num_pages: '1'
    });

    if (remote) searchParams.append('remote_jobs_only', 'true');
    if (job_type) searchParams.append('employment_types', job_type.toUpperCase());

    const apiUrl = `https://${rapidApiHost}/search?${searchParams.toString()}`;

    const response = await fetch(apiUrl, {
      headers: {
        'X-RapidAPI-Key': rapidApiKey,
        'X-RapidAPI-Host': rapidApiHost
      }
    });

    if (!response.ok) {
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: `${job.job_city}, ${job.job_state}`,
      description: job.job_description,
      salary: job.job_min_salary ? `$${job.job_min_salary} - $${job.job_max_salary}` : undefined,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc,
      apply_url: job.job_apply_link,
      source: 'JSearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote
    }));

    return new Response(JSON.stringify({
      jobs,
      total: data.total || jobs.length,
      page,
      totalPages: Math.ceil((data.total || jobs.length) / limit)
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Error:', error);
    return new Response(JSON.stringify({ 
      error: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

### Step 3: Deploy
```bash
supabase functions deploy fetch-jobs
```

### Step 4: Test
```bash
curl -X POST https://your-project.supabase.co/functions/v1/fetch-jobs \
  -H "Content-Type: application/json" \
  -d '{"query": "developer", "location": "New York"}'
```

## Key Changes Made:
✅ Removed ALL mock data generation
✅ Using real RapidAPI JSearch integration
✅ Using RAPIDAPI_KEY and RAPIDAPI_HOST from secrets
✅ Proper Deno.serve (not demo/external)
✅ Inline corsHeaders (no external imports)
✅ Real job data from JSearch API

## NO MORE DEMO MODE! 🎉
