# Resume Email Integration Guide

## Overview
The AI Resume Optimizer now includes comprehensive email functionality, allowing users to send resumes directly from the export modal with tracking capabilities.

## Features Added

### 1. Resume Email Integrator Component
**File**: `src/components/ResumeEmailIntegrator.tsx`

Features:
- Email template selection from job application templates
- Multiple recipient management
- Custom subject lines and message body
- Multiple resume version attachments
- Email preview before sending
- Real-time validation

### 2. Email Tracking Service
**File**: `src/services/resumeEmailService.ts`

Capabilities:
- Send resume emails with tracking
- Track email opens with pixel tracking
- Track link clicks
- Track attachment downloads
- Real-time tracking updates via Supabase subscriptions
- Historical tracking data retrieval

### 3. Email Tracking Dashboard
**File**: `src/components/EmailTrackingDashboard.tsx`

Displays:
- Total emails sent
- Open rate statistics
- Click-through rate
- Download rate
- Real-time tracking updates
- Individual email status

### 4. Enhanced Export Modal
**File**: `src/components/OptimizedResumeExportModal.tsx`

Updates:
- Tabbed interface (Export / Email)
- Export tab for resume generation
- Email tab for sending resumes
- Automatic tracking of exported versions
- Badge counter showing available versions to email

## Usage Instructions

### Exporting and Emailing a Resume

1. **Export Resume**:
   - Open the export modal
   - Select format (PDF, DOCX, TXT)
   - Choose sections to include
   - Configure formatting options
   - Click "Export Resume"
   - Resume is added to available versions

2. **Email Resume**:
   - Switch to "Email" tab (enabled after export)
   - Optionally select an email template
   - Add recipient email addresses
   - Customize subject and message
   - Select which resume versions to attach
   - Preview email before sending
   - Click "Send Email"

### Email Templates

Pre-configured templates available:
- **Initial Outreach**: Professional introduction, referral introduction
- **Follow-Up**: Polite follow-up, value-added follow-up
- **Thank You**: Post-interview thank you, thank you with additional info
- **Networking**: LinkedIn connection, informational interview request

### Tracking Email Performance

1. **Access Tracking Dashboard**:
   ```tsx
   import EmailTrackingDashboard from '@/components/EmailTrackingDashboard';
   
   <EmailTrackingDashboard userId={currentUser.id} />
   ```

2. **View Metrics**:
   - Total emails sent
   - Open rates
   - Click rates
   - Download rates
   - Individual email status

3. **Real-Time Updates**:
   - Dashboard automatically updates when recipients interact
   - See when emails are opened, clicked, or downloaded
   - Track engagement patterns

## Database Schema

### email_tracking Table
```sql
- id: UUID (primary key)
- message_id: TEXT (unique tracking ID)
- tracking_id: TEXT (batch tracking ID)
- user_id: UUID (sender)
- recipient_email: TEXT
- subject: TEXT
- template_id: TEXT (optional)
- attachment_count: INTEGER
- event_type: TEXT (sent, opened, clicked, downloaded)
- sent_at: TIMESTAMP
- opened: BOOLEAN
- opened_at: TIMESTAMP
- clicked: BOOLEAN
- clicked_at: TIMESTAMP
- click_url: TEXT
- downloaded: BOOLEAN
- downloaded_at: TIMESTAMP
```

## Integration with AI Resume Optimizer

### In AIResumeOptimizerPanel Component

```tsx
import OptimizedResumeExportModal from './OptimizedResumeExportModal';
import EmailTrackingDashboard from './EmailTrackingDashboard';

// In your component
const [showExportModal, setShowExportModal] = useState(false);

// Export button
<Button onClick={() => setShowExportModal(true)}>
  Export & Email Resume
</Button>

// Export modal with email integration
<OptimizedResumeExportModal
  open={showExportModal}
  onClose={() => setShowExportModal(false)}
  optimizedData={optimizedData}
  onExport={handleExport}
  userId={user.id}
/>

// Tracking dashboard
<EmailTrackingDashboard userId={user.id} />
```

## Email Tracking Implementation

### Tracking Pixel
Emails include an invisible 1x1 pixel image that tracks opens:
```html
<img src="https://yourapp.com/api/track-open?id={messageId}" width="1" height="1" alt="" />
```

### Click Tracking
All links in emails are wrapped with tracking URLs that record clicks before redirecting.

### Download Tracking
When recipients download attachments, a tracking event is recorded.

## Best Practices

### For Users
1. **Personalize Templates**: Customize email templates for each application
2. **Multiple Versions**: Export different resume versions for different roles
3. **Track Engagement**: Monitor which emails get opened and clicked
4. **Follow Up**: Use tracking data to time follow-up emails appropriately
5. **Test Emails**: Send test emails to yourself first

### For Developers
1. **Rate Limiting**: Implement rate limits on email sending
2. **Validation**: Validate email addresses before sending
3. **Error Handling**: Provide clear error messages for failed sends
4. **Privacy**: Respect user privacy in tracking implementation
5. **Unsubscribe**: Include unsubscribe links in emails

## Future Enhancements

Potential additions:
- Email scheduling for optimal send times
- A/B testing for email templates
- Automated follow-up sequences
- Email analytics and insights
- Integration with calendar for interview scheduling
- Bulk email campaigns
- Email template builder with drag-and-drop
- Advanced personalization with merge fields

## Troubleshooting

### Emails Not Sending
- Check SendGrid API key configuration
- Verify recipient email addresses
- Check for rate limiting
- Review error logs

### Tracking Not Working
- Verify tracking pixel URL is accessible
- Check database permissions
- Ensure real-time subscriptions are active
- Review CORS settings

### Export Issues
- Verify resume data is complete
- Check file generation logic
- Ensure proper format selection
- Review error handling

## Support

For issues or questions:
1. Check console for error messages
2. Verify database connection
3. Review Supabase logs
4. Check email service provider status
5. Test with sample data

## Conclusion

The resume email integration provides a complete solution for sending optimized resumes with comprehensive tracking. Users can manage their job application emails directly from the platform while gaining valuable insights into recipient engagement.
