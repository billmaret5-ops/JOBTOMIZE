#!/bin/bash
# Copy-Paste Commands for Deploying fetch-jobs Edge Function
# Run these commands one by one in your terminal

echo "=== STEP 1: Create Directory ==="
mkdir -p supabase/functions/fetch-jobs
echo "✓ Directory created"
echo ""

echo "=== STEP 2: Copy Code to File ==="
echo "Run this command to create the index.ts file:"
echo ""
echo "cat > supabase/functions/fetch-jobs/index.ts << 'EOFCODE'"
cat FETCH-JOBS-UPDATED-CODE.ts
echo "EOFCODE"
echo ""
echo "✓ File created with code"
echo ""

echo "=== STEP 3: Deploy Function (No JWT for Testing) ==="
echo "supabase functions deploy fetch-jobs --no-verify-jwt"
echo ""

echo "=== STEP 4: Get Your Project URL ==="
echo "Replace YOUR_PROJECT_REF with your actual Supabase project reference"
echo "Find it at: https://app.supabase.com/project/YOUR_PROJECT_REF/settings/api"
echo ""

echo "=== STEP 5: Test Health Endpoint ==="
echo "curl \"https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/health\""
echo ""

echo "=== STEP 6: Test GET Search ==="
echo "curl \"https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/search?query=developer&location=remote&limit=5\""
echo ""

echo "=== STEP 7: Test POST Search ==="
cat << 'EOFCURL'
curl -X POST "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "software engineer",
    "location": "San Francisco",
    "sources": ["indeed", "linkedin"],
    "limit": 10
  }'
EOFCURL
echo ""

echo "=== STEP 8: Check Logs ==="
echo "supabase functions logs fetch-jobs --follow"
echo ""

echo "=== All Commands Ready! ==="
echo "Copy and paste each command above into your terminal"
