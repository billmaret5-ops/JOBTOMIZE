# 🚀 Fetch Jobs Edge Function - Complete Code

## ⚠️ Security Note
This code does NOT contain any secrets. All credentials are read from environment variables set via `supabase secrets set`.

## 📁 File Location
`supabase/functions/fetch-jobs/index.ts`

## 📝 Complete Code

```typescript
// Deno Edge Function: fetch-jobs with RapidAPI JSearch Integration
import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { corsHeaders } from "../_shared/cors.ts";

interface JobListing {
  id: string;
  title: string;
  company: string;
  location: string;
  description: string;
  salary?: string;
  type?: string;
  posted_date?: string;
  url?: string;
}

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  const url = new URL(req.url);
  const path = url.pathname.split("/").pop();

  // Health check endpoint
  if (path === "health") {
    const rapidApiKey = Deno.env.get("RAPIDAPI_KEY");
    return new Response(
      JSON.stringify({
        ok: true,
        rapidapi_key_present: !!rapidApiKey,
        timestamp: new Date().toISOString(),
      }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }

  // Diagnostics endpoint
  if (path === "diagnostics") {
    const query = url.searchParams.get("query") || "software engineer";
    const rapidApiKey = Deno.env.get("RAPIDAPI_KEY");
    const rapidApiHost = Deno.env.get("RAPIDAPI_HOST");

    if (!rapidApiKey || !rapidApiHost) {
      return new Response(
        JSON.stringify({
          error: "Missing RapidAPI credentials",
          rapidapi_key_present: !!rapidApiKey,
          rapidapi_host_present: !!rapidApiHost,
        }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    try {
      const apiUrl = \`https://\${rapidApiHost}/search?query=\${encodeURIComponent(query)}&num_pages=1\`;
      const response = await fetch(apiUrl, {
        headers: {
          "X-RapidAPI-Key": rapidApiKey,
          "X-RapidAPI-Host": rapidApiHost,
        },
      });

      const data = await response.json();
      return new Response(
        JSON.stringify({
          ok: response.ok,
          status: response.status,
          jobs_found: data.data?.length || 0,
          rate_limit: response.headers.get("x-ratelimit-requests-remaining"),
        }),
        { headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    } catch (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }
  }

  // Main job search endpoint
  try {
    const query = url.searchParams.get("query") || "software engineer";
    const location = url.searchParams.get("location");
    const rapidApiKey = Deno.env.get("RAPIDAPI_KEY");
    const rapidApiHost = Deno.env.get("RAPIDAPI_HOST");

    if (!rapidApiKey || !rapidApiHost) {
      throw new Error("RapidAPI credentials not configured");
    }

    let searchQuery = query;
    if (location) searchQuery += \` in \${location}\`;

    const apiUrl = \`https://\${rapidApiHost}/search?query=\${encodeURIComponent(searchQuery)}&num_pages=1\`;
    const response = await fetch(apiUrl, {
      headers: {
        "X-RapidAPI-Key": rapidApiKey,
        "X-RapidAPI-Host": rapidApiHost,
      },
    });

    if (!response.ok) {
      throw new Error(\`API error: \${response.status}\`);
    }

    const data = await response.json();
    const jobs: JobListing[] = (data.data || []).map((job: any) => ({
      id: job.job_id || crypto.randomUUID(),
      title: job.job_title || "Untitled",
      company: job.employer_name || "Unknown Company",
      location: job.job_city && job.job_state ? \`\${job.job_city}, \${job.job_state}\` : job.job_country || "Remote",
      description: job.job_description || "",
      salary: job.job_salary || undefined,
      type: job.job_employment_type || undefined,
      posted_date: job.job_posted_at_datetime_utc || undefined,
      url: job.job_apply_link || undefined,
    }));

    return new Response(JSON.stringify(jobs), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Fetch jobs error:", error.message);
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
```

## 🎯 Next Steps

1. **YOU set secrets locally:**
   ```bash
   supabase secrets set RAPIDAPI_KEY="your-key" RAPIDAPI_HOST="jsearch.p.rapidapi.com"
   ```

2. **Deploy this function:**
   ```bash
   supabase functions deploy fetch-jobs
   ```

3. **Test health endpoint:**
   ```bash
   curl "$SUPABASE_URL/functions/v1/fetch-jobs/health" \
     -H "Authorization: Bearer $SUPABASE_ANON_KEY"
   ```

Expected: `{"ok":true,"rapidapi_key_present":true}`
