# Webhook Retry System with Exponential Backoff

## Overview

The Webhook Retry System provides automatic retry mechanisms with exponential backoff for failed webhook deliveries to Slack, PagerDuty, and other services. It includes a retry queue, dead letter queue for permanently failed messages, configurable retry policies, and comprehensive monitoring dashboards.

## Features

### 1. Automatic Retry with Exponential Backoff
- **Configurable Retry Policies**: Set max attempts, initial delay, max delay, and backoff multiplier
- **Exponential Backoff**: Delays increase exponentially between retries (e.g., 1s, 2s, 4s, 8s)
- **Status Code Filtering**: Retry only on specific HTTP status codes (500, 502, 503, 504, 429)
- **Service-Specific Policies**: Different retry strategies for Slack, PagerDuty, Email, SMS

### 2. Retry Queue Management
- **Priority Queue**: Process high-priority messages first
- **Scheduled Retries**: Automatic retry scheduling based on backoff calculation
- **Real-Time Monitoring**: Track pending retries, attempt counts, and next retry times
- **Manual Retry**: Force immediate retry for specific messages

### 3. Dead Letter Queue (DLQ)
- **Permanent Failure Tracking**: Messages that exceed max retry attempts
- **Failure Analysis**: Store detailed error messages and status codes
- **Recovery Options**: Manually recover and re-queue failed messages
- **Audit Trail**: Complete history of all failed deliveries

### 4. Statistics & Analytics
- **Success Rate Tracking**: Monitor first-attempt success vs. retry success
- **Retry Distribution**: Analyze average retry counts and patterns
- **Time-Series Data**: 7-day historical view of delivery performance
- **Service Breakdown**: Per-service statistics for targeted optimization

## Database Schema

### Retry Policies Table
```sql
CREATE TABLE retry_policies (
  id UUID PRIMARY KEY,
  name VARCHAR(255),
  service_type VARCHAR(50), -- slack, pagerduty, email, sms, webhook
  max_attempts INTEGER DEFAULT 5,
  initial_delay_ms INTEGER DEFAULT 1000,
  max_delay_ms INTEGER DEFAULT 300000,
  backoff_multiplier DECIMAL(3,2) DEFAULT 2.0,
  retry_on_status_codes INTEGER[],
  is_active BOOLEAN DEFAULT true
);
```

### Retry Queue Table
```sql
CREATE TABLE webhook_retry_queue (
  id UUID PRIMARY KEY,
  policy_id UUID REFERENCES retry_policies(id),
  service_type VARCHAR(50),
  webhook_url TEXT,
  payload JSONB,
  headers JSONB,
  attempt_count INTEGER DEFAULT 0,
  max_attempts INTEGER DEFAULT 5,
  next_retry_at TIMESTAMPTZ,
  last_error TEXT,
  last_status_code INTEGER,
  priority INTEGER DEFAULT 0
);
```

### Dead Letter Queue Table
```sql
CREATE TABLE webhook_dead_letter_queue (
  id UUID PRIMARY KEY,
  original_queue_id UUID,
  service_type VARCHAR(50),
  webhook_url TEXT,
  payload JSONB,
  total_attempts INTEGER,
  failure_reason TEXT,
  last_error TEXT,
  can_retry BOOLEAN DEFAULT true,
  failed_at TIMESTAMPTZ
);
```

## Usage Examples

### 1. Create a Retry Policy

```typescript
import { webhookRetryService } from '@/services/webhookRetryService';

const policy = await webhookRetryService.createRetryPolicy({
  name: 'Slack High Priority',
  service_type: 'slack',
  max_attempts: 5,
  initial_delay_ms: 1000,
  max_delay_ms: 300000,
  backoff_multiplier: 2.0,
  retry_on_status_codes: [500, 502, 503, 504, 429],
  is_active: true,
});
```

### 2. Add Message to Retry Queue

```typescript
await webhookRetryService.addToRetryQueue({
  service_type: 'slack',
  webhook_url: 'https://hooks.slack.com/services/...',
  payload: {
    text: 'ML Model Anomaly Detected',
    attachments: [...]
  },
  headers: {
    'Content-Type': 'application/json'
  },
  attempt_count: 0,
  max_attempts: 5,
  next_retry_at: new Date().toISOString(),
  priority: 1,
  metadata: { alert_id: '123' }
});
```

### 3. Process Retry Queue

```typescript
// Automatically processes pending retries
await webhookRetryService.processRetryQueue();
```

### 4. Recover from Dead Letter Queue

```typescript
await webhookRetryService.recoverFromDeadLetter('dlq-message-id');
```

### 5. Get Retry Statistics

```typescript
const stats = await webhookRetryService.getRetryStatistics(7); // Last 7 days
console.log(stats);
// [
//   {
//     service_type: 'slack',
//     date: '2025-01-15',
//     total_messages: 100,
//     successful_first_attempt: 85,
//     total_retries: 20,
//     successful_retries: 15,
//     failed_permanently: 5,
//     avg_retry_count: 1.2
//   }
// ]
```

## Exponential Backoff Calculation

The system calculates retry delays using the formula:

```
delay = min(initial_delay * (multiplier ^ attempt), max_delay)
```

**Example with default settings:**
- Attempt 1: 1000ms (1 second)
- Attempt 2: 2000ms (2 seconds)
- Attempt 3: 4000ms (4 seconds)
- Attempt 4: 8000ms (8 seconds)
- Attempt 5: 16000ms (16 seconds)

## Retry Policies Best Practices

### Slack Webhooks
```typescript
{
  max_attempts: 5,
  initial_delay_ms: 1000,
  max_delay_ms: 60000, // 1 minute
  backoff_multiplier: 2.0,
  retry_on_status_codes: [429, 500, 502, 503, 504]
}
```

### PagerDuty Incidents
```typescript
{
  max_attempts: 7,
  initial_delay_ms: 2000,
  max_delay_ms: 300000, // 5 minutes
  backoff_multiplier: 2.0,
  retry_on_status_codes: [429, 500, 502, 503, 504]
}
```

### Email Delivery
```typescript
{
  max_attempts: 3,
  initial_delay_ms: 5000,
  max_delay_ms: 600000, // 10 minutes
  backoff_multiplier: 3.0,
  retry_on_status_codes: [500, 502, 503, 504]
}
```

## Monitoring & Alerts

### Queue Metrics
- **Queue Size**: Number of pending retries
- **Dead Letter Size**: Number of permanently failed messages
- **Success Rate**: Percentage of successful deliveries
- **Average Retries**: Mean retry count per message

### Dashboard Features
1. **Retry Queue Tab**: View pending retries with next retry times
2. **Dead Letter Queue Tab**: Manage permanently failed messages
3. **Statistics Tab**: Analyze retry patterns and success rates
4. **Real-Time Updates**: Auto-refresh every 10 seconds

## Integration with ML Deployment System

The retry system integrates seamlessly with the ML automated response system:

```typescript
// In automated response action
try {
  await sendSlackAlert(anomaly);
} catch (error) {
  // Automatically added to retry queue
  await webhookRetryService.addToRetryQueue({
    service_type: 'slack',
    webhook_url: slackWebhookUrl,
    payload: alertPayload,
    attempt_count: 0,
    max_attempts: 5,
    next_retry_at: new Date().toISOString(),
    priority: anomaly.severity === 'critical' ? 2 : 1
  });
}
```

## Performance Optimization

### Indexes
```sql
CREATE INDEX idx_retry_queue_next_retry 
  ON webhook_retry_queue(next_retry_at) 
  WHERE next_retry_at <= NOW();

CREATE INDEX idx_retry_queue_priority 
  ON webhook_retry_queue(priority DESC, next_retry_at);
```

### Background Processing
Set up a cron job to process the retry queue:

```typescript
// Run every minute
setInterval(async () => {
  await webhookRetryService.processRetryQueue();
}, 60000);
```

## Troubleshooting

### High Failure Rate
1. Check service health (Slack, PagerDuty status pages)
2. Verify webhook URLs are correct
3. Review error messages in dead letter queue
4. Adjust retry policy (increase max_delay, attempts)

### Queue Backlog
1. Increase processing frequency
2. Add more workers for parallel processing
3. Review and optimize webhook payload sizes
4. Check for rate limiting issues

### Dead Letter Queue Growing
1. Investigate common failure patterns
2. Update webhook configurations
3. Implement circuit breaker for failing endpoints
4. Set up alerts for DLQ threshold

## API Reference

### webhookRetryService Methods

- `getRetryPolicies()`: Fetch all retry policies
- `createRetryPolicy(policy)`: Create new retry policy
- `updateRetryPolicy(id, updates)`: Update existing policy
- `getRetryQueue(filters)`: Get pending retry messages
- `addToRetryQueue(item)`: Add message to retry queue
- `processRetryQueue()`: Process pending retries
- `retryWebhook(item)`: Retry specific webhook
- `getDeadLetterQueue(filters)`: Get failed messages
- `recoverFromDeadLetter(id)`: Recover and retry failed message
- `getRetryStatistics(days)`: Get retry statistics
- `getQueueMetrics()`: Get current queue metrics

## Security Considerations

1. **Sensitive Data**: Webhook payloads may contain sensitive information
2. **Access Control**: Implement RLS policies for multi-tenant systems
3. **Rate Limiting**: Respect service provider rate limits
4. **Audit Logging**: Track all retry attempts and recoveries
5. **Encryption**: Consider encrypting webhook payloads at rest

## Future Enhancements

- [ ] Circuit breaker pattern for failing endpoints
- [ ] Adaptive retry strategies based on success patterns
- [ ] Webhook health scoring and automatic policy adjustment
- [ ] Integration with APM tools (Datadog, New Relic)
- [ ] Batch retry processing for improved performance
- [ ] Custom retry strategies per webhook endpoint
