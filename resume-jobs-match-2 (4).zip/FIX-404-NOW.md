# 🚨 FIX 404 ERROR - DO THIS NOW

## THE PROBLEM
You're getting **404** because the `fetch-jobs` function **DOESN'T EXIST** in Supabase.

## THE SOLUTION (5 MINUTES)

### Step 1: Create the Function File
1. Open your terminal/command prompt
2. Navigate to your project folder
3. Create the function:

```bash
mkdir -p supabase/functions/fetch-jobs
```

### Step 2: Create the Function Code
Create file: `supabase/functions/fetch-jobs/index.ts`

Paste this code:

```typescript
import { serve } from 'https://deno.land/std@0.168.0/http/server.ts';

const RAPIDAPI_KEY = Deno.env.get('RAPIDAPI_KEY') || '';

serve(async (req) => {
  const origin = req.headers.get('origin') || '*';
  
  if (req.method === 'OPTIONS') {
    return new Response(null, {
      headers: {
        'Access-Control-Allow-Origin': origin,
        'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
        'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
      },
    });
  }

  try {
    const url = new URL(req.url);
    const path = url.pathname.replace('/fetch-jobs', '').replace(/^\//, '');

    // Health check
    if (path === 'health' && req.method === 'GET') {
      return new Response(JSON.stringify({ ok: true, timestamp: new Date().toISOString() }), {
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
      });
    }

    // Search endpoint
    if (path === 'search') {
      let params: any = {};
      
      if (req.method === 'GET') {
        params.query = url.searchParams.get('query') || 'developer jobs';
        params.page = url.searchParams.get('page') || '1';
        params.num_pages = url.searchParams.get('num_pages') || '1';
      } else if (req.method === 'POST') {
        params = await req.json();
      }

      // Call JSearch API
      const jsearchUrl = `https://jsearch.p.rapidapi.com/search?query=${encodeURIComponent(params.query)}&page=${params.page || 1}&num_pages=${params.num_pages || 1}`;
      
      const response = await fetch(jsearchUrl, {
        headers: {
          'x-rapidapi-host': 'jsearch.p.rapidapi.com',
          'x-rapidapi-key': RAPIDAPI_KEY,
        },
      });

      const data = await response.json();
      
      return new Response(JSON.stringify({
        jobs: data.data || [],
        total: data.data?.length || 0,
        page: params.page || 1,
      }), {
        headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
      });
    }

    return new Response(JSON.stringify({ error: 'Not found' }), {
      status: 404,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  } catch (error: any) {
    return new Response(JSON.stringify({ error: error.message }), {
      status: 500,
      headers: { 'Content-Type': 'application/json', 'Access-Control-Allow-Origin': origin },
    });
  }
});
```

### Step 3: Deploy the Function
```bash
npx supabase functions deploy fetch-jobs --no-verify-jwt
```

### Step 4: Add Your RapidAPI Key
Go to: https://supabase.com/dashboard/project/rgdvevmqrjlkqfkiucdh/settings/functions

Click "Secrets" → Add new secret:
- Name: `RAPIDAPI_KEY`
- Value: `deffa6f1acmsh652e385a84f17fep1c4a3fjsna3d001bcfb82`

### Step 5: Test It
```bash
curl "https://rgdvevmqrjlkqfkiucdh.supabase.co/functions/v1/fetch-jobs/health"
```

Should return: `{"ok":true,"timestamp":"..."}`

## THAT'S IT! 
Your 404 will be gone. Jobs will load. 🎉
