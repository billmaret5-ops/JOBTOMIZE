# 🚀 Deploy Jobtomize.com on Famous.ai - COMPLETE GUIDE

## ✅ Current Status
- **Working Site**: resume-jobs-match-2.deploypad.app ✅
- **Target Domain**: jobtomize.com (Famous.ai hosting)
- **Backend**: Supabase (already configured)

---

## 🎯 QUICK DEPLOYMENT (3 Commands)

### Step 1: Build Production App
```bash
npm install
npm run build
```
✅ Creates optimized `dist/` folder

### Step 2: Upload to Famous.ai

**Option A: Using FTP/SFTP Client (FileZilla, Cyberduck)**
1. Get credentials from Famous.ai dashboard
2. Connect to: `ftp.famous.ai` or your server IP
3. Upload ALL files from `dist/` folder to `public_html/` or `www/`

**Option B: Using Command Line**
```bash
# If Famous.ai provides SFTP access
sftp username@famous.ai
cd public_html
put -r dist/*
```

### Step 3: Configure Domain & SSL
In Famous.ai control panel:
1. Add domain: `jobtomize.com`
2. Point DNS to Famous.ai servers
3. Enable SSL (Let's Encrypt - usually automatic)

---

## 🌐 DNS Configuration

### At Your Domain Registrar (GoDaddy, Namecheap, etc.)

**Get Famous.ai IP Address from their dashboard, then:**

```
Type: A
Name: @
Value: [Famous.ai IP - e.g., 123.45.67.89]
TTL: 3600

Type: A
Name: www
Value: [Famous.ai IP - e.g., 123.45.67.89]
TTL: 3600
```

**OR if Famous.ai uses CNAME:**
```
Type: CNAME
Name: www
Value: [your-account].famous.ai
TTL: 3600
```

---

## 📁 Required Files for Upload

Upload these from `dist/` folder:
```
dist/
├── index.html          ✅ Main entry
├── assets/            ✅ JS/CSS bundles
├── manifest.json      ✅ PWA config
├── robots.txt         ✅ SEO
├── sitemap.xml        ✅ SEO
├── .htaccess          ✅ SPA routing (CREATE THIS)
└── sw.js              ✅ Service worker
```

---

## 🔧 Create .htaccess File

**CRITICAL for React Router to work!**

Create `public/.htaccess` (will be copied to dist/):
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteBase /
  
  # Force HTTPS
  RewriteCond %{HTTPS} off
  RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
  
  # SPA Routing - serve index.html for all routes
  RewriteRule ^index\.html$ - [L]
  RewriteCond %{REQUEST_FILENAME} !-f
  RewriteCond %{REQUEST_FILENAME} !-d
  RewriteCond %{REQUEST_FILENAME} !-l
  RewriteRule . /index.html [L]
</IfModule>

# Security Headers
<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "DENY"
  Header set X-XSS-Protection "1; mode=block"
  Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# Cache Control
<IfModule mod_expires.c>
  ExpiresActive On
  ExpiresByType image/jpg "access plus 1 year"
  ExpiresByType image/jpeg "access plus 1 year"
  ExpiresByType image/png "access plus 1 year"
  ExpiresByType image/svg+xml "access plus 1 year"
  ExpiresByType text/css "access plus 1 month"
  ExpiresByType application/javascript "access plus 1 month"
</IfModule>
```

---

## 🔐 Environment Variables

**Already configured in code with fallbacks!**

If Famous.ai supports env vars, set these:
```
VITE_SUPABASE_URL=https://rgdvevmqrjlkqfkiucdh.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGci... (your key)
```

**Note:** App works without env vars due to hardcoded fallbacks in `src/lib/supabase.ts`

---

## ✅ Post-Deployment Checklist

After upload, test these URLs:

- [ ] https://jobtomize.com (loads homepage)
- [ ] https://www.jobtomize.com (redirects or loads)
- [ ] https://jobtomize.com/job-search (job search works)
- [ ] https://jobtomize.com/resume-builder (resume builder loads)
- [ ] Sign up / Login works
- [ ] Job search returns results
- [ ] All navigation links work
- [ ] SSL certificate shows (green padlock)

---

## 🆘 Troubleshooting

### Issue: 404 on Routes
**Solution:** Ensure `.htaccess` file is uploaded and mod_rewrite is enabled

### Issue: Blank Page
**Solution:** Check browser console for errors, verify all files uploaded

### Issue: API Errors
**Solution:** Verify Supabase URL/key in code or env vars

### Issue: SSL Not Working
**Solution:** Wait 15 mins after DNS propagation, contact Famous.ai support

### Issue: www Not Working
**Solution:** Add separate A record for www subdomain

---

## 📞 Famous.ai Support Info

Contact them for:
1. **Server IP address** (for DNS A record)
2. **FTP/SFTP credentials** (username, password, host)
3. **SSL certificate setup** (should be automatic)
4. **mod_rewrite status** (for .htaccess to work)
5. **Environment variables** (if they support it)

---

## 🎉 Success Indicators

When deployment is successful:
✅ jobtomize.com loads instantly
✅ All pages accessible via direct URL
✅ Green padlock (SSL) in browser
✅ Login/signup works
✅ Job search returns results
✅ Same functionality as deploypad.app

---

## 📋 Quick Command Reference

```bash
# Build app
npm run build

# Check build output
ls -la dist/

# Upload via SFTP (example)
sftp user@famous.ai
cd public_html
put -r dist/*
exit

# Test after upload
curl -I https://jobtomize.com
curl https://jobtomize.com/job-search
```

---

🚀 **Your jobtomize.com will be live in 5-15 minutes after DNS propagation!**
