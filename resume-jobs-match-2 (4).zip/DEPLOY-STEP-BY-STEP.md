# Step-by-Step Manual Deployment Guide for fetch-jobs Edge Function

## Prerequisites
- Supabase CLI installed (`npm install -g supabase`)
- Supabase project linked (`supabase link --project-ref YOUR_PROJECT_REF`)
- RAPIDAPI_KEY secret already set ✓

---

## Step 1: Create the Functions Directory Structure

```bash
# Create the fetch-jobs function directory
mkdir -p supabase/functions/fetch-jobs

# Verify it was created
ls -la supabase/functions/
```

---

## Step 2: Create the index.ts File

```bash
# Create and open the index.ts file
cat > supabase/functions/fetch-jobs/index.ts << 'EOF'
// Copy the entire content from FETCH-JOBS-UPDATED-CODE.ts here
EOF
```

**OR manually create the file:**

```bash
# Use your preferred editor
nano supabase/functions/fetch-jobs/index.ts
# OR
vim supabase/functions/fetch-jobs/index.ts
# OR
code supabase/functions/fetch-jobs/index.ts
```

Then copy ALL the code from `FETCH-JOBS-UPDATED-CODE.ts` into this file.

---

## Step 3: Deploy with --no-verify-jwt Flag (Testing Mode)

```bash
# Deploy without JWT verification for testing
supabase functions deploy fetch-jobs --no-verify-jwt

# You should see output like:
# Deploying Function fetch-jobs (project ref: YOUR_PROJECT_REF)
# Deployed Function fetch-jobs
```

**Note:** For production, remove `--no-verify-jwt` to enable authentication.

---

## Step 4: Test with curl Commands

### Test 1: Health Check (No Auth Required)
```bash
curl "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/health"
```

**Expected Response:**
```json
{
  "status": "healthy",
  "timestamp": "2025-11-20T16:11:00.000Z",
  "service": "fetch-jobs",
  "version": "2.0"
}
```

### Test 2: GET Search with Query Parameters
```bash
curl "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/search?query=developer&location=remote&limit=5"
```

### Test 3: POST Search with JSON Body
```bash
curl -X POST "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "software engineer",
    "location": "San Francisco",
    "sources": ["indeed", "linkedin"],
    "limit": 10
  }'
```

### Test 4: POST with Filters
```bash
curl -X POST "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "developer",
    "remote": true,
    "experience_level": "Senior",
    "limit": 5
  }'
```

---

## Step 5: Check the Logs

### View Real-Time Logs
```bash
supabase functions logs fetch-jobs --follow
```

### View Recent Logs
```bash
supabase functions logs fetch-jobs
```

### What to Look For in Logs:
```
=== FETCH-JOBS REQUEST ===
Method: POST
URL: https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs
Headers: {
  "authorization": "Bearer ...",
  "content-type": "application/json",
  "apikey": "...",
  ...
}
POST search requested
POST body: { query: "developer", location: "remote" }
```

---

## Troubleshooting 401 Errors

If you see 401 errors in the logs:

1. **Check if JWT verification is enabled:**
   ```bash
   # Redeploy without JWT for testing
   supabase functions deploy fetch-jobs --no-verify-jwt
   ```

2. **Verify the Authorization header:**
   ```bash
   # Add your anon key to the request
   curl "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/health" \
     -H "Authorization: Bearer YOUR_ANON_KEY"
   ```

3. **Check CORS headers in logs:**
   - Look for `access-control-allow-origin` in response headers
   - Verify `authorization` is in `access-control-allow-headers`

4. **Test from your app:**
   ```javascript
   const response = await fetch('https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/search?query=developer', {
     headers: {
       'Authorization': `Bearer ${supabase.auth.session()?.access_token}`,
       'apikey': 'YOUR_ANON_KEY'
     }
   });
   ```

---

## Quick Commands Reference

```bash
# Deploy (testing)
supabase functions deploy fetch-jobs --no-verify-jwt

# Deploy (production with JWT)
supabase functions deploy fetch-jobs

# View logs
supabase functions logs fetch-jobs --follow

# Test health
curl "https://YOUR_PROJECT_REF.supabase.co/functions/v1/fetch-jobs/health"

# Delete function (if needed)
supabase functions delete fetch-jobs
```

---

## Success Indicators

✅ Deployment shows "Deployed Function fetch-jobs"
✅ Health check returns 200 OK with JSON response
✅ Logs show "=== FETCH-JOBS REQUEST ===" with headers
✅ Search returns job listings
✅ No 401 errors in logs

---

## Next Steps After Successful Deployment

1. Test all endpoints (health, GET search, POST search)
2. Review logs to confirm headers are received correctly
3. If everything works, redeploy with JWT: `supabase functions deploy fetch-jobs`
4. Update your frontend to use the new endpoints
5. Monitor logs for any errors

---

**Need Help?**
- Check logs: `supabase functions logs fetch-jobs`
- View function details: `supabase functions list`
- Supabase docs: https://supabase.com/docs/guides/functions
