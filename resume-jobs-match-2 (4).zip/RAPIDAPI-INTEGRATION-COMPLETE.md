# RapidAPI Integration - Complete Setup Guide

## Step 1: Set the RapidAPI Secrets

Run this command to set both required secrets:

```bash
supabase secrets set RAPIDAPI_KEY=82715cb7bamsh0e3bb4e10131dc3p10ff3bjsn257ccc0971c7 RAPIDAPI_HOST=jsearch.p.rapidapi.com
```

## Step 2: Update the fetch-jobs Function

The updated function code is in `supabase/functions/fetch-jobs/index.ts` (see below)

## Step 3: Deploy the Function

```bash
supabase functions deploy fetch-jobs
```

## Step 4: Test the Integration

### Health Check (verify key is present)
```bash
curl -sS "$SUPABASE_URL/functions/v1/fetch-jobs/health" \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY"
```

Expected response:
```json
{
  "ok": true,
  "rapidapi_key_present": true,
  "rapidapi_host_present": true,
  "timestamp": "2025-11-22T06:49:00.000Z"
}
```

### Diagnostics (test actual API call)
```bash
curl -sS "$SUPABASE_URL/functions/v1/fetch-jobs/diagnostics?query=software+engineer" \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY"
```

Expected response:
```json
{
  "upstream_ok": true,
  "status": 200,
  "rate_limit_remaining": 499,
  "rate_limit_total": 500,
  "rapidapi_key_present": true,
  "rapidapi_host": "jsearch.p.rapidapi.com"
}
```

### Full Job Search
```bash
curl -X POST "$SUPABASE_URL/functions/v1/fetch-jobs" \
  -H "Authorization: Bearer $SUPABASE_ANON_KEY" \
  -H "apikey: $SUPABASE_ANON_KEY" \
  -H "Content-Type: application/json" \
  -d '{"query": "software engineer", "location": "San Francisco", "page": 1}'
```

## Step 5: Check Logs

If something doesn't work, check the function logs:

```bash
supabase functions logs fetch-jobs --include=invocations
```

## Common Issues

1. **"RAPIDAPI_KEY not configured"** - Run the secrets set command again
2. **401 Unauthorized from RapidAPI** - Check if the key is correct
3. **403 Forbidden** - Check if you have API credits remaining
4. **Secret not found** - Make sure to redeploy after setting secrets

## What Changed

✅ Reads RAPIDAPI_KEY from environment (Deno.env.get)
✅ Reads RAPIDAPI_HOST from environment (defaults to jsearch.p.rapidapi.com)
✅ Added /health endpoint to verify configuration
✅ Added /diagnostics endpoint to test API connectivity
✅ Proper X-RapidAPI-Key and X-RapidAPI-Host headers
✅ Safe logging (never logs the actual key value)
✅ Transforms JSearch API response to our format
✅ Better error handling with detailed messages
