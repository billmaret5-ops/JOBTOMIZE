# 🔒 SSL Deployment Checklist for Jobtomize.com

## ✅ Pre-Deployment Checklist

### 1. Code Changes Applied
- [x] Security headers configuration (`public/_headers`)
- [x] HTTPS redirect rules (`public/vercel.json`)
- [x] Supabase config HTTPS enforcement
- [x] Security utilities library (`src/lib/securityHeaders.ts`)
- [x] Main.tsx security initialization
- [x] Mixed content fixes

### 2. Configuration Files
- [x] `public/_headers` - Security headers
- [x] `public/vercel.json` - HTTPS redirects
- [x] `src/config/supabase.config.ts` - HTTPS enforcement
- [x] `src/lib/securityHeaders.ts` - Security utilities

## 🚀 Deployment Steps

### Step 1: Deploy to Famous.ai
```bash
# Build the application
npm run build

# Deploy to Famous.ai (automatic via git push)
git add .
git commit -m "Configure SSL/HTTPS with Let's Encrypt"
git push origin main
```

### Step 2: Configure Custom Domain
1. Go to Famous.ai Dashboard
2. Navigate to: **Project Settings → Custom Domains**
3. Click "Add Custom Domain"
4. Enter: `jobtomize.com`
5. Add: `www.jobtomize.com` (optional)
6. Wait 5-10 minutes for SSL provisioning

### Step 3: Update DNS Records
At your domain registrar (GoDaddy, Namecheap, etc.):

```
Type    Name    Value                           TTL
A       @       [Famous.ai IP]                  3600
CNAME   www     [your-project].supabase.co      3600
```

**Note:** Replace with actual values from Famous.ai dashboard

### Step 4: Verify SSL Certificate
```bash
# Test HTTPS
curl -I https://jobtomize.com

# Check certificate
openssl s_client -connect jobtomize.com:443 -servername jobtomize.com
```

## 🧪 Testing Checklist

### Browser Testing
- [ ] Visit https://jobtomize.com (should work)
- [ ] Visit http://jobtomize.com (should redirect to HTTPS)
- [ ] Check for green padlock in address bar
- [ ] Open DevTools Console (no mixed content warnings)
- [ ] Test in Chrome, Firefox, Safari, Edge

### Security Headers Test
```bash
curl -I https://jobtomize.com
```

Should include:
- [ ] `Strict-Transport-Security`
- [ ] `X-Content-Type-Options`
- [ ] `X-Frame-Options`
- [ ] `Content-Security-Policy`

### SSL Labs Test
- [ ] Visit: https://www.ssllabs.com/ssltest/analyze.html?d=jobtomize.com
- [ ] Target Grade: **A or A+**

## 📊 Monitoring

### Certificate Expiration
Let's Encrypt certificates expire in 90 days but auto-renew at 60 days.

**Monitor:**
```bash
# Check expiration date
echo | openssl s_client -servername jobtomize.com -connect jobtomize.com:443 2>/dev/null | openssl x509 -noout -dates
```

### Set Calendar Reminder
- [ ] Add reminder 30 days before expiration
- [ ] Verify auto-renewal worked
- [ ] Check Famous.ai dashboard for renewal status

## 🚨 Rollback Plan

If SSL causes issues:

1. **Remove custom domain** from Famous.ai dashboard
2. **Revert DNS changes** at registrar
3. **Use default URL** temporarily
4. **Debug and redeploy**

## 📝 Post-Deployment Tasks

- [ ] Update documentation with HTTPS URLs
- [ ] Update marketing materials
- [ ] Notify users of HTTPS availability
- [ ] Update social media links
- [ ] Submit to Google Search Console
- [ ] Update sitemap.xml with HTTPS URLs

## 🎯 Success Criteria

✅ HTTPS loads without errors
✅ HTTP redirects to HTTPS
✅ Green padlock visible
✅ No mixed content warnings
✅ SSL Labs grade A/A+
✅ All API calls use HTTPS
✅ Certificate auto-renewal enabled

---

**Deployment Date:** _____________
**Deployed By:** _____________
**SSL Grade:** _____________
**Issues Found:** _____________
