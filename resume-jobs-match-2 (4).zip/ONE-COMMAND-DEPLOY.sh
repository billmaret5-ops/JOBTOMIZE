#!/bin/bash

# 🎯 ONE COMMAND DEPLOYMENT FOR JOBTOMIZE.COM
# Run this, then upload dist/ folder to Famous.ai

clear
echo "╔════════════════════════════════════════════════════════╗"
echo "║     🚀 JOBTOMIZE.COM - FAMOUS.AI DEPLOYMENT 🚀        ║"
echo "╚════════════════════════════════════════════════════════╝"
echo ""

# Clean and build
rm -rf dist/ && npm install && npm run build

if [ $? -eq 0 ]; then
    echo ""
    echo "╔════════════════════════════════════════════════════════╗"
    echo "║                  ✅ BUILD SUCCESS! ✅                  ║"
    echo "╚════════════════════════════════════════════════════════╝"
    echo ""
    echo "📁 Files ready in: ./dist/"
    echo ""
    echo "🔄 UPLOAD TO FAMOUS.AI:"
    echo "   1. Open FileZilla or FTP client"
    echo "   2. Connect to Famous.ai server"
    echo "   3. Upload ALL files from dist/ to public_html/"
    echo ""
    echo "🌐 CONFIGURE DNS:"
    echo "   Point jobtomize.com A record to Famous.ai IP"
    echo ""
    echo "🔒 ENABLE SSL:"
    echo "   Install Let's Encrypt in Famous.ai dashboard"
    echo ""
    echo "📖 Full guide: FAMOUS-AI-DEPLOYMENT-STEPS.md"
else
    echo ""
    echo "❌ BUILD FAILED - Check errors above"
    exit 1
fi
