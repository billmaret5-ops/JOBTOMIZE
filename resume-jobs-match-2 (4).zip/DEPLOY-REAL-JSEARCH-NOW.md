# 🚨 EMERGENCY FIX - DEPLOY REAL JSEARCH API NOW

## The Problem
Your fetch-jobs function STILL has mock data! That's why it won't load.

## The Solution - Copy This EXACT Code

1. **Go to Supabase Dashboard**
2. **Edge Functions → fetch-jobs → Edit**
3. **DELETE EVERYTHING and paste this:**

```typescript
export const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type'
};

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders });
  }

  try {
    const { 
      query = 'software engineer', 
      location = '', 
      page = 1
    } = await req.json();

    const jsearchApiKey = Deno.env.get('Jsearch');
    
    if (!jsearchApiKey) {
      throw new Error('JSearch API key not configured');
    }

    const url = new URL('https://jsearch.p.rapidapi.com/search');
    url.searchParams.append('query', `${query} ${location}`.trim());
    url.searchParams.append('page', page.toString());
    url.searchParams.append('num_pages', '1');

    const response = await fetch(url.toString(), {
      method: 'GET',
      headers: {
        'X-RapidAPI-Key': jsearchApiKey,
        'X-RapidAPI-Host': 'jsearch.p.rapidapi.com'
      }
    });

    if (!response.ok) {
      throw new Error(`JSearch API error: ${response.status}`);
    }

    const data = await response.json();
    
    const jobs = (data.data || []).map((job: any) => ({
      id: job.job_id,
      title: job.job_title,
      company: job.employer_name,
      location: job.job_city && job.job_state 
        ? `${job.job_city}, ${job.job_state}` 
        : job.job_country || 'Remote',
      description: job.job_description || '',
      salary: job.job_min_salary && job.job_max_salary
        ? `$${job.job_min_salary} - $${job.job_max_salary}`
        : null,
      type: job.job_employment_type || 'Full-time',
      posted_date: job.job_posted_at_datetime_utc || new Date().toISOString(),
      apply_url: job.job_apply_link || job.job_google_link || '#',
      source: 'jsearch',
      skills: job.job_required_skills || [],
      remote: job.job_is_remote || false
    }));

    return new Response(JSON.stringify({
      jobs,
      total: jobs.length,
      page,
      totalPages: 1
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });

  } catch (error) {
    console.error('Job fetch error:', error);
    return new Response(JSON.stringify({ 
      error: 'Failed to fetch jobs',
      details: error.message 
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    });
  }
});
```

4. **Click Deploy**
5. **Wait for "Deployed successfully"**
6. **Refresh your app (Ctrl+Shift+R)**

## This Will:
✅ Remove ALL mock data
✅ Make REAL JSearch API calls
✅ Use your 'Jsearch' secret key
✅ Return actual job listings

## Test It Works:
After deploying, search for "software engineer" in your app. You should see REAL jobs!
