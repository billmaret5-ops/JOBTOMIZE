# 🔐 Authentication Flow Testing Guide

## ✅ FIXED: Using Service Role Key

### Problem Identified
- **Wrong Key**: Using `anon key` for admin user creation → 401/403 errors
- **Solution**: Use `service_role key` via Edge Function for admin operations

## 🎯 What's Been Fixed

### 1. Edge Function: `user-auth-manager`
**Location**: `supabase/functions/user-auth-manager/index.ts`

**Key Changes**:
- ✅ Uses `SUPABASE_SERVICE_ROLE_KEY` (auto-injected)
- ✅ Implements `auth.admin.createUser()` for proper user creation
- ✅ Auto-confirms email
- ✅ Creates profile automatically

### 2. Frontend Service: `AdminAuthService`
**Location**: `src/services/adminAuthService.ts`

**Methods**:
- `createUser()` - Calls Edge Function with service_role key
- `signIn()` - Client-side with anon key (correct)
- `resetPassword()` - Client-side with anon key (correct)
- `signOut()` - Client-side with anon key (correct)

### 3. Auth Flow Tester Updated
**Location**: `src/components/AuthFlowTester.tsx`

Now uses `AdminAuthService.createUser()` instead of direct `supabase.auth.signUp()`

## 🧪 How to Test

### Access the Tester
1. Navigate to: `/?auth-flow-test`
2. Or use Quick Access Menu → "Auth Flow Test"

### Run Tests
Click **"▶ Run Complete Auth Flow Test"**

### Expected Results
✅ **Signup** - Account created with service_role key
✅ **Session Check** - Session active or no session (depends on flow)
✅ **Logout** - Logged out successfully
✅ **Login** - Logged in with new account
✅ **Password Reset** - Reset email sent

## 🔑 Key Differences

### ❌ WRONG (Old Way)
```typescript
// Client-side with anon key - FAILS for admin operations
const { data, error } = await supabase.auth.signUp({
  email, password
});
```

### ✅ CORRECT (New Way)
```typescript
// Edge Function with service_role key
const { data, error } = await AdminAuthService.createUser({
  email, password, full_name, user_type
});
```

## 📋 Test Checklist

- [ ] Navigate to `/?auth-flow-test`
- [ ] Click "Run Complete Auth Flow Test"
- [ ] Verify Signup shows "✅ Account created with service_role key"
- [ ] Check all tests pass (green checkmarks)
- [ ] Review error details if any test fails

## 🐛 Troubleshooting

### If Signup Fails
1. Check Edge Function is deployed: `user-auth-manager`
2. Verify service_role key is configured in Supabase
3. Check browser console for errors
4. Review test details in the UI

### If Login Fails
- Signup might have failed - check previous test
- Password might be incorrect
- Email confirmation might be required (should be auto-confirmed)

### If Session Check Fails
- Normal if user creation doesn't auto-login
- Try manual login after signup

## 📚 Documentation References

- Edge Function Code: `supabase/functions/user-auth-manager/index.ts`
- Service Code: `src/services/adminAuthService.ts`
- Tester Component: `src/components/AuthFlowTester.tsx`
- Fix Guide: `AUTH-KEY-FIX-GUIDE.md`

## 🎉 Success Criteria

All tests should show green checkmarks:
- ✅ Signup with service_role key
- ✅ Session management
- ✅ Logout functionality
- ✅ Login with credentials
- ✅ Password reset flow

## 🔄 Next Steps

After successful testing:
1. Update all signup forms to use `AdminAuthService`
2. Replace direct `supabase.auth.signUp()` calls
3. Test production deployment
4. Monitor auth errors in production

---

**Note**: The Edge Function automatically has access to `SUPABASE_SERVICE_ROLE_KEY` - no manual configuration needed!
