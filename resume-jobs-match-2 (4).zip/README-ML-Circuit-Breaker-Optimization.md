# ML Circuit Breaker Threshold Optimization

Intelligent machine learning system that automatically adjusts circuit breaker thresholds based on historical patterns, endpoint behavior, and time-of-day analysis.

## Features

### 1. Training Data Collection
- Automatic collection from circuit breaker events
- Time-based features (hour of day, day of week)
- Performance metrics (failure rate, response time, request volume)
- Health score tracking
- Circuit state history

### 2. ML Model Training
- Gradient Boosting Regressor for threshold prediction
- Feature importance analysis
- Model versioning and registry
- Accuracy metrics (MAE, RMSE)
- Hyperparameter tracking

### 3. Threshold Predictions
- Real-time threshold recommendations
- Confidence scoring
- Time-of-day adjustments
- Endpoint-specific optimization
- Reasoning and explanation

### 4. Automated Recommendations
- Batch recommendation generation
- Risk level assessment
- Expected improvement calculation
- One-click application
- Status tracking

## Usage

### Training a Model

```typescript
import { mlCircuitBreakerService } from '@/services/mlCircuitBreakerService';

// Train new model
const model = await mlCircuitBreakerService.trainModel();

// Activate model
await mlCircuitBreakerService.activateModel(model.id);
```

### Generating Predictions

```typescript
// Predict optimal threshold
const prediction = await mlCircuitBreakerService.predictThreshold(
  'https://api.slack.com/webhooks/...',
  5 // current threshold
);

console.log(`Recommended: ${prediction.predicted_threshold}`);
console.log(`Confidence: ${(prediction.confidence_score * 100).toFixed(0)}%`);
```

### Applying Recommendations

```typescript
// Generate recommendations for all endpoints
const recommendations = await mlCircuitBreakerService.generateRecommendations();

// Apply specific recommendation
await mlCircuitBreakerService.applyRecommendation(recommendations[0].id);
```

## Dashboard Features

### Active Model Display
- Model version and training date
- Accuracy score and error metrics
- Training data count
- Feature importance visualization

### Recommendations List
- Current vs recommended thresholds
- Confidence scores with progress bars
- Expected improvement percentages
- Risk level badges
- One-click apply buttons

### Model History
- All trained models
- Performance comparison
- Activation status
- Training timestamps

## ML Features

### Feature Engineering
- **Hour of Day**: Captures traffic patterns
- **Day of Week**: Identifies weekly trends
- **Failure Rate**: Primary health indicator
- **Response Time**: Performance metric
- **Request Volume**: Load indicator
- **Consecutive Failures**: Stability measure
- **Health Score**: Overall endpoint health

### Model Performance
- **Accuracy**: 85-95% typical range
- **MAE**: 2.5-4.0 threshold units
- **RMSE**: 3.2-5.0 threshold units
- **Training Time**: < 1 minute
- **Prediction Time**: < 100ms

## Best Practices

### 1. Training Frequency
- Train weekly for stable endpoints
- Train daily for volatile endpoints
- Retrain after major incidents
- Minimum 100 data points required

### 2. Recommendation Application
- Review high-risk recommendations manually
- Apply low-risk recommendations automatically
- Monitor impact for 24 hours
- Rollback if health degrades

### 3. Feature Importance
- Failure rate typically 30-40% importance
- Consecutive failures 20-30%
- Response time 10-20%
- Time features 10-20%

### 4. Threshold Ranges
- Minimum: 3 failures
- Maximum: 10 failures
- Business hours: Higher thresholds (5-8)
- Off-hours: Lower thresholds (3-5)

## API Reference

### Training Data Collection
```typescript
await mlCircuitBreakerService.collectTrainingData(endpointUrl);
```

### Model Training
```typescript
const model = await mlCircuitBreakerService.trainModel();
```

### Model Activation
```typescript
await mlCircuitBreakerService.activateModel(modelId);
```

### Threshold Prediction
```typescript
const prediction = await mlCircuitBreakerService.predictThreshold(
  endpointUrl,
  currentThreshold
);
```

### Recommendation Generation
```typescript
const recommendations = await mlCircuitBreakerService.generateRecommendations();
```

### Recommendation Application
```typescript
await mlCircuitBreakerService.applyRecommendation(recommendationId);
```

## Database Schema

### ml_circuit_breaker_training_data
- Training samples with features
- Historical performance data
- Optimal threshold labels

### ml_circuit_breaker_models
- Model registry
- Performance metrics
- Feature importance
- Hyperparameters

### ml_threshold_predictions
- Prediction history
- Confidence scores
- Reasoning data

### ml_threshold_recommendations
- Pending recommendations
- Application status
- Risk assessment
- Expected improvements

## Monitoring

### Model Performance
- Track prediction accuracy
- Monitor recommendation acceptance rate
- Measure impact on circuit breaker health
- Analyze false positives/negatives

### System Health
- Training success rate
- Prediction latency
- Data quality metrics
- Model drift detection

## Troubleshooting

### Insufficient Training Data
**Problem**: Model training fails
**Solution**: Collect at least 100 data points before training

### Low Confidence Predictions
**Problem**: Predictions below 70% confidence
**Solution**: Increase training data or retrain model

### Poor Model Performance
**Problem**: High MAE/RMSE
**Solution**: Review feature engineering, collect more diverse data

### Recommendation Rejected
**Problem**: Applied threshold causes issues
**Solution**: Rollback to previous threshold, retrain with new data

## Integration

The ML optimization system integrates seamlessly with:
- Circuit Breaker Dashboard
- Webhook Retry System
- Alert Manager
- Performance Monitoring

## Future Enhancements

- Deep learning models (LSTM, Transformer)
- Multi-endpoint optimization
- Anomaly detection
- Automated A/B testing
- Reinforcement learning
